package android.support.p001a;

import android.os.Bundle;

/* compiled from: CustomTabsCallback */
public class C0001a {
    public void mo1129a(int navigationEvent, Bundle extras) {
    }

    public void mo1130a(String callbackName, Bundle args) {
    }
}
