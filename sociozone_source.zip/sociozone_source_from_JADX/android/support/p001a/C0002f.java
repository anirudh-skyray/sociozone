package android.support.p001a;

import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Parcel;
import android.os.RemoteException;

/* compiled from: ICustomTabsCallback */
public interface C0002f extends IInterface {

    /* compiled from: ICustomTabsCallback */
    public static abstract class C0003a extends Binder implements C0002f {

        /* compiled from: ICustomTabsCallback */
        private static class C0012a implements C0002f {
            private IBinder f14a;

            C0012a(IBinder remote) {
                this.f14a = remote;
            }

            public IBinder asBinder() {
                return this.f14a;
            }

            public void mo1a(int navigationEvent, Bundle extras) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                    _data.writeInt(navigationEvent);
                    if (extras != null) {
                        _data.writeInt(1);
                        extras.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    this.f14a.transact(2, _data, null, 1);
                } finally {
                    _data.recycle();
                }
            }

            public void mo2a(String callbackName, Bundle args) throws RemoteException {
                Parcel _data = Parcel.obtain();
                try {
                    _data.writeInterfaceToken("android.support.customtabs.ICustomTabsCallback");
                    _data.writeString(callbackName);
                    if (args != null) {
                        _data.writeInt(1);
                        args.writeToParcel(_data, 0);
                    } else {
                        _data.writeInt(0);
                    }
                    this.f14a.transact(3, _data, null, 1);
                } finally {
                    _data.recycle();
                }
            }
        }

        public C0003a() {
            attachInterface(this, "android.support.customtabs.ICustomTabsCallback");
        }

        public static C0002f m5a(IBinder obj) {
            if (obj == null) {
                return null;
            }
            IInterface iin = obj.queryLocalInterface("android.support.customtabs.ICustomTabsCallback");
            if (iin == null || !(iin instanceof C0002f)) {
                return new C0012a(obj);
            }
            return (C0002f) iin;
        }

        public IBinder asBinder() {
            return this;
        }

        public boolean onTransact(int code, Parcel data, Parcel reply, int flags) throws RemoteException {
            Bundle _arg1;
            switch (code) {
                case 2:
                    data.enforceInterface("android.support.customtabs.ICustomTabsCallback");
                    int _arg0 = data.readInt();
                    if (data.readInt() != 0) {
                        _arg1 = (Bundle) Bundle.CREATOR.createFromParcel(data);
                    } else {
                        _arg1 = null;
                    }
                    mo1a(_arg0, _arg1);
                    return true;
                case 3:
                    data.enforceInterface("android.support.customtabs.ICustomTabsCallback");
                    String _arg02 = data.readString();
                    if (data.readInt() != 0) {
                        _arg1 = (Bundle) Bundle.CREATOR.createFromParcel(data);
                    } else {
                        _arg1 = null;
                    }
                    mo2a(_arg02, _arg1);
                    return true;
                case 1598968902:
                    reply.writeString("android.support.customtabs.ICustomTabsCallback");
                    return true;
                default:
                    return super.onTransact(code, data, reply, flags);
            }
        }
    }

    void mo1a(int i, Bundle bundle) throws RemoteException;

    void mo2a(String str, Bundle bundle) throws RemoteException;
}
