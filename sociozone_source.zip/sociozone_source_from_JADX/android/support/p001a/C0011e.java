package android.support.p001a;

import android.content.ComponentName;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import java.util.List;

/* compiled from: CustomTabsSession */
public final class C0011e {
    private final C0013g f11a;
    private final C0002f f12b;
    private final ComponentName f13c;

    C0011e(C0013g service, C0002f callback, ComponentName componentName) {
        this.f11a = service;
        this.f12b = callback;
        this.f13c = componentName;
    }

    public boolean m15a(Uri url, Bundle extras, List<Bundle> otherLikelyBundles) {
        try {
            return this.f11a.mo6a(this.f12b, url, extras, otherLikelyBundles);
        } catch (RemoteException e) {
            return false;
        }
    }

    IBinder m14a() {
        return this.f12b.asBinder();
    }

    ComponentName m16b() {
        return this.f13c;
    }
}
