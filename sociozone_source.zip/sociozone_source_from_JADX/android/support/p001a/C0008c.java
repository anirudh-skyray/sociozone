package android.support.p001a;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.app.C0078a;
import android.support.v4.app.C0155l;
import java.util.ArrayList;

/* compiled from: CustomTabsIntent */
public final class C0008c {
    public final Intent f8a;
    public final Bundle f9b;

    /* compiled from: CustomTabsIntent */
    public static final class C0007a {
        private final Intent f4a;
        private ArrayList<Bundle> f5b;
        private Bundle f6c;
        private ArrayList<Bundle> f7d;

        public C0007a() {
            this(null);
        }

        public C0007a(C0011e session) {
            IBinder iBinder = null;
            this.f4a = new Intent("android.intent.action.VIEW");
            this.f5b = null;
            this.f6c = null;
            this.f7d = null;
            if (session != null) {
                this.f4a.setPackage(session.m16b().getPackageName());
            }
            Bundle bundle = new Bundle();
            String str = "android.support.customtabs.extra.SESSION";
            if (session != null) {
                iBinder = session.m14a();
            }
            C0155l.m560a(bundle, str, iBinder);
            this.f4a.putExtras(bundle);
        }

        public C0008c m11a() {
            if (this.f5b != null) {
                this.f4a.putParcelableArrayListExtra("android.support.customtabs.extra.MENU_ITEMS", this.f5b);
            }
            if (this.f7d != null) {
                this.f4a.putParcelableArrayListExtra("android.support.customtabs.extra.TOOLBAR_ITEMS", this.f7d);
            }
            return new C0008c(this.f4a, this.f6c);
        }
    }

    public void m12a(Activity context, Uri url) {
        this.f8a.setData(url);
        C0078a.m253a(context, this.f8a, this.f9b);
    }

    private C0008c(Intent intent, Bundle startAnimationBundle) {
        this.f8a = intent;
        this.f9b = startAnimationBundle;
    }
}
