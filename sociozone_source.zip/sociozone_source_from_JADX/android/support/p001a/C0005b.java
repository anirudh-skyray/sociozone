package android.support.p001a;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.p001a.C0002f.C0003a;
import android.text.TextUtils;

/* compiled from: CustomTabsClient */
public class C0005b {
    private final C0013g f2a;
    private final ComponentName f3b;

    C0005b(C0013g service, ComponentName componentName) {
        this.f2a = service;
        this.f3b = componentName;
    }

    public static boolean m8a(Context context, String packageName, C0010d connection) {
        Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
        if (!TextUtils.isEmpty(packageName)) {
            intent.setPackage(packageName);
        }
        return context.bindService(intent, connection, 33);
    }

    public boolean m10a(long flags) {
        try {
            return this.f2a.mo4a(flags);
        } catch (RemoteException e) {
            return false;
        }
    }

    public C0011e m9a(final C0001a callback) {
        C0002f wrapper = new C0003a(this) {
            final /* synthetic */ C0005b f1b;

            public void mo1a(int navigationEvent, Bundle extras) {
                if (callback != null) {
                    callback.mo1129a(navigationEvent, extras);
                }
            }

            public void mo2a(String callbackName, Bundle args) throws RemoteException {
                if (callback != null) {
                    callback.mo1130a(callbackName, args);
                }
            }
        };
        try {
            if (this.f2a.mo5a(wrapper)) {
                return new C0011e(this.f2a, wrapper, this.f3b);
            }
            return null;
        } catch (RemoteException e) {
            return null;
        }
    }
}
