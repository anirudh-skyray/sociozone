package android.support.p001a;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.support.p001a.C0013g.C0015a;

/* compiled from: CustomTabsServiceConnection */
public abstract class C0010d implements ServiceConnection {
    public abstract void mo1131a(ComponentName componentName, C0005b c0005b);

    public final void onServiceConnected(ComponentName name, IBinder service) {
        mo1131a(name, new C0005b(this, C0015a.m29a(service), name) {
            final /* synthetic */ C0010d f10a;
        });
    }
}
