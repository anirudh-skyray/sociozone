package android.support.v4.p011e;

import java.util.Collection;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/* compiled from: ArrayMap */
public class C0232a<K, V> extends C0231i<K, V> implements Map<K, V> {
    C0229g<K, V> f435a;

    /* compiled from: ArrayMap */
    class C02301 extends C0229g<K, V> {
        final /* synthetic */ C0232a f427a;

        C02301(C0232a c0232a) {
            this.f427a = c0232a;
        }

        protected int mo150a() {
            return this.f427a.h;
        }

        protected Object mo152a(int index, int offset) {
            return this.f427a.g[(index << 1) + offset];
        }

        protected int mo151a(Object key) {
            return this.f427a.m839a(key);
        }

        protected int mo156b(Object value) {
            return this.f427a.m844b(value);
        }

        protected Map<K, V> mo157b() {
            return this.f427a;
        }

        protected void mo155a(K key, V value) {
            this.f427a.put(key, value);
        }

        protected V mo153a(int index, V value) {
            return this.f427a.m841a(index, (Object) value);
        }

        protected void mo154a(int index) {
            this.f427a.m847d(index);
        }

        protected void mo158c() {
            this.f427a.clear();
        }
    }

    public C0232a(int capacity) {
        super(capacity);
    }

    private C0229g<K, V> m848b() {
        if (this.f435a == null) {
            this.f435a = new C02301(this);
        }
        return this.f435a;
    }

    public void putAll(Map<? extends K, ? extends V> map) {
        m842a(this.h + map.size());
        for (Entry<? extends K, ? extends V> entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    public boolean m849a(Collection<?> collection) {
        return C0229g.m812c(this, collection);
    }

    public Set<Entry<K, V>> entrySet() {
        return m848b().m824d();
    }

    public Set<K> keySet() {
        return m848b().m825e();
    }

    public Collection<V> values() {
        return m848b().m826f();
    }
}
