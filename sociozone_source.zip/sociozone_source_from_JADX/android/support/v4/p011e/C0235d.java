package android.support.v4.p011e;

import android.support.v4.app.ag;
import android.util.Log;
import java.io.Writer;

/* compiled from: LogWriter */
public class C0235d extends Writer {
    private final String f439a;
    private StringBuilder f440b = new StringBuilder(ag.FLAG_HIGH_PRIORITY);

    public C0235d(String tag) {
        this.f439a = tag;
    }

    public void close() {
        m857a();
    }

    public void flush() {
        m857a();
    }

    public void write(char[] buf, int offset, int count) {
        for (int i = 0; i < count; i++) {
            char c = buf[offset + i];
            if (c == '\n') {
                m857a();
            } else {
                this.f440b.append(c);
            }
        }
    }

    private void m857a() {
        if (this.f440b.length() > 0) {
            Log.d(this.f439a, this.f440b.toString());
            this.f440b.delete(0, this.f440b.length());
        }
    }
}
