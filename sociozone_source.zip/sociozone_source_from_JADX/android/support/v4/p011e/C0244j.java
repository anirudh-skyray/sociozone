package android.support.v4.p011e;

/* compiled from: SparseArrayCompat */
public class C0244j<E> implements Cloneable {
    private static final Object f460a = new Object();
    private boolean f461b;
    private int[] f462c;
    private Object[] f463d;
    private int f464e;

    public /* synthetic */ Object clone() throws CloneNotSupportedException {
        return m871a();
    }

    public C0244j() {
        this(10);
    }

    public C0244j(int initialCapacity) {
        this.f461b = false;
        if (initialCapacity == 0) {
            this.f462c = C0233b.f436a;
            this.f463d = C0233b.f438c;
        } else {
            initialCapacity = C0233b.m850a(initialCapacity);
            this.f462c = new int[initialCapacity];
            this.f463d = new Object[initialCapacity];
        }
        this.f464e = 0;
    }

    public C0244j<E> m871a() {
        C0244j<E> clone = null;
        try {
            clone = (C0244j) super.clone();
            clone.f462c = (int[]) this.f462c.clone();
            clone.f463d = (Object[]) this.f463d.clone();
            return clone;
        } catch (CloneNotSupportedException e) {
            return clone;
        }
    }

    public E m872a(int key) {
        return m873a(key, null);
    }

    public E m873a(int key, E valueIfKeyNotFound) {
        int i = C0233b.m851a(this.f462c, this.f464e, key);
        return (i < 0 || this.f463d[i] == f460a) ? valueIfKeyNotFound : this.f463d[i];
    }

    public void m875b(int key) {
        int i = C0233b.m851a(this.f462c, this.f464e, key);
        if (i >= 0 && this.f463d[i] != f460a) {
            this.f463d[i] = f460a;
            this.f461b = true;
        }
    }

    public void m878c(int key) {
        m875b(key);
    }

    private void m870d() {
        int n = this.f464e;
        int o = 0;
        int[] keys = this.f462c;
        Object[] values = this.f463d;
        for (int i = 0; i < n; i++) {
            Object val = values[i];
            if (val != f460a) {
                if (i != o) {
                    keys[o] = keys[i];
                    values[o] = val;
                    values[i] = null;
                }
                o++;
            }
        }
        this.f461b = false;
        this.f464e = o;
    }

    public void m876b(int key, E value) {
        int i = C0233b.m851a(this.f462c, this.f464e, key);
        if (i >= 0) {
            this.f463d[i] = value;
            return;
        }
        i ^= -1;
        if (i >= this.f464e || this.f463d[i] != f460a) {
            if (this.f461b && this.f464e >= this.f462c.length) {
                m870d();
                i = C0233b.m851a(this.f462c, this.f464e, key) ^ -1;
            }
            if (this.f464e >= this.f462c.length) {
                int n = C0233b.m850a(this.f464e + 1);
                int[] nkeys = new int[n];
                Object[] nvalues = new Object[n];
                System.arraycopy(this.f462c, 0, nkeys, 0, this.f462c.length);
                System.arraycopy(this.f463d, 0, nvalues, 0, this.f463d.length);
                this.f462c = nkeys;
                this.f463d = nvalues;
            }
            if (this.f464e - i != 0) {
                System.arraycopy(this.f462c, i, this.f462c, i + 1, this.f464e - i);
                System.arraycopy(this.f463d, i, this.f463d, i + 1, this.f464e - i);
            }
            this.f462c[i] = key;
            this.f463d[i] = value;
            this.f464e++;
            return;
        }
        this.f462c[i] = key;
        this.f463d[i] = value;
    }

    public int m874b() {
        if (this.f461b) {
            m870d();
        }
        return this.f464e;
    }

    public int m879d(int index) {
        if (this.f461b) {
            m870d();
        }
        return this.f462c[index];
    }

    public E m880e(int index) {
        if (this.f461b) {
            m870d();
        }
        return this.f463d[index];
    }

    public int m881f(int key) {
        if (this.f461b) {
            m870d();
        }
        return C0233b.m851a(this.f462c, this.f464e, key);
    }

    public void m877c() {
        int n = this.f464e;
        Object[] values = this.f463d;
        for (int i = 0; i < n; i++) {
            values[i] = null;
        }
        this.f464e = 0;
        this.f461b = false;
    }

    public String toString() {
        if (m874b() <= 0) {
            return "{}";
        }
        StringBuilder buffer = new StringBuilder(this.f464e * 28);
        buffer.append('{');
        for (int i = 0; i < this.f464e; i++) {
            if (i > 0) {
                buffer.append(", ");
            }
            buffer.append(m879d(i));
            buffer.append('=');
            C0244j value = m880e(i);
            if (value != this) {
                buffer.append(value);
            } else {
                buffer.append("(this Map)");
            }
        }
        buffer.append('}');
        return buffer.toString();
    }
}
