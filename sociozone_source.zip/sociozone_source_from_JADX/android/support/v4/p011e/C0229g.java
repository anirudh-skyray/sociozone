package android.support.v4.p011e;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

/* compiled from: MapCollections */
abstract class C0229g<K, V> {
    C0239b f424b;
    C0240c f425c;
    C0242e f426d;

    /* compiled from: MapCollections */
    final class C0238a<T> implements Iterator<T> {
        final int f446a;
        int f447b;
        int f448c;
        boolean f449d = false;
        final /* synthetic */ C0229g f450e;

        C0238a(C0229g c0229g, int offset) {
            this.f450e = c0229g;
            this.f446a = offset;
            this.f447b = c0229g.mo150a();
        }

        public boolean hasNext() {
            return this.f448c < this.f447b;
        }

        public T next() {
            Object res = this.f450e.mo152a(this.f448c, this.f446a);
            this.f448c++;
            this.f449d = true;
            return res;
        }

        public void remove() {
            if (this.f449d) {
                this.f448c--;
                this.f447b--;
                this.f449d = false;
                this.f450e.mo154a(this.f448c);
                return;
            }
            throw new IllegalStateException();
        }
    }

    /* compiled from: MapCollections */
    final class C0239b implements Set<Entry<K, V>> {
        final /* synthetic */ C0229g f451a;

        C0239b(C0229g c0229g) {
            this.f451a = c0229g;
        }

        public /* synthetic */ boolean add(Object obj) {
            return m867a((Entry) obj);
        }

        public boolean m867a(Entry<K, V> entry) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends Entry<K, V>> collection) {
            int oldSize = this.f451a.mo150a();
            for (Entry<K, V> entry : collection) {
                this.f451a.mo155a(entry.getKey(), entry.getValue());
            }
            return oldSize != this.f451a.mo150a();
        }

        public void clear() {
            this.f451a.mo158c();
        }

        public boolean contains(Object o) {
            if (!(o instanceof Entry)) {
                return false;
            }
            Entry<?, ?> e = (Entry) o;
            int index = this.f451a.mo151a(e.getKey());
            if (index >= 0) {
                return C0233b.m853a(this.f451a.mo152a(index, 1), e.getValue());
            }
            return false;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return this.f451a.mo150a() == 0;
        }

        public Iterator<Entry<K, V>> iterator() {
            return new C0241d(this.f451a);
        }

        public boolean remove(Object object) {
            throw new UnsupportedOperationException();
        }

        public boolean removeAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public boolean retainAll(Collection<?> collection) {
            throw new UnsupportedOperationException();
        }

        public int size() {
            return this.f451a.mo150a();
        }

        public Object[] toArray() {
            throw new UnsupportedOperationException();
        }

        public <T> T[] toArray(T[] tArr) {
            throw new UnsupportedOperationException();
        }

        public boolean equals(Object object) {
            return C0229g.m810a((Set) this, object);
        }

        public int hashCode() {
            int result = 0;
            for (int i = this.f451a.mo150a() - 1; i >= 0; i--) {
                Object key = this.f451a.mo152a(i, 0);
                Object value = this.f451a.mo152a(i, 1);
                result += (value == null ? 0 : value.hashCode()) ^ (key == null ? 0 : key.hashCode());
            }
            return result;
        }
    }

    /* compiled from: MapCollections */
    final class C0240c implements Set<K> {
        final /* synthetic */ C0229g f452a;

        C0240c(C0229g c0229g) {
            this.f452a = c0229g;
        }

        public boolean add(K k) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends K> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            this.f452a.mo158c();
        }

        public boolean contains(Object object) {
            return this.f452a.mo151a(object) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            return C0229g.m809a(this.f452a.mo157b(), (Collection) collection);
        }

        public boolean isEmpty() {
            return this.f452a.mo150a() == 0;
        }

        public Iterator<K> iterator() {
            return new C0238a(this.f452a, 0);
        }

        public boolean remove(Object object) {
            int index = this.f452a.mo151a(object);
            if (index < 0) {
                return false;
            }
            this.f452a.mo154a(index);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            return C0229g.m811b(this.f452a.mo157b(), collection);
        }

        public boolean retainAll(Collection<?> collection) {
            return C0229g.m812c(this.f452a.mo157b(), collection);
        }

        public int size() {
            return this.f452a.mo150a();
        }

        public Object[] toArray() {
            return this.f452a.m822b(0);
        }

        public <T> T[] toArray(T[] array) {
            return this.f452a.m819a((Object[]) array, 0);
        }

        public boolean equals(Object object) {
            return C0229g.m810a((Set) this, object);
        }

        public int hashCode() {
            int result = 0;
            for (int i = this.f452a.mo150a() - 1; i >= 0; i--) {
                Object obj = this.f452a.mo152a(i, 0);
                result += obj == null ? 0 : obj.hashCode();
            }
            return result;
        }
    }

    /* compiled from: MapCollections */
    final class C0241d implements Iterator<Entry<K, V>>, Entry<K, V> {
        int f453a;
        int f454b;
        boolean f455c = false;
        final /* synthetic */ C0229g f456d;

        public /* synthetic */ Object next() {
            return m868a();
        }

        C0241d(C0229g c0229g) {
            this.f456d = c0229g;
            this.f453a = c0229g.mo150a() - 1;
            this.f454b = -1;
        }

        public boolean hasNext() {
            return this.f454b < this.f453a;
        }

        public Entry<K, V> m868a() {
            this.f454b++;
            this.f455c = true;
            return this;
        }

        public void remove() {
            if (this.f455c) {
                this.f456d.mo154a(this.f454b);
                this.f454b--;
                this.f453a--;
                this.f455c = false;
                return;
            }
            throw new IllegalStateException();
        }

        public K getKey() {
            if (this.f455c) {
                return this.f456d.mo152a(this.f454b, 0);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V getValue() {
            if (this.f455c) {
                return this.f456d.mo152a(this.f454b, 1);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public V setValue(V object) {
            if (this.f455c) {
                return this.f456d.mo153a(this.f454b, (Object) object);
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final boolean equals(Object o) {
            boolean z = true;
            if (!this.f455c) {
                throw new IllegalStateException("This container does not support retaining Map.Entry objects");
            } else if (!(o instanceof Entry)) {
                return false;
            } else {
                Entry<?, ?> e = (Entry) o;
                if (!(C0233b.m853a(e.getKey(), this.f456d.mo152a(this.f454b, 0)) && C0233b.m853a(e.getValue(), this.f456d.mo152a(this.f454b, 1)))) {
                    z = false;
                }
                return z;
            }
        }

        public final int hashCode() {
            int i = 0;
            if (this.f455c) {
                Object key = this.f456d.mo152a(this.f454b, 0);
                Object value = this.f456d.mo152a(this.f454b, 1);
                int hashCode = key == null ? 0 : key.hashCode();
                if (value != null) {
                    i = value.hashCode();
                }
                return i ^ hashCode;
            }
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }

        public final String toString() {
            return getKey() + "=" + getValue();
        }
    }

    /* compiled from: MapCollections */
    final class C0242e implements Collection<V> {
        final /* synthetic */ C0229g f457a;

        C0242e(C0229g c0229g) {
            this.f457a = c0229g;
        }

        public boolean add(V v) {
            throw new UnsupportedOperationException();
        }

        public boolean addAll(Collection<? extends V> collection) {
            throw new UnsupportedOperationException();
        }

        public void clear() {
            this.f457a.mo158c();
        }

        public boolean contains(Object object) {
            return this.f457a.mo156b(object) >= 0;
        }

        public boolean containsAll(Collection<?> collection) {
            for (Object contains : collection) {
                if (!contains(contains)) {
                    return false;
                }
            }
            return true;
        }

        public boolean isEmpty() {
            return this.f457a.mo150a() == 0;
        }

        public Iterator<V> iterator() {
            return new C0238a(this.f457a, 1);
        }

        public boolean remove(Object object) {
            int index = this.f457a.mo156b(object);
            if (index < 0) {
                return false;
            }
            this.f457a.mo154a(index);
            return true;
        }

        public boolean removeAll(Collection<?> collection) {
            int N = this.f457a.mo150a();
            boolean changed = false;
            int i = 0;
            while (i < N) {
                if (collection.contains(this.f457a.mo152a(i, 1))) {
                    this.f457a.mo154a(i);
                    i--;
                    N--;
                    changed = true;
                }
                i++;
            }
            return changed;
        }

        public boolean retainAll(Collection<?> collection) {
            int N = this.f457a.mo150a();
            boolean changed = false;
            int i = 0;
            while (i < N) {
                if (!collection.contains(this.f457a.mo152a(i, 1))) {
                    this.f457a.mo154a(i);
                    i--;
                    N--;
                    changed = true;
                }
                i++;
            }
            return changed;
        }

        public int size() {
            return this.f457a.mo150a();
        }

        public Object[] toArray() {
            return this.f457a.m822b(1);
        }

        public <T> T[] toArray(T[] array) {
            return this.f457a.m819a((Object[]) array, 1);
        }
    }

    protected abstract int mo150a();

    protected abstract int mo151a(Object obj);

    protected abstract Object mo152a(int i, int i2);

    protected abstract V mo153a(int i, V v);

    protected abstract void mo154a(int i);

    protected abstract void mo155a(K k, V v);

    protected abstract int mo156b(Object obj);

    protected abstract Map<K, V> mo157b();

    protected abstract void mo158c();

    C0229g() {
    }

    public static <K, V> boolean m809a(Map<K, V> map, Collection<?> collection) {
        for (Object containsKey : collection) {
            if (!map.containsKey(containsKey)) {
                return false;
            }
        }
        return true;
    }

    public static <K, V> boolean m811b(Map<K, V> map, Collection<?> collection) {
        int oldSize = map.size();
        for (Object remove : collection) {
            map.remove(remove);
        }
        return oldSize != map.size();
    }

    public static <K, V> boolean m812c(Map<K, V> map, Collection<?> collection) {
        int oldSize = map.size();
        Iterator<K> it = map.keySet().iterator();
        while (it.hasNext()) {
            if (!collection.contains(it.next())) {
                it.remove();
            }
        }
        return oldSize != map.size();
    }

    public Object[] m822b(int offset) {
        int N = mo150a();
        Object[] result = new Object[N];
        for (int i = 0; i < N; i++) {
            result[i] = mo152a(i, offset);
        }
        return result;
    }

    public <T> T[] m819a(T[] array, int offset) {
        int N = mo150a();
        if (array.length < N) {
            array = (Object[]) ((Object[]) Array.newInstance(array.getClass().getComponentType(), N));
        }
        for (int i = 0; i < N; i++) {
            array[i] = mo152a(i, offset);
        }
        if (array.length > N) {
            array[N] = null;
        }
        return array;
    }

    public static <T> boolean m810a(Set<T> set, Object object) {
        boolean z = true;
        if (set == object) {
            return true;
        }
        if (!(object instanceof Set)) {
            return false;
        }
        Set<?> s = (Set) object;
        try {
            if (!(set.size() == s.size() && set.containsAll(s))) {
                z = false;
            }
            return z;
        } catch (NullPointerException e) {
            return false;
        } catch (ClassCastException e2) {
            return false;
        }
    }

    public Set<Entry<K, V>> m824d() {
        if (this.f424b == null) {
            this.f424b = new C0239b(this);
        }
        return this.f424b;
    }

    public Set<K> m825e() {
        if (this.f425c == null) {
            this.f425c = new C0240c(this);
        }
        return this.f425c;
    }

    public Collection<V> m826f() {
        if (this.f426d == null) {
            this.f426d = new C0242e(this);
        }
        return this.f426d;
    }
}
