package android.support.v4.view;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.C0348b.C0263a;
import android.support.v4.view.C0363c.C0268a;
import android.support.v4.view.p012a.C0286b;
import android.support.v4.view.p012a.C0299g;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

/* compiled from: AccessibilityDelegateCompat */
public class C0256a {
    private static final C0265b f484b;
    private static final Object f485c = f484b.mo173a();
    final Object f486a = f484b.mo174a(this);

    /* compiled from: AccessibilityDelegateCompat */
    interface C0265b {
        C0299g mo172a(Object obj, View view);

        Object mo173a();

        Object mo174a(C0256a c0256a);

        void mo175a(Object obj, View view, int i);

        void mo176a(Object obj, View view, C0286b c0286b);

        boolean mo177a(Object obj, View view, int i, Bundle bundle);

        boolean mo178a(Object obj, View view, AccessibilityEvent accessibilityEvent);

        boolean mo179a(Object obj, ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

        void mo180b(Object obj, View view, AccessibilityEvent accessibilityEvent);

        void mo181c(Object obj, View view, AccessibilityEvent accessibilityEvent);

        void mo182d(Object obj, View view, AccessibilityEvent accessibilityEvent);
    }

    /* compiled from: AccessibilityDelegateCompat */
    static class C0266d implements C0265b {
        C0266d() {
        }

        public Object mo173a() {
            return null;
        }

        public Object mo174a(C0256a listener) {
            return null;
        }

        public boolean mo178a(Object delegate, View host, AccessibilityEvent event) {
            return false;
        }

        public void mo180b(Object delegate, View host, AccessibilityEvent event) {
        }

        public void mo176a(Object delegate, View host, C0286b info) {
        }

        public void mo181c(Object delegate, View host, AccessibilityEvent event) {
        }

        public boolean mo179a(Object delegate, ViewGroup host, View child, AccessibilityEvent event) {
            return true;
        }

        public void mo175a(Object delegate, View host, int eventType) {
        }

        public void mo182d(Object delegate, View host, AccessibilityEvent event) {
        }

        public C0299g mo172a(Object delegate, View host) {
            return null;
        }

        public boolean mo177a(Object delegate, View host, int action, Bundle args) {
            return false;
        }
    }

    /* compiled from: AccessibilityDelegateCompat */
    static class C0267a extends C0266d {
        C0267a() {
        }

        public Object mo173a() {
            return C0348b.m1648a();
        }

        public Object mo174a(final C0256a compat) {
            return C0348b.m1649a(new C0263a(this) {
                final /* synthetic */ C0267a f539b;

                public boolean mo167a(View host, AccessibilityEvent event) {
                    return compat.mo355b(host, event);
                }

                public void mo169b(View host, AccessibilityEvent event) {
                    compat.mo164d(host, event);
                }

                public void mo166a(View host, Object info) {
                    compat.mo162a(host, new C0286b(info));
                }

                public void mo170c(View host, AccessibilityEvent event) {
                    compat.m898c(host, event);
                }

                public boolean mo168a(ViewGroup host, View child, AccessibilityEvent event) {
                    return compat.mo354a(host, child, event);
                }

                public void mo165a(View host, int eventType) {
                    compat.m892a(host, eventType);
                }

                public void mo171d(View host, AccessibilityEvent event) {
                    compat.m894a(host, event);
                }
            });
        }

        public boolean mo178a(Object delegate, View host, AccessibilityEvent event) {
            return C0348b.m1652a(delegate, host, event);
        }

        public void mo180b(Object delegate, View host, AccessibilityEvent event) {
            C0348b.m1654b(delegate, host, event);
        }

        public void mo176a(Object delegate, View host, C0286b info) {
            C0348b.m1651a(delegate, host, info.m1151a());
        }

        public void mo181c(Object delegate, View host, AccessibilityEvent event) {
            C0348b.m1655c(delegate, host, event);
        }

        public boolean mo179a(Object delegate, ViewGroup host, View child, AccessibilityEvent event) {
            return C0348b.m1653a(delegate, host, child, event);
        }

        public void mo175a(Object delegate, View host, int eventType) {
            C0348b.m1650a(delegate, host, eventType);
        }

        public void mo182d(Object delegate, View host, AccessibilityEvent event) {
            C0348b.m1656d(delegate, host, event);
        }
    }

    /* compiled from: AccessibilityDelegateCompat */
    static class C0270c extends C0267a {
        C0270c() {
        }

        public Object mo174a(final C0256a compat) {
            return C0363c.m1739a(new C0268a(this) {
                final /* synthetic */ C0270c f541b;

                public boolean mo187a(View host, AccessibilityEvent event) {
                    return compat.mo355b(host, event);
                }

                public void mo189b(View host, AccessibilityEvent event) {
                    compat.mo164d(host, event);
                }

                public void mo185a(View host, Object info) {
                    compat.mo162a(host, new C0286b(info));
                }

                public void mo190c(View host, AccessibilityEvent event) {
                    compat.m898c(host, event);
                }

                public boolean mo188a(ViewGroup host, View child, AccessibilityEvent event) {
                    return compat.mo354a(host, child, event);
                }

                public void mo184a(View host, int eventType) {
                    compat.m892a(host, eventType);
                }

                public void mo191d(View host, AccessibilityEvent event) {
                    compat.m894a(host, event);
                }

                public Object mo183a(View host) {
                    C0299g provider = compat.m890a(host);
                    return provider != null ? provider.m1253a() : null;
                }

                public boolean mo186a(View host, int action, Bundle args) {
                    return compat.mo163a(host, action, args);
                }
            });
        }

        public C0299g mo172a(Object delegate, View host) {
            Object provider = C0363c.m1740a(delegate, host);
            if (provider != null) {
                return new C0299g(provider);
            }
            return null;
        }

        public boolean mo177a(Object delegate, View host, int action, Bundle args) {
            return C0363c.m1741a(delegate, host, action, args);
        }
    }

    static {
        if (VERSION.SDK_INT >= 16) {
            f484b = new C0270c();
        } else if (VERSION.SDK_INT >= 14) {
            f484b = new C0267a();
        } else {
            f484b = new C0266d();
        }
    }

    Object m891a() {
        return this.f486a;
    }

    public void m892a(View host, int eventType) {
        f484b.mo175a(f485c, host, eventType);
    }

    public void m894a(View host, AccessibilityEvent event) {
        f484b.mo182d(f485c, host, event);
    }

    public boolean mo355b(View host, AccessibilityEvent event) {
        return f484b.mo178a(f485c, host, event);
    }

    public void m898c(View host, AccessibilityEvent event) {
        f484b.mo181c(f485c, host, event);
    }

    public void mo164d(View host, AccessibilityEvent event) {
        f484b.mo180b(f485c, host, event);
    }

    public void mo162a(View host, C0286b info) {
        f484b.mo176a(f485c, host, info);
    }

    public boolean mo354a(ViewGroup host, View child, AccessibilityEvent event) {
        return f484b.mo179a(f485c, host, child, event);
    }

    public C0299g m890a(View host) {
        return f484b.mo172a(f485c, host);
    }

    public boolean mo163a(View host, int action, Bundle args) {
        return f484b.mo177a(f485c, host, action, args);
    }
}
