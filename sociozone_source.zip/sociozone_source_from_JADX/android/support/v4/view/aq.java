package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatJellybeanMr1 */
class aq {
    public static int m1582a(View view) {
        return view.getLayoutDirection();
    }

    public static int m1583b(View view) {
        return view.getWindowSystemUiVisibility();
    }
}
