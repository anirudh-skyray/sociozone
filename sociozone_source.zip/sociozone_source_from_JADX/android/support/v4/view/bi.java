package android.support.v4.view;

/* compiled from: WindowInsetsCompat */
public class bi {
    bi() {
    }

    public int mo326a() {
        return 0;
    }

    public int mo328b() {
        return 0;
    }

    public int mo329c() {
        return 0;
    }

    public int mo330d() {
        return 0;
    }

    public boolean mo331e() {
        return false;
    }

    public bi mo327a(int left, int top, int right, int bottom) {
        return this;
    }
}
