package android.support.v4.view;

import android.animation.ValueAnimator;
import android.graphics.Paint;
import android.view.View;
import android.view.ViewParent;

/* compiled from: ViewCompatHC */
class am {
    static long m1552a() {
        return ValueAnimator.getFrameDelay();
    }

    public static void m1555a(View view, int layerType, Paint paint) {
        view.setLayerType(layerType, paint);
    }

    public static int m1551a(View view) {
        return view.getLayerType();
    }

    public static int m1550a(int size, int measureSpec, int childMeasuredState) {
        return View.resolveSizeAndState(size, measureSpec, childMeasuredState);
    }

    public static int m1557b(View view) {
        return view.getMeasuredWidthAndState();
    }

    public static int m1561c(View view) {
        return view.getMeasuredState();
    }

    public static float m1563d(View view) {
        return view.getTranslationY();
    }

    public static float m1565e(View view) {
        return view.getScaleX();
    }

    public static void m1553a(View view, float value) {
        view.setTranslationY(value);
    }

    public static void m1558b(View view, float value) {
        view.setAlpha(value);
    }

    public static void m1562c(View view, float value) {
        view.setScaleX(value);
    }

    public static void m1564d(View view, float value) {
        view.setScaleY(value);
    }

    public static void m1566f(View view) {
        view.jumpDrawablesToCurrentState();
    }

    public static void m1556a(View view, boolean enabled) {
        view.setSaveFromParentEnabled(enabled);
    }

    public static void m1560b(View view, boolean activated) {
        view.setActivated(activated);
    }

    static void m1554a(View view, int offset) {
        view.offsetTopAndBottom(offset);
        m1567g(view);
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            m1567g((View) parent);
        }
    }

    static void m1559b(View view, int offset) {
        view.offsetLeftAndRight(offset);
        m1567g(view);
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            m1567g((View) parent);
        }
    }

    private static void m1567g(View view) {
        float y = view.getTranslationY();
        view.setTranslationY(1.0f + y);
        view.setTranslationY(y);
    }
}
