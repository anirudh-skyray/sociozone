package android.support.v4.view;

import android.view.KeyEvent;

/* compiled from: KeyEventCompatEclair */
class C0377h {
    public static void m1762a(KeyEvent event) {
        event.startTracking();
    }
}
