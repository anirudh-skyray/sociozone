package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.view.View;
import android.view.ViewParent;
import java.lang.reflect.Field;

/* compiled from: ViewCompatBase */
class aj {
    private static Field f586a;
    private static boolean f587b;

    static ColorStateList m1539a(View view) {
        return view instanceof af ? ((af) view).getSupportBackgroundTintList() : null;
    }

    static void m1541a(View view, ColorStateList tintList) {
        if (view instanceof af) {
            ((af) view).setSupportBackgroundTintList(tintList);
        }
    }

    static Mode m1543b(View view) {
        return view instanceof af ? ((af) view).getSupportBackgroundTintMode() : null;
    }

    static void m1542a(View view, Mode mode) {
        if (view instanceof af) {
            ((af) view).setSupportBackgroundTintMode(mode);
        }
    }

    static boolean m1545c(View view) {
        return view.getWidth() > 0 && view.getHeight() > 0;
    }

    static int m1546d(View view) {
        if (!f587b) {
            try {
                f586a = View.class.getDeclaredField("mMinHeight");
                f586a.setAccessible(true);
            } catch (NoSuchFieldException e) {
            }
            f587b = true;
        }
        if (f586a != null) {
            try {
                return ((Integer) f586a.get(view)).intValue();
            } catch (Exception e2) {
            }
        }
        return 0;
    }

    static boolean m1547e(View view) {
        return view.getWindowToken() != null;
    }

    static void m1540a(View view, int offset) {
        int currentTop = view.getTop();
        view.offsetTopAndBottom(offset);
        if (offset != 0) {
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                int absOffset = Math.abs(offset);
                ((View) parent).invalidate(view.getLeft(), currentTop - absOffset, view.getRight(), (view.getHeight() + currentTop) + absOffset);
                return;
            }
            view.invalidate();
        }
    }

    static void m1544b(View view, int offset) {
        int currentLeft = view.getLeft();
        view.offsetLeftAndRight(offset);
        if (offset != 0) {
            ViewParent parent = view.getParent();
            if (parent instanceof View) {
                int absOffset = Math.abs(offset);
                ((View) parent).invalidate(currentLeft - absOffset, view.getTop(), (view.getWidth() + currentLeft) + absOffset, view.getBottom());
                return;
            }
            view.invalidate();
        }
    }
}
