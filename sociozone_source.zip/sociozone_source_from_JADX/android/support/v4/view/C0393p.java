package android.support.v4.view;

import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: MarginLayoutParamsCompatJellybeanMr1 */
class C0393p {
    public static int m1787a(MarginLayoutParams lp) {
        return lp.getMarginStart();
    }

    public static int m1788b(MarginLayoutParams lp) {
        return lp.getMarginEnd();
    }
}
