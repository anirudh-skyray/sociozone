package android.support.v4.view;

import android.view.MenuItem;

/* compiled from: MenuItemCompatIcs */
class C0402t {
    public static boolean m1820a(MenuItem item) {
        return item.expandActionView();
    }

    public static boolean m1821b(MenuItem item) {
        return item.isActionViewExpanded();
    }
}
