package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatMarshmallow */
class at {
    public static void m1602a(View view, int indicators, int mask) {
        view.setScrollIndicators(indicators, mask);
    }

    static void m1601a(View view, int offset) {
        view.offsetTopAndBottom(offset);
    }

    static void m1603b(View view, int offset) {
        view.offsetLeftAndRight(offset);
    }
}
