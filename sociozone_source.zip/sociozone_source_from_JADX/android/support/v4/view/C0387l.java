package android.support.v4.view;

import android.content.Context;
import android.support.v4.view.C0385k.C0384a;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.LayoutInflater.Factory2;
import android.view.View;
import java.lang.reflect.Field;

/* compiled from: LayoutInflaterCompatHC */
class C0387l {
    private static Field f622a;
    private static boolean f623b;

    /* compiled from: LayoutInflaterCompatHC */
    static class C0386a extends C0384a implements Factory2 {
        C0386a(C0175n delegateFactory) {
            super(delegateFactory);
        }

        public View onCreateView(View parent, String name, Context context, AttributeSet attributeSet) {
            return this.a.onCreateView(parent, name, context, attributeSet);
        }
    }

    static void m1776a(LayoutInflater inflater, C0175n factory) {
        Factory2 factory2 = factory != null ? new C0386a(factory) : null;
        inflater.setFactory2(factory2);
        Factory f = inflater.getFactory();
        if (f instanceof Factory2) {
            C0387l.m1777a(inflater, (Factory2) f);
        } else {
            C0387l.m1777a(inflater, factory2);
        }
    }

    static void m1777a(LayoutInflater inflater, Factory2 factory) {
        if (!f623b) {
            try {
                f622a = LayoutInflater.class.getDeclaredField("mFactory2");
                f622a.setAccessible(true);
            } catch (NoSuchFieldException e) {
                Log.e("LayoutInflaterCompatHC", "forceSetFactory2 Could not find field 'mFactory2' on class " + LayoutInflater.class.getName() + "; inflation may have unexpected results.", e);
            }
            f623b = true;
        }
        if (f622a != null) {
            try {
                f622a.set(inflater, factory);
            } catch (IllegalAccessException e2) {
                Log.e("LayoutInflaterCompatHC", "forceSetFactory2 could not set the Factory2 on LayoutInflater " + inflater + "; inflation may have unexpected results.", e2);
            }
        }
    }
}
