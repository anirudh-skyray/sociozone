package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewConfiguration;

/* compiled from: ViewConfigurationCompat */
public final class au {
    static final C0329e f591a;

    /* compiled from: ViewConfigurationCompat */
    interface C0329e {
        int mo302a(ViewConfiguration viewConfiguration);

        boolean mo303b(ViewConfiguration viewConfiguration);
    }

    /* compiled from: ViewConfigurationCompat */
    static class C0330a implements C0329e {
        C0330a() {
        }

        public int mo302a(ViewConfiguration config) {
            return config.getScaledTouchSlop();
        }

        public boolean mo303b(ViewConfiguration config) {
            return true;
        }
    }

    /* compiled from: ViewConfigurationCompat */
    static class C0331b extends C0330a {
        C0331b() {
        }

        public int mo302a(ViewConfiguration config) {
            return av.m1613a(config);
        }
    }

    /* compiled from: ViewConfigurationCompat */
    static class C0332c extends C0331b {
        C0332c() {
        }

        public boolean mo303b(ViewConfiguration config) {
            return false;
        }
    }

    /* compiled from: ViewConfigurationCompat */
    static class C0333d extends C0332c {
        C0333d() {
        }

        public boolean mo303b(ViewConfiguration config) {
            return aw.m1614a(config);
        }
    }

    static {
        if (VERSION.SDK_INT >= 14) {
            f591a = new C0333d();
        } else if (VERSION.SDK_INT >= 11) {
            f591a = new C0332c();
        } else if (VERSION.SDK_INT >= 8) {
            f591a = new C0331b();
        } else {
            f591a = new C0330a();
        }
    }

    public static int m1611a(ViewConfiguration config) {
        return f591a.mo302a(config);
    }

    public static boolean m1612b(ViewConfiguration config) {
        return f591a.mo303b(config);
    }
}
