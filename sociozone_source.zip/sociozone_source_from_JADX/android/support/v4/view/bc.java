package android.support.v4.view;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.animation.Interpolator;

/* compiled from: ViewPropertyAnimatorCompatICS */
class bc {
    public static void m1717a(View view, long value) {
        view.animate().setDuration(value);
    }

    public static void m1716a(View view, float value) {
        view.animate().alpha(value);
    }

    public static void m1721b(View view, float value) {
        view.animate().translationY(value);
    }

    public static long m1715a(View view) {
        return view.animate().getDuration();
    }

    public static void m1719a(View view, Interpolator value) {
        view.animate().setInterpolator(value);
    }

    public static void m1722b(View view, long value) {
        view.animate().setStartDelay(value);
    }

    public static void m1720b(View view) {
        view.animate().cancel();
    }

    public static void m1723c(View view) {
        view.animate().start();
    }

    public static void m1718a(final View view, final bf listener) {
        if (listener != null) {
            view.animate().setListener(new AnimatorListenerAdapter() {
                public void onAnimationCancel(Animator animation) {
                    listener.onAnimationCancel(view);
                }

                public void onAnimationEnd(Animator animation) {
                    listener.onAnimationEnd(view);
                }

                public void onAnimationStart(Animator animation) {
                    listener.onAnimationStart(view);
                }
            });
        } else {
            view.animate().setListener(null);
        }
    }
}
