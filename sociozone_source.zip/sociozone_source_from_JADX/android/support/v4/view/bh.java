package android.support.v4.view;

import android.view.View;

/* compiled from: ViewPropertyAnimatorUpdateListener */
public interface bh {
    void onAnimationUpdate(View view);
}
