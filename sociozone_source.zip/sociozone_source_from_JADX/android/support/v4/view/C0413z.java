package android.support.v4.view;

import android.view.View;
import android.view.ViewParent;

/* compiled from: NestedScrollingChildHelper */
public class C0413z {
    private final View f627a;
    private ViewParent f628b;
    private boolean f629c;
    private int[] f630d;

    public C0413z(View view) {
        this.f627a = view;
    }

    public void m1859a(boolean enabled) {
        if (this.f629c) {
            ai.m1535v(this.f627a);
        }
        this.f629c = enabled;
    }

    public boolean m1860a() {
        return this.f629c;
    }

    public boolean m1866b() {
        return this.f628b != null;
    }

    public boolean m1863a(int axes) {
        if (m1866b()) {
            return true;
        }
        if (m1860a()) {
            View child = this.f627a;
            for (ViewParent p = this.f627a.getParent(); p != null; p = p.getParent()) {
                if (az.m1646a(p, child, this.f627a, axes)) {
                    this.f628b = p;
                    az.m1647b(p, child, this.f627a, axes);
                    return true;
                }
                if (p instanceof View) {
                    child = (View) p;
                }
            }
        }
        return false;
    }

    public void m1867c() {
        if (this.f628b != null) {
            az.m1641a(this.f628b, this.f627a);
            this.f628b = null;
        }
    }

    public boolean m1864a(int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed, int[] offsetInWindow) {
        if (m1860a() && this.f628b != null) {
            if (dxConsumed != 0 || dyConsumed != 0 || dxUnconsumed != 0 || dyUnconsumed != 0) {
                int startX = 0;
                int startY = 0;
                if (offsetInWindow != null) {
                    this.f627a.getLocationInWindow(offsetInWindow);
                    startX = offsetInWindow[0];
                    startY = offsetInWindow[1];
                }
                az.m1642a(this.f628b, this.f627a, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
                if (offsetInWindow != null) {
                    this.f627a.getLocationInWindow(offsetInWindow);
                    offsetInWindow[0] = offsetInWindow[0] - startX;
                    offsetInWindow[1] = offsetInWindow[1] - startY;
                }
                return true;
            } else if (offsetInWindow != null) {
                offsetInWindow[0] = 0;
                offsetInWindow[1] = 0;
            }
        }
        return false;
    }

    public boolean m1865a(int dx, int dy, int[] consumed, int[] offsetInWindow) {
        if (!m1860a() || this.f628b == null) {
            return false;
        }
        if (dx != 0 || dy != 0) {
            int startX = 0;
            int startY = 0;
            if (offsetInWindow != null) {
                this.f627a.getLocationInWindow(offsetInWindow);
                startX = offsetInWindow[0];
                startY = offsetInWindow[1];
            }
            if (consumed == null) {
                if (this.f630d == null) {
                    this.f630d = new int[2];
                }
                consumed = this.f630d;
            }
            consumed[0] = 0;
            consumed[1] = 0;
            az.m1643a(this.f628b, this.f627a, dx, dy, consumed);
            if (offsetInWindow != null) {
                this.f627a.getLocationInWindow(offsetInWindow);
                offsetInWindow[0] = offsetInWindow[0] - startX;
                offsetInWindow[1] = offsetInWindow[1] - startY;
            }
            if (consumed[0] == 0 && consumed[1] == 0) {
                return false;
            }
            return true;
        } else if (offsetInWindow == null) {
            return false;
        } else {
            offsetInWindow[0] = 0;
            offsetInWindow[1] = 0;
            return false;
        }
    }

    public boolean m1862a(float velocityX, float velocityY, boolean consumed) {
        if (!m1860a() || this.f628b == null) {
            return false;
        }
        return az.m1645a(this.f628b, this.f627a, velocityX, velocityY, consumed);
    }

    public boolean m1861a(float velocityX, float velocityY) {
        if (!m1860a() || this.f628b == null) {
            return false;
        }
        return az.m1644a(this.f628b, this.f627a, velocityX, velocityY);
    }
}
