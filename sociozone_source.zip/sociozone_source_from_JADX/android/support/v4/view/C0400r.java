package android.support.v4.view;

import android.os.Build.VERSION;
import android.support.v4.p006b.p007a.C0188b;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

/* compiled from: MenuItemCompat */
public final class C0400r {
    static final C0395d f625a;

    /* compiled from: MenuItemCompat */
    interface C0395d {
        MenuItem mo341a(MenuItem menuItem, View view);

        View mo342a(MenuItem menuItem);

        void mo343a(MenuItem menuItem, int i);

        MenuItem mo344b(MenuItem menuItem, int i);

        boolean mo345b(MenuItem menuItem);

        boolean mo346c(MenuItem menuItem);
    }

    /* compiled from: MenuItemCompat */
    static class C0396a implements C0395d {
        C0396a() {
        }

        public void mo343a(MenuItem item, int actionEnum) {
        }

        public MenuItem mo341a(MenuItem item, View view) {
            return item;
        }

        public MenuItem mo344b(MenuItem item, int resId) {
            return item;
        }

        public View mo342a(MenuItem item) {
            return null;
        }

        public boolean mo345b(MenuItem item) {
            return false;
        }

        public boolean mo346c(MenuItem item) {
            return false;
        }
    }

    /* compiled from: MenuItemCompat */
    static class C0397b implements C0395d {
        C0397b() {
        }

        public void mo343a(MenuItem item, int actionEnum) {
            C0401s.m1818a(item, actionEnum);
        }

        public MenuItem mo341a(MenuItem item, View view) {
            return C0401s.m1816a(item, view);
        }

        public MenuItem mo344b(MenuItem item, int resId) {
            return C0401s.m1819b(item, resId);
        }

        public View mo342a(MenuItem item) {
            return C0401s.m1817a(item);
        }

        public boolean mo345b(MenuItem item) {
            return false;
        }

        public boolean mo346c(MenuItem item) {
            return false;
        }
    }

    /* compiled from: MenuItemCompat */
    static class C0398c extends C0397b {
        C0398c() {
        }

        public boolean mo345b(MenuItem item) {
            return C0402t.m1820a(item);
        }

        public boolean mo346c(MenuItem item) {
            return C0402t.m1821b(item);
        }
    }

    /* compiled from: MenuItemCompat */
    public interface C0399e {
        boolean onMenuItemActionCollapse(MenuItem menuItem);

        boolean onMenuItemActionExpand(MenuItem menuItem);
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 14) {
            f625a = new C0398c();
        } else if (version >= 11) {
            f625a = new C0397b();
        } else {
            f625a = new C0396a();
        }
    }

    public static void m1812a(MenuItem item, int actionEnum) {
        if (item instanceof C0188b) {
            ((C0188b) item).setShowAsAction(actionEnum);
        } else {
            f625a.mo343a(item, actionEnum);
        }
    }

    public static MenuItem m1810a(MenuItem item, View view) {
        if (item instanceof C0188b) {
            return ((C0188b) item).setActionView(view);
        }
        return f625a.mo341a(item, view);
    }

    public static MenuItem m1813b(MenuItem item, int resId) {
        if (item instanceof C0188b) {
            return ((C0188b) item).setActionView(resId);
        }
        return f625a.mo344b(item, resId);
    }

    public static View m1811a(MenuItem item) {
        if (item instanceof C0188b) {
            return ((C0188b) item).getActionView();
        }
        return f625a.mo342a(item);
    }

    public static MenuItem m1809a(MenuItem item, C0366d provider) {
        if (item instanceof C0188b) {
            return ((C0188b) item).setSupportActionProvider(provider);
        }
        Log.w("MenuItemCompat", "setActionProvider: item does not implement SupportMenuItem; ignoring");
        return item;
    }

    public static boolean m1814b(MenuItem item) {
        if (item instanceof C0188b) {
            return ((C0188b) item).expandActionView();
        }
        return f625a.mo345b(item);
    }

    public static boolean m1815c(MenuItem item) {
        if (item instanceof C0188b) {
            return ((C0188b) item).isActionViewExpanded();
        }
        return f625a.mo346c(item);
    }
}
