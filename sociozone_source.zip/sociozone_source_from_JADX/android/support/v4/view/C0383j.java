package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.LayoutInflater;

/* compiled from: LayoutInflaterCompat */
public final class C0383j {
    static final C0379a f620a;

    /* compiled from: LayoutInflaterCompat */
    interface C0379a {
        C0175n mo337a(LayoutInflater layoutInflater);

        void mo338a(LayoutInflater layoutInflater, C0175n c0175n);
    }

    /* compiled from: LayoutInflaterCompat */
    static class C0380b implements C0379a {
        C0380b() {
        }

        public void mo338a(LayoutInflater layoutInflater, C0175n factory) {
            C0385k.m1775a(layoutInflater, factory);
        }

        public C0175n mo337a(LayoutInflater layoutInflater) {
            return C0385k.m1774a(layoutInflater);
        }
    }

    /* compiled from: LayoutInflaterCompat */
    static class C0381c extends C0380b {
        C0381c() {
        }

        public void mo338a(LayoutInflater layoutInflater, C0175n factory) {
            C0387l.m1776a(layoutInflater, factory);
        }
    }

    /* compiled from: LayoutInflaterCompat */
    static class C0382d extends C0381c {
        C0382d() {
        }

        public void mo338a(LayoutInflater layoutInflater, C0175n factory) {
            C0388m.m1778a(layoutInflater, factory);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f620a = new C0382d();
        } else if (version >= 11) {
            f620a = new C0381c();
        } else {
            f620a = new C0380b();
        }
    }

    public static void m1773a(LayoutInflater inflater, C0175n factory) {
        f620a.mo338a(inflater, factory);
    }

    public static C0175n m1772a(LayoutInflater inflater) {
        return f620a.mo337a(inflater);
    }
}
