package android.support.v4.view;

import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityDelegateCompatIcs */
class C0348b {

    /* compiled from: AccessibilityDelegateCompatIcs */
    public interface C0263a {
        void mo165a(View view, int i);

        void mo166a(View view, Object obj);

        boolean mo167a(View view, AccessibilityEvent accessibilityEvent);

        boolean mo168a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

        void mo169b(View view, AccessibilityEvent accessibilityEvent);

        void mo170c(View view, AccessibilityEvent accessibilityEvent);

        void mo171d(View view, AccessibilityEvent accessibilityEvent);
    }

    public static Object m1648a() {
        return new AccessibilityDelegate();
    }

    public static Object m1649a(final C0263a bridge) {
        return new AccessibilityDelegate() {
            public boolean dispatchPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                return bridge.mo167a(host, event);
            }

            public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo169b(host, event);
            }

            public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
                bridge.mo166a(host, (Object) info);
            }

            public void onPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo170c(host, event);
            }

            public boolean onRequestSendAccessibilityEvent(ViewGroup host, View child, AccessibilityEvent event) {
                return bridge.mo168a(host, child, event);
            }

            public void sendAccessibilityEvent(View host, int eventType) {
                bridge.mo165a(host, eventType);
            }

            public void sendAccessibilityEventUnchecked(View host, AccessibilityEvent event) {
                bridge.mo171d(host, event);
            }
        };
    }

    public static boolean m1652a(Object delegate, View host, AccessibilityEvent event) {
        return ((AccessibilityDelegate) delegate).dispatchPopulateAccessibilityEvent(host, event);
    }

    public static void m1654b(Object delegate, View host, AccessibilityEvent event) {
        ((AccessibilityDelegate) delegate).onInitializeAccessibilityEvent(host, event);
    }

    public static void m1651a(Object delegate, View host, Object info) {
        ((AccessibilityDelegate) delegate).onInitializeAccessibilityNodeInfo(host, (AccessibilityNodeInfo) info);
    }

    public static void m1655c(Object delegate, View host, AccessibilityEvent event) {
        ((AccessibilityDelegate) delegate).onPopulateAccessibilityEvent(host, event);
    }

    public static boolean m1653a(Object delegate, ViewGroup host, View child, AccessibilityEvent event) {
        return ((AccessibilityDelegate) delegate).onRequestSendAccessibilityEvent(host, child, event);
    }

    public static void m1650a(Object delegate, View host, int eventType) {
        ((AccessibilityDelegate) delegate).sendAccessibilityEvent(host, eventType);
    }

    public static void m1656d(Object delegate, View host, AccessibilityEvent event) {
        ((AccessibilityDelegate) delegate).sendAccessibilityEventUnchecked(host, event);
    }
}
