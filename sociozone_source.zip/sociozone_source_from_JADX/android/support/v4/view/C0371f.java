package android.support.v4.view;

import android.view.Gravity;

/* compiled from: GravityCompatJellybeanMr1 */
class C0371f {
    public static int m1746a(int gravity, int layoutDirection) {
        return Gravity.getAbsoluteGravity(gravity, layoutDirection);
    }
}
