package android.support.v4.view;

import android.view.VelocityTracker;

/* compiled from: VelocityTrackerCompatHoneycomb */
class ah {
    public static float m1331a(VelocityTracker tracker, int pointerId) {
        return tracker.getXVelocity(pointerId);
    }

    public static float m1332b(VelocityTracker tracker, int pointerId) {
        return tracker.getYVelocity(pointerId);
    }
}
