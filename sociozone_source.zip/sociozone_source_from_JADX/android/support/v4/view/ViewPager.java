package android.support.v4.view;

import android.content.Context;
import android.content.res.Resources.NotFoundException;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.p008c.C0193c;
import android.support.v4.p008c.C0194d;
import android.support.v4.view.p012a.C0275a;
import android.support.v4.view.p012a.C0286b;
import android.support.v4.view.p012a.C0309j;
import android.support.v4.widget.C0466k;
import android.util.AttributeSet;
import android.util.Log;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.SoundEffectConstants;
import android.view.VelocityTracker;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.MeasureSpec;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.Scroller;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
    private static final int[] f489a = new int[]{16842931};
    private static final C0262i ai = new C0262i();
    private static final Comparator<C0254b> f490c = new C02481();
    private static final Interpolator f491d = new C02492();
    private int f492A = 1;
    private boolean f493B;
    private boolean f494C;
    private int f495D;
    private int f496E;
    private int f497F;
    private float f498G;
    private float f499H;
    private float f500I;
    private float f501J;
    private int f502K = -1;
    private VelocityTracker f503L;
    private int f504M;
    private int f505N;
    private int f506O;
    private int f507P;
    private boolean f508Q;
    private C0466k f509R;
    private C0466k f510S;
    private boolean f511T = true;
    private boolean f512U = false;
    private boolean f513V;
    private int f514W;
    private List<C0259f> aa;
    private C0259f ab;
    private C0259f ac;
    private C0258e ad;
    private C0260g ae;
    private Method af;
    private int ag;
    private ArrayList<View> ah;
    private final Runnable aj = new C02503(this);
    private int ak = 0;
    private int f515b;
    private final ArrayList<C0254b> f516e = new ArrayList();
    private final C0254b f517f = new C0254b();
    private final Rect f518g = new Rect();
    private ad f519h;
    private int f520i;
    private int f521j = -1;
    private Parcelable f522k = null;
    private ClassLoader f523l = null;
    private Scroller f524m;
    private boolean f525n;
    private C0261h f526o;
    private int f527p;
    private Drawable f528q;
    private int f529r;
    private int f530s;
    private float f531t = -3.4028235E38f;
    private float f532u = Float.MAX_VALUE;
    private int f533v;
    private int f534w;
    private boolean f535x;
    private boolean f536y;
    private boolean f537z;

    static class C02481 implements Comparator<C0254b> {
        C02481() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m887a((C0254b) obj, (C0254b) obj2);
        }

        public int m887a(C0254b lhs, C0254b rhs) {
            return lhs.f474b - rhs.f474b;
        }
    }

    static class C02492 implements Interpolator {
        C02492() {
        }

        public float getInterpolation(float t) {
            t -= 1.0f;
            return ((((t * t) * t) * t) * t) + 1.0f;
        }
    }

    class C02503 implements Runnable {
        final /* synthetic */ ViewPager f467a;

        C02503(ViewPager viewPager) {
            this.f467a = viewPager;
        }

        public void run() {
            this.f467a.setScrollState(0);
            this.f467a.m949c();
        }
    }

    class C02514 implements ac {
        final /* synthetic */ ViewPager f468a;
        private final Rect f469b = new Rect();

        C02514(ViewPager viewPager) {
            this.f468a = viewPager;
        }

        public bi onApplyWindowInsets(View v, bi originalInsets) {
            bi applied = ai.m1492a(v, originalInsets);
            if (applied.mo331e()) {
                return applied;
            }
            Rect res = this.f469b;
            res.left = applied.mo326a();
            res.top = applied.mo328b();
            res.right = applied.mo329c();
            res.bottom = applied.mo330d();
            int count = this.f468a.getChildCount();
            for (int i = 0; i < count; i++) {
                bi childInsets = ai.m1505b(this.f468a.getChildAt(i), applied);
                res.left = Math.min(childInsets.mo326a(), res.left);
                res.top = Math.min(childInsets.mo328b(), res.top);
                res.right = Math.min(childInsets.mo329c(), res.right);
                res.bottom = Math.min(childInsets.mo330d(), res.bottom);
            }
            return applied.mo327a(res.left, res.top, res.right, res.bottom);
        }
    }

    public static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = C0193c.m747a(new C02521());
        int f470a;
        Parcelable f471b;
        ClassLoader f472c;

        static class C02521 implements C0194d<SavedState> {
            C02521() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
                return m888a(parcel, classLoader);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m889a(i);
            }

            public SavedState m888a(Parcel in, ClassLoader loader) {
                return new SavedState(in, loader);
            }

            public SavedState[] m889a(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        public void writeToParcel(Parcel out, int flags) {
            super.writeToParcel(out, flags);
            out.writeInt(this.f470a);
            out.writeParcelable(this.f471b, flags);
        }

        public String toString() {
            return "FragmentPager.SavedState{" + Integer.toHexString(System.identityHashCode(this)) + " position=" + this.f470a + "}";
        }

        SavedState(Parcel in, ClassLoader loader) {
            super(in);
            if (loader == null) {
                loader = getClass().getClassLoader();
            }
            this.f470a = in.readInt();
            this.f471b = in.readParcelable(loader);
            this.f472c = loader;
        }
    }

    interface C0253a {
    }

    static class C0254b {
        Object f473a;
        int f474b;
        boolean f475c;
        float f476d;
        float f477e;

        C0254b() {
        }
    }

    public static class C0255c extends LayoutParams {
        public boolean f478a;
        public int f479b;
        float f480c = 0.0f;
        boolean f481d;
        int f482e;
        int f483f;

        public C0255c() {
            super(-1, -1);
        }

        public C0255c(Context context, AttributeSet attrs) {
            super(context, attrs);
            TypedArray a = context.obtainStyledAttributes(attrs, ViewPager.f489a);
            this.f479b = a.getInteger(0, 48);
            a.recycle();
        }
    }

    class C0257d extends C0256a {
        final /* synthetic */ ViewPager f487b;

        C0257d(ViewPager viewPager) {
            this.f487b = viewPager;
        }

        public void mo164d(View host, AccessibilityEvent event) {
            super.mo164d(host, event);
            event.setClassName(ViewPager.class.getName());
            C0309j recordCompat = C0275a.m1019a(event);
            recordCompat.m1284a(m900b());
            if (event.getEventType() == 4096 && this.f487b.f519h != null) {
                recordCompat.m1283a(this.f487b.f519h.mo1163a());
                recordCompat.m1285b(this.f487b.f520i);
                recordCompat.m1286c(this.f487b.f520i);
            }
        }

        public void mo162a(View host, C0286b info) {
            super.mo162a(host, info);
            info.m1161b(ViewPager.class.getName());
            info.m1179i(m900b());
            if (this.f487b.canScrollHorizontally(1)) {
                info.m1152a(4096);
            }
            if (this.f487b.canScrollHorizontally(-1)) {
                info.m1152a(8192);
            }
        }

        public boolean mo163a(View host, int action, Bundle args) {
            if (super.mo163a(host, action, args)) {
                return true;
            }
            switch (action) {
                case 4096:
                    if (!this.f487b.canScrollHorizontally(1)) {
                        return false;
                    }
                    this.f487b.setCurrentItem(this.f487b.f520i + 1);
                    return true;
                case 8192:
                    if (!this.f487b.canScrollHorizontally(-1)) {
                        return false;
                    }
                    this.f487b.setCurrentItem(this.f487b.f520i - 1);
                    return true;
                default:
                    return false;
            }
        }

        private boolean m900b() {
            return this.f487b.f519h != null && this.f487b.f519h.mo1163a() > 1;
        }
    }

    interface C0258e {
        void m904a(ad adVar, ad adVar2);
    }

    public interface C0259f {
        void mo852a(int i);

        void mo853a(int i, float f, int i2);

        void mo854b(int i);
    }

    public interface C0260g {
        void m908a(View view, float f);
    }

    private class C0261h extends DataSetObserver {
        final /* synthetic */ ViewPager f488a;

        private C0261h(ViewPager viewPager) {
            this.f488a = viewPager;
        }

        public void onChanged() {
            this.f488a.m948b();
        }

        public void onInvalidated() {
            this.f488a.m948b();
        }
    }

    static class C0262i implements Comparator<View> {
        C0262i() {
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m909a((View) obj, (View) obj2);
        }

        public int m909a(View lhs, View rhs) {
            C0255c llp = (C0255c) lhs.getLayoutParams();
            C0255c rlp = (C0255c) rhs.getLayoutParams();
            if (llp.f478a != rlp.f478a) {
                return llp.f478a ? 1 : -1;
            } else {
                return llp.f482e - rlp.f482e;
            }
        }
    }

    public ViewPager(Context context) {
        super(context);
        m937a();
    }

    public ViewPager(Context context, AttributeSet attrs) {
        super(context, attrs);
        m937a();
    }

    void m937a() {
        setWillNotDraw(false);
        setDescendantFocusability(262144);
        setFocusable(true);
        Context context = getContext();
        this.f524m = new Scroller(context, f491d);
        ViewConfiguration configuration = ViewConfiguration.get(context);
        float density = context.getResources().getDisplayMetrics().density;
        this.f497F = au.m1611a(configuration);
        this.f504M = (int) (400.0f * density);
        this.f505N = configuration.getScaledMaximumFlingVelocity();
        this.f509R = new C0466k(context);
        this.f510S = new C0466k(context);
        this.f506O = (int) (25.0f * density);
        this.f507P = (int) (2.0f * density);
        this.f495D = (int) (16.0f * density);
        ai.m1498a((View) this, new C0257d(this));
        if (ai.m1510c(this) == 0) {
            ai.m1512c((View) this, 1);
        }
        ai.m1499a((View) this, new C02514(this));
    }

    protected void onDetachedFromWindow() {
        removeCallbacks(this.aj);
        if (!(this.f524m == null || this.f524m.isFinished())) {
            this.f524m.abortAnimation();
        }
        super.onDetachedFromWindow();
    }

    private void setScrollState(int newState) {
        if (this.ak != newState) {
            this.ak = newState;
            if (this.ae != null) {
                m922b(newState != 0);
            }
            m927f(newState);
        }
    }

    public void setAdapter(ad adapter) {
        if (this.f519h != null) {
            this.f519h.m1322c(null);
            this.f519h.m1311a((ViewGroup) this);
            for (int i = 0; i < this.f516e.size(); i++) {
                C0254b ii = (C0254b) this.f516e.get(i);
                this.f519h.mo1166a((ViewGroup) this, ii.f474b, ii.f473a);
            }
            this.f519h.m1319b((ViewGroup) this);
            this.f516e.clear();
            m929g();
            this.f520i = 0;
            scrollTo(0, 0);
        }
        ad oldAdapter = this.f519h;
        this.f519h = adapter;
        this.f515b = 0;
        if (this.f519h != null) {
            if (this.f526o == null) {
                this.f526o = new C0261h();
            }
            this.f519h.m1322c(this.f526o);
            this.f537z = false;
            boolean wasFirstLayout = this.f511T;
            this.f511T = true;
            this.f515b = this.f519h.mo1163a();
            if (this.f521j >= 0) {
                this.f519h.m1308a(this.f522k, this.f523l);
                m942a(this.f521j, false, true);
                this.f521j = -1;
                this.f522k = null;
                this.f523l = null;
            } else if (wasFirstLayout) {
                requestLayout();
            } else {
                m949c();
            }
        }
        if (this.ad != null && oldAdapter != adapter) {
            this.ad.m904a(oldAdapter, adapter);
        }
    }

    private void m929g() {
        int i = 0;
        while (i < getChildCount()) {
            if (!((C0255c) getChildAt(i).getLayoutParams()).f478a) {
                removeViewAt(i);
                i--;
            }
            i++;
        }
    }

    public ad getAdapter() {
        return this.f519h;
    }

    void setOnAdapterChangeListener(C0258e listener) {
        this.ad = listener;
    }

    private int getClientWidth() {
        return (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
    }

    public void setCurrentItem(int item) {
        boolean z;
        this.f537z = false;
        if (this.f511T) {
            z = false;
        } else {
            z = true;
        }
        m942a(item, z, false);
    }

    public void m941a(int item, boolean smoothScroll) {
        this.f537z = false;
        m942a(item, smoothScroll, false);
    }

    public int getCurrentItem() {
        return this.f520i;
    }

    void m942a(int item, boolean smoothScroll, boolean always) {
        m943a(item, smoothScroll, always, 0);
    }

    void m943a(int item, boolean smoothScroll, boolean always, int velocity) {
        boolean dispatchSelected = true;
        if (this.f519h == null || this.f519h.mo1163a() <= 0) {
            setScrollingCacheEnabled(false);
        } else if (always || this.f520i != item || this.f516e.size() == 0) {
            if (item < 0) {
                item = 0;
            } else if (item >= this.f519h.mo1163a()) {
                item = this.f519h.mo1163a() - 1;
            }
            int pageLimit = this.f492A;
            if (item > this.f520i + pageLimit || item < this.f520i - pageLimit) {
                for (int i = 0; i < this.f516e.size(); i++) {
                    ((C0254b) this.f516e.get(i)).f475c = true;
                }
            }
            if (this.f520i == item) {
                dispatchSelected = false;
            }
            if (this.f511T) {
                this.f520i = item;
                if (dispatchSelected) {
                    m926e(item);
                }
                requestLayout();
                return;
            }
            m938a(item);
            m914a(item, smoothScroll, velocity, dispatchSelected);
        } else {
            setScrollingCacheEnabled(false);
        }
    }

    private void m914a(int item, boolean smoothScroll, int velocity, boolean dispatchSelected) {
        C0254b curInfo = m946b(item);
        int destX = 0;
        if (curInfo != null) {
            destX = (int) (((float) getClientWidth()) * Math.max(this.f531t, Math.min(curInfo.f477e, this.f532u)));
        }
        if (smoothScroll) {
            m940a(destX, 0, velocity);
            if (dispatchSelected) {
                m926e(item);
                return;
            }
            return;
        }
        if (dispatchSelected) {
            m926e(item);
        }
        m918a(false);
        scrollTo(destX, 0);
        m925d(destX);
    }

    @Deprecated
    public void setOnPageChangeListener(C0259f listener) {
        this.ab = listener;
    }

    void setChildrenDrawingOrderEnabledCompat(boolean enable) {
        if (VERSION.SDK_INT >= 7) {
            if (this.af == null) {
                try {
                    this.af = ViewGroup.class.getDeclaredMethod("setChildrenDrawingOrderEnabled", new Class[]{Boolean.TYPE});
                } catch (NoSuchMethodException e) {
                    Log.e("ViewPager", "Can't find setChildrenDrawingOrderEnabled", e);
                }
            }
            try {
                this.af.invoke(this, new Object[]{Boolean.valueOf(enable)});
            } catch (Exception e2) {
                Log.e("ViewPager", "Error changing children drawing order", e2);
            }
        }
    }

    protected int getChildDrawingOrder(int childCount, int i) {
        int index;
        if (this.ag == 2) {
            index = (childCount - 1) - i;
        } else {
            index = i;
        }
        return ((C0255c) ((View) this.ah.get(index)).getLayoutParams()).f483f;
    }

    public int getOffscreenPageLimit() {
        return this.f492A;
    }

    public void setOffscreenPageLimit(int limit) {
        if (limit < 1) {
            Log.w("ViewPager", "Requested offscreen page limit " + limit + " too small; defaulting to " + 1);
            limit = 1;
        }
        if (limit != this.f492A) {
            this.f492A = limit;
            m949c();
        }
    }

    public void setPageMargin(int marginPixels) {
        int oldMargin = this.f527p;
        this.f527p = marginPixels;
        int width = getWidth();
        m913a(width, width, marginPixels, oldMargin);
        requestLayout();
    }

    public int getPageMargin() {
        return this.f527p;
    }

    public void setPageMarginDrawable(Drawable d) {
        this.f528q = d;
        if (d != null) {
            refreshDrawableState();
        }
        setWillNotDraw(d == null);
        invalidate();
    }

    public void setPageMarginDrawable(int resId) {
        setPageMarginDrawable(getContext().getResources().getDrawable(resId));
    }

    protected boolean verifyDrawable(Drawable who) {
        return super.verifyDrawable(who) || who == this.f528q;
    }

    protected void drawableStateChanged() {
        super.drawableStateChanged();
        Drawable d = this.f528q;
        if (d != null && d.isStateful()) {
            d.setState(getDrawableState());
        }
    }

    float m934a(float f) {
        return (float) Math.sin((double) ((float) (((double) (f - 0.5f)) * 0.4712389167638204d)));
    }

    void m940a(int x, int y, int velocity) {
        if (getChildCount() == 0) {
            setScrollingCacheEnabled(false);
            return;
        }
        int sx;
        boolean wasScrolling = (this.f524m == null || this.f524m.isFinished()) ? false : true;
        if (wasScrolling) {
            sx = this.f525n ? this.f524m.getCurrX() : this.f524m.getStartX();
            this.f524m.abortAnimation();
            setScrollingCacheEnabled(false);
        } else {
            sx = getScrollX();
        }
        int sy = getScrollY();
        int dx = x - sx;
        int dy = y - sy;
        if (dx == 0 && dy == 0) {
            m918a(false);
            m949c();
            setScrollState(0);
            return;
        }
        int duration;
        setScrollingCacheEnabled(true);
        setScrollState(2);
        int width = getClientWidth();
        int halfWidth = width / 2;
        float distance = ((float) halfWidth) + (((float) halfWidth) * m934a(Math.min(1.0f, (1.0f * ((float) Math.abs(dx))) / ((float) width))));
        velocity = Math.abs(velocity);
        if (velocity > 0) {
            duration = Math.round(1000.0f * Math.abs(distance / ((float) velocity))) * 4;
        } else {
            duration = (int) ((1.0f + (((float) Math.abs(dx)) / (((float) this.f527p) + (((float) width) * this.f519h.m1314b(this.f520i))))) * 100.0f);
        }
        duration = Math.min(duration, 600);
        this.f525n = false;
        this.f524m.startScroll(sx, sy, dx, dy, duration);
        ai.m1506b(this);
    }

    C0254b m935a(int position, int index) {
        C0254b ii = new C0254b();
        ii.f474b = position;
        ii.f473a = this.f519h.mo1165a((ViewGroup) this, position);
        ii.f476d = this.f519h.m1314b(position);
        if (index < 0 || index >= this.f516e.size()) {
            this.f516e.add(ii);
        } else {
            this.f516e.add(index, ii);
        }
        return ii;
    }

    void m948b() {
        boolean needPopulate;
        int adapterCount = this.f519h.mo1163a();
        this.f515b = adapterCount;
        if (this.f516e.size() >= (this.f492A * 2) + 1 || this.f516e.size() >= adapterCount) {
            needPopulate = false;
        } else {
            needPopulate = true;
        }
        int newCurrItem = this.f520i;
        boolean isUpdating = false;
        int i = 0;
        while (i < this.f516e.size()) {
            C0254b ii = (C0254b) this.f516e.get(i);
            int newPos = this.f519h.m1303a(ii.f473a);
            if (newPos != -1) {
                if (newPos == -2) {
                    this.f516e.remove(i);
                    i--;
                    if (!isUpdating) {
                        this.f519h.m1311a((ViewGroup) this);
                        isUpdating = true;
                    }
                    this.f519h.mo1166a((ViewGroup) this, ii.f474b, ii.f473a);
                    needPopulate = true;
                    if (this.f520i == ii.f474b) {
                        newCurrItem = Math.max(0, Math.min(this.f520i, adapterCount - 1));
                        needPopulate = true;
                    }
                } else if (ii.f474b != newPos) {
                    if (ii.f474b == this.f520i) {
                        newCurrItem = newPos;
                    }
                    ii.f474b = newPos;
                    needPopulate = true;
                }
            }
            i++;
        }
        if (isUpdating) {
            this.f519h.m1319b((ViewGroup) this);
        }
        Collections.sort(this.f516e, f490c);
        if (needPopulate) {
            int childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                C0255c lp = (C0255c) getChildAt(i).getLayoutParams();
                if (!lp.f478a) {
                    lp.f480c = 0.0f;
                }
            }
            m942a(newCurrItem, false, true);
            requestLayout();
        }
    }

    void m949c() {
        m938a(this.f520i);
    }

    void m938a(int newCurrentItem) {
        C0254b oldCurInfo = null;
        if (this.f520i != newCurrentItem) {
            oldCurInfo = m946b(this.f520i);
            this.f520i = newCurrentItem;
        }
        if (this.f519h == null) {
            m930h();
        } else if (this.f537z) {
            m930h();
        } else if (getWindowToken() != null) {
            this.f519h.m1311a((ViewGroup) this);
            int pageLimit = this.f492A;
            int startPos = Math.max(0, this.f520i - pageLimit);
            int N = this.f519h.mo1163a();
            int endPos = Math.min(N - 1, this.f520i + pageLimit);
            if (N != this.f515b) {
                String resName;
                try {
                    resName = getResources().getResourceName(getId());
                } catch (NotFoundException e) {
                    resName = Integer.toHexString(getId());
                }
                throw new IllegalStateException("The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: " + this.f515b + ", found: " + N + " Pager id: " + resName + " Pager class: " + getClass() + " Problematic adapter: " + this.f519h.getClass());
            }
            C0254b ii;
            float extraWidthLeft;
            int itemIndex;
            int clientWidth;
            float leftWidthNeeded;
            int pos;
            float extraWidthRight;
            float rightWidthNeeded;
            int childCount;
            int i;
            View child;
            C0255c lp;
            View currentFocused;
            C0254b curItem = null;
            int curIndex = 0;
            while (curIndex < this.f516e.size()) {
                ii = (C0254b) this.f516e.get(curIndex);
                if (ii.f474b >= this.f520i) {
                    if (ii.f474b == this.f520i) {
                        curItem = ii;
                    }
                    if (curItem == null && N > 0) {
                        curItem = m935a(this.f520i, curIndex);
                    }
                    if (curItem != null) {
                        extraWidthLeft = 0.0f;
                        itemIndex = curIndex - 1;
                        ii = itemIndex < 0 ? (C0254b) this.f516e.get(itemIndex) : null;
                        clientWidth = getClientWidth();
                        leftWidthNeeded = clientWidth > 0 ? 0.0f : (2.0f - curItem.f476d) + (((float) getPaddingLeft()) / ((float) clientWidth));
                        pos = this.f520i - 1;
                        while (pos >= 0) {
                            if (extraWidthLeft >= leftWidthNeeded || pos >= startPos) {
                                if (ii == null && pos == ii.f474b) {
                                    extraWidthLeft += ii.f476d;
                                    itemIndex--;
                                    ii = itemIndex >= 0 ? (C0254b) this.f516e.get(itemIndex) : null;
                                } else {
                                    extraWidthLeft += m935a(pos, itemIndex + 1).f476d;
                                    curIndex++;
                                    ii = itemIndex < 0 ? (C0254b) this.f516e.get(itemIndex) : null;
                                }
                            } else if (ii == null) {
                                break;
                            } else {
                                if (pos == ii.f474b && !ii.f475c) {
                                    this.f516e.remove(itemIndex);
                                    this.f519h.mo1166a((ViewGroup) this, pos, ii.f473a);
                                    itemIndex--;
                                    curIndex--;
                                    if (itemIndex >= 0) {
                                        ii = (C0254b) this.f516e.get(itemIndex);
                                    } else {
                                        ii = null;
                                    }
                                }
                            }
                            pos--;
                        }
                        extraWidthRight = curItem.f476d;
                        itemIndex = curIndex + 1;
                        if (extraWidthRight < 2.0f) {
                            ii = itemIndex >= this.f516e.size() ? (C0254b) this.f516e.get(itemIndex) : null;
                            rightWidthNeeded = clientWidth > 0 ? 0.0f : (((float) getPaddingRight()) / ((float) clientWidth)) + 2.0f;
                            pos = this.f520i + 1;
                            while (pos < N) {
                                if (extraWidthRight >= rightWidthNeeded || pos <= endPos) {
                                    if (ii == null && pos == ii.f474b) {
                                        extraWidthRight += ii.f476d;
                                        itemIndex++;
                                        ii = itemIndex < this.f516e.size() ? (C0254b) this.f516e.get(itemIndex) : null;
                                    } else {
                                        itemIndex++;
                                        extraWidthRight += m935a(pos, itemIndex).f476d;
                                        ii = itemIndex >= this.f516e.size() ? (C0254b) this.f516e.get(itemIndex) : null;
                                    }
                                } else if (ii == null) {
                                    break;
                                } else {
                                    if (pos == ii.f474b && !ii.f475c) {
                                        this.f516e.remove(itemIndex);
                                        this.f519h.mo1166a((ViewGroup) this, pos, ii.f473a);
                                        if (itemIndex < this.f516e.size()) {
                                            ii = (C0254b) this.f516e.get(itemIndex);
                                        } else {
                                            ii = null;
                                        }
                                    }
                                }
                                pos++;
                            }
                        }
                        m915a(curItem, curIndex, oldCurInfo);
                    }
                    this.f519h.m1320b((ViewGroup) this, this.f520i, curItem == null ? curItem.f473a : null);
                    this.f519h.m1319b((ViewGroup) this);
                    childCount = getChildCount();
                    for (i = 0; i < childCount; i++) {
                        child = getChildAt(i);
                        lp = (C0255c) child.getLayoutParams();
                        lp.f483f = i;
                        if (!lp.f478a && lp.f480c == 0.0f) {
                            ii = m936a(child);
                            if (ii != null) {
                                lp.f480c = ii.f476d;
                                lp.f482e = ii.f474b;
                            }
                        }
                    }
                    m930h();
                    if (hasFocus()) {
                        currentFocused = findFocus();
                        ii = currentFocused == null ? m947b(currentFocused) : null;
                        if (ii != null || ii.f474b != this.f520i) {
                            while (i < getChildCount()) {
                                child = getChildAt(i);
                                ii = m936a(child);
                                if (ii != null || ii.f474b != this.f520i || !child.requestFocus(2)) {
                                } else {
                                    return;
                                }
                            }
                        }
                        return;
                    }
                }
                curIndex++;
            }
            curItem = m935a(this.f520i, curIndex);
            if (curItem != null) {
                extraWidthLeft = 0.0f;
                itemIndex = curIndex - 1;
                if (itemIndex < 0) {
                }
                clientWidth = getClientWidth();
                if (clientWidth > 0) {
                }
                pos = this.f520i - 1;
                while (pos >= 0) {
                    if (extraWidthLeft >= leftWidthNeeded) {
                    }
                    if (ii == null) {
                    }
                    extraWidthLeft += m935a(pos, itemIndex + 1).f476d;
                    curIndex++;
                    if (itemIndex < 0) {
                    }
                    pos--;
                }
                extraWidthRight = curItem.f476d;
                itemIndex = curIndex + 1;
                if (extraWidthRight < 2.0f) {
                    if (itemIndex >= this.f516e.size()) {
                    }
                    if (clientWidth > 0) {
                    }
                    pos = this.f520i + 1;
                    while (pos < N) {
                        if (extraWidthRight >= rightWidthNeeded) {
                        }
                        if (ii == null) {
                        }
                        itemIndex++;
                        extraWidthRight += m935a(pos, itemIndex).f476d;
                        if (itemIndex >= this.f516e.size()) {
                        }
                        pos++;
                    }
                }
                m915a(curItem, curIndex, oldCurInfo);
            }
            if (curItem == null) {
            }
            this.f519h.m1320b((ViewGroup) this, this.f520i, curItem == null ? curItem.f473a : null);
            this.f519h.m1319b((ViewGroup) this);
            childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                child = getChildAt(i);
                lp = (C0255c) child.getLayoutParams();
                lp.f483f = i;
                ii = m936a(child);
                if (ii != null) {
                    lp.f480c = ii.f476d;
                    lp.f482e = ii.f474b;
                }
            }
            m930h();
            if (hasFocus()) {
                currentFocused = findFocus();
                if (currentFocused == null) {
                }
                if (ii != null) {
                }
                for (i = 0; i < getChildCount(); i++) {
                    child = getChildAt(i);
                    ii = m936a(child);
                    if (ii != null) {
                    }
                }
            }
        }
    }

    private void m930h() {
        if (this.ag != 0) {
            if (this.ah == null) {
                this.ah = new ArrayList();
            } else {
                this.ah.clear();
            }
            int childCount = getChildCount();
            for (int i = 0; i < childCount; i++) {
                this.ah.add(getChildAt(i));
            }
            Collections.sort(this.ah, ai);
        }
    }

    private void m915a(C0254b curItem, int curIndex, C0254b oldCurInfo) {
        float offset;
        int pos;
        C0254b ii;
        int N = this.f519h.mo1163a();
        int width = getClientWidth();
        float marginOffset = width > 0 ? ((float) this.f527p) / ((float) width) : 0.0f;
        if (oldCurInfo != null) {
            int oldCurPosition = oldCurInfo.f474b;
            int itemIndex;
            if (oldCurPosition < curItem.f474b) {
                itemIndex = 0;
                offset = (oldCurInfo.f477e + oldCurInfo.f476d) + marginOffset;
                pos = oldCurPosition + 1;
                while (pos <= curItem.f474b && itemIndex < this.f516e.size()) {
                    ii = (C0254b) this.f516e.get(itemIndex);
                    while (pos > ii.f474b && itemIndex < this.f516e.size() - 1) {
                        itemIndex++;
                        ii = (C0254b) this.f516e.get(itemIndex);
                    }
                    while (pos < ii.f474b) {
                        offset += this.f519h.m1314b(pos) + marginOffset;
                        pos++;
                    }
                    ii.f477e = offset;
                    offset += ii.f476d + marginOffset;
                    pos++;
                }
            } else if (oldCurPosition > curItem.f474b) {
                itemIndex = this.f516e.size() - 1;
                offset = oldCurInfo.f477e;
                pos = oldCurPosition - 1;
                while (pos >= curItem.f474b && itemIndex >= 0) {
                    ii = (C0254b) this.f516e.get(itemIndex);
                    while (pos < ii.f474b && itemIndex > 0) {
                        itemIndex--;
                        ii = (C0254b) this.f516e.get(itemIndex);
                    }
                    while (pos > ii.f474b) {
                        offset -= this.f519h.m1314b(pos) + marginOffset;
                        pos--;
                    }
                    offset -= ii.f476d + marginOffset;
                    ii.f477e = offset;
                    pos--;
                }
            }
        }
        int itemCount = this.f516e.size();
        offset = curItem.f477e;
        pos = curItem.f474b - 1;
        this.f531t = curItem.f474b == 0 ? curItem.f477e : -3.4028235E38f;
        this.f532u = curItem.f474b == N + -1 ? (curItem.f477e + curItem.f476d) - 1.0f : Float.MAX_VALUE;
        int i = curIndex - 1;
        while (i >= 0) {
            ii = (C0254b) this.f516e.get(i);
            while (pos > ii.f474b) {
                offset -= this.f519h.m1314b(pos) + marginOffset;
                pos--;
            }
            offset -= ii.f476d + marginOffset;
            ii.f477e = offset;
            if (ii.f474b == 0) {
                this.f531t = offset;
            }
            i--;
            pos--;
        }
        offset = (curItem.f477e + curItem.f476d) + marginOffset;
        pos = curItem.f474b + 1;
        i = curIndex + 1;
        while (i < itemCount) {
            ii = (C0254b) this.f516e.get(i);
            while (pos < ii.f474b) {
                offset += this.f519h.m1314b(pos) + marginOffset;
                pos++;
            }
            if (ii.f474b == N - 1) {
                this.f532u = (ii.f476d + offset) - 1.0f;
            }
            ii.f477e = offset;
            offset += ii.f476d + marginOffset;
            i++;
            pos++;
        }
        this.f512U = false;
    }

    public Parcelable onSaveInstanceState() {
        SavedState ss = new SavedState(super.onSaveInstanceState());
        ss.f470a = this.f520i;
        if (this.f519h != null) {
            ss.f471b = this.f519h.m1315b();
        }
        return ss;
    }

    public void onRestoreInstanceState(Parcelable state) {
        if (state instanceof SavedState) {
            SavedState ss = (SavedState) state;
            super.onRestoreInstanceState(ss.getSuperState());
            if (this.f519h != null) {
                this.f519h.m1308a(ss.f471b, ss.f472c);
                m942a(ss.f470a, false, true);
                return;
            }
            this.f521j = ss.f470a;
            this.f522k = ss.f471b;
            this.f523l = ss.f472c;
            return;
        }
        super.onRestoreInstanceState(state);
    }

    public void addView(View child, int index, LayoutParams params) {
        if (!checkLayoutParams(params)) {
            params = generateLayoutParams(params);
        }
        C0255c lp = (C0255c) params;
        lp.f478a |= child instanceof C0253a;
        if (!this.f535x) {
            super.addView(child, index, params);
        } else if (lp == null || !lp.f478a) {
            lp.f481d = true;
            addViewInLayout(child, index, params);
        } else {
            throw new IllegalStateException("Cannot add pager decor view during layout");
        }
    }

    public void removeView(View view) {
        if (this.f535x) {
            removeViewInLayout(view);
        } else {
            super.removeView(view);
        }
    }

    C0254b m936a(View child) {
        for (int i = 0; i < this.f516e.size(); i++) {
            C0254b ii = (C0254b) this.f516e.get(i);
            if (this.f519h.mo1167a(child, ii.f473a)) {
                return ii;
            }
        }
        return null;
    }

    C0254b m947b(View child) {
        while (true) {
            View parent = child.getParent();
            if (parent == this) {
                return m936a(child);
            }
            if (parent != null && (parent instanceof View)) {
                child = parent;
            }
        }
        return null;
    }

    C0254b m946b(int position) {
        for (int i = 0; i < this.f516e.size(); i++) {
            C0254b ii = (C0254b) this.f516e.get(i);
            if (ii.f474b == position) {
                return ii;
            }
        }
        return null;
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.f511T = true;
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        int i;
        C0255c lp;
        setMeasuredDimension(getDefaultSize(0, widthMeasureSpec), getDefaultSize(0, heightMeasureSpec));
        int measuredWidth = getMeasuredWidth();
        this.f496E = Math.min(measuredWidth / 10, this.f495D);
        int childWidthSize = (measuredWidth - getPaddingLeft()) - getPaddingRight();
        int childHeightSize = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        int size = getChildCount();
        for (i = 0; i < size; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0255c) child.getLayoutParams();
                if (lp != null && lp.f478a) {
                    int hgrav = lp.f479b & 7;
                    int vgrav = lp.f479b & 112;
                    int widthMode = RtlSpacingHelper.UNDEFINED;
                    int heightMode = RtlSpacingHelper.UNDEFINED;
                    boolean consumeVertical = vgrav == 48 || vgrav == 80;
                    boolean consumeHorizontal = hgrav == 3 || hgrav == 5;
                    if (consumeVertical) {
                        widthMode = 1073741824;
                    } else if (consumeHorizontal) {
                        heightMode = 1073741824;
                    }
                    int widthSize = childWidthSize;
                    int heightSize = childHeightSize;
                    if (lp.width != -2) {
                        widthMode = 1073741824;
                        if (lp.width != -1) {
                            widthSize = lp.width;
                        }
                    }
                    if (lp.height != -2) {
                        heightMode = 1073741824;
                        if (lp.height != -1) {
                            heightSize = lp.height;
                        }
                    }
                    child.measure(MeasureSpec.makeMeasureSpec(widthSize, widthMode), MeasureSpec.makeMeasureSpec(heightSize, heightMode));
                    if (consumeVertical) {
                        childHeightSize -= child.getMeasuredHeight();
                    } else if (consumeHorizontal) {
                        childWidthSize -= child.getMeasuredWidth();
                    }
                }
            }
        }
        this.f533v = MeasureSpec.makeMeasureSpec(childWidthSize, 1073741824);
        this.f534w = MeasureSpec.makeMeasureSpec(childHeightSize, 1073741824);
        this.f535x = true;
        m949c();
        this.f535x = false;
        size = getChildCount();
        for (i = 0; i < size; i++) {
            child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0255c) child.getLayoutParams();
                if (lp == null || !lp.f478a) {
                    child.measure(MeasureSpec.makeMeasureSpec((int) (((float) childWidthSize) * lp.f480c), 1073741824), this.f534w);
                }
            }
        }
    }

    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w != oldw) {
            m913a(w, oldw, this.f527p, this.f527p);
        }
    }

    private void m913a(int width, int oldWidth, int margin, int oldMargin) {
        if (oldWidth <= 0 || this.f516e.isEmpty()) {
            C0254b ii = m946b(this.f520i);
            int scrollPos = (int) (((float) ((width - getPaddingLeft()) - getPaddingRight())) * (ii != null ? Math.min(ii.f477e, this.f532u) : 0.0f));
            if (scrollPos != getScrollX()) {
                m918a(false);
                scrollTo(scrollPos, getScrollY());
            }
        } else if (this.f524m.isFinished()) {
            scrollTo((int) (((float) (((width - getPaddingLeft()) - getPaddingRight()) + margin)) * (((float) getScrollX()) / ((float) (((oldWidth - getPaddingLeft()) - getPaddingRight()) + oldMargin)))), getScrollY());
        } else {
            this.f524m.setFinalX(getCurrentItem() * getClientWidth());
        }
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        int i;
        int childLeft;
        int childTop;
        int count = getChildCount();
        int width = r - l;
        int height = b - t;
        int paddingLeft = getPaddingLeft();
        int paddingTop = getPaddingTop();
        int paddingRight = getPaddingRight();
        int paddingBottom = getPaddingBottom();
        int scrollX = getScrollX();
        int decorCount = 0;
        for (i = 0; i < count; i++) {
            C0255c lp;
            View child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0255c) child.getLayoutParams();
                if (lp.f478a) {
                    int vgrav = lp.f479b & 112;
                    switch (lp.f479b & 7) {
                        case 1:
                            childLeft = Math.max((width - child.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            childLeft = paddingLeft;
                            paddingLeft += child.getMeasuredWidth();
                            break;
                        case 5:
                            childLeft = (width - paddingRight) - child.getMeasuredWidth();
                            paddingRight += child.getMeasuredWidth();
                            break;
                        default:
                            childLeft = paddingLeft;
                            break;
                    }
                    switch (vgrav) {
                        case 16:
                            childTop = Math.max((height - child.getMeasuredHeight()) / 2, paddingTop);
                            break;
                        case 48:
                            childTop = paddingTop;
                            paddingTop += child.getMeasuredHeight();
                            break;
                        case 80:
                            childTop = (height - paddingBottom) - child.getMeasuredHeight();
                            paddingBottom += child.getMeasuredHeight();
                            break;
                        default:
                            childTop = paddingTop;
                            break;
                    }
                    childLeft += scrollX;
                    child.layout(childLeft, childTop, child.getMeasuredWidth() + childLeft, child.getMeasuredHeight() + childTop);
                    decorCount++;
                }
            }
        }
        int childWidth = (width - paddingLeft) - paddingRight;
        for (i = 0; i < count; i++) {
            child = getChildAt(i);
            if (child.getVisibility() != 8) {
                lp = (C0255c) child.getLayoutParams();
                if (!lp.f478a) {
                    C0254b ii = m936a(child);
                    if (ii != null) {
                        childLeft = paddingLeft + ((int) (((float) childWidth) * ii.f477e));
                        childTop = paddingTop;
                        if (lp.f481d) {
                            lp.f481d = false;
                            child.measure(MeasureSpec.makeMeasureSpec((int) (((float) childWidth) * lp.f480c), 1073741824), MeasureSpec.makeMeasureSpec((height - paddingTop) - paddingBottom, 1073741824));
                        }
                        child.layout(childLeft, childTop, child.getMeasuredWidth() + childLeft, child.getMeasuredHeight() + childTop);
                    }
                }
            }
        }
        this.f529r = paddingTop;
        this.f530s = height - paddingBottom;
        this.f514W = decorCount;
        if (this.f511T) {
            m914a(this.f520i, false, 0, false);
        }
        this.f511T = false;
    }

    public void computeScroll() {
        this.f525n = true;
        if (this.f524m.isFinished() || !this.f524m.computeScrollOffset()) {
            m918a(true);
            return;
        }
        int oldX = getScrollX();
        int oldY = getScrollY();
        int x = this.f524m.getCurrX();
        int y = this.f524m.getCurrY();
        if (!(oldX == x && oldY == y)) {
            scrollTo(x, y);
            if (!m925d(x)) {
                this.f524m.abortAnimation();
                scrollTo(0, y);
            }
        }
        ai.m1506b(this);
    }

    private boolean m925d(int xpos) {
        if (this.f516e.size() != 0) {
            C0254b ii = m932j();
            int width = getClientWidth();
            int widthWithMargin = width + this.f527p;
            float marginOffset = ((float) this.f527p) / ((float) width);
            int currentPage = ii.f474b;
            float pageOffset = ((((float) xpos) / ((float) width)) - ii.f477e) / (ii.f476d + marginOffset);
            int offsetPixels = (int) (((float) widthWithMargin) * pageOffset);
            this.f513V = false;
            m939a(currentPage, pageOffset, offsetPixels);
            if (this.f513V) {
                return true;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        } else if (this.f511T) {
            return false;
        } else {
            this.f513V = false;
            m939a(0, 0.0f, 0);
            if (this.f513V) {
                return false;
            }
            throw new IllegalStateException("onPageScrolled did not call superclass implementation");
        }
    }

    protected void m939a(int position, float offset, int offsetPixels) {
        int scrollX;
        int childCount;
        int i;
        View child;
        if (this.f514W > 0) {
            scrollX = getScrollX();
            int paddingLeft = getPaddingLeft();
            int paddingRight = getPaddingRight();
            int width = getWidth();
            childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                child = getChildAt(i);
                C0255c lp = (C0255c) child.getLayoutParams();
                if (lp.f478a) {
                    int childLeft;
                    switch (lp.f479b & 7) {
                        case 1:
                            childLeft = Math.max((width - child.getMeasuredWidth()) / 2, paddingLeft);
                            break;
                        case 3:
                            childLeft = paddingLeft;
                            paddingLeft += child.getWidth();
                            break;
                        case 5:
                            childLeft = (width - paddingRight) - child.getMeasuredWidth();
                            paddingRight += child.getMeasuredWidth();
                            break;
                        default:
                            childLeft = paddingLeft;
                            break;
                    }
                    int childOffset = (childLeft + scrollX) - child.getLeft();
                    if (childOffset != 0) {
                        child.offsetLeftAndRight(childOffset);
                    }
                }
            }
        }
        m921b(position, offset, offsetPixels);
        if (this.ae != null) {
            scrollX = getScrollX();
            childCount = getChildCount();
            for (i = 0; i < childCount; i++) {
                child = getChildAt(i);
                if (!((C0255c) child.getLayoutParams()).f478a) {
                    this.ae.m908a(child, ((float) (child.getLeft() - scrollX)) / ((float) getClientWidth()));
                }
            }
        }
        this.f513V = true;
    }

    private void m921b(int position, float offset, int offsetPixels) {
        if (this.ab != null) {
            this.ab.mo853a(position, offset, offsetPixels);
        }
        if (this.aa != null) {
            int z = this.aa.size();
            for (int i = 0; i < z; i++) {
                C0259f listener = (C0259f) this.aa.get(i);
                if (listener != null) {
                    listener.mo853a(position, offset, offsetPixels);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo853a(position, offset, offsetPixels);
        }
    }

    private void m926e(int position) {
        if (this.ab != null) {
            this.ab.mo852a(position);
        }
        if (this.aa != null) {
            int z = this.aa.size();
            for (int i = 0; i < z; i++) {
                C0259f listener = (C0259f) this.aa.get(i);
                if (listener != null) {
                    listener.mo852a(position);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo852a(position);
        }
    }

    private void m927f(int state) {
        if (this.ab != null) {
            this.ab.mo854b(state);
        }
        if (this.aa != null) {
            int z = this.aa.size();
            for (int i = 0; i < z; i++) {
                C0259f listener = (C0259f) this.aa.get(i);
                if (listener != null) {
                    listener.mo854b(state);
                }
            }
        }
        if (this.ac != null) {
            this.ac.mo854b(state);
        }
    }

    private void m918a(boolean postEvents) {
        boolean needPopulate;
        boolean wasScrolling = true;
        if (this.ak == 2) {
            needPopulate = true;
        } else {
            needPopulate = false;
        }
        if (needPopulate) {
            setScrollingCacheEnabled(false);
            if (this.f524m.isFinished()) {
                wasScrolling = false;
            }
            if (wasScrolling) {
                this.f524m.abortAnimation();
                int oldX = getScrollX();
                int oldY = getScrollY();
                int x = this.f524m.getCurrX();
                int y = this.f524m.getCurrY();
                if (!(oldX == x && oldY == y)) {
                    scrollTo(x, y);
                    if (x != oldX) {
                        m925d(x);
                    }
                }
            }
        }
        this.f537z = false;
        for (int i = 0; i < this.f516e.size(); i++) {
            C0254b ii = (C0254b) this.f516e.get(i);
            if (ii.f475c) {
                needPopulate = true;
                ii.f475c = false;
            }
        }
        if (!needPopulate) {
            return;
        }
        if (postEvents) {
            ai.m1500a((View) this, this.aj);
        } else {
            this.aj.run();
        }
    }

    private boolean m919a(float x, float dx) {
        return (x < ((float) this.f496E) && dx > 0.0f) || (x > ((float) (getWidth() - this.f496E)) && dx < 0.0f);
    }

    private void m922b(boolean enable) {
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            ai.m1495a(getChildAt(i), enable ? 2 : 0, null);
        }
    }

    public boolean onInterceptTouchEvent(MotionEvent ev) {
        int action = ev.getAction() & 255;
        if (action == 3 || action == 1) {
            m931i();
            return false;
        }
        if (action != 0) {
            if (this.f493B) {
                return true;
            }
            if (this.f494C) {
                return false;
            }
        }
        switch (action) {
            case 0:
                float x = ev.getX();
                this.f500I = x;
                this.f498G = x;
                x = ev.getY();
                this.f501J = x;
                this.f499H = x;
                this.f502K = C0408u.m1846b(ev, 0);
                this.f494C = false;
                this.f525n = true;
                this.f524m.computeScrollOffset();
                if (this.ak == 2 && Math.abs(this.f524m.getFinalX() - this.f524m.getCurrX()) > this.f507P) {
                    this.f524m.abortAnimation();
                    this.f537z = false;
                    m949c();
                    this.f493B = true;
                    m924c(true);
                    setScrollState(1);
                    break;
                }
                m918a(false);
                this.f493B = false;
                break;
            case 2:
                int activePointerId = this.f502K;
                if (activePointerId != -1) {
                    int pointerIndex = C0408u.m1844a(ev, activePointerId);
                    float x2 = C0408u.m1847c(ev, pointerIndex);
                    float dx = x2 - this.f498G;
                    float xDiff = Math.abs(dx);
                    float y = C0408u.m1849d(ev, pointerIndex);
                    float yDiff = Math.abs(y - this.f501J);
                    if (dx == 0.0f || m919a(this.f498G, dx) || !m945a(this, false, (int) dx, (int) x2, (int) y)) {
                        if (xDiff > ((float) this.f497F) && 0.5f * xDiff > yDiff) {
                            this.f493B = true;
                            m924c(true);
                            setScrollState(1);
                            this.f498G = dx > 0.0f ? this.f500I + ((float) this.f497F) : this.f500I - ((float) this.f497F);
                            this.f499H = y;
                            setScrollingCacheEnabled(true);
                        } else if (yDiff > ((float) this.f497F)) {
                            this.f494C = true;
                        }
                        if (this.f493B && m923b(x2)) {
                            ai.m1506b(this);
                            break;
                        }
                    }
                    this.f498G = x2;
                    this.f499H = y;
                    this.f494C = true;
                    return false;
                }
                break;
            case 6:
                m917a(ev);
                break;
        }
        if (this.f503L == null) {
            this.f503L = VelocityTracker.obtain();
        }
        this.f503L.addMovement(ev);
        return this.f493B;
    }

    public boolean onTouchEvent(MotionEvent ev) {
        if (this.f508Q) {
            return true;
        }
        if (ev.getAction() == 0 && ev.getEdgeFlags() != 0) {
            return false;
        }
        if (this.f519h == null || this.f519h.mo1163a() == 0) {
            return false;
        }
        if (this.f503L == null) {
            this.f503L = VelocityTracker.obtain();
        }
        this.f503L.addMovement(ev);
        boolean needsInvalidate = false;
        float x;
        switch (ev.getAction() & 255) {
            case 0:
                this.f524m.abortAnimation();
                this.f537z = false;
                m949c();
                x = ev.getX();
                this.f500I = x;
                this.f498G = x;
                x = ev.getY();
                this.f501J = x;
                this.f499H = x;
                this.f502K = C0408u.m1846b(ev, 0);
                break;
            case 1:
                if (this.f493B) {
                    VelocityTracker velocityTracker = this.f503L;
                    velocityTracker.computeCurrentVelocity(1000, (float) this.f505N);
                    int initialVelocity = (int) ag.m1329a(velocityTracker, this.f502K);
                    this.f537z = true;
                    int width = getClientWidth();
                    int scrollX = getScrollX();
                    C0254b ii = m932j();
                    float marginOffset = ((float) this.f527p) / ((float) width);
                    m943a(m910a(ii.f474b, ((((float) scrollX) / ((float) width)) - ii.f477e) / (ii.f476d + marginOffset), initialVelocity, (int) (C0408u.m1847c(ev, C0408u.m1844a(ev, this.f502K)) - this.f500I)), true, true, initialVelocity);
                    needsInvalidate = m931i();
                    break;
                }
                break;
            case 2:
                if (!this.f493B) {
                    int pointerIndex = C0408u.m1844a(ev, this.f502K);
                    if (pointerIndex == -1) {
                        needsInvalidate = m931i();
                        break;
                    }
                    float x2 = C0408u.m1847c(ev, pointerIndex);
                    float xDiff = Math.abs(x2 - this.f498G);
                    float y = C0408u.m1849d(ev, pointerIndex);
                    float yDiff = Math.abs(y - this.f499H);
                    if (xDiff > ((float) this.f497F) && xDiff > yDiff) {
                        this.f493B = true;
                        m924c(true);
                        if (x2 - this.f500I > 0.0f) {
                            x = this.f500I + ((float) this.f497F);
                        } else {
                            x = this.f500I - ((float) this.f497F);
                        }
                        this.f498G = x;
                        this.f499H = y;
                        setScrollState(1);
                        setScrollingCacheEnabled(true);
                        ViewParent parent = getParent();
                        if (parent != null) {
                            parent.requestDisallowInterceptTouchEvent(true);
                        }
                    }
                }
                if (this.f493B) {
                    needsInvalidate = false | m923b(C0408u.m1847c(ev, C0408u.m1844a(ev, this.f502K)));
                    break;
                }
                break;
            case 3:
                if (this.f493B) {
                    m914a(this.f520i, true, 0, false);
                    needsInvalidate = m931i();
                    break;
                }
                break;
            case 5:
                int index = C0408u.m1845b(ev);
                this.f498G = C0408u.m1847c(ev, index);
                this.f502K = C0408u.m1846b(ev, index);
                break;
            case 6:
                m917a(ev);
                this.f498G = C0408u.m1847c(ev, C0408u.m1844a(ev, this.f502K));
                break;
        }
        if (needsInvalidate) {
            ai.m1506b(this);
        }
        return true;
    }

    private boolean m931i() {
        this.f502K = -1;
        m933k();
        return this.f509R.m2200c() | this.f510S.m2200c();
    }

    private void m924c(boolean disallowIntercept) {
        ViewParent parent = getParent();
        if (parent != null) {
            parent.requestDisallowInterceptTouchEvent(disallowIntercept);
        }
    }

    private boolean m923b(float x) {
        boolean needsInvalidate = false;
        float deltaX = this.f498G - x;
        this.f498G = x;
        float scrollX = ((float) getScrollX()) + deltaX;
        int width = getClientWidth();
        float leftBound = ((float) width) * this.f531t;
        float rightBound = ((float) width) * this.f532u;
        boolean leftAbsolute = true;
        boolean rightAbsolute = true;
        C0254b firstItem = (C0254b) this.f516e.get(0);
        C0254b lastItem = (C0254b) this.f516e.get(this.f516e.size() - 1);
        if (firstItem.f474b != 0) {
            leftAbsolute = false;
            leftBound = firstItem.f477e * ((float) width);
        }
        if (lastItem.f474b != this.f519h.mo1163a() - 1) {
            rightAbsolute = false;
            rightBound = lastItem.f477e * ((float) width);
        }
        if (scrollX < leftBound) {
            if (leftAbsolute) {
                needsInvalidate = this.f509R.m2195a(Math.abs(leftBound - scrollX) / ((float) width));
            }
            scrollX = leftBound;
        } else if (scrollX > rightBound) {
            if (rightAbsolute) {
                needsInvalidate = this.f510S.m2195a(Math.abs(scrollX - rightBound) / ((float) width));
            }
            scrollX = rightBound;
        }
        this.f498G += scrollX - ((float) ((int) scrollX));
        scrollTo((int) scrollX, getScrollY());
        m925d((int) scrollX);
        return needsInvalidate;
    }

    private C0254b m932j() {
        float scrollOffset;
        float marginOffset = 0.0f;
        int width = getClientWidth();
        if (width > 0) {
            scrollOffset = ((float) getScrollX()) / ((float) width);
        } else {
            scrollOffset = 0.0f;
        }
        if (width > 0) {
            marginOffset = ((float) this.f527p) / ((float) width);
        }
        int lastPos = -1;
        float lastOffset = 0.0f;
        float lastWidth = 0.0f;
        boolean first = true;
        C0254b lastItem = null;
        int i = 0;
        while (i < this.f516e.size()) {
            C0254b ii = (C0254b) this.f516e.get(i);
            if (!(first || ii.f474b == lastPos + 1)) {
                ii = this.f517f;
                ii.f477e = (lastOffset + lastWidth) + marginOffset;
                ii.f474b = lastPos + 1;
                ii.f476d = this.f519h.m1314b(ii.f474b);
                i--;
            }
            float offset = ii.f477e;
            float leftBound = offset;
            float rightBound = (ii.f476d + offset) + marginOffset;
            if (!first && scrollOffset < leftBound) {
                return lastItem;
            }
            if (scrollOffset < rightBound || i == this.f516e.size() - 1) {
                return ii;
            }
            first = false;
            lastPos = ii.f474b;
            lastOffset = offset;
            lastWidth = ii.f476d;
            lastItem = ii;
            i++;
        }
        return lastItem;
    }

    private int m910a(int currentPage, float pageOffset, int velocity, int deltaX) {
        int targetPage;
        if (Math.abs(deltaX) <= this.f506O || Math.abs(velocity) <= this.f504M) {
            targetPage = (int) ((((float) currentPage) + pageOffset) + (currentPage >= this.f520i ? 0.4f : 0.6f));
        } else {
            targetPage = velocity > 0 ? currentPage : currentPage + 1;
        }
        if (this.f516e.size() <= 0) {
            return targetPage;
        }
        return Math.max(((C0254b) this.f516e.get(0)).f474b, Math.min(targetPage, ((C0254b) this.f516e.get(this.f516e.size() - 1)).f474b));
    }

    public void draw(Canvas canvas) {
        super.draw(canvas);
        boolean needsInvalidate = false;
        int overScrollMode = ai.m1491a(this);
        if (overScrollMode == 0 || (overScrollMode == 1 && this.f519h != null && this.f519h.mo1163a() > 1)) {
            int restoreCount;
            int height;
            int width;
            if (!this.f509R.m2194a()) {
                restoreCount = canvas.save();
                height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                width = getWidth();
                canvas.rotate(270.0f);
                canvas.translate((float) ((-height) + getPaddingTop()), this.f531t * ((float) width));
                this.f509R.m2193a(height, width);
                needsInvalidate = false | this.f509R.m2198a(canvas);
                canvas.restoreToCount(restoreCount);
            }
            if (!this.f510S.m2194a()) {
                restoreCount = canvas.save();
                width = getWidth();
                height = (getHeight() - getPaddingTop()) - getPaddingBottom();
                canvas.rotate(90.0f);
                canvas.translate((float) (-getPaddingTop()), (-(this.f532u + 1.0f)) * ((float) width));
                this.f510S.m2193a(height, width);
                needsInvalidate |= this.f510S.m2198a(canvas);
                canvas.restoreToCount(restoreCount);
            }
        } else {
            this.f509R.m2199b();
            this.f510S.m2199b();
        }
        if (needsInvalidate) {
            ai.m1506b(this);
        }
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (this.f527p > 0 && this.f528q != null && this.f516e.size() > 0 && this.f519h != null) {
            int scrollX = getScrollX();
            int width = getWidth();
            float marginOffset = ((float) this.f527p) / ((float) width);
            int itemIndex = 0;
            C0254b ii = (C0254b) this.f516e.get(0);
            float offset = ii.f477e;
            int itemCount = this.f516e.size();
            int firstPos = ii.f474b;
            int lastPos = ((C0254b) this.f516e.get(itemCount - 1)).f474b;
            int pos = firstPos;
            while (pos < lastPos) {
                float drawAt;
                while (pos > ii.f474b && itemIndex < itemCount) {
                    itemIndex++;
                    ii = (C0254b) this.f516e.get(itemIndex);
                }
                if (pos == ii.f474b) {
                    drawAt = (ii.f477e + ii.f476d) * ((float) width);
                    offset = (ii.f477e + ii.f476d) + marginOffset;
                } else {
                    float widthFactor = this.f519h.m1314b(pos);
                    drawAt = (offset + widthFactor) * ((float) width);
                    offset += widthFactor + marginOffset;
                }
                if (((float) this.f527p) + drawAt > ((float) scrollX)) {
                    this.f528q.setBounds(Math.round(drawAt), this.f529r, Math.round(((float) this.f527p) + drawAt), this.f530s);
                    this.f528q.draw(canvas);
                }
                if (drawAt <= ((float) (scrollX + width))) {
                    pos++;
                } else {
                    return;
                }
            }
        }
    }

    private void m917a(MotionEvent ev) {
        int pointerIndex = C0408u.m1845b(ev);
        if (C0408u.m1846b(ev, pointerIndex) == this.f502K) {
            int newPointerIndex = pointerIndex == 0 ? 1 : 0;
            this.f498G = C0408u.m1847c(ev, newPointerIndex);
            this.f502K = C0408u.m1846b(ev, newPointerIndex);
            if (this.f503L != null) {
                this.f503L.clear();
            }
        }
    }

    private void m933k() {
        this.f493B = false;
        this.f494C = false;
        if (this.f503L != null) {
            this.f503L.recycle();
            this.f503L = null;
        }
    }

    private void setScrollingCacheEnabled(boolean enabled) {
        if (this.f536y != enabled) {
            this.f536y = enabled;
        }
    }

    public boolean canScrollHorizontally(int direction) {
        boolean z = true;
        if (this.f519h == null) {
            return false;
        }
        int width = getClientWidth();
        int scrollX = getScrollX();
        if (direction < 0) {
            if (scrollX <= ((int) (((float) width) * this.f531t))) {
                z = false;
            }
            return z;
        } else if (direction <= 0) {
            return false;
        } else {
            if (scrollX >= ((int) (((float) width) * this.f532u))) {
                z = false;
            }
            return z;
        }
    }

    protected boolean m945a(View v, boolean checkV, int dx, int x, int y) {
        if (v instanceof ViewGroup) {
            ViewGroup group = (ViewGroup) v;
            int scrollX = v.getScrollX();
            int scrollY = v.getScrollY();
            for (int i = group.getChildCount() - 1; i >= 0; i--) {
                View child = group.getChildAt(i);
                if (x + scrollX >= child.getLeft() && x + scrollX < child.getRight() && y + scrollY >= child.getTop() && y + scrollY < child.getBottom()) {
                    if (m945a(child, true, dx, (x + scrollX) - child.getLeft(), (y + scrollY) - child.getTop())) {
                        return true;
                    }
                }
            }
        }
        return checkV && ai.m1504a(v, -dx);
    }

    public boolean dispatchKeyEvent(KeyEvent event) {
        return super.dispatchKeyEvent(event) || m944a(event);
    }

    public boolean m944a(KeyEvent event) {
        if (event.getAction() != 0) {
            return false;
        }
        switch (event.getKeyCode()) {
            case 21:
                return m950c(17);
            case 22:
                return m950c(66);
            case 61:
                if (VERSION.SDK_INT < 11) {
                    return false;
                }
                if (C0376g.m1759a(event)) {
                    return m950c(2);
                }
                if (C0376g.m1760a(event, 1)) {
                    return m950c(1);
                }
                return false;
            default:
                return false;
        }
    }

    public boolean m950c(int direction) {
        View currentFocused = findFocus();
        if (currentFocused == this) {
            currentFocused = null;
        } else if (currentFocused != null) {
            boolean isChild = false;
            for (ViewPager parent = currentFocused.getParent(); parent instanceof ViewGroup; parent = parent.getParent()) {
                if (parent == this) {
                    isChild = true;
                    break;
                }
            }
            if (!isChild) {
                StringBuilder sb = new StringBuilder();
                sb.append(currentFocused.getClass().getSimpleName());
                for (ViewParent parent2 = currentFocused.getParent(); parent2 instanceof ViewGroup; parent2 = parent2.getParent()) {
                    sb.append(" => ").append(parent2.getClass().getSimpleName());
                }
                Log.e("ViewPager", "arrowScroll tried to find focus based on non-child current focused view " + sb.toString());
                currentFocused = null;
            }
        }
        boolean handled = false;
        View nextFocused = FocusFinder.getInstance().findNextFocus(this, currentFocused, direction);
        if (nextFocused == null || nextFocused == currentFocused) {
            if (direction == 17 || direction == 1) {
                handled = m951d();
            } else if (direction == 66 || direction == 2) {
                handled = m952e();
            }
        } else if (direction == 17) {
            handled = (currentFocused == null || m911a(this.f518g, nextFocused).left < m911a(this.f518g, currentFocused).left) ? nextFocused.requestFocus() : m951d();
        } else if (direction == 66) {
            handled = (currentFocused == null || m911a(this.f518g, nextFocused).left > m911a(this.f518g, currentFocused).left) ? nextFocused.requestFocus() : m952e();
        }
        if (handled) {
            playSoundEffect(SoundEffectConstants.getContantForFocusDirection(direction));
        }
        return handled;
    }

    private Rect m911a(Rect outRect, View child) {
        if (outRect == null) {
            outRect = new Rect();
        }
        if (child == null) {
            outRect.set(0, 0, 0, 0);
        } else {
            outRect.left = child.getLeft();
            outRect.right = child.getRight();
            outRect.top = child.getTop();
            outRect.bottom = child.getBottom();
            ViewGroup parent = child.getParent();
            while ((parent instanceof ViewGroup) && parent != this) {
                ViewGroup group = parent;
                outRect.left += group.getLeft();
                outRect.right += group.getRight();
                outRect.top += group.getTop();
                outRect.bottom += group.getBottom();
                parent = group.getParent();
            }
        }
        return outRect;
    }

    boolean m951d() {
        if (this.f520i <= 0) {
            return false;
        }
        m941a(this.f520i - 1, true);
        return true;
    }

    boolean m952e() {
        if (this.f519h == null || this.f520i >= this.f519h.mo1163a() - 1) {
            return false;
        }
        m941a(this.f520i + 1, true);
        return true;
    }

    public void addFocusables(ArrayList<View> views, int direction, int focusableMode) {
        int focusableCount = views.size();
        int descendantFocusability = getDescendantFocusability();
        if (descendantFocusability != 393216) {
            for (int i = 0; i < getChildCount(); i++) {
                View child = getChildAt(i);
                if (child.getVisibility() == 0) {
                    C0254b ii = m936a(child);
                    if (ii != null && ii.f474b == this.f520i) {
                        child.addFocusables(views, direction, focusableMode);
                    }
                }
            }
        }
        if ((descendantFocusability == 262144 && focusableCount != views.size()) || !isFocusable()) {
            return;
        }
        if (((focusableMode & 1) != 1 || !isInTouchMode() || isFocusableInTouchMode()) && views != null) {
            views.add(this);
        }
    }

    public void addTouchables(ArrayList<View> views) {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == 0) {
                C0254b ii = m936a(child);
                if (ii != null && ii.f474b == this.f520i) {
                    child.addTouchables(views);
                }
            }
        }
    }

    protected boolean onRequestFocusInDescendants(int direction, Rect previouslyFocusedRect) {
        int index;
        int increment;
        int end;
        int count = getChildCount();
        if ((direction & 2) != 0) {
            index = 0;
            increment = 1;
            end = count;
        } else {
            index = count - 1;
            increment = -1;
            end = -1;
        }
        for (int i = index; i != end; i += increment) {
            View child = getChildAt(i);
            if (child.getVisibility() == 0) {
                C0254b ii = m936a(child);
                if (ii != null && ii.f474b == this.f520i && child.requestFocus(direction, previouslyFocusedRect)) {
                    return true;
                }
            }
        }
        return false;
    }

    public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent event) {
        if (event.getEventType() == 4096) {
            return super.dispatchPopulateAccessibilityEvent(event);
        }
        int childCount = getChildCount();
        for (int i = 0; i < childCount; i++) {
            View child = getChildAt(i);
            if (child.getVisibility() == 0) {
                C0254b ii = m936a(child);
                if (ii != null && ii.f474b == this.f520i && child.dispatchPopulateAccessibilityEvent(event)) {
                    return true;
                }
            }
        }
        return false;
    }

    protected LayoutParams generateDefaultLayoutParams() {
        return new C0255c();
    }

    protected LayoutParams generateLayoutParams(LayoutParams p) {
        return generateDefaultLayoutParams();
    }

    protected boolean checkLayoutParams(LayoutParams p) {
        return (p instanceof C0255c) && super.checkLayoutParams(p);
    }

    public LayoutParams generateLayoutParams(AttributeSet attrs) {
        return new C0255c(getContext(), attrs);
    }
}
