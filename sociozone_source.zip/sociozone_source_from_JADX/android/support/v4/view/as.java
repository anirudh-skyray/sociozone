package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.view.View;
import android.view.View.OnApplyWindowInsetsListener;
import android.view.ViewParent;
import android.view.WindowInsets;

/* compiled from: ViewCompatLollipop */
class as {
    private static ThreadLocal<Rect> f590a;

    public static void m1588a(View view) {
        view.requestApplyInsets();
    }

    public static void m1589a(View view, float elevation) {
        view.setElevation(elevation);
    }

    public static float m1594b(View view) {
        return view.getElevation();
    }

    public static void m1593a(View view, final ac listener) {
        if (listener == null) {
            view.setOnApplyWindowInsetsListener(null);
        } else {
            view.setOnApplyWindowInsetsListener(new OnApplyWindowInsetsListener() {
                public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
                    return ((bj) listener.onApplyWindowInsets(view, new bj(windowInsets))).m1738f();
                }
            });
        }
    }

    static ColorStateList m1597c(View view) {
        return view.getBackgroundTintList();
    }

    static void m1591a(View view, ColorStateList tintList) {
        view.setBackgroundTintList(tintList);
        if (VERSION.SDK_INT == 21) {
            Drawable background = view.getBackground();
            boolean hasTint = (view.getBackgroundTintList() == null || view.getBackgroundTintMode() == null) ? false : true;
            if (background != null && hasTint) {
                if (background.isStateful()) {
                    background.setState(view.getDrawableState());
                }
                view.setBackground(background);
            }
        }
    }

    static Mode m1598d(View view) {
        return view.getBackgroundTintMode();
    }

    static void m1592a(View view, Mode mode) {
        view.setBackgroundTintMode(mode);
        if (VERSION.SDK_INT == 21) {
            Drawable background = view.getBackground();
            boolean hasTint = (view.getBackgroundTintList() == null || view.getBackgroundTintMode() == null) ? false : true;
            if (background != null && hasTint) {
                if (background.isStateful()) {
                    background.setState(view.getDrawableState());
                }
                view.setBackground(background);
            }
        }
    }

    public static bi m1587a(View v, bi insets) {
        if (!(insets instanceof bj)) {
            return insets;
        }
        WindowInsets unwrapped = ((bj) insets).m1738f();
        WindowInsets result = v.onApplyWindowInsets(unwrapped);
        if (result != unwrapped) {
            return new bj(result);
        }
        return insets;
    }

    public static bi m1595b(View v, bi insets) {
        if (!(insets instanceof bj)) {
            return insets;
        }
        WindowInsets unwrapped = ((bj) insets).m1738f();
        WindowInsets result = v.dispatchApplyWindowInsets(unwrapped);
        if (result != unwrapped) {
            return new bj(result);
        }
        return insets;
    }

    public static boolean m1599e(View view) {
        return view.isNestedScrollingEnabled();
    }

    public static void m1600f(View view) {
        view.stopNestedScroll();
    }

    static void m1590a(View view, int offset) {
        Rect parentRect = m1586a();
        boolean needInvalidateWorkaround = false;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View p = (View) parent;
            parentRect.set(p.getLeft(), p.getTop(), p.getRight(), p.getBottom());
            needInvalidateWorkaround = !parentRect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        am.m1554a(view, offset);
        if (needInvalidateWorkaround && parentRect.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(parentRect);
        }
    }

    static void m1596b(View view, int offset) {
        Rect parentRect = m1586a();
        boolean needInvalidateWorkaround = false;
        ViewParent parent = view.getParent();
        if (parent instanceof View) {
            View p = (View) parent;
            parentRect.set(p.getLeft(), p.getTop(), p.getRight(), p.getBottom());
            needInvalidateWorkaround = !parentRect.intersects(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
        }
        am.m1559b(view, offset);
        if (needInvalidateWorkaround && parentRect.intersect(view.getLeft(), view.getTop(), view.getRight(), view.getBottom())) {
            ((View) parent).invalidate(parentRect);
        }
    }

    private static Rect m1586a() {
        if (f590a == null) {
            f590a = new ThreadLocal();
        }
        Rect rect = (Rect) f590a.get();
        if (rect == null) {
            rect = new Rect();
            f590a.set(rect);
        }
        rect.setEmpty();
        return rect;
    }
}
