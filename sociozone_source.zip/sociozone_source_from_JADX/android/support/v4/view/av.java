package android.support.v4.view;

import android.view.ViewConfiguration;

/* compiled from: ViewConfigurationCompatFroyo */
class av {
    public static int m1613a(ViewConfiguration config) {
        return config.getScaledPagingTouchSlop();
    }
}
