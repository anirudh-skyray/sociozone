package android.support.v4.view;

import android.os.Bundle;
import android.view.View;
import android.view.View.AccessibilityDelegate;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;

/* compiled from: AccessibilityDelegateCompatJellyBean */
class C0363c {

    /* compiled from: AccessibilityDelegateCompatJellyBean */
    public interface C0268a {
        Object mo183a(View view);

        void mo184a(View view, int i);

        void mo185a(View view, Object obj);

        boolean mo186a(View view, int i, Bundle bundle);

        boolean mo187a(View view, AccessibilityEvent accessibilityEvent);

        boolean mo188a(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent);

        void mo189b(View view, AccessibilityEvent accessibilityEvent);

        void mo190c(View view, AccessibilityEvent accessibilityEvent);

        void mo191d(View view, AccessibilityEvent accessibilityEvent);
    }

    public static Object m1739a(final C0268a bridge) {
        return new AccessibilityDelegate() {
            public boolean dispatchPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                return bridge.mo187a(host, event);
            }

            public void onInitializeAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo189b(host, event);
            }

            public void onInitializeAccessibilityNodeInfo(View host, AccessibilityNodeInfo info) {
                bridge.mo185a(host, (Object) info);
            }

            public void onPopulateAccessibilityEvent(View host, AccessibilityEvent event) {
                bridge.mo190c(host, event);
            }

            public boolean onRequestSendAccessibilityEvent(ViewGroup host, View child, AccessibilityEvent event) {
                return bridge.mo188a(host, child, event);
            }

            public void sendAccessibilityEvent(View host, int eventType) {
                bridge.mo184a(host, eventType);
            }

            public void sendAccessibilityEventUnchecked(View host, AccessibilityEvent event) {
                bridge.mo191d(host, event);
            }

            public AccessibilityNodeProvider getAccessibilityNodeProvider(View host) {
                return (AccessibilityNodeProvider) bridge.mo183a(host);
            }

            public boolean performAccessibilityAction(View host, int action, Bundle args) {
                return bridge.mo186a(host, action, args);
            }
        };
    }

    public static Object m1740a(Object delegate, View host) {
        return ((AccessibilityDelegate) delegate).getAccessibilityNodeProvider(host);
    }

    public static boolean m1741a(Object delegate, View host, int action, Bundle args) {
        return ((AccessibilityDelegate) delegate).performAccessibilityAction(host, action, args);
    }
}
