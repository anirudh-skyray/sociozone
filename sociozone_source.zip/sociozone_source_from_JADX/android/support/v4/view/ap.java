package android.support.v4.view;

import android.view.View;
import android.view.ViewParent;

/* compiled from: ViewCompatJB */
class ap {
    public static void m1572a(View view) {
        view.postInvalidateOnAnimation();
    }

    public static void m1574a(View view, Runnable action) {
        view.postOnAnimation(action);
    }

    public static void m1575a(View view, Runnable action, long delayMillis) {
        view.postOnAnimationDelayed(action, delayMillis);
    }

    public static int m1576b(View view) {
        return view.getImportantForAccessibility();
    }

    public static void m1573a(View view, int mode) {
        view.setImportantForAccessibility(mode);
    }

    public static ViewParent m1577c(View view) {
        return view.getParentForAccessibility();
    }

    public static int m1578d(View view) {
        return view.getMinimumHeight();
    }

    public static void m1579e(View view) {
        view.requestFitSystemWindows();
    }

    public static boolean m1580f(View view) {
        return view.getFitsSystemWindows();
    }

    public static boolean m1581g(View view) {
        return view.hasOverlappingRendering();
    }
}
