package android.support.v4.view;

import android.view.MotionEvent;

/* compiled from: MotionEventCompatGingerbread */
class C0410w {
    public static int m1857a(MotionEvent event) {
        return event.getSource();
    }
}
