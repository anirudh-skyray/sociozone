package android.support.v4.view;

import android.view.WindowInsets;

/* compiled from: WindowInsetsCompatApi21 */
class bj extends bi {
    private final WindowInsets f616a;

    bj(WindowInsets source) {
        this.f616a = source;
    }

    public int mo326a() {
        return this.f616a.getSystemWindowInsetLeft();
    }

    public int mo328b() {
        return this.f616a.getSystemWindowInsetTop();
    }

    public int mo329c() {
        return this.f616a.getSystemWindowInsetRight();
    }

    public int mo330d() {
        return this.f616a.getSystemWindowInsetBottom();
    }

    public boolean mo331e() {
        return this.f616a.isConsumed();
    }

    public bi mo327a(int left, int top, int right, int bottom) {
        return new bj(this.f616a.replaceSystemWindowInsets(left, top, right, bottom));
    }

    WindowInsets m1738f() {
        return this.f616a;
    }
}
