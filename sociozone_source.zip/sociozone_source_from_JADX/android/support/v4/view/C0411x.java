package android.support.v4.view;

import android.view.MotionEvent;

/* compiled from: MotionEventCompatHoneycombMr1 */
class C0411x {
    static float m1858a(MotionEvent event, int axis) {
        return event.getAxisValue(axis);
    }
}
