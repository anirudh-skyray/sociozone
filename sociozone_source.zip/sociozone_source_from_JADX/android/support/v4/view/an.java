package android.support.v4.view;

import android.view.View;
import android.view.View.AccessibilityDelegate;

/* compiled from: ViewCompatICS */
class an {
    public static boolean m1569a(View v, int direction) {
        return v.canScrollHorizontally(direction);
    }

    public static boolean m1570b(View v, int direction) {
        return v.canScrollVertically(direction);
    }

    public static void m1568a(View v, Object delegate) {
        v.setAccessibilityDelegate((AccessibilityDelegate) delegate);
    }
}
