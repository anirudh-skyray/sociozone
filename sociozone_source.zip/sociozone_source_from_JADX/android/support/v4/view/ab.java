package android.support.v4.view;

import android.view.View;
import android.view.ViewGroup;

/* compiled from: NestedScrollingParentHelper */
public class ab {
    private final ViewGroup f578a;
    private int f579b;

    public ab(ViewGroup viewGroup) {
        this.f578a = viewGroup;
    }

    public void m1301a(View child, View target, int axes) {
        this.f579b = axes;
    }

    public int m1299a() {
        return this.f579b;
    }

    public void m1300a(View target) {
        this.f579b = 0;
    }
}
