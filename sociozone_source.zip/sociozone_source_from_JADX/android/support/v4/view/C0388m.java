package android.support.v4.view;

import android.support.v4.view.C0387l.C0386a;
import android.view.LayoutInflater;

/* compiled from: LayoutInflaterCompatLollipop */
class C0388m {
    static void m1778a(LayoutInflater inflater, C0175n factory) {
        inflater.setFactory2(factory != null ? new C0386a(factory) : null);
    }
}
