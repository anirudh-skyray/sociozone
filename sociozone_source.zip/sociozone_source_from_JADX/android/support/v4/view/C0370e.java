package android.support.v4.view;

import android.os.Build.VERSION;

/* compiled from: GravityCompat */
public final class C0370e {
    static final C0367a f618a;

    /* compiled from: GravityCompat */
    interface C0367a {
        int mo332a(int i, int i2);
    }

    /* compiled from: GravityCompat */
    static class C0368b implements C0367a {
        C0368b() {
        }

        public int mo332a(int gravity, int layoutDirection) {
            return -8388609 & gravity;
        }
    }

    /* compiled from: GravityCompat */
    static class C0369c implements C0367a {
        C0369c() {
        }

        public int mo332a(int gravity, int layoutDirection) {
            return C0371f.m1746a(gravity, layoutDirection);
        }
    }

    static {
        if (VERSION.SDK_INT >= 17) {
            f618a = new C0369c();
        } else {
            f618a = new C0368b();
        }
    }

    public static int m1745a(int gravity, int layoutDirection) {
        return f618a.mo332a(gravity, layoutDirection);
    }
}
