package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.animation.Interpolator;
import java.lang.ref.WeakReference;
import java.util.WeakHashMap;

/* compiled from: ViewPropertyAnimatorCompat */
public final class bb {
    static final C0351g f605a;
    private WeakReference<View> f606b;
    private Runnable f607c = null;
    private Runnable f608d = null;
    private int f609e = -1;

    /* compiled from: ViewPropertyAnimatorCompat */
    interface C0351g {
        long mo313a(bb bbVar, View view);

        void mo314a(bb bbVar, View view, float f);

        void mo315a(bb bbVar, View view, long j);

        void mo316a(bb bbVar, View view, bf bfVar);

        void mo317a(bb bbVar, View view, bh bhVar);

        void mo318a(bb bbVar, View view, Interpolator interpolator);

        void mo319b(bb bbVar, View view);

        void mo320b(bb bbVar, View view, float f);

        void mo321b(bb bbVar, View view, long j);

        void mo322c(bb bbVar, View view);
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    static class C0352a implements C0351g {
        WeakHashMap<View, Runnable> f601a = null;

        /* compiled from: ViewPropertyAnimatorCompat */
        class C0350a implements Runnable {
            WeakReference<View> f598a;
            bb f599b;
            final /* synthetic */ C0352a f600c;

            private C0350a(C0352a c0352a, bb vpa, View view) {
                this.f600c = c0352a;
                this.f598a = new WeakReference(view);
                this.f599b = vpa;
            }

            public void run() {
                View view = (View) this.f598a.get();
                if (view != null) {
                    this.f600c.m1676d(this.f599b, view);
                }
            }
        }

        C0352a() {
        }

        public void mo315a(bb vpa, View view, long value) {
        }

        public void mo314a(bb vpa, View view, float value) {
            m1677e(vpa, view);
        }

        public void mo320b(bb vpa, View view, float value) {
            m1677e(vpa, view);
        }

        public long mo313a(bb vpa, View view) {
            return 0;
        }

        public void mo318a(bb vpa, View view, Interpolator value) {
        }

        public void mo321b(bb vpa, View view, long value) {
        }

        public void mo319b(bb vpa, View view) {
            m1677e(vpa, view);
        }

        public void mo322c(bb vpa, View view) {
            m1675a(view);
            m1676d(vpa, view);
        }

        public void mo316a(bb vpa, View view, bf listener) {
            view.setTag(2113929216, listener);
        }

        public void mo317a(bb vpa, View view, bh listener) {
        }

        private void m1676d(bb vpa, View view) {
            bf listenerTag = view.getTag(2113929216);
            bf listener = null;
            if (listenerTag instanceof bf) {
                listener = listenerTag;
            }
            Runnable startAction = vpa.f607c;
            Runnable endAction = vpa.f608d;
            vpa.f607c = null;
            vpa.f608d = null;
            if (startAction != null) {
                startAction.run();
            }
            if (listener != null) {
                listener.onAnimationStart(view);
                listener.onAnimationEnd(view);
            }
            if (endAction != null) {
                endAction.run();
            }
            if (this.f601a != null) {
                this.f601a.remove(view);
            }
        }

        private void m1675a(View view) {
            if (this.f601a != null) {
                Runnable starter = (Runnable) this.f601a.get(view);
                if (starter != null) {
                    view.removeCallbacks(starter);
                }
            }
        }

        private void m1677e(bb vpa, View view) {
            Runnable runnable = null;
            if (this.f601a != null) {
                runnable = (Runnable) this.f601a.get(view);
            }
            if (runnable == null) {
                runnable = new C0350a(vpa, view);
                if (this.f601a == null) {
                    this.f601a = new WeakHashMap();
                }
                this.f601a.put(view, runnable);
            }
            view.removeCallbacks(runnable);
            view.post(runnable);
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    static class C0354b extends C0352a {
        WeakHashMap<View, Integer> f604b = null;

        /* compiled from: ViewPropertyAnimatorCompat */
        static class C0353a implements bf {
            bb f602a;
            boolean f603b;

            C0353a(bb vpa) {
                this.f602a = vpa;
            }

            public void onAnimationStart(View view) {
                this.f603b = false;
                if (this.f602a.f609e >= 0) {
                    ai.m1495a(view, 2, null);
                }
                if (this.f602a.f607c != null) {
                    Runnable startAction = this.f602a.f607c;
                    this.f602a.f607c = null;
                    startAction.run();
                }
                bf listenerTag = view.getTag(2113929216);
                bf listener = null;
                if (listenerTag instanceof bf) {
                    listener = listenerTag;
                }
                if (listener != null) {
                    listener.onAnimationStart(view);
                }
            }

            public void onAnimationEnd(View view) {
                if (this.f602a.f609e >= 0) {
                    ai.m1495a(view, this.f602a.f609e, null);
                    this.f602a.f609e = -1;
                }
                if (VERSION.SDK_INT >= 16 || !this.f603b) {
                    if (this.f602a.f608d != null) {
                        Runnable endAction = this.f602a.f608d;
                        this.f602a.f608d = null;
                        endAction.run();
                    }
                    bf listenerTag = view.getTag(2113929216);
                    bf listener = null;
                    if (listenerTag instanceof bf) {
                        listener = listenerTag;
                    }
                    if (listener != null) {
                        listener.onAnimationEnd(view);
                    }
                    this.f603b = true;
                }
            }

            public void onAnimationCancel(View view) {
                bf listenerTag = view.getTag(2113929216);
                bf listener = null;
                if (listenerTag instanceof bf) {
                    listener = listenerTag;
                }
                if (listener != null) {
                    listener.onAnimationCancel(view);
                }
            }
        }

        C0354b() {
        }

        public void mo315a(bb vpa, View view, long value) {
            bc.m1717a(view, value);
        }

        public void mo314a(bb vpa, View view, float value) {
            bc.m1716a(view, value);
        }

        public void mo320b(bb vpa, View view, float value) {
            bc.m1721b(view, value);
        }

        public long mo313a(bb vpa, View view) {
            return bc.m1715a(view);
        }

        public void mo318a(bb vpa, View view, Interpolator value) {
            bc.m1719a(view, value);
        }

        public void mo321b(bb vpa, View view, long value) {
            bc.m1722b(view, value);
        }

        public void mo319b(bb vpa, View view) {
            bc.m1720b(view);
        }

        public void mo322c(bb vpa, View view) {
            bc.m1723c(view);
        }

        public void mo316a(bb vpa, View view, bf listener) {
            view.setTag(2113929216, listener);
            bc.m1718a(view, new C0353a(vpa));
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    static class C0355d extends C0354b {
        C0355d() {
        }

        public void mo316a(bb vpa, View view, bf listener) {
            bd.m1724a(view, listener);
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    static class C0356c extends C0355d {
        C0356c() {
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    static class C0357e extends C0356c {
        C0357e() {
        }

        public void mo317a(bb vpa, View view, bh listener) {
            be.m1725a(view, listener);
        }
    }

    /* compiled from: ViewPropertyAnimatorCompat */
    static class C0358f extends C0357e {
        C0358f() {
        }
    }

    bb(View view) {
        this.f606b = new WeakReference(view);
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f605a = new C0358f();
        } else if (version >= 19) {
            f605a = new C0357e();
        } else if (version >= 18) {
            f605a = new C0356c();
        } else if (version >= 16) {
            f605a = new C0355d();
        } else if (version >= 14) {
            f605a = new C0354b();
        } else {
            f605a = new C0352a();
        }
    }

    public bb m1707a(long value) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo315a(this, view, value);
        }
        return this;
    }

    public bb m1706a(float value) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo314a(this, view, value);
        }
        return this;
    }

    public bb m1711b(float value) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo320b(this, view, value);
        }
        return this;
    }

    public long m1705a() {
        View view = (View) this.f606b.get();
        if (view != null) {
            return f605a.mo313a(this, view);
        }
        return 0;
    }

    public bb m1710a(Interpolator value) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo318a(this, view, value);
        }
        return this;
    }

    public bb m1712b(long value) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo321b(this, view, value);
        }
        return this;
    }

    public void m1713b() {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo319b(this, view);
        }
    }

    public void m1714c() {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo322c(this, view);
        }
    }

    public bb m1708a(bf listener) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo316a(this, view, listener);
        }
        return this;
    }

    public bb m1709a(bh listener) {
        View view = (View) this.f606b.get();
        if (view != null) {
            f605a.mo317a(this, view, listener);
        }
        return this;
    }
}
