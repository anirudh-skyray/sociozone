package android.support.v4.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.LayoutInflater.Factory;
import android.view.View;

/* compiled from: LayoutInflaterCompatBase */
class C0385k {

    /* compiled from: LayoutInflaterCompatBase */
    static class C0384a implements Factory {
        final C0175n f621a;

        C0384a(C0175n delegateFactory) {
            this.f621a = delegateFactory;
        }

        public View onCreateView(String name, Context context, AttributeSet attrs) {
            return this.f621a.onCreateView(null, name, context, attrs);
        }

        public String toString() {
            return getClass().getName() + "{" + this.f621a + "}";
        }
    }

    static void m1775a(LayoutInflater inflater, C0175n factory) {
        inflater.setFactory(factory != null ? new C0384a(factory) : null);
    }

    static C0175n m1774a(LayoutInflater inflater) {
        Factory factory = inflater.getFactory();
        if (factory instanceof C0384a) {
            return ((C0384a) factory).f621a;
        }
        return null;
    }
}
