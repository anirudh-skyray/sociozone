package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatGingerbread */
class al {
    public static int m1549a(View v) {
        return v.getOverScrollMode();
    }
}
