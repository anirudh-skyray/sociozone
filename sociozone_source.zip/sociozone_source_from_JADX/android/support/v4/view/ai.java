package android.support.v4.view;

import android.content.res.ColorStateList;
import android.graphics.Paint;
import android.graphics.PorterDuff.Mode;
import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import java.util.WeakHashMap;

/* compiled from: ViewCompat */
public final class ai {
    static final C0315m f585a;

    /* compiled from: ViewCompat */
    interface C0315m {
        int mo252a(int i, int i2, int i3);

        int mo253a(View view);

        bi mo254a(View view, bi biVar);

        void mo255a(View view, float f);

        void mo256a(View view, int i, int i2);

        void mo257a(View view, int i, Paint paint);

        void mo258a(View view, ColorStateList colorStateList);

        void mo259a(View view, Mode mode);

        void mo260a(View view, C0256a c0256a);

        void mo261a(View view, ac acVar);

        void mo262a(View view, Runnable runnable);

        void mo263a(View view, Runnable runnable, long j);

        void mo264a(View view, boolean z);

        void mo265a(ViewGroup viewGroup, boolean z);

        boolean mo266a(View view, int i);

        bi mo267b(View view, bi biVar);

        void mo268b(View view);

        void mo269b(View view, float f);

        void mo270b(View view, boolean z);

        boolean mo271b(View view, int i);

        int mo272c(View view);

        void mo273c(View view, float f);

        void mo274c(View view, int i);

        int mo275d(View view);

        void mo276d(View view, float f);

        void mo277d(View view, int i);

        int mo278e(View view);

        void mo279e(View view, float f);

        void mo280e(View view, int i);

        ViewParent mo281f(View view);

        int mo282g(View view);

        int mo283h(View view);

        boolean mo284i(View view);

        float mo285j(View view);

        float mo286k(View view);

        int mo287l(View view);

        bb mo288m(View view);

        int mo289n(View view);

        void mo290o(View view);

        float mo291p(View view);

        boolean mo292q(View view);

        void mo293r(View view);

        boolean mo294s(View view);

        ColorStateList mo295t(View view);

        Mode mo296u(View view);

        void mo297v(View view);

        boolean mo298w(View view);

        boolean mo299x(View view);

        boolean mo300y(View view);
    }

    /* compiled from: ViewCompat */
    static class C0316a implements C0315m {
        WeakHashMap<View, bb> f583a = null;

        C0316a() {
        }

        public boolean mo266a(View v, int direction) {
            return (v instanceof ae) && m1382a((ae) v, direction);
        }

        public boolean mo271b(View v, int direction) {
            return (v instanceof ae) && m1383b((ae) v, direction);
        }

        public int mo253a(View v) {
            return 2;
        }

        public void mo260a(View v, C0256a delegate) {
        }

        public void mo268b(View view) {
            view.invalidate();
        }

        public void mo262a(View view, Runnable action) {
            view.postDelayed(action, mo301a());
        }

        public void mo263a(View view, Runnable action, long delayMillis) {
            view.postDelayed(action, mo301a() + delayMillis);
        }

        long mo301a() {
            return 10;
        }

        public int mo272c(View view) {
            return 0;
        }

        public void mo274c(View view, int mode) {
        }

        public void mo257a(View view, int layerType, Paint paint) {
        }

        public int mo275d(View view) {
            return 0;
        }

        public int mo278e(View view) {
            return 0;
        }

        public ViewParent mo281f(View view) {
            return view.getParent();
        }

        public int mo252a(int size, int measureSpec, int childMeasuredState) {
            return View.resolveSize(size, measureSpec);
        }

        public int mo282g(View view) {
            return view.getMeasuredWidth();
        }

        public int mo283h(View view) {
            return 0;
        }

        public boolean mo284i(View view) {
            return true;
        }

        public float mo285j(View view) {
            return 0.0f;
        }

        public float mo286k(View view) {
            return 0.0f;
        }

        public int mo287l(View view) {
            return aj.m1546d(view);
        }

        public bb mo288m(View view) {
            return new bb(view);
        }

        public void mo255a(View view, float value) {
        }

        public void mo269b(View view, float value) {
        }

        public void mo273c(View view, float value) {
        }

        public void mo276d(View view, float value) {
        }

        public int mo289n(View view) {
            return 0;
        }

        public void mo290o(View view) {
        }

        public void mo279e(View view, float elevation) {
        }

        public float mo291p(View view) {
            return 0.0f;
        }

        public void mo265a(ViewGroup viewGroup, boolean enabled) {
        }

        public boolean mo292q(View view) {
            return false;
        }

        public void mo293r(View view) {
        }

        public void mo261a(View view, ac listener) {
        }

        public bi mo254a(View v, bi insets) {
            return insets;
        }

        public bi mo267b(View v, bi insets) {
            return insets;
        }

        public void mo264a(View v, boolean enabled) {
        }

        public void mo270b(View view, boolean activated) {
        }

        public boolean mo294s(View view) {
            if (view instanceof C0412y) {
                return ((C0412y) view).isNestedScrollingEnabled();
            }
            return false;
        }

        public ColorStateList mo295t(View view) {
            return aj.m1539a(view);
        }

        public void mo258a(View view, ColorStateList tintList) {
            aj.m1541a(view, tintList);
        }

        public void mo259a(View view, Mode mode) {
            aj.m1542a(view, mode);
        }

        public Mode mo296u(View view) {
            return aj.m1543b(view);
        }

        private boolean m1382a(ae view, int direction) {
            int offset = view.computeHorizontalScrollOffset();
            int range = view.computeHorizontalScrollRange() - view.computeHorizontalScrollExtent();
            if (range == 0) {
                return false;
            }
            if (direction < 0) {
                if (offset <= 0) {
                    return false;
                }
                return true;
            } else if (offset >= range - 1) {
                return false;
            } else {
                return true;
            }
        }

        private boolean m1383b(ae view, int direction) {
            int offset = view.computeVerticalScrollOffset();
            int range = view.computeVerticalScrollRange() - view.computeVerticalScrollExtent();
            if (range == 0) {
                return false;
            }
            if (direction < 0) {
                if (offset <= 0) {
                    return false;
                }
                return true;
            } else if (offset >= range - 1) {
                return false;
            } else {
                return true;
            }
        }

        public void mo297v(View view) {
            if (view instanceof C0412y) {
                ((C0412y) view).stopNestedScroll();
            }
        }

        public boolean mo298w(View view) {
            return aj.m1545c(view);
        }

        public boolean mo299x(View view) {
            return aj.m1547e(view);
        }

        public boolean mo300y(View view) {
            return false;
        }

        public void mo256a(View view, int indicators, int mask) {
        }

        public void mo277d(View view, int offset) {
            aj.m1544b(view, offset);
        }

        public void mo280e(View view, int offset) {
            aj.m1540a(view, offset);
        }
    }

    /* compiled from: ViewCompat */
    static class C0317b extends C0316a {
        C0317b() {
        }

        public void mo265a(ViewGroup viewGroup, boolean enabled) {
            ak.m1548a(viewGroup, enabled);
        }
    }

    /* compiled from: ViewCompat */
    static class C0318c extends C0317b {
        C0318c() {
        }

        public int mo253a(View v) {
            return al.m1549a(v);
        }
    }

    /* compiled from: ViewCompat */
    static class C0319d extends C0318c {
        C0319d() {
        }

        long mo301a() {
            return am.m1552a();
        }

        public void mo257a(View view, int layerType, Paint paint) {
            am.m1555a(view, layerType, paint);
        }

        public int mo275d(View view) {
            return am.m1551a(view);
        }

        public int mo252a(int size, int measureSpec, int childMeasuredState) {
            return am.m1550a(size, measureSpec, childMeasuredState);
        }

        public int mo282g(View view) {
            return am.m1557b(view);
        }

        public int mo283h(View view) {
            return am.m1561c(view);
        }

        public float mo285j(View view) {
            return am.m1563d(view);
        }

        public void mo255a(View view, float value) {
            am.m1553a(view, value);
        }

        public void mo269b(View view, float value) {
            am.m1558b(view, value);
        }

        public void mo273c(View view, float value) {
            am.m1562c(view, value);
        }

        public void mo276d(View view, float value) {
            am.m1564d(view, value);
        }

        public float mo286k(View view) {
            return am.m1565e(view);
        }

        public void mo293r(View view) {
            am.m1566f(view);
        }

        public void mo264a(View view, boolean enabled) {
            am.m1556a(view, enabled);
        }

        public void mo270b(View view, boolean activated) {
            am.m1560b(view, activated);
        }

        public void mo277d(View view, int offset) {
            am.m1559b(view, offset);
        }

        public void mo280e(View view, int offset) {
            am.m1554a(view, offset);
        }
    }

    /* compiled from: ViewCompat */
    static class C0320f extends C0319d {
        static boolean f584b = false;

        C0320f() {
        }

        public boolean mo266a(View v, int direction) {
            return an.m1569a(v, direction);
        }

        public boolean mo271b(View v, int direction) {
            return an.m1570b(v, direction);
        }

        public void mo260a(View v, C0256a delegate) {
            an.m1568a(v, delegate == null ? null : delegate.m891a());
        }

        public bb mo288m(View view) {
            if (this.a == null) {
                this.a = new WeakHashMap();
            }
            bb vpa = (bb) this.a.get(view);
            if (vpa != null) {
                return vpa;
            }
            vpa = new bb(view);
            this.a.put(view, vpa);
            return vpa;
        }
    }

    /* compiled from: ViewCompat */
    static class C0321e extends C0320f {
        C0321e() {
        }

        public boolean mo300y(View view) {
            return ao.m1571a(view);
        }
    }

    /* compiled from: ViewCompat */
    static class C0322g extends C0321e {
        C0322g() {
        }

        public void mo268b(View view) {
            ap.m1572a(view);
        }

        public void mo262a(View view, Runnable action) {
            ap.m1574a(view, action);
        }

        public void mo263a(View view, Runnable action, long delayMillis) {
            ap.m1575a(view, action, delayMillis);
        }

        public int mo272c(View view) {
            return ap.m1576b(view);
        }

        public void mo274c(View view, int mode) {
            if (mode == 4) {
                mode = 2;
            }
            ap.m1573a(view, mode);
        }

        public ViewParent mo281f(View view) {
            return ap.m1577c(view);
        }

        public int mo287l(View view) {
            return ap.m1578d(view);
        }

        public void mo290o(View view) {
            ap.m1579e(view);
        }

        public boolean mo292q(View view) {
            return ap.m1580f(view);
        }

        public boolean mo284i(View view) {
            return ap.m1581g(view);
        }
    }

    /* compiled from: ViewCompat */
    static class C0323h extends C0322g {
        C0323h() {
        }

        public int mo278e(View view) {
            return aq.m1582a(view);
        }

        public int mo289n(View view) {
            return aq.m1583b(view);
        }
    }

    /* compiled from: ViewCompat */
    static class C0324i extends C0323h {
        C0324i() {
        }
    }

    /* compiled from: ViewCompat */
    static class C0325j extends C0324i {
        C0325j() {
        }

        public void mo274c(View view, int mode) {
            ap.m1573a(view, mode);
        }

        public boolean mo298w(View view) {
            return ar.m1584a(view);
        }

        public boolean mo299x(View view) {
            return ar.m1585b(view);
        }
    }

    /* compiled from: ViewCompat */
    static class C0326k extends C0325j {
        C0326k() {
        }

        public void mo290o(View view) {
            as.m1588a(view);
        }

        public void mo279e(View view, float elevation) {
            as.m1589a(view, elevation);
        }

        public float mo291p(View view) {
            return as.m1594b(view);
        }

        public void mo261a(View view, ac listener) {
            as.m1593a(view, listener);
        }

        public boolean mo294s(View view) {
            return as.m1599e(view);
        }

        public void mo297v(View view) {
            as.m1600f(view);
        }

        public ColorStateList mo295t(View view) {
            return as.m1597c(view);
        }

        public void mo258a(View view, ColorStateList tintList) {
            as.m1591a(view, tintList);
        }

        public void mo259a(View view, Mode mode) {
            as.m1592a(view, mode);
        }

        public Mode mo296u(View view) {
            return as.m1598d(view);
        }

        public bi mo254a(View v, bi insets) {
            return as.m1587a(v, insets);
        }

        public bi mo267b(View v, bi insets) {
            return as.m1595b(v, insets);
        }

        public void mo277d(View view, int offset) {
            as.m1596b(view, offset);
        }

        public void mo280e(View view, int offset) {
            as.m1590a(view, offset);
        }
    }

    /* compiled from: ViewCompat */
    static class C0327l extends C0326k {
        C0327l() {
        }

        public void mo256a(View view, int indicators, int mask) {
            at.m1602a(view, indicators, mask);
        }

        public void mo277d(View view, int offset) {
            at.m1603b(view, offset);
        }

        public void mo280e(View view, int offset) {
            at.m1601a(view, offset);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 23) {
            f585a = new C0327l();
        } else if (version >= 21) {
            f585a = new C0326k();
        } else if (version >= 19) {
            f585a = new C0325j();
        } else if (version >= 17) {
            f585a = new C0323h();
        } else if (version >= 16) {
            f585a = new C0322g();
        } else if (version >= 15) {
            f585a = new C0321e();
        } else if (version >= 14) {
            f585a = new C0320f();
        } else if (version >= 11) {
            f585a = new C0319d();
        } else if (version >= 9) {
            f585a = new C0318c();
        } else if (version >= 7) {
            f585a = new C0317b();
        } else {
            f585a = new C0316a();
        }
    }

    public static boolean m1504a(View v, int direction) {
        return f585a.mo266a(v, direction);
    }

    public static boolean m1509b(View v, int direction) {
        return f585a.mo271b(v, direction);
    }

    public static int m1491a(View v) {
        return f585a.mo253a(v);
    }

    public static void m1498a(View v, C0256a delegate) {
        f585a.mo260a(v, delegate);
    }

    public static void m1506b(View view) {
        f585a.mo268b(view);
    }

    public static void m1500a(View view, Runnable action) {
        f585a.mo262a(view, action);
    }

    public static void m1501a(View view, Runnable action, long delayMillis) {
        f585a.mo263a(view, action, delayMillis);
    }

    public static int m1510c(View view) {
        return f585a.mo272c(view);
    }

    public static void m1512c(View view, int mode) {
        f585a.mo274c(view, mode);
    }

    public static void m1495a(View view, int layerType, Paint paint) {
        f585a.mo257a(view, layerType, paint);
    }

    public static int m1513d(View view) {
        return f585a.mo275d(view);
    }

    public static int m1516e(View view) {
        return f585a.mo278e(view);
    }

    public static ViewParent m1519f(View view) {
        return f585a.mo281f(view);
    }

    public static int m1490a(int size, int measureSpec, int childMeasuredState) {
        return f585a.mo252a(size, measureSpec, childMeasuredState);
    }

    public static int m1520g(View view) {
        return f585a.mo282g(view);
    }

    public static int m1521h(View view) {
        return f585a.mo283h(view);
    }

    public static float m1522i(View view) {
        return f585a.mo285j(view);
    }

    public static int m1523j(View view) {
        return f585a.mo287l(view);
    }

    public static bb m1524k(View view) {
        return f585a.mo288m(view);
    }

    public static void m1493a(View view, float value) {
        f585a.mo255a(view, value);
    }

    public static void m1507b(View view, float value) {
        f585a.mo269b(view, value);
    }

    public static void m1511c(View view, float value) {
        f585a.mo273c(view, value);
    }

    public static void m1514d(View view, float value) {
        f585a.mo276d(view, value);
    }

    public static float m1525l(View view) {
        return f585a.mo286k(view);
    }

    public static void m1517e(View view, float elevation) {
        f585a.mo279e(view, elevation);
    }

    public static float m1526m(View view) {
        return f585a.mo291p(view);
    }

    public static int m1527n(View view) {
        return f585a.mo289n(view);
    }

    public static void m1528o(View view) {
        f585a.mo290o(view);
    }

    public static void m1503a(ViewGroup viewGroup, boolean enabled) {
        f585a.mo265a(viewGroup, enabled);
    }

    public static boolean m1529p(View v) {
        return f585a.mo292q(v);
    }

    public static void m1530q(View v) {
        f585a.mo293r(v);
    }

    public static void m1499a(View v, ac listener) {
        f585a.mo261a(v, listener);
    }

    public static bi m1492a(View view, bi insets) {
        return f585a.mo254a(view, insets);
    }

    public static bi m1505b(View view, bi insets) {
        return f585a.mo267b(view, insets);
    }

    public static void m1502a(View v, boolean enabled) {
        f585a.mo264a(v, enabled);
    }

    public static void m1508b(View view, boolean activated) {
        f585a.mo270b(view, activated);
    }

    public static boolean m1531r(View view) {
        return f585a.mo284i(view);
    }

    public static ColorStateList m1532s(View view) {
        return f585a.mo295t(view);
    }

    public static void m1496a(View view, ColorStateList tintList) {
        f585a.mo258a(view, tintList);
    }

    public static Mode m1533t(View view) {
        return f585a.mo296u(view);
    }

    public static void m1497a(View view, Mode mode) {
        f585a.mo259a(view, mode);
    }

    public static boolean m1534u(View view) {
        return f585a.mo294s(view);
    }

    public static void m1535v(View view) {
        f585a.mo297v(view);
    }

    public static boolean m1536w(View view) {
        return f585a.mo298w(view);
    }

    public static void m1515d(View view, int offset) {
        f585a.mo280e(view, offset);
    }

    public static void m1518e(View view, int offset) {
        f585a.mo277d(view, offset);
    }

    public static boolean m1537x(View view) {
        return f585a.mo299x(view);
    }

    public static boolean m1538y(View view) {
        return f585a.mo300y(view);
    }

    public static void m1494a(View view, int indicators, int mask) {
        f585a.mo256a(view, indicators, mask);
    }
}
