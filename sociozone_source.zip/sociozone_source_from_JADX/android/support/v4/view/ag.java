package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.VelocityTracker;

/* compiled from: VelocityTrackerCompat */
public final class ag {
    static final C0312c f582a;

    /* compiled from: VelocityTrackerCompat */
    interface C0312c {
        float mo250a(VelocityTracker velocityTracker, int i);

        float mo251b(VelocityTracker velocityTracker, int i);
    }

    /* compiled from: VelocityTrackerCompat */
    static class C0313a implements C0312c {
        C0313a() {
        }

        public float mo250a(VelocityTracker tracker, int pointerId) {
            return tracker.getXVelocity();
        }

        public float mo251b(VelocityTracker tracker, int pointerId) {
            return tracker.getYVelocity();
        }
    }

    /* compiled from: VelocityTrackerCompat */
    static class C0314b implements C0312c {
        C0314b() {
        }

        public float mo250a(VelocityTracker tracker, int pointerId) {
            return ah.m1331a(tracker, pointerId);
        }

        public float mo251b(VelocityTracker tracker, int pointerId) {
            return ah.m1332b(tracker, pointerId);
        }
    }

    static {
        if (VERSION.SDK_INT >= 11) {
            f582a = new C0314b();
        } else {
            f582a = new C0313a();
        }
    }

    public static float m1329a(VelocityTracker tracker, int pointerId) {
        return f582a.mo250a(tracker, pointerId);
    }

    public static float m1330b(VelocityTracker tracker, int pointerId) {
        return f582a.mo251b(tracker, pointerId);
    }
}
