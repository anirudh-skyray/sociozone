package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewGroup;

/* compiled from: ViewGroupCompat */
public final class ax {
    static final C0334c f592a;

    /* compiled from: ViewGroupCompat */
    interface C0334c {
        void mo304a(ViewGroup viewGroup, boolean z);
    }

    /* compiled from: ViewGroupCompat */
    static class C0335f implements C0334c {
        C0335f() {
        }

        public void mo304a(ViewGroup group, boolean split) {
        }
    }

    /* compiled from: ViewGroupCompat */
    static class C0336a extends C0335f {
        C0336a() {
        }

        public void mo304a(ViewGroup group, boolean split) {
            ay.m1619a(group, split);
        }
    }

    /* compiled from: ViewGroupCompat */
    static class C0337b extends C0336a {
        C0337b() {
        }
    }

    /* compiled from: ViewGroupCompat */
    static class C0338d extends C0337b {
        C0338d() {
        }
    }

    /* compiled from: ViewGroupCompat */
    static class C0339e extends C0338d {
        C0339e() {
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f592a = new C0339e();
        } else if (version >= 18) {
            f592a = new C0338d();
        } else if (version >= 14) {
            f592a = new C0337b();
        } else if (version >= 11) {
            f592a = new C0336a();
        } else {
            f592a = new C0335f();
        }
    }

    public static void m1618a(ViewGroup group, boolean split) {
        f592a.mo304a(group, split);
    }
}
