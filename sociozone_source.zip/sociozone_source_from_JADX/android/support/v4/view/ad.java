package android.support.v4.view;

import android.database.DataSetObservable;
import android.database.DataSetObserver;
import android.os.Parcelable;
import android.view.View;
import android.view.ViewGroup;

/* compiled from: PagerAdapter */
public abstract class ad {
    private final DataSetObservable f580a = new DataSetObservable();
    private DataSetObserver f581b;

    public abstract int mo1163a();

    public abstract boolean mo1167a(View view, Object obj);

    public void m1311a(ViewGroup container) {
        m1309a((View) container);
    }

    public Object mo1165a(ViewGroup container, int position) {
        return m1305a((View) container, position);
    }

    public void mo1166a(ViewGroup container, int position, Object object) {
        m1310a((View) container, position, object);
    }

    public void m1320b(ViewGroup container, int position, Object object) {
        m1318b((View) container, position, object);
    }

    public void m1319b(ViewGroup container) {
        m1317b((View) container);
    }

    public void m1309a(View container) {
    }

    public Object m1305a(View container, int position) {
        throw new UnsupportedOperationException("Required method instantiateItem was not overridden");
    }

    public void m1310a(View container, int position, Object object) {
        throw new UnsupportedOperationException("Required method destroyItem was not overridden");
    }

    public void m1318b(View container, int position, Object object) {
    }

    public void m1317b(View container) {
    }

    public Parcelable m1315b() {
        return null;
    }

    public void m1308a(Parcelable state, ClassLoader loader) {
    }

    public int m1303a(Object object) {
        return -1;
    }

    public void m1321c() {
        synchronized (this) {
            if (this.f581b != null) {
                this.f581b.onChanged();
            }
        }
        this.f580a.notifyChanged();
    }

    public void m1307a(DataSetObserver observer) {
        this.f580a.registerObserver(observer);
    }

    public void m1316b(DataSetObserver observer) {
        this.f580a.unregisterObserver(observer);
    }

    void m1322c(DataSetObserver observer) {
        synchronized (this) {
            this.f581b = observer;
        }
    }

    public CharSequence mo1164a(int position) {
        return null;
    }

    public float m1314b(int position) {
        return 1.0f;
    }
}
