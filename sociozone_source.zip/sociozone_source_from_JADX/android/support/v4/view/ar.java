package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatKitKat */
class ar {
    public static boolean m1584a(View view) {
        return view.isLaidOut();
    }

    public static boolean m1585b(View view) {
        return view.isAttachedToWindow();
    }
}
