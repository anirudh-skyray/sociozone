package android.support.v4.view.p013b;

import android.view.animation.Interpolator;

/* compiled from: LookupTableInterpolator */
abstract class C0346b implements Interpolator {
    private final float[] f595a;
    private final float f596b = (1.0f / ((float) (this.f595a.length - 1)));

    public C0346b(float[] values) {
        this.f595a = values;
    }

    public float getInterpolation(float input) {
        if (input >= 1.0f) {
            return 1.0f;
        }
        if (input <= 0.0f) {
            return 0.0f;
        }
        int position = Math.min((int) (((float) (this.f595a.length - 1)) * input), this.f595a.length - 2);
        return this.f595a[position] + ((this.f595a[position + 1] - this.f595a[position]) * ((input - (((float) position) * this.f596b)) / this.f596b));
    }
}
