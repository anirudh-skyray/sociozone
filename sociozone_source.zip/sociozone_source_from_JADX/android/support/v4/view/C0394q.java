package android.support.v4.view;

/* compiled from: MenuCompat */
public final class C0394q {
    private C0394q() {
    }
}
