package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.ViewGroup.MarginLayoutParams;

/* compiled from: MarginLayoutParamsCompat */
public final class C0392o {
    static final C0389a f624a;

    /* compiled from: MarginLayoutParamsCompat */
    interface C0389a {
        int mo339a(MarginLayoutParams marginLayoutParams);

        int mo340b(MarginLayoutParams marginLayoutParams);
    }

    /* compiled from: MarginLayoutParamsCompat */
    static class C0390b implements C0389a {
        C0390b() {
        }

        public int mo339a(MarginLayoutParams lp) {
            return lp.leftMargin;
        }

        public int mo340b(MarginLayoutParams lp) {
            return lp.rightMargin;
        }
    }

    /* compiled from: MarginLayoutParamsCompat */
    static class C0391c implements C0389a {
        C0391c() {
        }

        public int mo339a(MarginLayoutParams lp) {
            return C0393p.m1787a(lp);
        }

        public int mo340b(MarginLayoutParams lp) {
            return C0393p.m1788b(lp);
        }
    }

    static {
        if (VERSION.SDK_INT >= 17) {
            f624a = new C0391c();
        } else {
            f624a = new C0390b();
        }
    }

    public static int m1785a(MarginLayoutParams lp) {
        return f624a.mo339a(lp);
    }

    public static int m1786b(MarginLayoutParams lp) {
        return f624a.mo340b(lp);
    }
}
