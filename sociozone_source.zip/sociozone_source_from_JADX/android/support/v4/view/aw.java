package android.support.v4.view;

import android.view.ViewConfiguration;

/* compiled from: ViewConfigurationCompatICS */
class aw {
    static boolean m1614a(ViewConfiguration config) {
        return config.hasPermanentMenuKey();
    }
}
