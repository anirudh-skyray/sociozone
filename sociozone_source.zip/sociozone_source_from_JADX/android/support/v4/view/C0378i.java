package android.support.v4.view;

import android.view.KeyEvent;

/* compiled from: KeyEventCompatHoneycomb */
class C0378i {
    public static int m1763a(int metaState) {
        return KeyEvent.normalizeMetaState(metaState);
    }

    public static boolean m1764a(int metaState, int modifiers) {
        return KeyEvent.metaStateHasModifiers(metaState, modifiers);
    }

    public static boolean m1765b(int metaState) {
        return KeyEvent.metaStateHasNoModifiers(metaState);
    }
}
