package android.support.v4.view;

import android.view.MenuItem;
import android.view.View;

/* compiled from: MenuItemCompatHoneycomb */
class C0401s {
    public static void m1818a(MenuItem item, int actionEnum) {
        item.setShowAsAction(actionEnum);
    }

    public static MenuItem m1816a(MenuItem item, View view) {
        return item.setActionView(view);
    }

    public static MenuItem m1819b(MenuItem item, int resId) {
        return item.setActionView(resId);
    }

    public static View m1817a(MenuItem item) {
        return item.getActionView();
    }
}
