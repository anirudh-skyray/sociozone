package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.View;
import android.view.ViewParent;

/* compiled from: ViewParentCompat */
public final class az {
    static final C0340b f593a;

    /* compiled from: ViewParentCompat */
    interface C0340b {
        void mo305a(ViewParent viewParent, View view);

        void mo306a(ViewParent viewParent, View view, int i, int i2, int i3, int i4);

        void mo307a(ViewParent viewParent, View view, int i, int i2, int[] iArr);

        boolean mo308a(ViewParent viewParent, View view, float f, float f2);

        boolean mo309a(ViewParent viewParent, View view, float f, float f2, boolean z);

        boolean mo310a(ViewParent viewParent, View view, View view2, int i);

        void mo311b(ViewParent viewParent, View view, View view2, int i);
    }

    /* compiled from: ViewParentCompat */
    static class C0341e implements C0340b {
        C0341e() {
        }

        public boolean mo310a(ViewParent parent, View child, View target, int nestedScrollAxes) {
            if (parent instanceof aa) {
                return ((aa) parent).onStartNestedScroll(child, target, nestedScrollAxes);
            }
            return false;
        }

        public void mo311b(ViewParent parent, View child, View target, int nestedScrollAxes) {
            if (parent instanceof aa) {
                ((aa) parent).onNestedScrollAccepted(child, target, nestedScrollAxes);
            }
        }

        public void mo305a(ViewParent parent, View target) {
            if (parent instanceof aa) {
                ((aa) parent).onStopNestedScroll(target);
            }
        }

        public void mo306a(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
            if (parent instanceof aa) {
                ((aa) parent).onNestedScroll(target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
            }
        }

        public void mo307a(ViewParent parent, View target, int dx, int dy, int[] consumed) {
            if (parent instanceof aa) {
                ((aa) parent).onNestedPreScroll(target, dx, dy, consumed);
            }
        }

        public boolean mo309a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
            if (parent instanceof aa) {
                return ((aa) parent).onNestedFling(target, velocityX, velocityY, consumed);
            }
            return false;
        }

        public boolean mo308a(ViewParent parent, View target, float velocityX, float velocityY) {
            if (parent instanceof aa) {
                return ((aa) parent).onNestedPreFling(target, velocityX, velocityY);
            }
            return false;
        }
    }

    /* compiled from: ViewParentCompat */
    static class C0342a extends C0341e {
        C0342a() {
        }
    }

    /* compiled from: ViewParentCompat */
    static class C0343c extends C0342a {
        C0343c() {
        }
    }

    /* compiled from: ViewParentCompat */
    static class C0344d extends C0343c {
        C0344d() {
        }

        public boolean mo310a(ViewParent parent, View child, View target, int nestedScrollAxes) {
            return ba.m1662a(parent, child, target, nestedScrollAxes);
        }

        public void mo311b(ViewParent parent, View child, View target, int nestedScrollAxes) {
            ba.m1663b(parent, child, target, nestedScrollAxes);
        }

        public void mo305a(ViewParent parent, View target) {
            ba.m1657a(parent, target);
        }

        public void mo306a(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
            ba.m1658a(parent, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
        }

        public void mo307a(ViewParent parent, View target, int dx, int dy, int[] consumed) {
            ba.m1659a(parent, target, dx, dy, consumed);
        }

        public boolean mo309a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
            return ba.m1661a(parent, target, velocityX, velocityY, consumed);
        }

        public boolean mo308a(ViewParent parent, View target, float velocityX, float velocityY) {
            return ba.m1660a(parent, target, velocityX, velocityY);
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 21) {
            f593a = new C0344d();
        } else if (version >= 19) {
            f593a = new C0343c();
        } else if (version >= 14) {
            f593a = new C0342a();
        } else {
            f593a = new C0341e();
        }
    }

    public static boolean m1646a(ViewParent parent, View child, View target, int nestedScrollAxes) {
        return f593a.mo310a(parent, child, target, nestedScrollAxes);
    }

    public static void m1647b(ViewParent parent, View child, View target, int nestedScrollAxes) {
        f593a.mo311b(parent, child, target, nestedScrollAxes);
    }

    public static void m1641a(ViewParent parent, View target) {
        f593a.mo305a(parent, target);
    }

    public static void m1642a(ViewParent parent, View target, int dxConsumed, int dyConsumed, int dxUnconsumed, int dyUnconsumed) {
        f593a.mo306a(parent, target, dxConsumed, dyConsumed, dxUnconsumed, dyUnconsumed);
    }

    public static void m1643a(ViewParent parent, View target, int dx, int dy, int[] consumed) {
        f593a.mo307a(parent, target, dx, dy, consumed);
    }

    public static boolean m1645a(ViewParent parent, View target, float velocityX, float velocityY, boolean consumed) {
        return f593a.mo309a(parent, target, velocityX, velocityY, consumed);
    }

    public static boolean m1644a(ViewParent parent, View target, float velocityX, float velocityY) {
        return f593a.mo308a(parent, target, velocityX, velocityY);
    }
}
