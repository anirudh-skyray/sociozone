package android.support.v4.view;

import android.view.MotionEvent;

/* compiled from: MotionEventCompatEclair */
class C0409v {
    public static int m1853a(MotionEvent event, int pointerId) {
        return event.findPointerIndex(pointerId);
    }

    public static int m1854b(MotionEvent event, int pointerIndex) {
        return event.getPointerId(pointerIndex);
    }

    public static float m1855c(MotionEvent event, int pointerIndex) {
        return event.getX(pointerIndex);
    }

    public static float m1856d(MotionEvent event, int pointerIndex) {
        return event.getY(pointerIndex);
    }

    public static int m1852a(MotionEvent event) {
        return event.getPointerCount();
    }
}
