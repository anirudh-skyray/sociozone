package android.support.v4.view;

import android.view.View;

/* compiled from: ViewCompatICSMr1 */
class ao {
    public static boolean m1571a(View v) {
        return v.hasOnClickListeners();
    }
}
