package android.support.v4.view;

/* compiled from: NestedScrollingChild */
public interface C0412y {
    boolean isNestedScrollingEnabled();

    void stopNestedScroll();
}
