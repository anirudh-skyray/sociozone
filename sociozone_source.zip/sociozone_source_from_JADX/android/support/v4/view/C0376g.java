package android.support.v4.view;

import android.os.Build.VERSION;
import android.support.v4.app.ag;
import android.view.KeyEvent;

/* compiled from: KeyEventCompat */
public final class C0376g {
    static final C0372d f619a;

    /* compiled from: KeyEventCompat */
    interface C0372d {
        void mo333a(KeyEvent keyEvent);

        boolean mo334a(int i, int i2);

        boolean mo335b(int i);
    }

    /* compiled from: KeyEventCompat */
    static class C0373a implements C0372d {
        C0373a() {
        }

        private static int m1750a(int metaState, int modifiers, int basic, int left, int right) {
            boolean wantBasic;
            boolean wantLeftOrRight = true;
            if ((modifiers & basic) != 0) {
                wantBasic = true;
            } else {
                wantBasic = false;
            }
            int directional = left | right;
            if ((modifiers & directional) == 0) {
                wantLeftOrRight = false;
            }
            if (wantBasic) {
                if (!wantLeftOrRight) {
                    return metaState & (directional ^ -1);
                }
                throw new IllegalArgumentException("bad arguments");
            } else if (wantLeftOrRight) {
                return metaState & (basic ^ -1);
            } else {
                return metaState;
            }
        }

        public int mo336a(int metaState) {
            if ((metaState & 192) != 0) {
                metaState |= 1;
            }
            if ((metaState & 48) != 0) {
                metaState |= 2;
            }
            return metaState & 247;
        }

        public boolean mo334a(int metaState, int modifiers) {
            if (C0373a.m1750a(C0373a.m1750a(mo336a(metaState) & 247, modifiers, 1, 64, ag.FLAG_HIGH_PRIORITY), modifiers, 2, 16, 32) == modifiers) {
                return true;
            }
            return false;
        }

        public boolean mo335b(int metaState) {
            return (mo336a(metaState) & 247) == 0;
        }

        public void mo333a(KeyEvent event) {
        }
    }

    /* compiled from: KeyEventCompat */
    static class C0374b extends C0373a {
        C0374b() {
        }

        public void mo333a(KeyEvent event) {
            C0377h.m1762a(event);
        }
    }

    /* compiled from: KeyEventCompat */
    static class C0375c extends C0374b {
        C0375c() {
        }

        public int mo336a(int metaState) {
            return C0378i.m1763a(metaState);
        }

        public boolean mo334a(int metaState, int modifiers) {
            return C0378i.m1764a(metaState, modifiers);
        }

        public boolean mo335b(int metaState) {
            return C0378i.m1765b(metaState);
        }
    }

    static {
        if (VERSION.SDK_INT >= 11) {
            f619a = new C0375c();
        } else {
            f619a = new C0373a();
        }
    }

    public static boolean m1760a(KeyEvent event, int modifiers) {
        return f619a.mo334a(event.getMetaState(), modifiers);
    }

    public static boolean m1759a(KeyEvent event) {
        return f619a.mo335b(event.getMetaState());
    }

    public static void m1761b(KeyEvent event) {
        f619a.mo333a(event);
    }
}
