package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityNodeInfoCompatJellybeanMr2 */
class C0290f {
    public static String m1233a(Object info) {
        return ((AccessibilityNodeInfo) info).getViewIdResourceName();
    }
}
