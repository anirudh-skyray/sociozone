package android.support.v4.view.p012a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompatKitKat */
class C0303i {

    /* compiled from: AccessibilityNodeProviderCompatKitKat */
    interface C0296a {
        Object mo238a(int i);

        List<Object> mo239a(String str, int i);

        boolean mo240a(int i, int i2, Bundle bundle);

        Object mo241b(int i);
    }

    public static Object m1258a(final C0296a bridge) {
        return new AccessibilityNodeProvider() {
            public AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                return (AccessibilityNodeInfo) bridge.mo238a(virtualViewId);
            }

            public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                return bridge.mo239a(text, virtualViewId);
            }

            public boolean performAction(int virtualViewId, int action, Bundle arguments) {
                return bridge.mo240a(virtualViewId, action, arguments);
            }

            public AccessibilityNodeInfo findFocus(int focus) {
                return (AccessibilityNodeInfo) bridge.mo241b(focus);
            }
        };
    }
}
