package android.support.v4.view.p012a;

import android.os.Build.VERSION;

/* compiled from: AccessibilityRecordCompat */
public class C0309j {
    private static final C0304c f576a;
    private final Object f577b;

    /* compiled from: AccessibilityRecordCompat */
    interface C0304c {
        void mo242a(Object obj, int i);

        void mo243a(Object obj, boolean z);

        void mo244b(Object obj, int i);

        void mo245c(Object obj, int i);

        void mo246d(Object obj, int i);

        void mo247e(Object obj, int i);

        void mo248f(Object obj, int i);

        void mo249g(Object obj, int i);
    }

    /* compiled from: AccessibilityRecordCompat */
    static class C0305e implements C0304c {
        C0305e() {
        }

        public void mo242a(Object record, int fromIndex) {
        }

        public void mo244b(Object record, int itemCount) {
        }

        public void mo248f(Object record, int maxScrollX) {
        }

        public void mo249g(Object record, int maxScrollY) {
        }

        public void mo245c(Object record, int scrollX) {
        }

        public void mo246d(Object record, int scrollY) {
        }

        public void mo243a(Object record, boolean scrollable) {
        }

        public void mo247e(Object record, int toIndex) {
        }
    }

    /* compiled from: AccessibilityRecordCompat */
    static class C0306a extends C0305e {
        C0306a() {
        }

        public void mo242a(Object record, int fromIndex) {
            C0310k.m1291a(record, fromIndex);
        }

        public void mo244b(Object record, int itemCount) {
            C0310k.m1293b(record, itemCount);
        }

        public void mo245c(Object record, int scrollX) {
            C0310k.m1294c(record, scrollX);
        }

        public void mo246d(Object record, int scrollY) {
            C0310k.m1295d(record, scrollY);
        }

        public void mo243a(Object record, boolean scrollable) {
            C0310k.m1292a(record, scrollable);
        }

        public void mo247e(Object record, int toIndex) {
            C0310k.m1296e(record, toIndex);
        }
    }

    /* compiled from: AccessibilityRecordCompat */
    static class C0307b extends C0306a {
        C0307b() {
        }

        public void mo248f(Object record, int maxScrollX) {
            C0311l.m1297a(record, maxScrollX);
        }

        public void mo249g(Object record, int maxScrollY) {
            C0311l.m1298b(record, maxScrollY);
        }
    }

    /* compiled from: AccessibilityRecordCompat */
    static class C0308d extends C0307b {
        C0308d() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 16) {
            f576a = new C0308d();
        } else if (VERSION.SDK_INT >= 15) {
            f576a = new C0307b();
        } else if (VERSION.SDK_INT >= 14) {
            f576a = new C0306a();
        } else {
            f576a = new C0305e();
        }
    }

    public C0309j(Object record) {
        this.f577b = record;
    }

    public void m1284a(boolean scrollable) {
        f576a.mo243a(this.f577b, scrollable);
    }

    public void m1283a(int itemCount) {
        f576a.mo244b(this.f577b, itemCount);
    }

    public void m1285b(int fromIndex) {
        f576a.mo242a(this.f577b, fromIndex);
    }

    public void m1286c(int toIndex) {
        f576a.mo247e(this.f577b, toIndex);
    }

    public void m1287d(int scrollX) {
        f576a.mo245c(this.f577b, scrollX);
    }

    public void m1288e(int scrollY) {
        f576a.mo246d(this.f577b, scrollY);
    }

    public void m1289f(int maxScrollX) {
        f576a.mo248f(this.f577b, maxScrollX);
    }

    public void m1290g(int maxScrollY) {
        f576a.mo249g(this.f577b, maxScrollY);
    }

    public int hashCode() {
        return this.f577b == null ? 0 : this.f577b.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        C0309j other = (C0309j) obj;
        if (this.f577b == null) {
            if (other.f577b != null) {
                return false;
            }
            return true;
        } else if (this.f577b.equals(other.f577b)) {
            return true;
        } else {
            return false;
        }
    }
}
