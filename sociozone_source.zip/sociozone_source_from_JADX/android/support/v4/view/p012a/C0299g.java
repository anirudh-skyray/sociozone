package android.support.v4.view.p012a;

import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.v4.view.p012a.C0301h.C0292a;
import android.support.v4.view.p012a.C0303i.C0296a;
import java.util.ArrayList;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompat */
public class C0299g {
    private static final C0291a f572a;
    private final Object f573b;

    /* compiled from: AccessibilityNodeProviderCompat */
    interface C0291a {
        Object mo237a(C0299g c0299g);
    }

    /* compiled from: AccessibilityNodeProviderCompat */
    static class C0294d implements C0291a {
        C0294d() {
        }

        public Object mo237a(C0299g compat) {
            return null;
        }
    }

    /* compiled from: AccessibilityNodeProviderCompat */
    static class C0295b extends C0294d {
        C0295b() {
        }

        public Object mo237a(final C0299g compat) {
            return C0301h.m1257a(new C0292a(this) {
                final /* synthetic */ C0295b f569b;

                public boolean mo236a(int virtualViewId, int action, Bundle arguments) {
                    return compat.m1255a(virtualViewId, action, arguments);
                }

                public List<Object> mo235a(String text, int virtualViewId) {
                    List<C0286b> compatInfos = compat.m1254a(text, virtualViewId);
                    List<Object> infos = new ArrayList();
                    int infoCount = compatInfos.size();
                    for (int i = 0; i < infoCount; i++) {
                        infos.add(((C0286b) compatInfos.get(i)).m1151a());
                    }
                    return infos;
                }

                public Object mo234a(int virtualViewId) {
                    C0286b compatInfo = compat.m1252a(virtualViewId);
                    if (compatInfo == null) {
                        return null;
                    }
                    return compatInfo.m1151a();
                }
            });
        }
    }

    /* compiled from: AccessibilityNodeProviderCompat */
    static class C0298c extends C0294d {
        C0298c() {
        }

        public Object mo237a(final C0299g compat) {
            return C0303i.m1258a(new C0296a(this) {
                final /* synthetic */ C0298c f571b;

                public boolean mo240a(int virtualViewId, int action, Bundle arguments) {
                    return compat.m1255a(virtualViewId, action, arguments);
                }

                public List<Object> mo239a(String text, int virtualViewId) {
                    List<C0286b> compatInfos = compat.m1254a(text, virtualViewId);
                    List<Object> infos = new ArrayList();
                    int infoCount = compatInfos.size();
                    for (int i = 0; i < infoCount; i++) {
                        infos.add(((C0286b) compatInfos.get(i)).m1151a());
                    }
                    return infos;
                }

                public Object mo238a(int virtualViewId) {
                    C0286b compatInfo = compat.m1252a(virtualViewId);
                    if (compatInfo == null) {
                        return null;
                    }
                    return compatInfo.m1151a();
                }

                public Object mo241b(int focus) {
                    C0286b compatInfo = compat.m1256b(focus);
                    if (compatInfo == null) {
                        return null;
                    }
                    return compatInfo.m1151a();
                }
            });
        }
    }

    static {
        if (VERSION.SDK_INT >= 19) {
            f572a = new C0298c();
        } else if (VERSION.SDK_INT >= 16) {
            f572a = new C0295b();
        } else {
            f572a = new C0294d();
        }
    }

    public C0299g() {
        this.f573b = f572a.mo237a(this);
    }

    public C0299g(Object provider) {
        this.f573b = provider;
    }

    public Object m1253a() {
        return this.f573b;
    }

    public C0286b m1252a(int virtualViewId) {
        return null;
    }

    public boolean m1255a(int virtualViewId, int action, Bundle arguments) {
        return false;
    }

    public List<C0286b> m1254a(String text, int virtualViewId) {
        return null;
    }

    public C0286b m1256b(int focus) {
        return null;
    }
}
