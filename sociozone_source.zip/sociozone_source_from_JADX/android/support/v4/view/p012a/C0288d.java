package android.support.v4.view.p012a;

import android.graphics.Rect;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;

/* compiled from: AccessibilityNodeInfoCompatIcs */
class C0288d {
    public static Object m1194a(Object info) {
        return AccessibilityNodeInfo.obtain((AccessibilityNodeInfo) info);
    }

    public static void m1195a(Object info, int action) {
        ((AccessibilityNodeInfo) info).addAction(action);
    }

    public static void m1197a(Object info, View child) {
        ((AccessibilityNodeInfo) info).addChild(child);
    }

    public static int m1200b(Object info) {
        return ((AccessibilityNodeInfo) info).getActions();
    }

    public static void m1196a(Object info, Rect outBounds) {
        ((AccessibilityNodeInfo) info).getBoundsInParent(outBounds);
    }

    public static void m1201b(Object info, Rect outBounds) {
        ((AccessibilityNodeInfo) info).getBoundsInScreen(outBounds);
    }

    public static CharSequence m1205c(Object info) {
        return ((AccessibilityNodeInfo) info).getClassName();
    }

    public static CharSequence m1210d(Object info) {
        return ((AccessibilityNodeInfo) info).getContentDescription();
    }

    public static CharSequence m1213e(Object info) {
        return ((AccessibilityNodeInfo) info).getPackageName();
    }

    public static CharSequence m1215f(Object info) {
        return ((AccessibilityNodeInfo) info).getText();
    }

    public static boolean m1218g(Object info) {
        return ((AccessibilityNodeInfo) info).isCheckable();
    }

    public static boolean m1219h(Object info) {
        return ((AccessibilityNodeInfo) info).isChecked();
    }

    public static boolean m1220i(Object info) {
        return ((AccessibilityNodeInfo) info).isClickable();
    }

    public static boolean m1221j(Object info) {
        return ((AccessibilityNodeInfo) info).isEnabled();
    }

    public static boolean m1222k(Object info) {
        return ((AccessibilityNodeInfo) info).isFocusable();
    }

    public static boolean m1223l(Object info) {
        return ((AccessibilityNodeInfo) info).isFocused();
    }

    public static boolean m1224m(Object info) {
        return ((AccessibilityNodeInfo) info).isLongClickable();
    }

    public static boolean m1225n(Object info) {
        return ((AccessibilityNodeInfo) info).isPassword();
    }

    public static boolean m1226o(Object info) {
        return ((AccessibilityNodeInfo) info).isScrollable();
    }

    public static boolean m1227p(Object info) {
        return ((AccessibilityNodeInfo) info).isSelected();
    }

    public static void m1206c(Object info, Rect bounds) {
        ((AccessibilityNodeInfo) info).setBoundsInParent(bounds);
    }

    public static void m1211d(Object info, Rect bounds) {
        ((AccessibilityNodeInfo) info).setBoundsInScreen(bounds);
    }

    public static void m1198a(Object info, CharSequence className) {
        ((AccessibilityNodeInfo) info).setClassName(className);
    }

    public static void m1199a(Object info, boolean clickable) {
        ((AccessibilityNodeInfo) info).setClickable(clickable);
    }

    public static void m1203b(Object info, CharSequence contentDescription) {
        ((AccessibilityNodeInfo) info).setContentDescription(contentDescription);
    }

    public static void m1204b(Object info, boolean enabled) {
        ((AccessibilityNodeInfo) info).setEnabled(enabled);
    }

    public static void m1209c(Object info, boolean focusable) {
        ((AccessibilityNodeInfo) info).setFocusable(focusable);
    }

    public static void m1212d(Object info, boolean focused) {
        ((AccessibilityNodeInfo) info).setFocused(focused);
    }

    public static void m1214e(Object info, boolean longClickable) {
        ((AccessibilityNodeInfo) info).setLongClickable(longClickable);
    }

    public static void m1208c(Object info, CharSequence packageName) {
        ((AccessibilityNodeInfo) info).setPackageName(packageName);
    }

    public static void m1202b(Object info, View parent) {
        ((AccessibilityNodeInfo) info).setParent(parent);
    }

    public static void m1216f(Object info, boolean scrollable) {
        ((AccessibilityNodeInfo) info).setScrollable(scrollable);
    }

    public static void m1217g(Object info, boolean selected) {
        ((AccessibilityNodeInfo) info).setSelected(selected);
    }

    public static void m1207c(Object info, View source) {
        ((AccessibilityNodeInfo) info).setSource(source);
    }

    public static void m1228q(Object info) {
        ((AccessibilityNodeInfo) info).recycle();
    }
}
