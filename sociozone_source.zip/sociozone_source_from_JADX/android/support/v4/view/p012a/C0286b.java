package android.support.v4.view.p012a;

import android.graphics.Rect;
import android.os.Build.VERSION;
import android.support.v4.app.ag;
import android.view.View;

/* compiled from: AccessibilityNodeInfoCompat */
public class C0286b {
    private static final C0277e f566a;
    private final Object f567b;

    /* compiled from: AccessibilityNodeInfoCompat */
    public static class C0276a {
        public static final C0276a f543a = new C0276a(1, null);
        public static final C0276a f544b = new C0276a(2, null);
        public static final C0276a f545c = new C0276a(4, null);
        public static final C0276a f546d = new C0276a(8, null);
        public static final C0276a f547e = new C0276a(16, null);
        public static final C0276a f548f = new C0276a(32, null);
        public static final C0276a f549g = new C0276a(64, null);
        public static final C0276a f550h = new C0276a(ag.FLAG_HIGH_PRIORITY, null);
        public static final C0276a f551i = new C0276a(ag.FLAG_LOCAL_ONLY, null);
        public static final C0276a f552j = new C0276a(ag.FLAG_GROUP_SUMMARY, null);
        public static final C0276a f553k = new C0276a(1024, null);
        public static final C0276a f554l = new C0276a(2048, null);
        public static final C0276a f555m = new C0276a(4096, null);
        public static final C0276a f556n = new C0276a(8192, null);
        public static final C0276a f557o = new C0276a(16384, null);
        public static final C0276a f558p = new C0276a(32768, null);
        public static final C0276a f559q = new C0276a(65536, null);
        public static final C0276a f560r = new C0276a(131072, null);
        public static final C0276a f561s = new C0276a(262144, null);
        public static final C0276a f562t = new C0276a(524288, null);
        public static final C0276a f563u = new C0276a(1048576, null);
        public static final C0276a f564v = new C0276a(2097152, null);
        private final Object f565w;

        public C0276a(int actionId, CharSequence label) {
            this(C0286b.f566a.mo192a(actionId, label));
        }

        private C0276a(Object action) {
            this.f565w = action;
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    interface C0277e {
        Object mo192a(int i, CharSequence charSequence);

        Object mo193a(Object obj);

        void mo194a(Object obj, int i);

        void mo195a(Object obj, Rect rect);

        void mo196a(Object obj, View view);

        void mo197a(Object obj, CharSequence charSequence);

        void mo198a(Object obj, boolean z);

        boolean mo199a(Object obj, Object obj2);

        int mo200b(Object obj);

        void mo201b(Object obj, Rect rect);

        void mo202b(Object obj, View view);

        void mo203b(Object obj, CharSequence charSequence);

        void mo204b(Object obj, boolean z);

        CharSequence mo205c(Object obj);

        void mo206c(Object obj, Rect rect);

        void mo207c(Object obj, View view);

        void mo208c(Object obj, CharSequence charSequence);

        void mo209c(Object obj, boolean z);

        CharSequence mo210d(Object obj);

        void mo211d(Object obj, Rect rect);

        void mo212d(Object obj, boolean z);

        CharSequence mo213e(Object obj);

        void mo214e(Object obj, boolean z);

        CharSequence mo215f(Object obj);

        void mo216f(Object obj, boolean z);

        void mo217g(Object obj, boolean z);

        boolean mo218g(Object obj);

        void mo219h(Object obj, boolean z);

        boolean mo220h(Object obj);

        void mo221i(Object obj, boolean z);

        boolean mo222i(Object obj);

        boolean mo223j(Object obj);

        boolean mo224k(Object obj);

        boolean mo225l(Object obj);

        boolean mo226m(Object obj);

        boolean mo227n(Object obj);

        boolean mo228o(Object obj);

        boolean mo229p(Object obj);

        void mo230q(Object obj);

        boolean mo231r(Object obj);

        boolean mo232s(Object obj);

        String mo233t(Object obj);
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0278j implements C0277e {
        C0278j() {
        }

        public Object mo192a(int actionId, CharSequence label) {
            return null;
        }

        public Object mo193a(Object info) {
            return null;
        }

        public void mo194a(Object info, int action) {
        }

        public boolean mo199a(Object info, Object action) {
            return false;
        }

        public void mo196a(Object info, View child) {
        }

        public int mo200b(Object info) {
            return 0;
        }

        public void mo195a(Object info, Rect outBounds) {
        }

        public void mo201b(Object info, Rect outBounds) {
        }

        public CharSequence mo205c(Object info) {
            return null;
        }

        public CharSequence mo210d(Object info) {
            return null;
        }

        public CharSequence mo213e(Object info) {
            return null;
        }

        public CharSequence mo215f(Object info) {
            return null;
        }

        public boolean mo218g(Object info) {
            return false;
        }

        public boolean mo220h(Object info) {
            return false;
        }

        public boolean mo222i(Object info) {
            return false;
        }

        public boolean mo223j(Object info) {
            return false;
        }

        public boolean mo224k(Object info) {
            return false;
        }

        public boolean mo225l(Object info) {
            return false;
        }

        public boolean mo231r(Object info) {
            return false;
        }

        public boolean mo232s(Object info) {
            return false;
        }

        public boolean mo226m(Object info) {
            return false;
        }

        public boolean mo227n(Object info) {
            return false;
        }

        public boolean mo228o(Object info) {
            return false;
        }

        public boolean mo229p(Object info) {
            return false;
        }

        public void mo206c(Object info, Rect bounds) {
        }

        public void mo211d(Object info, Rect bounds) {
        }

        public void mo197a(Object info, CharSequence className) {
        }

        public void mo198a(Object info, boolean clickable) {
        }

        public void mo203b(Object info, CharSequence contentDescription) {
        }

        public void mo204b(Object info, boolean enabled) {
        }

        public void mo209c(Object info, boolean focusable) {
        }

        public void mo212d(Object info, boolean focused) {
        }

        public void mo219h(Object info, boolean visibleToUser) {
        }

        public void mo221i(Object info, boolean focused) {
        }

        public void mo214e(Object info, boolean longClickable) {
        }

        public void mo208c(Object info, CharSequence packageName) {
        }

        public void mo202b(Object info, View parent) {
        }

        public void mo216f(Object info, boolean scrollable) {
        }

        public void mo217g(Object info, boolean selected) {
        }

        public void mo207c(Object info, View source) {
        }

        public void mo230q(Object info) {
        }

        public String mo233t(Object info) {
            return null;
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0279d extends C0278j {
        C0279d() {
        }

        public Object mo193a(Object info) {
            return C0288d.m1194a(info);
        }

        public void mo194a(Object info, int action) {
            C0288d.m1195a(info, action);
        }

        public void mo196a(Object info, View child) {
            C0288d.m1197a(info, child);
        }

        public int mo200b(Object info) {
            return C0288d.m1200b(info);
        }

        public void mo195a(Object info, Rect outBounds) {
            C0288d.m1196a(info, outBounds);
        }

        public void mo201b(Object info, Rect outBounds) {
            C0288d.m1201b(info, outBounds);
        }

        public CharSequence mo205c(Object info) {
            return C0288d.m1205c(info);
        }

        public CharSequence mo210d(Object info) {
            return C0288d.m1210d(info);
        }

        public CharSequence mo213e(Object info) {
            return C0288d.m1213e(info);
        }

        public CharSequence mo215f(Object info) {
            return C0288d.m1215f(info);
        }

        public boolean mo218g(Object info) {
            return C0288d.m1218g(info);
        }

        public boolean mo220h(Object info) {
            return C0288d.m1219h(info);
        }

        public boolean mo222i(Object info) {
            return C0288d.m1220i(info);
        }

        public boolean mo223j(Object info) {
            return C0288d.m1221j(info);
        }

        public boolean mo224k(Object info) {
            return C0288d.m1222k(info);
        }

        public boolean mo225l(Object info) {
            return C0288d.m1223l(info);
        }

        public boolean mo226m(Object info) {
            return C0288d.m1224m(info);
        }

        public boolean mo227n(Object info) {
            return C0288d.m1225n(info);
        }

        public boolean mo228o(Object info) {
            return C0288d.m1226o(info);
        }

        public boolean mo229p(Object info) {
            return C0288d.m1227p(info);
        }

        public void mo206c(Object info, Rect bounds) {
            C0288d.m1206c(info, bounds);
        }

        public void mo211d(Object info, Rect bounds) {
            C0288d.m1211d(info, bounds);
        }

        public void mo197a(Object info, CharSequence className) {
            C0288d.m1198a(info, className);
        }

        public void mo198a(Object info, boolean clickable) {
            C0288d.m1199a(info, clickable);
        }

        public void mo203b(Object info, CharSequence contentDescription) {
            C0288d.m1203b(info, contentDescription);
        }

        public void mo204b(Object info, boolean enabled) {
            C0288d.m1204b(info, enabled);
        }

        public void mo209c(Object info, boolean focusable) {
            C0288d.m1209c(info, focusable);
        }

        public void mo212d(Object info, boolean focused) {
            C0288d.m1212d(info, focused);
        }

        public void mo214e(Object info, boolean longClickable) {
            C0288d.m1214e(info, longClickable);
        }

        public void mo208c(Object info, CharSequence packageName) {
            C0288d.m1208c(info, packageName);
        }

        public void mo202b(Object info, View parent) {
            C0288d.m1202b(info, parent);
        }

        public void mo216f(Object info, boolean scrollable) {
            C0288d.m1216f(info, scrollable);
        }

        public void mo217g(Object info, boolean selected) {
            C0288d.m1217g(info, selected);
        }

        public void mo207c(Object info, View source) {
            C0288d.m1207c(info, source);
        }

        public void mo230q(Object info) {
            C0288d.m1228q(info);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0280f extends C0279d {
        C0280f() {
        }

        public boolean mo231r(Object info) {
            return C0289e.m1230a(info);
        }

        public void mo219h(Object info, boolean visibleToUser) {
            C0289e.m1229a(info, visibleToUser);
        }

        public boolean mo232s(Object info) {
            return C0289e.m1232b(info);
        }

        public void mo221i(Object info, boolean focused) {
            C0289e.m1231b(info, focused);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0281g extends C0280f {
        C0281g() {
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0282h extends C0281g {
        C0282h() {
        }

        public String mo233t(Object info) {
            return C0290f.m1233a(info);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0283i extends C0282h {
        C0283i() {
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0284b extends C0283i {
        C0284b() {
        }

        public Object mo192a(int actionId, CharSequence label) {
            return C0287c.m1192a(actionId, label);
        }

        public boolean mo199a(Object info, Object action) {
            return C0287c.m1193a(info, action);
        }
    }

    /* compiled from: AccessibilityNodeInfoCompat */
    static class C0285c extends C0284b {
        C0285c() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 22) {
            f566a = new C0285c();
        } else if (VERSION.SDK_INT >= 21) {
            f566a = new C0284b();
        } else if (VERSION.SDK_INT >= 19) {
            f566a = new C0283i();
        } else if (VERSION.SDK_INT >= 18) {
            f566a = new C0282h();
        } else if (VERSION.SDK_INT >= 17) {
            f566a = new C0281g();
        } else if (VERSION.SDK_INT >= 16) {
            f566a = new C0280f();
        } else if (VERSION.SDK_INT >= 14) {
            f566a = new C0279d();
        } else {
            f566a = new C0278j();
        }
    }

    static C0286b m1148a(Object object) {
        if (object != null) {
            return new C0286b(object);
        }
        return null;
    }

    public C0286b(Object info) {
        this.f567b = info;
    }

    public Object m1151a() {
        return this.f567b;
    }

    public static C0286b m1147a(C0286b info) {
        return C0286b.m1148a(f566a.mo193a(info.f567b));
    }

    public void m1154a(View source) {
        f566a.mo207c(this.f567b, source);
    }

    public void m1160b(View child) {
        f566a.mo196a(this.f567b, child);
    }

    public int m1158b() {
        return f566a.mo200b(this.f567b);
    }

    public void m1152a(int action) {
        f566a.mo194a(this.f567b, action);
    }

    public boolean m1157a(C0276a action) {
        return f566a.mo199a(this.f567b, action.f565w);
    }

    public void m1164c(View parent) {
        f566a.mo202b(this.f567b, parent);
    }

    public void m1153a(Rect outBounds) {
        f566a.mo195a(this.f567b, outBounds);
    }

    public void m1159b(Rect bounds) {
        f566a.mo206c(this.f567b, bounds);
    }

    public void m1163c(Rect outBounds) {
        f566a.mo201b(this.f567b, outBounds);
    }

    public void m1168d(Rect bounds) {
        f566a.mo211d(this.f567b, bounds);
    }

    public boolean m1167c() {
        return f566a.mo218g(this.f567b);
    }

    public boolean m1170d() {
        return f566a.mo220h(this.f567b);
    }

    public boolean m1172e() {
        return f566a.mo224k(this.f567b);
    }

    public void m1156a(boolean focusable) {
        f566a.mo209c(this.f567b, focusable);
    }

    public boolean m1174f() {
        return f566a.mo225l(this.f567b);
    }

    public void m1162b(boolean focused) {
        f566a.mo212d(this.f567b, focused);
    }

    public boolean m1176g() {
        return f566a.mo231r(this.f567b);
    }

    public void m1166c(boolean visibleToUser) {
        f566a.mo219h(this.f567b, visibleToUser);
    }

    public boolean m1178h() {
        return f566a.mo232s(this.f567b);
    }

    public void m1169d(boolean focused) {
        f566a.mo221i(this.f567b, focused);
    }

    public boolean m1180i() {
        return f566a.mo229p(this.f567b);
    }

    public void m1171e(boolean selected) {
        f566a.mo217g(this.f567b, selected);
    }

    public boolean m1181j() {
        return f566a.mo222i(this.f567b);
    }

    public void m1173f(boolean clickable) {
        f566a.mo198a(this.f567b, clickable);
    }

    public boolean m1182k() {
        return f566a.mo226m(this.f567b);
    }

    public void m1175g(boolean longClickable) {
        f566a.mo214e(this.f567b, longClickable);
    }

    public boolean m1183l() {
        return f566a.mo223j(this.f567b);
    }

    public void m1177h(boolean enabled) {
        f566a.mo204b(this.f567b, enabled);
    }

    public boolean m1184m() {
        return f566a.mo227n(this.f567b);
    }

    public boolean m1185n() {
        return f566a.mo228o(this.f567b);
    }

    public void m1179i(boolean scrollable) {
        f566a.mo216f(this.f567b, scrollable);
    }

    public CharSequence m1186o() {
        return f566a.mo213e(this.f567b);
    }

    public void m1155a(CharSequence packageName) {
        f566a.mo208c(this.f567b, packageName);
    }

    public CharSequence m1187p() {
        return f566a.mo205c(this.f567b);
    }

    public void m1161b(CharSequence className) {
        f566a.mo197a(this.f567b, className);
    }

    public CharSequence m1188q() {
        return f566a.mo215f(this.f567b);
    }

    public CharSequence m1189r() {
        return f566a.mo210d(this.f567b);
    }

    public void m1165c(CharSequence contentDescription) {
        f566a.mo203b(this.f567b, contentDescription);
    }

    public void m1190s() {
        f566a.mo230q(this.f567b);
    }

    public String m1191t() {
        return f566a.mo233t(this.f567b);
    }

    public int hashCode() {
        return this.f567b == null ? 0 : this.f567b.hashCode();
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        C0286b other = (C0286b) obj;
        if (this.f567b == null) {
            if (other.f567b != null) {
                return false;
            }
            return true;
        } else if (this.f567b.equals(other.f567b)) {
            return true;
        } else {
            return false;
        }
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append(super.toString());
        Rect bounds = new Rect();
        m1153a(bounds);
        builder.append("; boundsInParent: " + bounds);
        m1163c(bounds);
        builder.append("; boundsInScreen: " + bounds);
        builder.append("; packageName: ").append(m1186o());
        builder.append("; className: ").append(m1187p());
        builder.append("; text: ").append(m1188q());
        builder.append("; contentDescription: ").append(m1189r());
        builder.append("; viewId: ").append(m1191t());
        builder.append("; checkable: ").append(m1167c());
        builder.append("; checked: ").append(m1170d());
        builder.append("; focusable: ").append(m1172e());
        builder.append("; focused: ").append(m1174f());
        builder.append("; selected: ").append(m1180i());
        builder.append("; clickable: ").append(m1181j());
        builder.append("; longClickable: ").append(m1182k());
        builder.append("; enabled: ").append(m1183l());
        builder.append("; password: ").append(m1184m());
        builder.append("; scrollable: " + m1185n());
        builder.append("; [");
        int actionBits = m1158b();
        while (actionBits != 0) {
            int action = 1 << Integer.numberOfTrailingZeros(actionBits);
            actionBits &= action ^ -1;
            builder.append(C0286b.m1149b(action));
            if (actionBits != 0) {
                builder.append(", ");
            }
        }
        builder.append("]");
        return builder.toString();
    }

    private static String m1149b(int action) {
        switch (action) {
            case 1:
                return "ACTION_FOCUS";
            case 2:
                return "ACTION_CLEAR_FOCUS";
            case 4:
                return "ACTION_SELECT";
            case 8:
                return "ACTION_CLEAR_SELECTION";
            case 16:
                return "ACTION_CLICK";
            case 32:
                return "ACTION_LONG_CLICK";
            case 64:
                return "ACTION_ACCESSIBILITY_FOCUS";
            case ag.FLAG_HIGH_PRIORITY /*128*/:
                return "ACTION_CLEAR_ACCESSIBILITY_FOCUS";
            case ag.FLAG_LOCAL_ONLY /*256*/:
                return "ACTION_NEXT_AT_MOVEMENT_GRANULARITY";
            case ag.FLAG_GROUP_SUMMARY /*512*/:
                return "ACTION_PREVIOUS_AT_MOVEMENT_GRANULARITY";
            case 1024:
                return "ACTION_NEXT_HTML_ELEMENT";
            case 2048:
                return "ACTION_PREVIOUS_HTML_ELEMENT";
            case 4096:
                return "ACTION_SCROLL_FORWARD";
            case 8192:
                return "ACTION_SCROLL_BACKWARD";
            case 16384:
                return "ACTION_COPY";
            case 32768:
                return "ACTION_PASTE";
            case 65536:
                return "ACTION_CUT";
            case 131072:
                return "ACTION_SET_SELECTION";
            default:
                return "ACTION_UNKNOWN";
        }
    }
}
