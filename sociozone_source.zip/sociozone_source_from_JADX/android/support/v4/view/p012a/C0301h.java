package android.support.v4.view.p012a;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.util.List;

/* compiled from: AccessibilityNodeProviderCompatJellyBean */
class C0301h {

    /* compiled from: AccessibilityNodeProviderCompatJellyBean */
    interface C0292a {
        Object mo234a(int i);

        List<Object> mo235a(String str, int i);

        boolean mo236a(int i, int i2, Bundle bundle);
    }

    public static Object m1257a(final C0292a bridge) {
        return new AccessibilityNodeProvider() {
            public AccessibilityNodeInfo createAccessibilityNodeInfo(int virtualViewId) {
                return (AccessibilityNodeInfo) bridge.mo234a(virtualViewId);
            }

            public List<AccessibilityNodeInfo> findAccessibilityNodeInfosByText(String text, int virtualViewId) {
                return bridge.mo235a(text, virtualViewId);
            }

            public boolean performAction(int virtualViewId, int action, Bundle arguments) {
                return bridge.mo236a(virtualViewId, action, arguments);
            }
        };
    }
}
