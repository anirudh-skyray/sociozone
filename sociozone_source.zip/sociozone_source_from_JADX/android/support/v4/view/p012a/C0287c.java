package android.support.v4.view.p012a;

import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeInfo.AccessibilityAction;

/* compiled from: AccessibilityNodeInfoCompatApi21 */
class C0287c {
    public static boolean m1193a(Object info, Object action) {
        return ((AccessibilityNodeInfo) info).removeAction((AccessibilityAction) action);
    }

    static Object m1192a(int actionId, CharSequence label) {
        return new AccessibilityAction(actionId, label);
    }
}
