package android.support.v4.view.p012a;

import android.os.Build.VERSION;
import android.view.accessibility.AccessibilityEvent;

/* compiled from: AccessibilityEventCompat */
public final class C0275a {
    private static final C0271d f542a;

    /* compiled from: AccessibilityEventCompat */
    interface C0271d {
    }

    /* compiled from: AccessibilityEventCompat */
    static class C0272c implements C0271d {
        C0272c() {
        }
    }

    /* compiled from: AccessibilityEventCompat */
    static class C0273a extends C0272c {
        C0273a() {
        }
    }

    /* compiled from: AccessibilityEventCompat */
    static class C0274b extends C0273a {
        C0274b() {
        }
    }

    static {
        if (VERSION.SDK_INT >= 19) {
            f542a = new C0274b();
        } else if (VERSION.SDK_INT >= 14) {
            f542a = new C0273a();
        } else {
            f542a = new C0272c();
        }
    }

    public static C0309j m1019a(AccessibilityEvent event) {
        return new C0309j(event);
    }
}
