package android.support.v4.view;

import android.os.Build.VERSION;
import android.view.MotionEvent;

/* compiled from: MotionEventCompat */
public final class C0408u {
    static final C0403e f626a;

    /* compiled from: MotionEventCompat */
    interface C0403e {
        int mo347a(MotionEvent motionEvent);

        int mo348a(MotionEvent motionEvent, int i);

        int mo349b(MotionEvent motionEvent);

        int mo350b(MotionEvent motionEvent, int i);

        float mo351c(MotionEvent motionEvent, int i);

        float mo352d(MotionEvent motionEvent, int i);

        float mo353e(MotionEvent motionEvent, int i);
    }

    /* compiled from: MotionEventCompat */
    static class C0404a implements C0403e {
        C0404a() {
        }

        public int mo348a(MotionEvent event, int pointerId) {
            if (pointerId == 0) {
                return 0;
            }
            return -1;
        }

        public int mo350b(MotionEvent event, int pointerIndex) {
            if (pointerIndex == 0) {
                return 0;
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        public float mo351c(MotionEvent event, int pointerIndex) {
            if (pointerIndex == 0) {
                return event.getX();
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        public float mo352d(MotionEvent event, int pointerIndex) {
            if (pointerIndex == 0) {
                return event.getY();
            }
            throw new IndexOutOfBoundsException("Pre-Eclair does not support multiple pointers");
        }

        public int mo347a(MotionEvent event) {
            return 1;
        }

        public int mo349b(MotionEvent event) {
            return 0;
        }

        public float mo353e(MotionEvent event, int axis) {
            return 0.0f;
        }
    }

    /* compiled from: MotionEventCompat */
    static class C0405b extends C0404a {
        C0405b() {
        }

        public int mo348a(MotionEvent event, int pointerId) {
            return C0409v.m1853a(event, pointerId);
        }

        public int mo350b(MotionEvent event, int pointerIndex) {
            return C0409v.m1854b(event, pointerIndex);
        }

        public float mo351c(MotionEvent event, int pointerIndex) {
            return C0409v.m1855c(event, pointerIndex);
        }

        public float mo352d(MotionEvent event, int pointerIndex) {
            return C0409v.m1856d(event, pointerIndex);
        }

        public int mo347a(MotionEvent event) {
            return C0409v.m1852a(event);
        }
    }

    /* compiled from: MotionEventCompat */
    static class C0406c extends C0405b {
        C0406c() {
        }

        public int mo349b(MotionEvent event) {
            return C0410w.m1857a(event);
        }
    }

    /* compiled from: MotionEventCompat */
    static class C0407d extends C0406c {
        C0407d() {
        }

        public float mo353e(MotionEvent event, int axis) {
            return C0411x.m1858a(event, axis);
        }
    }

    static {
        if (VERSION.SDK_INT >= 12) {
            f626a = new C0407d();
        } else if (VERSION.SDK_INT >= 9) {
            f626a = new C0406c();
        } else if (VERSION.SDK_INT >= 5) {
            f626a = new C0405b();
        } else {
            f626a = new C0404a();
        }
    }

    public static int m1843a(MotionEvent event) {
        return event.getAction() & 255;
    }

    public static int m1845b(MotionEvent event) {
        return (event.getAction() & 65280) >> 8;
    }

    public static int m1844a(MotionEvent event, int pointerId) {
        return f626a.mo348a(event, pointerId);
    }

    public static int m1846b(MotionEvent event, int pointerIndex) {
        return f626a.mo350b(event, pointerIndex);
    }

    public static float m1847c(MotionEvent event, int pointerIndex) {
        return f626a.mo351c(event, pointerIndex);
    }

    public static float m1849d(MotionEvent event, int pointerIndex) {
        return f626a.mo352d(event, pointerIndex);
    }

    public static int m1848c(MotionEvent event) {
        return f626a.mo347a(event);
    }

    public static int m1850d(MotionEvent event) {
        return f626a.mo349b(event);
    }

    public static float m1851e(MotionEvent event, int axis) {
        return f626a.mo353e(event, axis);
    }
}
