package android.support.v4.content;

import android.content.ComponentName;
import android.content.Intent;

/* compiled from: IntentCompatHoneycomb */
class C0209f {
    public static Intent m770a(ComponentName mainActivity) {
        return Intent.makeMainActivity(mainActivity);
    }
}
