package android.support.v4.content;

import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.util.Log;
import android.util.SparseArray;

/* compiled from: WakefulBroadcastReceiver */
public abstract class C0216j extends BroadcastReceiver {
    private static final SparseArray<WakeLock> f414a = new SparseArray();
    private static int f415b = 1;

    public static ComponentName m791a(Context context, Intent intent) {
        ComponentName comp;
        synchronized (f414a) {
            int id = f415b;
            f415b++;
            if (f415b <= 0) {
                f415b = 1;
            }
            intent.putExtra("android.support.content.wakelockid", id);
            comp = context.startService(intent);
            if (comp == null) {
                comp = null;
            } else {
                WakeLock wl = ((PowerManager) context.getSystemService("power")).newWakeLock(1, "wake:" + comp.flattenToShortString());
                wl.setReferenceCounted(false);
                wl.acquire(60000);
                f414a.put(id, wl);
            }
        }
        return comp;
    }

    public static boolean m792a(Intent intent) {
        int id = intent.getIntExtra("android.support.content.wakelockid", 0);
        if (id == 0) {
            return false;
        }
        synchronized (f414a) {
            WakeLock wl = (WakeLock) f414a.get(id);
            if (wl != null) {
                wl.release();
                f414a.remove(id);
                return true;
            }
            Log.w("WakefulBroadcastReceiver", "No active wake lock id #" + id);
            return true;
        }
    }
}
