package android.support.v4.content;

import android.support.v4.p011e.C0234c;
import java.io.FileDescriptor;
import java.io.PrintWriter;

/* compiled from: Loader */
public class C0210g<D> {
    int f393a;
    C0080b<D> f394b;
    C0079a<D> f395c;
    boolean f396d;
    boolean f397e;
    boolean f398f;
    boolean f399g;
    boolean f400h;

    /* compiled from: Loader */
    public interface C0079a<D> {
    }

    /* compiled from: Loader */
    public interface C0080b<D> {
    }

    public void m773a(int id, C0080b<D> listener) {
        if (this.f394b != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.f394b = listener;
        this.f393a = id;
    }

    public void m775a(C0080b<D> listener) {
        if (this.f394b == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.f394b != listener) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.f394b = null;
        }
    }

    public void m774a(C0079a<D> listener) {
        if (this.f395c != null) {
            throw new IllegalStateException("There is already a listener registered");
        }
        this.f395c = listener;
    }

    public void m778b(C0079a<D> listener) {
        if (this.f395c == null) {
            throw new IllegalStateException("No listener register");
        } else if (this.f395c != listener) {
            throw new IllegalArgumentException("Attempting to unregister the wrong listener");
        } else {
            this.f395c = null;
        }
    }

    public final void m772a() {
        this.f396d = true;
        this.f398f = false;
        this.f397e = false;
        m777b();
    }

    protected void m777b() {
    }

    public void m779c() {
        this.f396d = false;
        m780d();
    }

    protected void m780d() {
    }

    public void m781e() {
        m782f();
        this.f398f = true;
        this.f396d = false;
        this.f397e = false;
        this.f399g = false;
        this.f400h = false;
    }

    protected void m782f() {
    }

    public String m771a(D data) {
        StringBuilder sb = new StringBuilder(64);
        C0234c.m856a(data, sb);
        sb.append("}");
        return sb.toString();
    }

    public String toString() {
        StringBuilder sb = new StringBuilder(64);
        C0234c.m856a(this, sb);
        sb.append(" id=");
        sb.append(this.f393a);
        sb.append("}");
        return sb.toString();
    }

    public void m776a(String prefix, FileDescriptor fd, PrintWriter writer, String[] args) {
        writer.print(prefix);
        writer.print("mId=");
        writer.print(this.f393a);
        writer.print(" mListener=");
        writer.println(this.f394b);
        if (this.f396d || this.f399g || this.f400h) {
            writer.print(prefix);
            writer.print("mStarted=");
            writer.print(this.f396d);
            writer.print(" mContentChanged=");
            writer.print(this.f399g);
            writer.print(" mProcessingChange=");
            writer.println(this.f400h);
        }
        if (this.f397e || this.f398f) {
            writer.print(prefix);
            writer.print("mAbandoned=");
            writer.print(this.f397e);
            writer.print(" mReset=");
            writer.println(this.f398f);
        }
    }
}
