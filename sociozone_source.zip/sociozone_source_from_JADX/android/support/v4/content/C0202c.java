package android.support.v4.content;

import android.content.Context;
import android.content.Intent;

/* compiled from: ContextCompatHoneycomb */
class C0202c {
    static void m764a(Context context, Intent[] intents) {
        context.startActivities(intents);
    }
}
