package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

/* compiled from: ContextCompatJellybean */
class C0203d {
    public static void m765a(Context context, Intent[] intents, Bundle options) {
        context.startActivities(intents, options);
    }
}
