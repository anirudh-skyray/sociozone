package android.support.v4.content;

import android.content.Context;
import android.graphics.drawable.Drawable;

/* compiled from: ContextCompatApi21 */
class C0201b {
    public static Drawable m763a(Context context, int id) {
        return context.getDrawable(id);
    }
}
