package android.support.v4.content;

import android.content.Context;
import android.os.Process;
import android.support.v4.app.C0142f;

/* compiled from: PermissionChecker */
public final class C0215i {
    public static int m790a(Context context, String permission, int pid, int uid, String packageName) {
        if (context.checkPermission(permission, pid, uid) == -1) {
            return -1;
        }
        String op = C0142f.m506a(permission);
        if (op == null) {
            return 0;
        }
        if (packageName == null) {
            String[] packageNames = context.getPackageManager().getPackagesForUid(uid);
            if (packageNames == null || packageNames.length <= 0) {
                return -1;
            }
            packageName = packageNames[0];
        }
        return C0142f.m505a(context, op, packageName) != 0 ? -2 : 0;
    }

    public static int m789a(Context context, String permission) {
        return C0215i.m790a(context, permission, Process.myPid(), Process.myUid(), context.getPackageName());
    }
}
