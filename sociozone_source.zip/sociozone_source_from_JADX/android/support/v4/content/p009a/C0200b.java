package android.support.v4.content.p009a;

import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;

/* compiled from: ResourcesCompatApi21 */
class C0200b {
    public static Drawable m762a(Resources res, int id, Theme theme) throws NotFoundException {
        return res.getDrawable(id, theme);
    }
}
