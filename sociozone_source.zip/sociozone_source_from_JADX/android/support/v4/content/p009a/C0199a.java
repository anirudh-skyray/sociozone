package android.support.v4.content.p009a;

import android.content.res.Resources;
import android.content.res.Resources.NotFoundException;
import android.content.res.Resources.Theme;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;

/* compiled from: ResourcesCompat */
public final class C0199a {
    public static Drawable m761a(Resources res, int id, Theme theme) throws NotFoundException {
        if (VERSION.SDK_INT >= 21) {
            return C0200b.m762a(res, id, theme);
        }
        return res.getDrawable(id);
    }
}
