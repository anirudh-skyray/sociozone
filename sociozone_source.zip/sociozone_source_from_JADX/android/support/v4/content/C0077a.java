package android.support.v4.content;

import android.content.Context;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Process;

/* compiled from: ContextCompat */
public class C0077a {
    public static boolean m249a(Context context, Intent[] intents, Bundle options) {
        int version = VERSION.SDK_INT;
        if (version >= 16) {
            C0203d.m765a(context, intents, options);
            return true;
        } else if (version < 11) {
            return false;
        } else {
            C0202c.m764a(context, intents);
            return true;
        }
    }

    public static final Drawable m248a(Context context, int id) {
        if (VERSION.SDK_INT >= 21) {
            return C0201b.m763a(context, id);
        }
        return context.getResources().getDrawable(id);
    }

    public static int m247a(Context context, String permission) {
        if (permission != null) {
            return context.checkPermission(permission, Process.myPid(), Process.myUid());
        }
        throw new IllegalArgumentException("permission is null");
    }
}
