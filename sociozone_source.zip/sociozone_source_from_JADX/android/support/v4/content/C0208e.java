package android.support.v4.content;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Build.VERSION;

/* compiled from: IntentCompat */
public final class C0208e {
    private static final C0204a f392a;

    /* compiled from: IntentCompat */
    interface C0204a {
        Intent mo147a(ComponentName componentName);
    }

    /* compiled from: IntentCompat */
    static class C0205b implements C0204a {
        C0205b() {
        }

        public Intent mo147a(ComponentName componentName) {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.setComponent(componentName);
            intent.addCategory("android.intent.category.LAUNCHER");
            return intent;
        }
    }

    /* compiled from: IntentCompat */
    static class C0206c extends C0205b {
        C0206c() {
        }

        public Intent mo147a(ComponentName componentName) {
            return C0209f.m770a(componentName);
        }
    }

    /* compiled from: IntentCompat */
    static class C0207d extends C0206c {
        C0207d() {
        }
    }

    static {
        int version = VERSION.SDK_INT;
        if (version >= 15) {
            f392a = new C0207d();
        } else if (version >= 11) {
            f392a = new C0206c();
        } else {
            f392a = new C0205b();
        }
    }

    public static Intent m769a(ComponentName mainActivity) {
        return f392a.mo147a(mainActivity);
    }
}
