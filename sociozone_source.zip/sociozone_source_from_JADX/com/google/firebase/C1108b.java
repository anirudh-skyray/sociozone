package com.google.firebase;

import android.content.Context;
import android.text.TextUtils;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0871f;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.p022a.C0812i;

public final class C1108b {
    private final String f2289a;
    private final String f2290b;
    private final String f2291c;
    private final String f2292d;
    private final String f2293e;
    private final String f2294f;

    private C1108b(String str, String str2, String str3, String str4, String str5, String str6) {
        C0864b.m3459a(!C0812i.m3277a(str), (Object) "ApplicationId must be set.");
        this.f2290b = str;
        this.f2289a = str2;
        this.f2291c = str3;
        this.f2292d = str4;
        this.f2293e = str5;
        this.f2294f = str6;
    }

    public static C1108b m4665a(Context context) {
        C0871f c0871f = new C0871f(context);
        Object a = c0871f.m3526a("google_app_id");
        return TextUtils.isEmpty(a) ? null : new C1108b(a, c0871f.m3526a("google_api_key"), c0871f.m3526a("firebase_database_url"), c0871f.m3526a("ga_trackingId"), c0871f.m3526a("gcm_defaultSenderId"), c0871f.m3526a("google_storage_bucket"));
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof C1108b)) {
            return false;
        }
        C1108b c1108b = (C1108b) obj;
        return ab.m3453a(this.f2290b, c1108b.f2290b) && ab.m3453a(this.f2289a, c1108b.f2289a) && ab.m3453a(this.f2291c, c1108b.f2291c) && ab.m3453a(this.f2292d, c1108b.f2292d) && ab.m3453a(this.f2293e, c1108b.f2293e) && ab.m3453a(this.f2294f, c1108b.f2294f);
    }

    public int hashCode() {
        return ab.m3451a(this.f2290b, this.f2289a, this.f2291c, this.f2292d, this.f2293e, this.f2294f);
    }

    public String toString() {
        return ab.m3452a((Object) this).m3450a("applicationId", this.f2290b).m3450a("apiKey", this.f2289a).m3450a("databaseUrl", this.f2291c).m3450a("gcmSenderId", this.f2293e).m3450a("storageBucket", this.f2294f).toString();
    }
}
