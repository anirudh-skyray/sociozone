package com.google.firebase;

import android.annotation.TargetApi;
import android.app.Application;
import android.content.Context;
import android.support.v4.p011e.C0232a;
import android.util.Log;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.p022a.C0810g;
import com.google.android.gms.p023d.C0944a;
import com.google.android.gms.p023d.C0961b;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicBoolean;

public class C1107a {
    static final Map<String, C1107a> f2275a = new C0232a();
    private static final List<String> f2276b = Arrays.asList(new String[]{"com.google.firebase.auth.FirebaseAuth", "com.google.firebase.iid.FirebaseInstanceId"});
    private static final List<String> f2277c = Collections.singletonList("com.google.firebase.crash.FirebaseCrash");
    private static final List<String> f2278d = Arrays.asList(new String[]{"com.google.android.gms.measurement.AppMeasurement"});
    private static final Set<String> f2279e = Collections.emptySet();
    private static final Object f2280f = new Object();
    private final Context f2281g;
    private final String f2282h;
    private final C1108b f2283i;
    private final AtomicBoolean f2284j = new AtomicBoolean(true);
    private final AtomicBoolean f2285k = new AtomicBoolean();
    private final List<Object> f2286l = new CopyOnWriteArrayList();
    private final List<C1106a> f2287m = new CopyOnWriteArrayList();
    private final List<Object> f2288n = new CopyOnWriteArrayList();

    public interface C1106a {
        void m4652a(boolean z);
    }

    protected C1107a(Context context, String str, C1108b c1108b) {
        this.f2281g = (Context) C0864b.m3454a((Object) context);
        this.f2282h = C0864b.m3456a(str);
        this.f2283i = (C1108b) C0864b.m3454a((Object) c1108b);
    }

    public static C1107a m4653a(Context context) {
        C1108b a = C1108b.m4665a(context);
        return a == null ? null : C1107a.m4654a(context, a);
    }

    public static C1107a m4654a(Context context, C1108b c1108b) {
        return C1107a.m4655a(context, c1108b, "[DEFAULT]");
    }

    public static C1107a m4655a(Context context, C1108b c1108b, String str) {
        Object c1107a;
        C0961b a = C0961b.m3935a(context);
        C1107a.m4659b(context);
        String a2 = C1107a.m4656a(str);
        Object applicationContext = context.getApplicationContext();
        synchronized (f2280f) {
            C0864b.m3459a(!f2275a.containsKey(a2), new StringBuilder(String.valueOf(a2).length() + 33).append("FirebaseApp name ").append(a2).append(" already exists!").toString());
            C0864b.m3455a(applicationContext, (Object) "Application context cannot be null.");
            c1107a = new C1107a(applicationContext, a2, c1108b);
            f2275a.put(a2, c1107a);
        }
        a.m3936a((C1107a) c1107a);
        C1107a.m4657a(C1107a.class, c1107a, f2276b);
        if (c1107a.m4664c()) {
            C1107a.m4657a(C1107a.class, c1107a, f2277c);
            C1107a.m4657a(Context.class, c1107a.m4662a(), f2278d);
        }
        return c1107a;
    }

    private static String m4656a(String str) {
        return str.trim();
    }

    private static <T> void m4657a(Class<T> cls, T t, Iterable<String> iterable) {
        String valueOf;
        for (String valueOf2 : iterable) {
            try {
                Class cls2 = Class.forName(valueOf2);
                Method method = cls2.getMethod("getInstance", new Class[]{cls});
                if ((method.getModifiers() & 9) == 9) {
                    method.invoke(null, new Object[]{t});
                }
                String valueOf3 = String.valueOf(cls2);
                Log.d("FirebaseApp", new StringBuilder(String.valueOf(valueOf3).length() + 13).append("Initialized ").append(valueOf3).append(".").toString());
            } catch (ClassNotFoundException e) {
                if (f2279e.contains(valueOf2)) {
                    throw new IllegalStateException(String.valueOf(valueOf2).concat(" is missing, but is required. Check if it has been removed by Proguard."));
                }
                Log.d("FirebaseApp", String.valueOf(valueOf2).concat(" is not linked. Skipping initialization."));
            } catch (NoSuchMethodException e2) {
                throw new IllegalStateException(String.valueOf(valueOf2).concat("#getInstance has been removed by Proguard. Add keep rule to prevent it."));
            } catch (Throwable e3) {
                Log.wtf("FirebaseApp", "Firebase API initialization failure.", e3);
            } catch (Throwable e4) {
                String str = "FirebaseApp";
                String str2 = "Failed to initialize ";
                valueOf2 = String.valueOf(valueOf2);
                Log.wtf(str, valueOf2.length() != 0 ? str2.concat(valueOf2) : new String(str2), e4);
            }
        }
    }

    public static void m4658a(boolean z) {
        synchronized (f2280f) {
            Iterator it = new ArrayList(f2275a.values()).iterator();
            while (it.hasNext()) {
                C1107a c1107a = (C1107a) it.next();
                if (c1107a.f2284j.get()) {
                    c1107a.m4660b(z);
                }
            }
        }
    }

    @TargetApi(14)
    private static void m4659b(Context context) {
        if (C0810g.m3269c() && (context.getApplicationContext() instanceof Application)) {
            C0944a.m3846a((Application) context.getApplicationContext());
        }
    }

    private void m4660b(boolean z) {
        Log.d("FirebaseApp", "Notifying background state change listeners.");
        for (C1106a a : this.f2287m) {
            a.m4652a(z);
        }
    }

    private void m4661d() {
        C0864b.m3459a(!this.f2285k.get(), (Object) "FirebaseApp was deleted");
    }

    public Context m4662a() {
        m4661d();
        return this.f2281g;
    }

    public String m4663b() {
        m4661d();
        return this.f2282h;
    }

    public boolean m4664c() {
        return "[DEFAULT]".equals(m4663b());
    }

    public boolean equals(Object obj) {
        return !(obj instanceof C1107a) ? false : this.f2282h.equals(((C1107a) obj).m4663b());
    }

    public int hashCode() {
        return this.f2282h.hashCode();
    }

    public String toString() {
        return ab.m3452a((Object) this).m3450a("name", this.f2282h).m3450a("options", this.f2283i).toString();
    }
}
