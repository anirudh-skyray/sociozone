package com.google.android.gms.common;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.support.v4.app.C0159p;
import android.support.v4.app.C0167u;
import com.google.android.gms.common.internal.C0864b;

public class C0856f extends C0159p {
    private Dialog f1620a = null;
    private OnCancelListener f1621b = null;

    public static C0856f m3422a(Dialog dialog, OnCancelListener onCancelListener) {
        C0856f c0856f = new C0856f();
        Dialog dialog2 = (Dialog) C0864b.m3455a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0856f.f1620a = dialog2;
        if (onCancelListener != null) {
            c0856f.f1621b = onCancelListener;
        }
        return c0856f;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.f1621b != null) {
            this.f1621b.onCancel(dialogInterface);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (this.f1620a == null) {
            setShowsDialog(false);
        }
        return this.f1620a;
    }

    public void show(C0167u c0167u, String str) {
        super.show(c0167u, str);
    }
}
