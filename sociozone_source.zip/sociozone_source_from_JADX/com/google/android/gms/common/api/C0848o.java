package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0848o implements Creator<Status> {
    static void m3368a(Status status, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, status.m3321f());
        C0917b.m3679a(parcel, 2, status.m3318c(), false);
        C0917b.m3677a(parcel, 3, status.m3317b(), i, false);
        C0917b.m3673a(parcel, 1000, status.m3319d());
        C0917b.m3670a(parcel, a);
    }

    public Status m3369a(Parcel parcel) {
        PendingIntent pendingIntent = null;
        int i = 0;
        int b = C0916a.m3653b(parcel);
        String str = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 3:
                    pendingIntent = (PendingIntent) C0916a.m3650a(parcel, a, PendingIntent.CREATOR);
                    break;
                case 1000:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new Status(i2, i, str, pendingIntent);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public Status[] m3370a(int i) {
        return new Status[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3369a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3370a(i);
    }
}
