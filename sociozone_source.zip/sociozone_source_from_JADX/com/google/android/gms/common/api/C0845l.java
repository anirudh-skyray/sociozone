package com.google.android.gms.common.api;

import android.content.Context;
import com.google.android.gms.common.api.C0834a.C0820a;
import com.google.android.gms.p023d.C0967e;
import com.google.android.gms.p023d.C1023u;
import com.google.android.gms.p023d.ae;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class C0845l<O extends C0820a> {
    private final Context f1594a;
    private final ae f1595b;
    private final C0834a<O> f1596c;
    private final O f1597d;
    private final C0967e<O> f1598e;
    private final int f1599f;
    private final C1023u f1600g;
    private final AtomicBoolean f1601h;
    private final AtomicInteger f1602i;

    public void m3359a() {
        boolean z = true;
        if (!this.f1601h.getAndSet(true)) {
            this.f1595b.m3859a();
            C1023u c1023u = this.f1600g;
            int i = this.f1599f;
            if (this.f1602i.get() <= 0) {
                z = false;
            }
            c1023u.m4265a(i, z);
        }
    }

    public C0834a<O> m3360b() {
        return this.f1596c;
    }

    public O m3361c() {
        return this.f1597d;
    }

    public C0967e<O> m3362d() {
        return this.f1598e;
    }

    public Context m3363e() {
        return this.f1594a;
    }
}
