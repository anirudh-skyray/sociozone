package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0847n implements Creator<Scope> {
    static void m3365a(Scope scope, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, scope.f1574a);
        C0917b.m3679a(parcel, 2, scope.m3313a(), false);
        C0917b.m3670a(parcel, a);
    }

    public Scope m3366a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        String str = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    str = C0916a.m3664j(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new Scope(i, str);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public Scope[] m3367a(int i) {
        return new Scope[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3366a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3367a(i);
    }
}
