package com.google.android.gms.common.api;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class Status extends AbstractSafeParcelable implements C0819e {
    public static final Creator<Status> CREATOR = new C0848o();
    public static final Status f1576a = new Status(0);
    public static final Status f1577b = new Status(14);
    public static final Status f1578c = new Status(8);
    public static final Status f1579d = new Status(15);
    public static final Status f1580e = new Status(16);
    public static final Status f1581f = new Status(17);
    private final int f1582g;
    private final int f1583h;
    private final String f1584i;
    private final PendingIntent f1585j;

    public Status(int i) {
        this(i, null);
    }

    Status(int i, int i2, String str, PendingIntent pendingIntent) {
        this.f1582g = i;
        this.f1583h = i2;
        this.f1584i = str;
        this.f1585j = pendingIntent;
    }

    public Status(int i, String str) {
        this(1, i, str, null);
    }

    public Status(int i, String str, PendingIntent pendingIntent) {
        this(1, i, str, pendingIntent);
    }

    private String m3315g() {
        return this.f1584i != null ? this.f1584i : C0835b.m3348a(this.f1583h);
    }

    public Status mo897a() {
        return this;
    }

    PendingIntent m3317b() {
        return this.f1585j;
    }

    public String m3318c() {
        return this.f1584i;
    }

    int m3319d() {
        return this.f1582g;
    }

    public boolean m3320e() {
        return this.f1583h <= 0;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof Status)) {
            return false;
        }
        Status status = (Status) obj;
        return this.f1582g == status.f1582g && this.f1583h == status.f1583h && ab.m3453a(this.f1584i, status.f1584i) && ab.m3453a(this.f1585j, status.f1585j);
    }

    public int m3321f() {
        return this.f1583h;
    }

    public int hashCode() {
        return ab.m3451a(Integer.valueOf(this.f1582g), Integer.valueOf(this.f1583h), this.f1584i, this.f1585j);
    }

    public String toString() {
        return ab.m3452a((Object) this).m3450a("statusCode", m3315g()).m3450a("resolution", this.f1585j).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0848o.m3368a(this, parcel, i);
    }
}
