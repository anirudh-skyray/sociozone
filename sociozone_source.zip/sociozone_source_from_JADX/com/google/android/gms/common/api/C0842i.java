package com.google.android.gms.common.api;

public abstract class C0842i<R extends C0819e> {
}
