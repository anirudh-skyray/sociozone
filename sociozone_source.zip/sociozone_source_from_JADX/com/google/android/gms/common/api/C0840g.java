package com.google.android.gms.common.api;

public abstract class C0840g<R extends C0819e> implements C0839f<R> {
    public abstract void m3354a(Status status);

    public abstract void m3355b(R r);
}
