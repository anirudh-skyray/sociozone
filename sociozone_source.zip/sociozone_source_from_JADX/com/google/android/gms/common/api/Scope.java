package com.google.android.gms.common.api;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class Scope extends AbstractSafeParcelable {
    public static final Creator<Scope> CREATOR = new C0847n();
    final int f1574a;
    private final String f1575b;

    Scope(int i, String str) {
        C0864b.m3457a(str, (Object) "scopeUri must not be null or empty");
        this.f1574a = i;
        this.f1575b = str;
    }

    public Scope(String str) {
        this(1, str);
    }

    public String m3313a() {
        return this.f1575b;
    }

    public boolean equals(Object obj) {
        return this == obj ? true : !(obj instanceof Scope) ? false : this.f1575b.equals(((Scope) obj).f1575b);
    }

    public int hashCode() {
        return this.f1575b.hashCode();
    }

    public String toString() {
        return this.f1575b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0847n.m3365a(this, parcel, i);
    }
}
