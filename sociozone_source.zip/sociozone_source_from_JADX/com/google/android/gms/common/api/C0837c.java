package com.google.android.gms.common.api;

public abstract class C0837c<R extends C0819e> {

    public interface C0836a {
        void m3349a(Status status);
    }

    public Integer mo988a() {
        throw new UnsupportedOperationException();
    }

    public abstract void mo989a(C0839f<? super R> c0839f);
}
