package com.google.android.gms.common.api;

public abstract class C0841h<R extends C0819e, S extends C0819e> {
    public Status m3356a(Status status) {
        return status;
    }

    public abstract C0837c<S> m3357a(R r);
}
