package com.google.android.gms.common.api;

import android.support.v4.p011e.C0232a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.p023d.C0967e;

public class C0844j extends C0843k {
    private final ConnectionResult f1593a;

    public C0844j(Status status, C0232a<C0967e<?>, ConnectionResult> c0232a) {
        super(status, c0232a);
        this.f1593a = (ConnectionResult) c0232a.get(c0232a.m845b(0));
    }
}
