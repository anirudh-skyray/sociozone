package com.google.android.gms.common.api;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.p011e.C0232a;
import android.view.View;
import com.google.android.gms.common.C0850b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0834a.C0820a;
import com.google.android.gms.common.api.C0834a.C0820a.C0822c;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.C0834a.C0831h;
import com.google.android.gms.common.api.C0834a.C0832i;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0870e;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.common.internal.C0900l.C0899a;
import com.google.android.gms.p023d.C0971f;
import com.google.android.gms.p023d.C0976h.C0975a;
import com.google.android.gms.p023d.C0984k;
import com.google.android.gms.p023d.C1015q;
import com.google.android.gms.p023d.C1028y;
import com.google.android.gms.p023d.aj;
import com.google.android.gms.p023d.aq;
import com.google.android.gms.p023d.ar;
import com.google.android.gms.p023d.as;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.ReentrantLock;

public abstract class GoogleApiClient {
    private static final Set<GoogleApiClient> f1573a = Collections.newSetFromMap(new WeakHashMap());

    public static final class C0816a {
        private Account f1555a;
        private final Set<Scope> f1556b = new HashSet();
        private final Set<Scope> f1557c = new HashSet();
        private int f1558d;
        private View f1559e;
        private String f1560f;
        private String f1561g;
        private final Map<C0834a<?>, C0899a> f1562h = new C0232a();
        private final Context f1563i;
        private final Map<C0834a<?>, C0820a> f1564j = new C0232a();
        private C1028y f1565k;
        private int f1566l = -1;
        private C0818c f1567m;
        private Looper f1568n;
        private C0850b f1569o = C0850b.m3382a();
        private C0826b<? extends ar, as> f1570p = aq.f1893c;
        private final ArrayList<C0817b> f1571q = new ArrayList();
        private final ArrayList<C0818c> f1572r = new ArrayList();

        public C0816a(Context context) {
            this.f1563i = context;
            this.f1568n = context.getMainLooper();
            this.f1560f = context.getPackageName();
            this.f1561g = context.getClass().getName();
        }

        private static <C extends C0829f, O> C m3289a(C0826b<C, O> c0826b, Object obj, Context context, Looper looper, C0900l c0900l, C0817b c0817b, C0818c c0818c) {
            return c0826b.mo994a(context, looper, c0900l, obj, c0817b, c0818c);
        }

        private static <C extends C0831h, O> C0870e m3290a(C0832i<C, O> c0832i, Object obj, Context context, Looper looper, C0900l c0900l, C0817b c0817b, C0818c c0818c) {
            return new C0870e(context, looper, c0832i.m3340b(), c0817b, c0818c, c0900l, c0832i.m3341b(obj));
        }

        private void m3291a(GoogleApiClient googleApiClient) {
            C0971f.m3978a(this.f1565k).m3981a(this.f1566l, googleApiClient, this.f1567m);
        }

        private GoogleApiClient m3292c() {
            C0900l a = m3297a();
            C0834a c0834a = null;
            Map e = a.m3590e();
            Map c0232a = new C0232a();
            Map c0232a2 = new C0232a();
            ArrayList arrayList = new ArrayList();
            C0834a c0834a2 = null;
            for (C0834a c0834a3 : this.f1564j.keySet()) {
                C0834a c0834a32;
                C0829f a2;
                C0834a c0834a4;
                Object obj = this.f1564j.get(c0834a32);
                int i = 0;
                if (e.get(c0834a32) != null) {
                    i = ((C0899a) e.get(c0834a32)).f1729b ? 1 : 2;
                }
                c0232a.put(c0834a32, Integer.valueOf(i));
                C0817b c0984k = new C0984k(c0834a32, i);
                arrayList.add(c0984k);
                C0834a c0834a5;
                if (c0834a32.m3346e()) {
                    C0832i c = c0834a32.m3344c();
                    c0834a5 = c.m3322a() == 1 ? c0834a32 : c0834a2;
                    a2 = C0816a.m3290a(c, obj, this.f1563i, this.f1568n, a, c0984k, (C0818c) c0984k);
                    c0834a4 = c0834a5;
                } else {
                    C0826b b = c0834a32.m3343b();
                    c0834a5 = b.m3322a() == 1 ? c0834a32 : c0834a2;
                    a2 = C0816a.m3289a(b, obj, this.f1563i, this.f1568n, a, c0984k, (C0818c) c0984k);
                    c0834a4 = c0834a5;
                }
                c0232a2.put(c0834a32.m3345d(), a2);
                if (!a2.m3333f()) {
                    c0834a32 = c0834a;
                } else if (c0834a != null) {
                    String valueOf = String.valueOf(c0834a32.m3347f());
                    String valueOf2 = String.valueOf(c0834a.m3347f());
                    throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot be used with ").append(valueOf2).toString());
                }
                c0834a2 = c0834a4;
                c0834a = c0834a32;
            }
            if (c0834a != null) {
                if (c0834a2 != null) {
                    valueOf = String.valueOf(c0834a.m3347f());
                    valueOf2 = String.valueOf(c0834a2.m3347f());
                    throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 21) + String.valueOf(valueOf2).length()).append(valueOf).append(" cannot be used with ").append(valueOf2).toString());
                }
                C0864b.m3460a(this.f1555a == null, "Must not set an account in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead", c0834a.m3347f());
                C0864b.m3460a(this.f1556b.equals(this.f1557c), "Must not set scopes in GoogleApiClient.Builder when using %s. Set account in GoogleSignInOptions.Builder instead.", c0834a.m3347f());
            }
            return new C1015q(this.f1563i, new ReentrantLock(), this.f1568n, a, this.f1569o, this.f1570p, c0232a, this.f1571q, this.f1572r, c0232a2, this.f1566l, C1015q.m4171a(c0232a2.values(), true), arrayList);
        }

        public C0816a m3293a(Handler handler) {
            C0864b.m3455a((Object) handler, (Object) "Handler must not be null");
            this.f1568n = handler.getLooper();
            return this;
        }

        public C0816a m3294a(C0817b c0817b) {
            C0864b.m3455a((Object) c0817b, (Object) "Listener must not be null");
            this.f1571q.add(c0817b);
            return this;
        }

        public C0816a m3295a(C0818c c0818c) {
            C0864b.m3455a((Object) c0818c, (Object) "Listener must not be null");
            this.f1572r.add(c0818c);
            return this;
        }

        public C0816a m3296a(C0834a<? extends C0822c> c0834a) {
            C0864b.m3455a((Object) c0834a, (Object) "Api must not be null");
            this.f1564j.put(c0834a, null);
            Collection a = c0834a.m3342a().m3323a(null);
            this.f1557c.addAll(a);
            this.f1556b.addAll(a);
            return this;
        }

        public C0900l m3297a() {
            as asVar = as.f1899a;
            if (this.f1564j.containsKey(aq.f1897g)) {
                asVar = (as) this.f1564j.get(aq.f1897g);
            }
            return new C0900l(this.f1555a, this.f1556b, this.f1562h, this.f1558d, this.f1559e, this.f1560f, this.f1561g, asVar);
        }

        public GoogleApiClient m3298b() {
            C0864b.m3463b(!this.f1564j.isEmpty(), "must call addApi() to add at least one API");
            GoogleApiClient c = m3292c();
            synchronized (GoogleApiClient.f1573a) {
                GoogleApiClient.f1573a.add(c);
            }
            if (this.f1566l >= 0) {
                m3291a(c);
            }
            return c;
        }
    }

    public interface C0817b {
        void mo1018a(int i);

        void mo1019a(Bundle bundle);
    }

    public interface C0818c {
        void mo1003a(ConnectionResult connectionResult);
    }

    public Looper mo1045a() {
        throw new UnsupportedOperationException();
    }

    public <C extends C0829f> C mo1046a(C0828d<C> c0828d) {
        throw new UnsupportedOperationException();
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1047a(T t) {
        throw new UnsupportedOperationException();
    }

    public void mo1048a(int i) {
        throw new UnsupportedOperationException();
    }

    public abstract void mo1049a(C0818c c0818c);

    public void mo1050a(aj ajVar) {
        throw new UnsupportedOperationException();
    }

    public abstract void mo1051a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract void mo1052b(C0818c c0818c);

    public void mo1053b(aj ajVar) {
        throw new UnsupportedOperationException();
    }

    public abstract boolean mo1054b();

    public abstract void connect();

    public abstract void disconnect();
}
