package com.google.android.gms.common.api;

import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0859u;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0867i.C0879f;
import com.google.android.gms.common.internal.C0900l;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Collections;
import java.util.List;
import java.util.Set;

public final class C0834a<O extends C0820a> {
    private final C0826b<?, O> f1586a;
    private final C0832i<?, O> f1587b = null;
    private final C0830g<?> f1588c;
    private final C0833j<?> f1589d;
    private final String f1590e;

    public interface C0820a {

        public interface C0821a extends C0820a {
        }

        public interface C0822c extends C0820a {
        }

        public static final class C0823b implements C0822c {
            private C0823b() {
            }
        }

        public interface C0824d extends C0821a, C0822c {
        }
    }

    public static abstract class C0825e<T extends C0827c, O> {
        public int m3322a() {
            return ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        }

        public List<Scope> m3323a(O o) {
            return Collections.emptyList();
        }
    }

    public static abstract class C0826b<T extends C0829f, O> extends C0825e<T, O> {
        public abstract T mo994a(Context context, Looper looper, C0900l c0900l, O o, C0817b c0817b, C0818c c0818c);
    }

    public interface C0827c {
    }

    public static class C0828d<C extends C0827c> {
    }

    public interface C0829f extends C0827c {
        void mo1105a();

        void m3326a(C0879f c0879f);

        void m3327a(C0859u c0859u, Set<Scope> set);

        void m3328a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

        boolean m3329b();

        boolean m3330c();

        boolean mo1118d();

        boolean m3332e();

        boolean m3333f();

        Intent m3334g();

        IBinder m3335h();
    }

    public static final class C0830g<C extends C0829f> extends C0828d<C> {
    }

    public interface C0831h<T extends IInterface> extends C0827c {
        T m3336a(IBinder iBinder);

        String m3337a();

        void m3338a(int i, T t);

        String m3339b();
    }

    public static abstract class C0832i<T extends C0831h, O> extends C0825e<T, O> {
        public abstract int m3340b();

        public abstract T m3341b(O o);
    }

    public static final class C0833j<C extends C0831h> extends C0828d<C> {
    }

    public <C extends C0829f> C0834a(String str, C0826b<C, O> c0826b, C0830g<C> c0830g) {
        C0864b.m3455a((Object) c0826b, (Object) "Cannot construct an Api with a null ClientBuilder");
        C0864b.m3455a((Object) c0830g, (Object) "Cannot construct an Api with a null ClientKey");
        this.f1590e = str;
        this.f1586a = c0826b;
        this.f1588c = c0830g;
        this.f1589d = null;
    }

    public C0825e<?, O> m3342a() {
        return m3346e() ? null : this.f1586a;
    }

    public C0826b<?, O> m3343b() {
        C0864b.m3459a(this.f1586a != null, (Object) "This API was constructed with a SimpleClientBuilder. Use getSimpleClientBuilder");
        return this.f1586a;
    }

    public C0832i<?, O> m3344c() {
        C0864b.m3459a(false, (Object) "This API was constructed with a ClientBuilder. Use getClientBuilder");
        return null;
    }

    public C0828d<?> m3345d() {
        if (this.f1588c != null) {
            return this.f1588c;
        }
        throw new IllegalStateException("This API was constructed with null client keys. This should not be possible.");
    }

    public boolean m3346e() {
        return false;
    }

    public String m3347f() {
        return this.f1590e;
    }
}
