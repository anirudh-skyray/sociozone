package com.google.android.gms.common.api;

public interface C0839f<R extends C0819e> {
    void mo991a(R r);
}
