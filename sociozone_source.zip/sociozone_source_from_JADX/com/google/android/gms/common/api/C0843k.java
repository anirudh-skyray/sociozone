package com.google.android.gms.common.api;

import android.support.v4.p011e.C0232a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.p023d.C0967e;

public class C0843k implements C0819e {
    private final Status f1591a;
    private final C0232a<C0967e<?>, ConnectionResult> f1592b;

    public C0843k(Status status, C0232a<C0967e<?>, ConnectionResult> c0232a) {
        this.f1591a = status;
        this.f1592b = c0232a;
    }

    public Status mo897a() {
        return this.f1591a;
    }
}
