package com.google.android.gms.common.api;

import java.util.Map;
import java.util.WeakHashMap;

public abstract class C0846m {
    private static final Map<Object, C0846m> f1603a = new WeakHashMap();
    private static final Object f1604b = new Object();

    public abstract void m3364a(int i);
}
