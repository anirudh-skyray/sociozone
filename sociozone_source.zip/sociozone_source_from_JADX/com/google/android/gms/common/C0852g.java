package com.google.android.gms.common;

public class C0852g extends Exception {
}
