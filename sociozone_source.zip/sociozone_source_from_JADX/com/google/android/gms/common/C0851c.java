package com.google.android.gms.common;

public final class C0851c extends Exception {
    public final int f1609a;

    public C0851c(int i) {
        this.f1609a = i;
    }
}
