package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageInstaller.SessionInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build;
import android.os.Bundle;
import android.os.UserManager;
import android.text.TextUtils;
import android.util.Log;
import com.google.android.gms.C0795a.C0791b;
import com.google.android.gms.common.C0936k.C0935d;
import com.google.android.gms.common.internal.C0887j;
import com.google.android.gms.common.p022a.C0808e;
import com.google.android.gms.common.p022a.C0809f;
import com.google.android.gms.common.p022a.C0810g;
import com.google.android.gms.common.p022a.C0814k;
import com.google.android.gms.p023d.ap;
import java.util.concurrent.atomic.AtomicBoolean;

public class C0854l {
    private static String f1610a = null;
    @Deprecated
    public static final int f1611b = C0854l.m3400b();
    public static boolean f1612c = false;
    public static boolean f1613d = false;
    static boolean f1614e = false;
    static final AtomicBoolean f1615f = new AtomicBoolean();
    private static int f1616g = 0;
    private static boolean f1617h = false;
    private static final AtomicBoolean f1618i = new AtomicBoolean();

    C0854l() {
    }

    private static void m3396a(Context context) {
        if (!f1618i.get()) {
            C0854l.m3411h(context);
            if (f1616g == 0) {
                throw new IllegalStateException("A required meta-data tag in your app's AndroidManifest.xml does not exist.  You must have the following declaration within the <application> element:     <meta-data android:name=\"com.google.android.gms.version\" android:value=\"@integer/google_play_services_version\" />");
            } else if (f1616g != f1611b) {
                int i = f1611b;
                int i2 = f1616g;
                String valueOf = String.valueOf("com.google.android.gms.version");
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 290).append("The meta-data tag in your app's AndroidManifest.xml does not have the right value.  Expected ").append(i).append(" but found ").append(i2).append(".  You must have the following declaration within the <application> element:     <meta-data android:name=\"").append(valueOf).append("\" android:value=\"@integer/google_play_services_version\" />").toString());
            }
        }
    }

    @Deprecated
    public static boolean m3397a() {
        return "user".equals(Build.TYPE);
    }

    static boolean m3398a(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 18:
            case 42:
                return true;
            default:
                return false;
        }
    }

    @TargetApi(21)
    static boolean m3399a(Context context, String str) {
        if (C0810g.m3274h()) {
            for (SessionInfo appPackageName : context.getPackageManager().getPackageInstaller().getAllSessions()) {
                if (str.equals(appPackageName.getAppPackageName())) {
                    return true;
                }
            }
        }
        if (C0854l.m3410g(context)) {
            return false;
        }
        try {
            return context.getPackageManager().getApplicationInfo(str, 8192).enabled;
        } catch (NameNotFoundException e) {
            return false;
        }
    }

    private static int m3400b() {
        return C0887j.f1705a;
    }

    @Deprecated
    public static int m3401b(Context context) {
        PackageManager packageManager = context.getPackageManager();
        try {
            context.getResources().getString(C0791b.common_google_play_services_unknown_issue);
        } catch (Throwable th) {
            Log.e("GooglePlayServicesUtil", "The Google Play services resources were not found. Check your project configuration to ensure that the resources are included.");
        }
        if (!"com.google.android.gms".equals(context.getPackageName())) {
            C0854l.m3396a(context);
        }
        try {
            PackageInfo packageInfo = packageManager.getPackageInfo("com.google.android.gms", 64);
            C0937m a = C0937m.m3804a(context);
            if (!C0808e.m3262a(context)) {
                try {
                    if (a.m3805a(packageManager.getPackageInfo("com.android.vending", 8256), C0935d.f1789a) == null) {
                        Log.w("GooglePlayServicesUtil", "Google Play Store signature invalid.");
                        return 9;
                    }
                    if (a.m3805a(packageInfo, a.m3805a(packageManager.getPackageInfo("com.android.vending", 8256), C0935d.f1789a)) == null) {
                        Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
                        return 9;
                    }
                } catch (NameNotFoundException e) {
                    Log.w("GooglePlayServicesUtil", "Google Play Store is neither installed nor updating.");
                    return 9;
                }
            } else if (a.m3805a(packageInfo, C0935d.f1789a) == null) {
                Log.w("GooglePlayServicesUtil", "Google Play services signature invalid.");
                return 9;
            }
            if (C0809f.m3265a(packageInfo.versionCode) < C0809f.m3265a(f1611b)) {
                Log.w("GooglePlayServicesUtil", "Google Play services out of date.  Requires " + f1611b + " but found " + packageInfo.versionCode);
                return 2;
            }
            ApplicationInfo applicationInfo = packageInfo.applicationInfo;
            if (applicationInfo == null) {
                try {
                    applicationInfo = packageManager.getApplicationInfo("com.google.android.gms", 0);
                } catch (Throwable e2) {
                    Log.wtf("GooglePlayServicesUtil", "Google Play services missing when getting application info.", e2);
                    return 1;
                }
            }
            return !applicationInfo.enabled ? 3 : 0;
        } catch (NameNotFoundException e3) {
            Log.w("GooglePlayServicesUtil", "Google Play services is missing.");
            return 1;
        }
    }

    @Deprecated
    public static PendingIntent m3402b(int i, Context context, int i2) {
        return C0849j.m3371b().mo899a(context, i, i2);
    }

    @Deprecated
    public static boolean m3403b(int i) {
        switch (i) {
            case 1:
            case 2:
            case 3:
            case 9:
                return true;
            default:
                return false;
        }
    }

    @Deprecated
    public static boolean m3404b(Context context, int i) {
        return C0814k.m3280a(context, i);
    }

    public static boolean m3405c(Context context) {
        C0854l.m3411h(context);
        return f1614e;
    }

    @Deprecated
    public static boolean m3406c(Context context, int i) {
        return i == 18 ? true : i == 1 ? C0854l.m3399a(context, "com.google.android.gms") : false;
    }

    public static boolean m3407d(Context context) {
        return C0854l.m3405c(context) || !C0854l.m3397a();
    }

    @Deprecated
    public static void m3408e(Context context) {
        if (!f1615f.getAndSet(true)) {
            try {
                ((NotificationManager) context.getSystemService("notification")).cancel(10436);
            } catch (SecurityException e) {
            }
        }
    }

    public static String m3409f(Context context) {
        Object obj = context.getApplicationInfo().name;
        if (!TextUtils.isEmpty(obj)) {
            return obj;
        }
        ApplicationInfo a;
        String packageName = context.getPackageName();
        PackageManager packageManager = context.getApplicationContext().getPackageManager();
        try {
            a = ap.m3917b(context).m3914a(context.getPackageName(), 0);
        } catch (NameNotFoundException e) {
            a = null;
        }
        return a != null ? packageManager.getApplicationLabel(a).toString() : packageName;
    }

    @TargetApi(18)
    public static boolean m3410g(Context context) {
        if (C0810g.m3271e()) {
            Bundle applicationRestrictions = ((UserManager) context.getSystemService("user")).getApplicationRestrictions(context.getPackageName());
            if (applicationRestrictions != null && "true".equals(applicationRestrictions.getString("restricted_profile"))) {
                return true;
            }
        }
        return false;
    }

    private static void m3411h(Context context) {
        if (!f1617h) {
            C0854l.m3412i(context);
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    private static void m3412i(android.content.Context r7) {
        /*
        r6 = 1;
        r0 = r7.getPackageName();	 Catch:{ NameNotFoundException -> 0x003a }
        f1610a = r0;	 Catch:{ NameNotFoundException -> 0x003a }
        r0 = com.google.android.gms.p023d.ap.m3917b(r7);	 Catch:{ NameNotFoundException -> 0x003a }
        r1 = com.google.android.gms.common.internal.aa.m3448a(r7);	 Catch:{ NameNotFoundException -> 0x003a }
        f1616g = r1;	 Catch:{ NameNotFoundException -> 0x003a }
        r1 = "com.google.android.gms";
        r2 = 64;
        r0 = r0.m3916b(r1, r2);	 Catch:{ NameNotFoundException -> 0x003a }
        if (r0 == 0) goto L_0x0036;
    L_0x001b:
        r1 = com.google.android.gms.common.C0937m.m3804a(r7);	 Catch:{ NameNotFoundException -> 0x003a }
        r2 = 1;
        r2 = new com.google.android.gms.common.C0936k.C0930a[r2];	 Catch:{ NameNotFoundException -> 0x003a }
        r3 = 0;
        r4 = com.google.android.gms.common.C0936k.C0935d.f1789a;	 Catch:{ NameNotFoundException -> 0x003a }
        r5 = 1;
        r4 = r4[r5];	 Catch:{ NameNotFoundException -> 0x003a }
        r2[r3] = r4;	 Catch:{ NameNotFoundException -> 0x003a }
        r0 = r1.m3805a(r0, r2);	 Catch:{ NameNotFoundException -> 0x003a }
        if (r0 == 0) goto L_0x0036;
    L_0x0030:
        r0 = 1;
        f1614e = r0;	 Catch:{ NameNotFoundException -> 0x003a }
    L_0x0033:
        f1617h = r6;
    L_0x0035:
        return;
    L_0x0036:
        r0 = 0;
        f1614e = r0;	 Catch:{ NameNotFoundException -> 0x003a }
        goto L_0x0033;
    L_0x003a:
        r0 = move-exception;
        r1 = "GooglePlayServicesUtil";
        r2 = "Cannot find Google Play services package name.";
        android.util.Log.w(r1, r2, r0);	 Catch:{ all -> 0x0045 }
        f1617h = r6;
        goto L_0x0035;
    L_0x0045:
        r0 = move-exception;
        f1617h = r6;
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.l.i(android.content.Context):void");
    }
}
