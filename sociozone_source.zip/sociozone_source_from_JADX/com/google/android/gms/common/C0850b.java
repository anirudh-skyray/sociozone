package com.google.android.gms.common;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.view.View;
import android.widget.ProgressBar;
import com.google.android.gms.C0795a.C0791b;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.common.internal.C0902n;
import com.google.android.gms.common.p022a.C0808e;
import com.google.android.gms.p023d.C1024v;
import com.google.android.gms.p023d.C1024v.C0978a;
import com.google.android.gms.p023d.aa;

public class C0850b extends C0849j {
    public static final int f1607a = C0849j.f1606b;
    private static final C0850b f1608c = new C0850b();

    C0850b() {
    }

    public static C0850b m3382a() {
        return f1608c;
    }

    public int mo898a(Context context) {
        return super.mo898a(context);
    }

    public Dialog m3384a(Activity activity, OnCancelListener onCancelListener) {
        View progressBar = new ProgressBar(activity, null, 16842874);
        progressBar.setIndeterminate(true);
        progressBar.setVisibility(0);
        Builder builder = new Builder(activity);
        builder.setView(progressBar);
        String f = C0854l.m3409f(activity);
        builder.setMessage(activity.getResources().getString(C0791b.common_google_play_services_updating_text, new Object[]{f}));
        builder.setTitle(C0791b.common_google_play_services_updating_title);
        builder.setPositiveButton("", null);
        Dialog create = builder.create();
        C0855e.m3418a(activity, onCancelListener, "GooglePlayServicesUpdatingDialog", create);
        return create;
    }

    public PendingIntent mo899a(Context context, int i, int i2) {
        return super.mo899a(context, i, i2);
    }

    public PendingIntent mo900a(Context context, int i, int i2, String str) {
        return super.mo900a(context, i, i2, str);
    }

    public PendingIntent m3387a(Context context, ConnectionResult connectionResult) {
        if (connectionResult.m3251a()) {
            return connectionResult.m3254d();
        }
        int c = connectionResult.m3253c();
        if (C0808e.m3262a(context) && c == 2) {
            c = 42;
        }
        return mo899a(context, c, 0);
    }

    public Intent mo901a(Context context, int i, String str) {
        return super.mo901a(context, i, str);
    }

    public C1024v m3389a(Context context, C0978a c0978a) {
        IntentFilter intentFilter = new IntentFilter("android.intent.action.PACKAGE_ADDED");
        intentFilter.addDataScheme("package");
        BroadcastReceiver c1024v = new C1024v(c0978a);
        context.registerReceiver(c1024v, intentFilter);
        c1024v.m4272a(context);
        if (m3379a(context, "com.google.android.gms")) {
            return c1024v;
        }
        c0978a.mo1017a();
        c1024v.m4271a();
        return null;
    }

    public void m3390a(Context context, ConnectionResult connectionResult, int i) {
        PendingIntent a = m3387a(context, connectionResult);
        if (a != null) {
            C0855e.m3416a(connectionResult.m3253c(), context, GoogleApiActivity.m3283a(context, a, i));
        }
    }

    public final boolean mo902a(int i) {
        return super.mo902a(i);
    }

    public boolean m3392a(Activity activity, int i, int i2, OnCancelListener onCancelListener) {
        return C0855e.m3419a(i, activity, i2, onCancelListener);
    }

    public boolean m3393a(Activity activity, aa aaVar, int i, int i2, OnCancelListener onCancelListener) {
        Dialog a = C0855e.m3414a(i, activity, C0902n.m3602a(aaVar, mo901a((Context) activity, i, "d"), i2), onCancelListener);
        if (a == null) {
            return false;
        }
        C0855e.m3418a(activity, onCancelListener, "GooglePlayServicesErrorDialog", a);
        return true;
    }

    public boolean mo903a(Context context, int i) {
        return super.mo903a(context, i);
    }

    @Deprecated
    public Intent mo904b(int i) {
        return super.mo904b(i);
    }
}
