package com.google.android.gms.common.p022a;

import android.os.Build.VERSION;

public final class C0810g {
    public static boolean m3266a() {
        return C0810g.m3267a(11);
    }

    private static boolean m3267a(int i) {
        return VERSION.SDK_INT >= i;
    }

    public static boolean m3268b() {
        return C0810g.m3267a(13);
    }

    public static boolean m3269c() {
        return C0810g.m3267a(14);
    }

    public static boolean m3270d() {
        return C0810g.m3267a(16);
    }

    public static boolean m3271e() {
        return C0810g.m3267a(18);
    }

    public static boolean m3272f() {
        return C0810g.m3267a(19);
    }

    public static boolean m3273g() {
        return C0810g.m3267a(20);
    }

    public static boolean m3274h() {
        return C0810g.m3267a(21);
    }
}
