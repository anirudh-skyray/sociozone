package com.google.android.gms.common.p022a;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C0937m;
import com.google.android.gms.p023d.ap;

public final class C0814k {
    public static boolean m3280a(Context context, int i) {
        boolean z = false;
        if (!C0814k.m3281a(context, i, "com.google.android.gms")) {
            return z;
        }
        try {
            return C0937m.m3804a(context).m3807a(context.getPackageManager(), context.getPackageManager().getPackageInfo("com.google.android.gms", 64));
        } catch (NameNotFoundException e) {
            if (!Log.isLoggable("UidVerifier", 3)) {
                return z;
            }
            Log.d("UidVerifier", "Package manager can't find google play services package, defaulting to false");
            return z;
        }
    }

    @TargetApi(19)
    public static boolean m3281a(Context context, int i, String str) {
        return ap.m3917b(context).m3915a(i, str);
    }
}
