package com.google.android.gms.common.p022a;

public interface C0806c {
    long mo896a();
}
