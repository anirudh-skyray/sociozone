package com.google.android.gms.common.p022a;

import android.annotation.TargetApi;
import android.content.Context;
import android.util.Log;
import java.io.File;

public class C0813j {
    @TargetApi(21)
    public static File m3278a(Context context) {
        return C0810g.m3274h() ? context.getNoBackupFilesDir() : C0813j.m3279a(new File(context.getApplicationInfo().dataDir, "no_backup"));
    }

    private static synchronized File m3279a(File file) {
        synchronized (C0813j.class) {
            if (!(file.exists() || file.mkdirs() || file.exists())) {
                String str = "SupportV4Utils";
                String str2 = "Unable to create no-backup dir ";
                String valueOf = String.valueOf(file.getPath());
                Log.w(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                file = null;
            }
        }
        return file;
    }
}
