package com.google.android.gms.common.p022a;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;

public class C0805b {
    public static boolean m3257a() {
        return false;
    }

    public static boolean m3258a(Context context, String str) {
        try {
            return (context.getPackageManager().getApplicationInfo(str, 0).flags & 2097152) != 0;
        } catch (NameNotFoundException e) {
            return false;
        }
    }
}
