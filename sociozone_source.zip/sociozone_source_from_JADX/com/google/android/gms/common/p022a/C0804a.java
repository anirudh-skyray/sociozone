package com.google.android.gms.common.p022a;

import android.support.v4.p011e.C0232a;
import java.util.AbstractSet;
import java.util.Collection;
import java.util.Iterator;

public class C0804a<E> extends AbstractSet<E> {
    private final C0232a<E, E> f1544a = new C0232a();

    public boolean m3256a(C0804a<? extends E> c0804a) {
        int size = size();
        this.f1544a.m843a(c0804a.f1544a);
        return size() > size;
    }

    public boolean add(E e) {
        if (this.f1544a.containsKey(e)) {
            return false;
        }
        this.f1544a.put(e, e);
        return true;
    }

    public boolean addAll(Collection<? extends E> collection) {
        return collection instanceof C0804a ? m3256a((C0804a) collection) : super.addAll(collection);
    }

    public void clear() {
        this.f1544a.clear();
    }

    public boolean contains(Object obj) {
        return this.f1544a.containsKey(obj);
    }

    public Iterator<E> iterator() {
        return this.f1544a.keySet().iterator();
    }

    public boolean remove(Object obj) {
        if (!this.f1544a.containsKey(obj)) {
            return false;
        }
        this.f1544a.remove(obj);
        return true;
    }

    public int size() {
        return this.f1544a.size();
    }
}
