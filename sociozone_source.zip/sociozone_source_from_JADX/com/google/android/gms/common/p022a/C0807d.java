package com.google.android.gms.common.p022a;

public final class C0807d implements C0806c {
    private static C0807d f1545a;

    public static synchronized C0806c m3260b() {
        C0806c c0806c;
        synchronized (C0807d.class) {
            if (f1545a == null) {
                f1545a = new C0807d();
            }
            c0806c = f1545a;
        }
        return c0806c;
    }

    public long mo896a() {
        return System.currentTimeMillis();
    }
}
