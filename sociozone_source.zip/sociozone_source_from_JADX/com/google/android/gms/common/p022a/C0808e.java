package com.google.android.gms.common.p022a;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;

public final class C0808e {
    private static Boolean f1546a;
    private static Boolean f1547b;
    private static Boolean f1548c;

    @TargetApi(20)
    public static boolean m3262a(Context context) {
        if (f1548c == null) {
            boolean z = C0810g.m3273g() && context.getPackageManager().hasSystemFeature("android.hardware.type.watch");
            f1548c = Boolean.valueOf(z);
        }
        return f1548c.booleanValue();
    }

    public static boolean m3263a(Resources resources) {
        boolean z = false;
        if (resources == null) {
            return false;
        }
        if (f1546a == null) {
            boolean z2 = (resources.getConfiguration().screenLayout & 15) > 3;
            if ((C0810g.m3266a() && z2) || C0808e.m3264b(resources)) {
                z = true;
            }
            f1546a = Boolean.valueOf(z);
        }
        return f1546a.booleanValue();
    }

    @TargetApi(13)
    private static boolean m3264b(Resources resources) {
        if (f1547b == null) {
            Configuration configuration = resources.getConfiguration();
            boolean z = C0810g.m3268b() && (configuration.screenLayout & 15) <= 3 && configuration.smallestScreenWidthDp >= 600;
            f1547b = Boolean.valueOf(z);
        }
        return f1547b.booleanValue();
    }
}
