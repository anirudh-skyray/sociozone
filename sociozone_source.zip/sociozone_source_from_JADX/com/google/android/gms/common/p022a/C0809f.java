package com.google.android.gms.common.p022a;

import java.util.regex.Pattern;

public final class C0809f {
    private static Pattern f1549a = null;

    public static int m3265a(int i) {
        return i / 1000;
    }
}
