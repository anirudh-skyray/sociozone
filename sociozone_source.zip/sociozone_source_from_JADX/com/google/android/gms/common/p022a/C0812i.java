package com.google.android.gms.common.p022a;

import com.google.android.gms.common.internal.C0888k;
import java.util.regex.Pattern;

public class C0812i {
    private static final Pattern f1551a = Pattern.compile("\\$\\{(.*?)\\}");

    public static boolean m3277a(String str) {
        return str == null || C0888k.f1706a.mo924b((CharSequence) str);
    }
}
