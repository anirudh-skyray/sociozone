package com.google.android.gms.common.stats;

import com.google.android.gms.p023d.al;

public final class C0941c {
    public static al<Integer> f1820a = al.m3899a("gms:common:stats:max_num_of_events", Integer.valueOf(100));
    public static al<Integer> f1821b = al.m3899a("gms:common:stats:max_chunk_size", Integer.valueOf(100));

    public static final class C0940a {
        public static al<Integer> f1814a = al.m3899a("gms:common:stats:connections:level", Integer.valueOf(C0942d.f1823b));
        public static al<String> f1815b = al.m3901a("gms:common:stats:connections:ignored_calling_processes", "");
        public static al<String> f1816c = al.m3901a("gms:common:stats:connections:ignored_calling_services", "");
        public static al<String> f1817d = al.m3901a("gms:common:stats:connections:ignored_target_processes", "");
        public static al<String> f1818e = al.m3901a("gms:common:stats:connections:ignored_target_services", "com.google.android.gms.auth.GetToken");
        public static al<Long> f1819f = al.m3900a("gms:common:stats:connections:time_out_duration", Long.valueOf(600000));
    }
}
