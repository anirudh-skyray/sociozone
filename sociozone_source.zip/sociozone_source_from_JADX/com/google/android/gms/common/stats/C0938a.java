package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0938a implements Creator<ConnectionEvent> {
    static void m3824a(ConnectionEvent connectionEvent, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, connectionEvent.f1793a);
        C0917b.m3674a(parcel, 2, connectionEvent.mo981a());
        C0917b.m3679a(parcel, 4, connectionEvent.m3814c(), false);
        C0917b.m3679a(parcel, 5, connectionEvent.m3815d(), false);
        C0917b.m3679a(parcel, 6, connectionEvent.m3816e(), false);
        C0917b.m3679a(parcel, 7, connectionEvent.m3817f(), false);
        C0917b.m3679a(parcel, 8, connectionEvent.m3818g(), false);
        C0917b.m3674a(parcel, 10, connectionEvent.m3822k());
        C0917b.m3674a(parcel, 11, connectionEvent.m3821j());
        C0917b.m3673a(parcel, 12, connectionEvent.mo982b());
        C0917b.m3679a(parcel, 13, connectionEvent.m3819h(), false);
        C0917b.m3670a(parcel, a);
    }

    public ConnectionEvent m3825a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        long j = 0;
        int i2 = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        String str5 = null;
        String str6 = null;
        long j2 = 0;
        long j3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    j = C0916a.m3661g(parcel, a);
                    break;
                case 4:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 5:
                    str2 = C0916a.m3664j(parcel, a);
                    break;
                case 6:
                    str3 = C0916a.m3664j(parcel, a);
                    break;
                case 7:
                    str4 = C0916a.m3664j(parcel, a);
                    break;
                case 8:
                    str5 = C0916a.m3664j(parcel, a);
                    break;
                case 10:
                    j2 = C0916a.m3661g(parcel, a);
                    break;
                case 11:
                    j3 = C0916a.m3661g(parcel, a);
                    break;
                case 12:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 13:
                    str6 = C0916a.m3664j(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ConnectionEvent(i, j, i2, str, str2, str3, str4, str5, str6, j2, j3);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public ConnectionEvent[] m3826a(int i) {
        return new ConnectionEvent[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3825a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3826a(i);
    }
}
