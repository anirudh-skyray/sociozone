package com.google.android.gms.common.stats;

import android.annotation.SuppressLint;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.os.Debug;
import android.os.Parcelable;
import android.os.Process;
import android.os.SystemClock;
import android.support.v4.app.ag;
import android.util.Log;
import com.google.android.gms.common.p022a.C0805b;
import com.google.android.gms.common.p022a.C0811h;
import com.google.android.gms.common.stats.C0941c.C0940a;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class C0939b {
    private static final Object f1805a = new Object();
    private static C0939b f1806b;
    private static Integer f1807h;
    private final List<String> f1808c;
    private final List<String> f1809d;
    private final List<String> f1810e;
    private final List<String> f1811f;
    private C0943e f1812g;
    private C0943e f1813i;

    private C0939b() {
        if (C0939b.m3837c() == C0942d.f1823b) {
            this.f1808c = Collections.EMPTY_LIST;
            this.f1809d = Collections.EMPTY_LIST;
            this.f1810e = Collections.EMPTY_LIST;
            this.f1811f = Collections.EMPTY_LIST;
            return;
        }
        String str = (String) C0940a.f1815b.m3903a();
        this.f1808c = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0940a.f1816c.m3903a();
        this.f1809d = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0940a.f1817d.m3903a();
        this.f1810e = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        str = (String) C0940a.f1818e.m3903a();
        this.f1811f = str == null ? Collections.EMPTY_LIST : Arrays.asList(str.split(","));
        this.f1812g = new C0943e(1024, ((Long) C0940a.f1819f.m3903a()).longValue());
        this.f1813i = new C0943e(1024, ((Long) C0940a.f1819f.m3903a()).longValue());
    }

    public static C0939b m3827a() {
        synchronized (f1805a) {
            if (f1806b == null) {
                f1806b = new C0939b();
            }
        }
        return f1806b;
    }

    private static String m3828a(int i, int i2) {
        StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
        StringBuffer stringBuffer = new StringBuffer();
        int i3 = i2 + i;
        while (i < i3) {
            stringBuffer.append(C0939b.m3830a(stackTrace, i)).append(" ");
            i++;
        }
        return stringBuffer.toString();
    }

    private String m3829a(ServiceConnection serviceConnection) {
        return String.valueOf((((long) Process.myPid()) << 32) | ((long) System.identityHashCode(serviceConnection)));
    }

    private static String m3830a(StackTraceElement[] stackTraceElementArr, int i) {
        if (i + 4 >= stackTraceElementArr.length) {
            return "<bottom of call stack>";
        }
        StackTraceElement stackTraceElement = stackTraceElementArr[i + 4];
        String valueOf = String.valueOf(stackTraceElement.getClassName());
        String valueOf2 = String.valueOf(stackTraceElement.getMethodName());
        return new StringBuilder((String.valueOf(valueOf).length() + 13) + String.valueOf(valueOf2).length()).append(valueOf).append(".").append(valueOf2).append(":").append(stackTraceElement.getLineNumber()).toString();
    }

    private void m3831a(Context context, String str, int i, String str2, String str3, String str4, String str5) {
        Parcelable connectionEvent;
        long currentTimeMillis = System.currentTimeMillis();
        String str6 = null;
        if (!((C0939b.m3837c() & C0942d.f1827f) == 0 || i == 13)) {
            str6 = C0939b.m3828a(3, 5);
        }
        long j = 0;
        if ((C0939b.m3837c() & C0942d.f1829h) != 0) {
            j = Debug.getNativeHeapAllocatedSize();
        }
        if (i == 1 || i == 4 || i == 14) {
            connectionEvent = new ConnectionEvent(currentTimeMillis, i, null, null, null, null, str6, str, SystemClock.elapsedRealtime(), j);
        } else {
            connectionEvent = new ConnectionEvent(currentTimeMillis, i, str2, str3, str4, str5, str6, str, SystemClock.elapsedRealtime(), j);
        }
        context.startService(new Intent().setComponent(C0942d.f1822a).putExtra("com.google.android.gms.common.stats.EXTRA_LOG_EVENT", connectionEvent));
    }

    private void m3832a(Context context, String str, String str2, Intent intent, int i) {
        String str3 = null;
        if (m3836b() && this.f1812g != null) {
            String str4;
            String str5;
            if (i != 4 && i != 1) {
                ServiceInfo b = C0939b.m3835b(context, intent);
                if (b == null) {
                    Log.w("ConnectionTracker", String.format("Client %s made an invalid request %s", new Object[]{str2, intent.toUri(0)}));
                    return;
                }
                str4 = b.processName;
                str5 = b.name;
                str3 = C0811h.m3275a();
                if (m3834a(str3, str2, str4, str5)) {
                    this.f1812g.m3844a(str);
                } else {
                    return;
                }
            } else if (this.f1812g.m3845b(str)) {
                str5 = null;
                str4 = null;
            } else {
                return;
            }
            m3831a(context, str, i, str3, str2, str4, str5);
        }
    }

    private boolean m3833a(Context context, Intent intent) {
        ComponentName component = intent.getComponent();
        return component != null ? C0805b.m3258a(context, component.getPackageName()) : false;
    }

    private boolean m3834a(String str, String str2, String str3, String str4) {
        return (this.f1808c.contains(str) || this.f1809d.contains(str2) || this.f1810e.contains(str3) || this.f1811f.contains(str4) || (str3.equals(str) && (C0939b.m3837c() & C0942d.f1828g) != 0)) ? false : true;
    }

    private static ServiceInfo m3835b(Context context, Intent intent) {
        List<ResolveInfo> queryIntentServices = context.getPackageManager().queryIntentServices(intent, ag.FLAG_HIGH_PRIORITY);
        if (queryIntentServices == null || queryIntentServices.size() == 0) {
            Log.w("ConnectionTracker", String.format("There are no handler of this intent: %s\n Stack trace: %s", new Object[]{intent.toUri(0), C0939b.m3828a(3, 20)}));
            return null;
        } else if (queryIntentServices.size() <= 1) {
            return ((ResolveInfo) queryIntentServices.get(0)).serviceInfo;
        } else {
            Log.w("ConnectionTracker", String.format("Multiple handlers found for this intent: %s\n Stack trace: %s", new Object[]{intent.toUri(0), C0939b.m3828a(3, 20)}));
            for (ResolveInfo resolveInfo : queryIntentServices) {
                Log.w("ConnectionTracker", resolveInfo.serviceInfo.name);
            }
            return null;
        }
    }

    private boolean m3836b() {
        return false;
    }

    private static int m3837c() {
        if (f1807h == null) {
            try {
                f1807h = Integer.valueOf(C0805b.m3257a() ? ((Integer) C0940a.f1814a.m3903a()).intValue() : C0942d.f1823b);
            } catch (SecurityException e) {
                f1807h = Integer.valueOf(C0942d.f1823b);
            }
        }
        return f1807h.intValue();
    }

    @SuppressLint({"UntrackedBindService"})
    public void m3838a(Context context, ServiceConnection serviceConnection) {
        context.unbindService(serviceConnection);
        m3832a(context, m3829a(serviceConnection), null, null, 1);
    }

    public void m3839a(Context context, ServiceConnection serviceConnection, String str, Intent intent) {
        m3832a(context, m3829a(serviceConnection), str, intent, 3);
    }

    public boolean m3840a(Context context, Intent intent, ServiceConnection serviceConnection, int i) {
        return m3841a(context, context.getClass().getName(), intent, serviceConnection, i);
    }

    @SuppressLint({"UntrackedBindService"})
    public boolean m3841a(Context context, String str, Intent intent, ServiceConnection serviceConnection, int i) {
        if (m3833a(context, intent)) {
            Log.w("ConnectionTracker", "Attempted to bind to a service in a STOPPED package.");
            return false;
        }
        boolean bindService = context.bindService(intent, serviceConnection, i);
        if (bindService) {
            m3832a(context, m3829a(serviceConnection), str, intent, 2);
        }
        return bindService;
    }

    public void m3842b(Context context, ServiceConnection serviceConnection) {
        m3832a(context, m3829a(serviceConnection), null, null, 4);
    }
}
