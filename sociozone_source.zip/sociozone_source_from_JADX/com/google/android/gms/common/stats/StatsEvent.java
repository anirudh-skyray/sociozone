package com.google.android.gms.common.stats;

import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public abstract class StatsEvent extends AbstractSafeParcelable {
    public abstract long mo981a();

    public abstract int mo982b();

    public abstract long mo983i();

    public abstract String mo984l();

    public String toString() {
        long a = mo981a();
        String valueOf = String.valueOf("\t");
        int b = mo982b();
        String valueOf2 = String.valueOf("\t");
        long i = mo983i();
        String valueOf3 = String.valueOf(mo984l());
        return new StringBuilder(((String.valueOf(valueOf).length() + 51) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()).append(a).append(valueOf).append(b).append(valueOf2).append(i).append(valueOf3).toString();
    }
}
