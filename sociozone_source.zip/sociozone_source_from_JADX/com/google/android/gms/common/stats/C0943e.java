package com.google.android.gms.common.stats;

import android.os.SystemClock;
import android.support.v4.p011e.C0231i;
import android.util.Log;

public class C0943e {
    private final long f1831a;
    private final int f1832b;
    private final C0231i<String, Long> f1833c;

    public C0943e() {
        this.f1831a = 60000;
        this.f1832b = 10;
        this.f1833c = new C0231i(10);
    }

    public C0943e(int i, long j) {
        this.f1831a = j;
        this.f1832b = i;
        this.f1833c = new C0231i();
    }

    private void m3843a(long j, long j2) {
        for (int size = this.f1833c.size() - 1; size >= 0; size--) {
            if (j2 - ((Long) this.f1833c.m846c(size)).longValue() > j) {
                this.f1833c.m847d(size);
            }
        }
    }

    public Long m3844a(String str) {
        Long l;
        long elapsedRealtime = SystemClock.elapsedRealtime();
        long j = this.f1831a;
        synchronized (this) {
            while (this.f1833c.size() >= this.f1832b) {
                m3843a(j, elapsedRealtime);
                j /= 2;
                Log.w("ConnectionTracker", "The max capacity " + this.f1832b + " is not enough. Current durationThreshold is: " + j);
            }
            l = (Long) this.f1833c.put(str, Long.valueOf(elapsedRealtime));
        }
        return l;
    }

    public boolean m3845b(String str) {
        boolean z;
        synchronized (this) {
            z = this.f1833c.remove(str) != null;
        }
        return z;
    }
}
