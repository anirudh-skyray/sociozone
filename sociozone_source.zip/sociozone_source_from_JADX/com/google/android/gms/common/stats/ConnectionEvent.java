package com.google.android.gms.common.stats;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ConnectionEvent extends StatsEvent {
    public static final Creator<ConnectionEvent> CREATOR = new C0938a();
    final int f1793a;
    private final long f1794b;
    private int f1795c;
    private final String f1796d;
    private final String f1797e;
    private final String f1798f;
    private final String f1799g;
    private final String f1800h;
    private final String f1801i;
    private final long f1802j;
    private final long f1803k;
    private long f1804l;

    ConnectionEvent(int i, long j, int i2, String str, String str2, String str3, String str4, String str5, String str6, long j2, long j3) {
        this.f1793a = i;
        this.f1794b = j;
        this.f1795c = i2;
        this.f1796d = str;
        this.f1797e = str2;
        this.f1798f = str3;
        this.f1799g = str4;
        this.f1804l = -1;
        this.f1800h = str5;
        this.f1801i = str6;
        this.f1802j = j2;
        this.f1803k = j3;
    }

    public ConnectionEvent(long j, int i, String str, String str2, String str3, String str4, String str5, String str6, long j2, long j3) {
        this(1, j, i, str, str2, str3, str4, str5, str6, j2, j3);
    }

    public long mo981a() {
        return this.f1794b;
    }

    public int mo982b() {
        return this.f1795c;
    }

    public String m3814c() {
        return this.f1796d;
    }

    public String m3815d() {
        return this.f1797e;
    }

    public String m3816e() {
        return this.f1798f;
    }

    public String m3817f() {
        return this.f1799g;
    }

    public String m3818g() {
        return this.f1800h;
    }

    public String m3819h() {
        return this.f1801i;
    }

    public long mo983i() {
        return this.f1804l;
    }

    public long m3821j() {
        return this.f1803k;
    }

    public long m3822k() {
        return this.f1802j;
    }

    public String mo984l() {
        String valueOf = String.valueOf("\t");
        String valueOf2 = String.valueOf(m3814c());
        String valueOf3 = String.valueOf(m3815d());
        String valueOf4 = String.valueOf("\t");
        String valueOf5 = String.valueOf(m3816e());
        String valueOf6 = String.valueOf(m3817f());
        String valueOf7 = String.valueOf("\t");
        String str = this.f1800h == null ? "" : this.f1800h;
        String valueOf8 = String.valueOf("\t");
        return new StringBuilder(((((((((String.valueOf(valueOf).length() + 22) + String.valueOf(valueOf2).length()) + String.valueOf(valueOf3).length()) + String.valueOf(valueOf4).length()) + String.valueOf(valueOf5).length()) + String.valueOf(valueOf6).length()) + String.valueOf(valueOf7).length()) + String.valueOf(str).length()) + String.valueOf(valueOf8).length()).append(valueOf).append(valueOf2).append("/").append(valueOf3).append(valueOf4).append(valueOf5).append("/").append(valueOf6).append(valueOf7).append(str).append(valueOf8).append(m3821j()).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0938a.m3824a(this, parcel, i);
    }
}
