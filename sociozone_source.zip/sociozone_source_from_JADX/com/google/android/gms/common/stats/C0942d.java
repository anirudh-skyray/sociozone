package com.google.android.gms.common.stats;

import android.content.ComponentName;

public final class C0942d {
    public static final ComponentName f1822a = new ComponentName("com.google.android.gms", "com.google.android.gms.common.stats.GmsCoreStatsService");
    public static int f1823b = 0;
    public static int f1824c = 1;
    public static int f1825d = 2;
    public static int f1826e = 4;
    public static int f1827f = 8;
    public static int f1828g = 16;
    public static int f1829h = 32;
    public static int f1830i = 1;
}
