package com.google.android.gms.common;

import android.app.PendingIntent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class ConnectionResult extends AbstractSafeParcelable {
    public static final Creator<ConnectionResult> CREATOR = new C0858i();
    public static final ConnectionResult f1539a = new ConnectionResult(0);
    final int f1540b;
    private final int f1541c;
    private final PendingIntent f1542d;
    private final String f1543e;

    public ConnectionResult(int i) {
        this(i, null, null);
    }

    ConnectionResult(int i, int i2, PendingIntent pendingIntent, String str) {
        this.f1540b = i;
        this.f1541c = i2;
        this.f1542d = pendingIntent;
        this.f1543e = str;
    }

    public ConnectionResult(int i, PendingIntent pendingIntent) {
        this(i, pendingIntent, null);
    }

    public ConnectionResult(int i, PendingIntent pendingIntent, String str) {
        this(1, i, pendingIntent, str);
    }

    static String m3250a(int i) {
        switch (i) {
            case -1:
                return "UNKNOWN";
            case 0:
                return "SUCCESS";
            case 1:
                return "SERVICE_MISSING";
            case 2:
                return "SERVICE_VERSION_UPDATE_REQUIRED";
            case 3:
                return "SERVICE_DISABLED";
            case 4:
                return "SIGN_IN_REQUIRED";
            case 5:
                return "INVALID_ACCOUNT";
            case 6:
                return "RESOLUTION_REQUIRED";
            case 7:
                return "NETWORK_ERROR";
            case 8:
                return "INTERNAL_ERROR";
            case 9:
                return "SERVICE_INVALID";
            case 10:
                return "DEVELOPER_ERROR";
            case 11:
                return "LICENSE_CHECK_FAILED";
            case 13:
                return "CANCELED";
            case 14:
                return "TIMEOUT";
            case 15:
                return "INTERRUPTED";
            case 16:
                return "API_UNAVAILABLE";
            case 17:
                return "SIGN_IN_FAILED";
            case 18:
                return "SERVICE_UPDATING";
            case 19:
                return "SERVICE_MISSING_PERMISSION";
            case 20:
                return "RESTRICTED_PROFILE";
            case 21:
                return "API_VERSION_UPDATE_REQUIRED";
            case 42:
                return "UPDATE_ANDROID_WEAR";
            case 99:
                return "UNFINISHED";
            case 1500:
                return "DRIVE_EXTERNAL_STORAGE_REQUIRED";
            default:
                return "UNKNOWN_ERROR_CODE(" + i + ")";
        }
    }

    public boolean m3251a() {
        return (this.f1541c == 0 || this.f1542d == null) ? false : true;
    }

    public boolean m3252b() {
        return this.f1541c == 0;
    }

    public int m3253c() {
        return this.f1541c;
    }

    public PendingIntent m3254d() {
        return this.f1542d;
    }

    public String m3255e() {
        return this.f1543e;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof ConnectionResult)) {
            return false;
        }
        ConnectionResult connectionResult = (ConnectionResult) obj;
        return this.f1541c == connectionResult.f1541c && ab.m3453a(this.f1542d, connectionResult.f1542d) && ab.m3453a(this.f1543e, connectionResult.f1543e);
    }

    public int hashCode() {
        return ab.m3451a(Integer.valueOf(this.f1541c), this.f1542d, this.f1543e);
    }

    public String toString() {
        return ab.m3452a((Object) this).m3450a("statusCode", m3250a(this.f1541c)).m3450a("resolution", this.f1542d).m3450a("message", this.f1543e).toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0858i.m3424a(this, parcel, i);
    }
}
