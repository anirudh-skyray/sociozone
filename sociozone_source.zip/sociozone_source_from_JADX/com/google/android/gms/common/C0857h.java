package com.google.android.gms.common;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import com.google.android.gms.common.internal.C0864b;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

public class C0857h implements ServiceConnection {
    boolean f1622a = false;
    private final BlockingQueue<IBinder> f1623b = new LinkedBlockingQueue();

    public IBinder m3423a(long j, TimeUnit timeUnit) throws InterruptedException, TimeoutException {
        C0864b.m3461b("BlockingServiceConnection.getServiceWithTimeout() called on main thread");
        if (this.f1622a) {
            throw new IllegalStateException("Cannot call get on this connection more than once");
        }
        this.f1622a = true;
        IBinder iBinder = (IBinder) this.f1623b.poll(j, timeUnit);
        if (iBinder != null) {
            return iBinder;
        }
        throw new TimeoutException("Timed out waiting for the service connection");
    }

    public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
        this.f1623b.add(iBinder);
    }

    public void onServiceDisconnected(ComponentName componentName) {
    }
}
