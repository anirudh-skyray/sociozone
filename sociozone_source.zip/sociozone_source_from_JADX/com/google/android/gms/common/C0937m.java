package com.google.android.gms.common;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.common.C0936k.C0930a;
import com.google.android.gms.common.C0936k.C0931b;
import com.google.android.gms.common.C0936k.C0935d;
import com.google.android.gms.common.internal.C0864b;

public class C0937m {
    private static C0937m f1791a;
    private final Context f1792b;

    private C0937m(Context context) {
        this.f1792b = context.getApplicationContext();
    }

    public static C0937m m3804a(Context context) {
        C0864b.m3454a((Object) context);
        synchronized (C0937m.class) {
            if (f1791a == null) {
                C0936k.m3803a(context);
                f1791a = new C0937m(context);
            }
        }
        return f1791a;
    }

    C0930a m3805a(PackageInfo packageInfo, C0930a... c0930aArr) {
        if (packageInfo.signatures == null) {
            return null;
        }
        if (packageInfo.signatures.length != 1) {
            Log.w("GoogleSignatureVerifier", "Package has more than one signature.");
            return null;
        }
        C0930a c0931b = new C0931b(packageInfo.signatures[0].toByteArray());
        for (int i = 0; i < c0930aArr.length; i++) {
            if (c0930aArr[i].equals(c0931b)) {
                return c0930aArr[i];
            }
        }
        String valueOf = String.valueOf(packageInfo.packageName);
        String valueOf2 = String.valueOf(Base64.encodeToString(c0931b.mo979c(), 0));
        Log.v("GoogleSignatureVerifier", new StringBuilder((String.valueOf(valueOf).length() + 31) + String.valueOf(valueOf2).length()).append(valueOf).append(" signature not valid.  Found: \n").append(valueOf2).toString());
        return null;
    }

    public boolean m3806a(PackageInfo packageInfo, boolean z) {
        if (!(packageInfo == null || packageInfo.signatures == null)) {
            C0930a a;
            if (z) {
                a = m3805a(packageInfo, C0935d.f1789a);
            } else {
                a = m3805a(packageInfo, C0935d.f1789a[0]);
            }
            if (a != null) {
                return true;
            }
        }
        return false;
    }

    public boolean m3807a(PackageManager packageManager, PackageInfo packageInfo) {
        if (packageInfo == null) {
            return false;
        }
        if (C0854l.m3407d(this.f1792b)) {
            return m3806a(packageInfo, true);
        }
        boolean a = m3806a(packageInfo, false);
        if (a || !m3806a(packageInfo, true)) {
            return a;
        }
        Log.w("GoogleSignatureVerifier", "Test-keys aren't accepted on this build.");
        return a;
    }
}
