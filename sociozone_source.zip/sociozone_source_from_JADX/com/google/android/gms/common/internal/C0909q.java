package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.atomic.AtomicInteger;

public final class C0909q implements Callback {
    final ArrayList<C0817b> f1751a = new ArrayList();
    private final C0868a f1752b;
    private final ArrayList<C0817b> f1753c = new ArrayList();
    private final ArrayList<C0818c> f1754d = new ArrayList();
    private volatile boolean f1755e = false;
    private final AtomicInteger f1756f = new AtomicInteger(0);
    private boolean f1757g = false;
    private final Handler f1758h;
    private final Object f1759i = new Object();

    public interface C0868a {
        boolean mo1043b();

        Bundle mo1044s();
    }

    public C0909q(Looper looper, C0868a c0868a) {
        this.f1752b = c0868a;
        this.f1758h = new Handler(looper, this);
    }

    public void m3613a() {
        this.f1755e = false;
        this.f1756f.incrementAndGet();
    }

    public void m3614a(int i) {
        boolean z = false;
        if (Looper.myLooper() == this.f1758h.getLooper()) {
            z = true;
        }
        C0864b.m3459a(z, (Object) "onUnintentionalDisconnection must only be called on the Handler thread");
        this.f1758h.removeMessages(1);
        synchronized (this.f1759i) {
            this.f1757g = true;
            ArrayList arrayList = new ArrayList(this.f1753c);
            int i2 = this.f1756f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                C0817b c0817b = (C0817b) it.next();
                if (!this.f1755e || this.f1756f.get() != i2) {
                    break;
                } else if (this.f1753c.contains(c0817b)) {
                    c0817b.mo1018a(i);
                }
            }
            this.f1751a.clear();
            this.f1757g = false;
        }
    }

    public void m3615a(Bundle bundle) {
        boolean z = true;
        C0864b.m3459a(Looper.myLooper() == this.f1758h.getLooper(), (Object) "onConnectionSuccess must only be called on the Handler thread");
        synchronized (this.f1759i) {
            C0864b.m3458a(!this.f1757g);
            this.f1758h.removeMessages(1);
            this.f1757g = true;
            if (this.f1751a.size() != 0) {
                z = false;
            }
            C0864b.m3458a(z);
            ArrayList arrayList = new ArrayList(this.f1753c);
            int i = this.f1756f.get();
            Iterator it = arrayList.iterator();
            while (it.hasNext()) {
                C0817b c0817b = (C0817b) it.next();
                if (!this.f1755e || !this.f1752b.mo1043b() || this.f1756f.get() != i) {
                    break;
                } else if (!this.f1751a.contains(c0817b)) {
                    c0817b.mo1019a(bundle);
                }
            }
            this.f1751a.clear();
            this.f1757g = false;
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m3616a(com.google.android.gms.common.ConnectionResult r6) {
        /*
        r5 = this;
        r1 = 1;
        r0 = android.os.Looper.myLooper();
        r2 = r5.f1758h;
        r2 = r2.getLooper();
        if (r0 != r2) goto L_0x0046;
    L_0x000d:
        r0 = r1;
    L_0x000e:
        r2 = "onConnectionFailure must only be called on the Handler thread";
        com.google.android.gms.common.internal.C0864b.m3459a(r0, r2);
        r0 = r5.f1758h;
        r0.removeMessages(r1);
        r1 = r5.f1759i;
        monitor-enter(r1);
        r0 = new java.util.ArrayList;	 Catch:{ all -> 0x0054 }
        r2 = r5.f1754d;	 Catch:{ all -> 0x0054 }
        r0.<init>(r2);	 Catch:{ all -> 0x0054 }
        r2 = r5.f1756f;	 Catch:{ all -> 0x0054 }
        r2 = r2.get();	 Catch:{ all -> 0x0054 }
        r3 = r0.iterator();	 Catch:{ all -> 0x0054 }
    L_0x002c:
        r0 = r3.hasNext();	 Catch:{ all -> 0x0054 }
        if (r0 == 0) goto L_0x0057;
    L_0x0032:
        r0 = r3.next();	 Catch:{ all -> 0x0054 }
        r0 = (com.google.android.gms.common.api.GoogleApiClient.C0818c) r0;	 Catch:{ all -> 0x0054 }
        r4 = r5.f1755e;	 Catch:{ all -> 0x0054 }
        if (r4 == 0) goto L_0x0044;
    L_0x003c:
        r4 = r5.f1756f;	 Catch:{ all -> 0x0054 }
        r4 = r4.get();	 Catch:{ all -> 0x0054 }
        if (r4 == r2) goto L_0x0048;
    L_0x0044:
        monitor-exit(r1);	 Catch:{ all -> 0x0054 }
    L_0x0045:
        return;
    L_0x0046:
        r0 = 0;
        goto L_0x000e;
    L_0x0048:
        r4 = r5.f1754d;	 Catch:{ all -> 0x0054 }
        r4 = r4.contains(r0);	 Catch:{ all -> 0x0054 }
        if (r4 == 0) goto L_0x002c;
    L_0x0050:
        r0.mo1003a(r6);	 Catch:{ all -> 0x0054 }
        goto L_0x002c;
    L_0x0054:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0054 }
        throw r0;
    L_0x0057:
        monitor-exit(r1);	 Catch:{ all -> 0x0054 }
        goto L_0x0045;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.common.internal.q.a(com.google.android.gms.common.ConnectionResult):void");
    }

    public void m3617a(C0817b c0817b) {
        C0864b.m3454a((Object) c0817b);
        synchronized (this.f1759i) {
            if (this.f1753c.contains(c0817b)) {
                String valueOf = String.valueOf(c0817b);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 62).append("registerConnectionCallbacks(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.f1753c.add(c0817b);
            }
        }
        if (this.f1752b.mo1043b()) {
            this.f1758h.sendMessage(this.f1758h.obtainMessage(1, c0817b));
        }
    }

    public void m3618a(C0818c c0818c) {
        C0864b.m3454a((Object) c0818c);
        synchronized (this.f1759i) {
            if (this.f1754d.contains(c0818c)) {
                String valueOf = String.valueOf(c0818c);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 67).append("registerConnectionFailedListener(): listener ").append(valueOf).append(" is already registered").toString());
            } else {
                this.f1754d.add(c0818c);
            }
        }
    }

    public void m3619b() {
        this.f1755e = true;
    }

    public void m3620b(C0818c c0818c) {
        C0864b.m3454a((Object) c0818c);
        synchronized (this.f1759i) {
            if (!this.f1754d.remove(c0818c)) {
                String valueOf = String.valueOf(c0818c);
                Log.w("GmsClientEvents", new StringBuilder(String.valueOf(valueOf).length() + 57).append("unregisterConnectionFailedListener(): listener ").append(valueOf).append(" not found").toString());
            }
        }
    }

    public boolean handleMessage(Message message) {
        if (message.what == 1) {
            C0817b c0817b = (C0817b) message.obj;
            synchronized (this.f1759i) {
                if (this.f1755e && this.f1752b.mo1043b() && this.f1753c.contains(c0817b)) {
                    c0817b.mo1019a(this.f1752b.mo1044s());
                }
            }
            return true;
        }
        Log.wtf("GmsClientEvents", "Don't know how to handle message: " + message.what, new Exception());
        return false;
    }
}
