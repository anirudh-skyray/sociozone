package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C0849j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0835b;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0880x.C0881a;
import com.google.android.gms.common.internal.C0924y.C0926a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;

public abstract class C0867i<T extends IInterface> {
    public static final String[] f1660c = new String[]{"service_esmobile", "service_googleme"};
    final Handler f1661a;
    protected AtomicInteger f1662b = new AtomicInteger(0);
    private int f1663d;
    private long f1664e;
    private long f1665f;
    private int f1666g;
    private long f1667h;
    private final Context f1668i;
    private final Looper f1669j;
    private final C0910r f1670k;
    private final C0849j f1671l;
    private final Object f1672m = new Object();
    private final Object f1673n = new Object();
    private C0924y f1674o;
    private C0879f f1675p;
    private T f1676q;
    private final ArrayList<C0874e<?>> f1677r = new ArrayList();
    private C0883h f1678s;
    private int f1679t = 1;
    private final C0876b f1680u;
    private final C0877c f1681v;
    private final int f1682w;
    private final String f1683x;

    protected abstract class C0874e<TListener> {
        private TListener f1690a;
        private boolean f1691b = false;
        final /* synthetic */ C0867i f1692d;

        public C0874e(C0867i c0867i, TListener tListener) {
            this.f1692d = c0867i;
            this.f1690a = tListener;
        }

        protected abstract void mo915a(TListener tListener);

        protected abstract void mo916b();

        public void m3535c() {
            synchronized (this) {
                Object obj = this.f1690a;
                if (this.f1691b) {
                    String valueOf = String.valueOf(this);
                    Log.w("GmsClient", new StringBuilder(String.valueOf(valueOf).length() + 47).append("Callback proxy ").append(valueOf).append(" being reused. This is not safe.").toString());
                }
            }
            if (obj != null) {
                try {
                    mo915a(obj);
                } catch (RuntimeException e) {
                    mo916b();
                    throw e;
                }
            }
            mo916b();
            synchronized (this) {
                this.f1691b = true;
            }
            m3536d();
        }

        public void m3536d() {
            m3537e();
            synchronized (this.f1692d.f1677r) {
                this.f1692d.f1677r.remove(this);
            }
        }

        public void m3537e() {
            synchronized (this) {
                this.f1690a = null;
            }
        }
    }

    private abstract class C0875a extends C0874e<Boolean> {
        public final int f1693a;
        public final Bundle f1694b;
        final /* synthetic */ C0867i f1695c;

        protected C0875a(C0867i c0867i, int i, Bundle bundle) {
            this.f1695c = c0867i;
            super(c0867i, Boolean.valueOf(true));
            this.f1693a = i;
            this.f1694b = bundle;
        }

        protected abstract void mo920a(ConnectionResult connectionResult);

        protected void m3539a(Boolean bool) {
            PendingIntent pendingIntent = null;
            if (bool == null) {
                this.f1695c.m3476b(1, null);
                return;
            }
            switch (this.f1693a) {
                case 0:
                    if (!mo921a()) {
                        this.f1695c.m3476b(1, null);
                        mo920a(new ConnectionResult(8, null));
                        return;
                    }
                    return;
                case 10:
                    this.f1695c.m3476b(1, null);
                    throw new IllegalStateException("A fatal developer error has occurred. Check the logs for further information.");
                default:
                    this.f1695c.m3476b(1, null);
                    if (this.f1694b != null) {
                        pendingIntent = (PendingIntent) this.f1694b.getParcelable("pendingIntent");
                    }
                    mo920a(new ConnectionResult(this.f1693a, pendingIntent));
                    return;
            }
        }

        protected /* synthetic */ void mo915a(Object obj) {
            m3539a((Boolean) obj);
        }

        protected abstract boolean mo921a();

        protected void mo916b() {
        }
    }

    public interface C0876b {
        void mo926a(int i);

        void mo927a(Bundle bundle);
    }

    public interface C0877c {
        void mo928a(ConnectionResult connectionResult);
    }

    final class C0878d extends Handler {
        final /* synthetic */ C0867i f1696a;

        public C0878d(C0867i c0867i, Looper looper) {
            this.f1696a = c0867i;
            super(looper);
        }

        private void m3546a(Message message) {
            C0874e c0874e = (C0874e) message.obj;
            c0874e.mo916b();
            c0874e.m3536d();
        }

        private boolean m3547b(Message message) {
            return message.what == 2 || message.what == 1 || message.what == 5;
        }

        public void handleMessage(Message message) {
            PendingIntent pendingIntent = null;
            if (this.f1696a.f1662b.get() != message.arg1) {
                if (m3547b(message)) {
                    m3546a(message);
                }
            } else if ((message.what == 1 || message.what == 5) && !this.f1696a.m3495c()) {
                m3546a(message);
            } else if (message.what == 3) {
                if (message.obj instanceof PendingIntent) {
                    pendingIntent = (PendingIntent) message.obj;
                }
                ConnectionResult connectionResult = new ConnectionResult(message.arg2, pendingIntent);
                this.f1696a.f1675p.mo919a(connectionResult);
                this.f1696a.m3489a(connectionResult);
            } else if (message.what == 4) {
                this.f1696a.m3476b(4, null);
                if (this.f1696a.f1680u != null) {
                    this.f1696a.f1680u.mo926a(message.arg2);
                }
                this.f1696a.m3484a(message.arg2);
                this.f1696a.m3473a(4, 1, null);
            } else if (message.what == 2 && !this.f1696a.m3494b()) {
                m3546a(message);
            } else if (m3547b(message)) {
                ((C0874e) message.obj).m3535c();
            } else {
                Log.wtf("GmsClient", "Don't know how to handle message: " + message.what, new Exception());
            }
        }
    }

    public interface C0879f {
        void mo919a(ConnectionResult connectionResult);
    }

    public static final class C0882g extends C0881a {
        private C0867i f1697a;
        private final int f1698b;

        public C0882g(C0867i c0867i, int i) {
            this.f1697a = c0867i;
            this.f1698b = i;
        }

        private void m3552a() {
            this.f1697a = null;
        }

        public void mo917a(int i, Bundle bundle) {
            Log.wtf("GmsClient", "received deprecated onAccountValidationComplete callback, ignoring", new Exception());
        }

        public void mo918a(int i, IBinder iBinder, Bundle bundle) {
            C0864b.m3455a(this.f1697a, (Object) "onPostInitComplete can be called only once per call to getRemoteService");
            this.f1697a.m3486a(i, iBinder, bundle, this.f1698b);
            m3552a();
        }
    }

    public final class C0883h implements ServiceConnection {
        final /* synthetic */ C0867i f1699a;
        private final int f1700b;

        public C0883h(C0867i c0867i, int i) {
            this.f1699a = c0867i;
            this.f1700b = i;
        }

        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            C0864b.m3455a((Object) iBinder, (Object) "Expecting a valid IBinder");
            synchronized (this.f1699a.f1673n) {
                this.f1699a.f1674o = C0926a.m3790a(iBinder);
            }
            this.f1699a.m3485a(0, null, this.f1700b);
        }

        public void onServiceDisconnected(ComponentName componentName) {
            synchronized (this.f1699a.f1673n) {
                this.f1699a.f1674o = null;
            }
            this.f1699a.f1661a.sendMessage(this.f1699a.f1661a.obtainMessage(4, this.f1700b, 1));
        }
    }

    protected class C0884i implements C0879f {
        final /* synthetic */ C0867i f1701a;

        public C0884i(C0867i c0867i) {
            this.f1701a = c0867i;
        }

        public void mo919a(ConnectionResult connectionResult) {
            if (connectionResult.m3252b()) {
                this.f1701a.m3491a(null, this.f1701a.mo909v());
            } else if (this.f1701a.f1681v != null) {
                this.f1701a.f1681v.mo928a(connectionResult);
            }
        }
    }

    protected final class C0885j extends C0875a {
        public final IBinder f1702e;
        final /* synthetic */ C0867i f1703f;

        public C0885j(C0867i c0867i, int i, IBinder iBinder, Bundle bundle) {
            this.f1703f = c0867i;
            super(c0867i, i, bundle);
            this.f1702e = iBinder;
        }

        protected void mo920a(ConnectionResult connectionResult) {
            if (this.f1703f.f1681v != null) {
                this.f1703f.f1681v.mo928a(connectionResult);
            }
            this.f1703f.m3489a(connectionResult);
        }

        protected boolean mo921a() {
            try {
                String interfaceDescriptor = this.f1702e.getInterfaceDescriptor();
                if (this.f1703f.mo913j().equals(interfaceDescriptor)) {
                    IInterface a = this.f1703f.mo910a(this.f1702e);
                    if (a == null || !this.f1703f.m3473a(2, 3, a)) {
                        return false;
                    }
                    Bundle s = this.f1703f.m3509s();
                    if (this.f1703f.f1680u != null) {
                        this.f1703f.f1680u.mo927a(s);
                    }
                    return true;
                }
                String valueOf = String.valueOf(this.f1703f.mo913j());
                Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(interfaceDescriptor).length()).append("service descriptor mismatch: ").append(valueOf).append(" vs. ").append(interfaceDescriptor).toString());
                return false;
            } catch (RemoteException e) {
                Log.w("GmsClient", "service probably died");
                return false;
            }
        }
    }

    protected final class C0886k extends C0875a {
        final /* synthetic */ C0867i f1704e;

        public C0886k(C0867i c0867i, int i, Bundle bundle) {
            this.f1704e = c0867i;
            super(c0867i, i, bundle);
        }

        protected void mo920a(ConnectionResult connectionResult) {
            this.f1704e.f1675p.mo919a(connectionResult);
            this.f1704e.m3489a(connectionResult);
        }

        protected boolean mo921a() {
            this.f1704e.f1675p.mo919a(ConnectionResult.f1539a);
            return true;
        }
    }

    protected C0867i(Context context, Looper looper, C0910r c0910r, C0849j c0849j, int i, C0876b c0876b, C0877c c0877c, String str) {
        this.f1668i = (Context) C0864b.m3455a((Object) context, (Object) "Context must not be null");
        this.f1669j = (Looper) C0864b.m3455a((Object) looper, (Object) "Looper must not be null");
        this.f1670k = (C0910r) C0864b.m3455a((Object) c0910r, (Object) "Supervisor must not be null");
        this.f1671l = (C0849j) C0864b.m3455a((Object) c0849j, (Object) "API availability must not be null");
        this.f1661a = new C0878d(this, looper);
        this.f1682w = i;
        this.f1680u = c0876b;
        this.f1681v = c0877c;
        this.f1683x = str;
    }

    private boolean m3473a(int i, int i2, T t) {
        boolean z;
        synchronized (this.f1672m) {
            if (this.f1679t != i) {
                z = false;
            } else {
                m3476b(i2, t);
                z = true;
            }
        }
        return z;
    }

    private void m3476b(int i, T t) {
        boolean z = true;
        if ((i == 3) != (t != null)) {
            z = false;
        }
        C0864b.m3462b(z);
        synchronized (this.f1672m) {
            this.f1679t = i;
            this.f1676q = t;
            mo911a(i, (IInterface) t);
            switch (i) {
                case 1:
                    m3481w();
                    break;
                case 2:
                    mo914k();
                    break;
                case 3:
                    m3488a((IInterface) t);
                    break;
            }
        }
    }

    private void mo914k() {
        if (this.f1678s != null) {
            String valueOf = String.valueOf(mo912i());
            String valueOf2 = String.valueOf(c_());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(valueOf2).length()).append("Calling connect() while still connected, missing disconnect() for ").append(valueOf).append(" on ").append(valueOf2).toString());
            this.f1670k.mo930b(mo912i(), c_(), this.f1678s, m3503m());
            this.f1662b.incrementAndGet();
        }
        this.f1678s = new C0883h(this, this.f1662b.get());
        if (!this.f1670k.mo929a(mo912i(), c_(), this.f1678s, m3503m())) {
            valueOf = String.valueOf(mo912i());
            valueOf2 = String.valueOf(c_());
            Log.e("GmsClient", new StringBuilder((String.valueOf(valueOf).length() + 34) + String.valueOf(valueOf2).length()).append("unable to connect to service: ").append(valueOf).append(" on ").append(valueOf2).toString());
            m3485a(16, null, this.f1662b.get());
        }
    }

    private void m3481w() {
        if (this.f1678s != null) {
            this.f1670k.mo930b(mo912i(), c_(), this.f1678s, m3503m());
            this.f1678s = null;
        }
    }

    protected abstract T mo910a(IBinder iBinder);

    public void mo1105a() {
        this.f1662b.incrementAndGet();
        synchronized (this.f1677r) {
            int size = this.f1677r.size();
            for (int i = 0; i < size; i++) {
                ((C0874e) this.f1677r.get(i)).m3537e();
            }
            this.f1677r.clear();
        }
        synchronized (this.f1673n) {
            this.f1674o = null;
        }
        m3476b(1, null);
    }

    protected void m3484a(int i) {
        this.f1663d = i;
        this.f1664e = System.currentTimeMillis();
    }

    protected void m3485a(int i, Bundle bundle, int i2) {
        this.f1661a.sendMessage(this.f1661a.obtainMessage(5, i2, -1, new C0886k(this, i, bundle)));
    }

    protected void m3486a(int i, IBinder iBinder, Bundle bundle, int i2) {
        this.f1661a.sendMessage(this.f1661a.obtainMessage(1, i2, -1, new C0885j(this, i, iBinder, bundle)));
    }

    void mo911a(int i, T t) {
    }

    protected void m3488a(T t) {
        this.f1665f = System.currentTimeMillis();
    }

    protected void m3489a(ConnectionResult connectionResult) {
        this.f1666g = connectionResult.m3253c();
        this.f1667h = System.currentTimeMillis();
    }

    public void m3490a(C0879f c0879f) {
        this.f1675p = (C0879f) C0864b.m3455a((Object) c0879f, (Object) "Connection progress callbacks cannot be null.");
        m3476b(2, null);
    }

    public void m3491a(C0859u c0859u, Set<Scope> set) {
        try {
            GetServiceRequest a = new GetServiceRequest(this.f1682w).m3431a(this.f1668i.getPackageName()).m3429a(mo1061q());
            if (set != null) {
                a.m3432a((Collection) set);
            }
            if (mo1118d()) {
                a.m3428a(m3506p()).m3430a(c0859u);
            } else if (m3511u()) {
                a.m3428a(mo908o());
            }
            synchronized (this.f1673n) {
                if (this.f1674o != null) {
                    this.f1674o.mo943a(new C0882g(this, this.f1662b.get()), a);
                } else {
                    Log.w("GmsClient", "mServiceBroker is null, client disconnected");
                }
            }
        } catch (DeadObjectException e) {
            Log.w("GmsClient", "service died");
            m3493b(1);
        } catch (Throwable e2) {
            Log.w("GmsClient", "Remote exception occurred", e2);
        }
    }

    public void m3492a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        synchronized (this.f1672m) {
            int i = this.f1679t;
            IInterface iInterface = this.f1676q;
        }
        printWriter.append(str).append("mConnectState=");
        switch (i) {
            case 1:
                printWriter.print("DISCONNECTED");
                break;
            case 2:
                printWriter.print("CONNECTING");
                break;
            case 3:
                printWriter.print("CONNECTED");
                break;
            case 4:
                printWriter.print("DISCONNECTING");
                break;
            default:
                printWriter.print("UNKNOWN");
                break;
        }
        printWriter.append(" mService=");
        if (iInterface == null) {
            printWriter.println("null");
        } else {
            printWriter.append(mo913j()).append("@").println(Integer.toHexString(System.identityHashCode(iInterface.asBinder())));
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US);
        if (this.f1665f > 0) {
            PrintWriter append = printWriter.append(str).append("lastConnectedTime=");
            long j = this.f1665f;
            String valueOf = String.valueOf(simpleDateFormat.format(new Date(this.f1665f)));
            append.println(new StringBuilder(String.valueOf(valueOf).length() + 21).append(j).append(" ").append(valueOf).toString());
        }
        if (this.f1664e > 0) {
            printWriter.append(str).append("lastSuspendedCause=");
            switch (this.f1663d) {
                case 1:
                    printWriter.append("CAUSE_SERVICE_DISCONNECTED");
                    break;
                case 2:
                    printWriter.append("CAUSE_NETWORK_LOST");
                    break;
                default:
                    printWriter.append(String.valueOf(this.f1663d));
                    break;
            }
            append = printWriter.append(" lastSuspendedTime=");
            j = this.f1664e;
            valueOf = String.valueOf(simpleDateFormat.format(new Date(this.f1664e)));
            append.println(new StringBuilder(String.valueOf(valueOf).length() + 21).append(j).append(" ").append(valueOf).toString());
        }
        if (this.f1667h > 0) {
            printWriter.append(str).append("lastFailedStatus=").append(C0835b.m3348a(this.f1666g));
            append = printWriter.append(" lastFailedTime=");
            j = this.f1667h;
            String valueOf2 = String.valueOf(simpleDateFormat.format(new Date(this.f1667h)));
            append.println(new StringBuilder(String.valueOf(valueOf2).length() + 21).append(j).append(" ").append(valueOf2).toString());
        }
    }

    public void m3493b(int i) {
        this.f1661a.sendMessage(this.f1661a.obtainMessage(4, this.f1662b.get(), i));
    }

    public boolean m3494b() {
        boolean z;
        synchronized (this.f1672m) {
            z = this.f1679t == 3;
        }
        return z;
    }

    public boolean m3495c() {
        boolean z;
        synchronized (this.f1672m) {
            z = this.f1679t == 2;
        }
        return z;
    }

    protected String c_() {
        return "com.google.android.gms";
    }

    public boolean mo1118d() {
        return false;
    }

    public boolean m3497e() {
        return true;
    }

    public boolean m3498f() {
        return false;
    }

    public Intent m3499g() {
        throw new UnsupportedOperationException("Not a sign in API");
    }

    public IBinder m3500h() {
        IBinder iBinder;
        synchronized (this.f1673n) {
            if (this.f1674o == null) {
                iBinder = null;
            } else {
                iBinder = this.f1674o.asBinder();
            }
        }
        return iBinder;
    }

    protected abstract String mo912i();

    protected abstract String mo913j();

    protected final String m3503m() {
        return this.f1683x == null ? this.f1668i.getClass().getName() : this.f1683x;
    }

    public final Context m3504n() {
        return this.f1668i;
    }

    public Account mo908o() {
        return null;
    }

    public final Account m3506p() {
        return mo908o() != null ? mo908o() : new Account("<<default account>>", "com.google");
    }

    protected Bundle mo1061q() {
        return new Bundle();
    }

    protected final void m3508r() {
        if (!m3494b()) {
            throw new IllegalStateException("Not connected. Call connect() and wait for onConnected() to be called.");
        }
    }

    public Bundle m3509s() {
        return null;
    }

    public final T m3510t() throws DeadObjectException {
        T t;
        synchronized (this.f1672m) {
            if (this.f1679t == 4) {
                throw new DeadObjectException();
            }
            m3508r();
            C0864b.m3459a(this.f1676q != null, (Object) "Client is connected but service is null");
            t = this.f1676q;
        }
        return t;
    }

    public boolean m3511u() {
        return false;
    }

    protected Set<Scope> mo909v() {
        return Collections.EMPTY_SET;
    }
}
