package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0866d implements Creator<ResolveAccountResponse> {
    static void m3467a(ResolveAccountResponse resolveAccountResponse, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, resolveAccountResponse.f1642a);
        C0917b.m3676a(parcel, 2, resolveAccountResponse.f1643b, false);
        C0917b.m3677a(parcel, 3, resolveAccountResponse.m3437b(), i, false);
        C0917b.m3682a(parcel, 4, resolveAccountResponse.m3438c());
        C0917b.m3682a(parcel, 5, resolveAccountResponse.m3439d());
        C0917b.m3670a(parcel, a);
    }

    public ResolveAccountResponse m3468a(Parcel parcel) {
        ConnectionResult connectionResult = null;
        boolean z = false;
        int b = C0916a.m3653b(parcel);
        boolean z2 = false;
        IBinder iBinder = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    iBinder = C0916a.m3665k(parcel, a);
                    break;
                case 3:
                    connectionResult = (ConnectionResult) C0916a.m3650a(parcel, a, ConnectionResult.CREATOR);
                    break;
                case 4:
                    z2 = C0916a.m3657c(parcel, a);
                    break;
                case 5:
                    z = C0916a.m3657c(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ResolveAccountResponse(i, iBinder, connectionResult, z2, z);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public ResolveAccountResponse[] m3469a(int i) {
        return new ResolveAccountResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3468a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3469a(i);
    }
}
