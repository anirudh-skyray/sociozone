package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.C0859u.C0860a;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountResponse extends AbstractSafeParcelable {
    public static final Creator<ResolveAccountResponse> CREATOR = new C0866d();
    final int f1642a;
    IBinder f1643b;
    private ConnectionResult f1644c;
    private boolean f1645d;
    private boolean f1646e;

    ResolveAccountResponse(int i, IBinder iBinder, ConnectionResult connectionResult, boolean z, boolean z2) {
        this.f1642a = i;
        this.f1643b = iBinder;
        this.f1644c = connectionResult;
        this.f1645d = z;
        this.f1646e = z2;
    }

    public C0859u m3436a() {
        return C0860a.m3445a(this.f1643b);
    }

    public ConnectionResult m3437b() {
        return this.f1644c;
    }

    public boolean m3438c() {
        return this.f1645d;
    }

    public boolean m3439d() {
        return this.f1646e;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ResolveAccountResponse)) {
            return false;
        }
        ResolveAccountResponse resolveAccountResponse = (ResolveAccountResponse) obj;
        return this.f1644c.equals(resolveAccountResponse.f1644c) && m3436a().equals(resolveAccountResponse.m3436a());
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0866d.m3467a(this, parcel, i);
    }
}
