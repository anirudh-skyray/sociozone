package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.view.View;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.GoogleApiClient.C0816a;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.p023d.as;
import java.util.Collections;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class C0900l {
    private final Account f1730a;
    private final Set<Scope> f1731b;
    private final Set<Scope> f1732c;
    private final Map<C0834a<?>, C0899a> f1733d;
    private final int f1734e;
    private final View f1735f;
    private final String f1736g;
    private final String f1737h;
    private final as f1738i;
    private Integer f1739j;

    public static final class C0899a {
        public final Set<Scope> f1728a;
        public final boolean f1729b;
    }

    public C0900l(Account account, Set<Scope> set, Map<C0834a<?>, C0899a> map, int i, View view, String str, String str2, as asVar) {
        Map map2;
        this.f1730a = account;
        this.f1731b = set == null ? Collections.EMPTY_SET : Collections.unmodifiableSet(set);
        if (map == null) {
            map2 = Collections.EMPTY_MAP;
        }
        this.f1733d = map2;
        this.f1735f = view;
        this.f1734e = i;
        this.f1736g = str;
        this.f1737h = str2;
        this.f1738i = asVar;
        Set hashSet = new HashSet(this.f1731b);
        for (C0899a c0899a : this.f1733d.values()) {
            hashSet.addAll(c0899a.f1728a);
        }
        this.f1732c = Collections.unmodifiableSet(hashSet);
    }

    public static C0900l m3584a(Context context) {
        return new C0816a(context).m3297a();
    }

    public Account m3585a() {
        return this.f1730a;
    }

    public void m3586a(Integer num) {
        this.f1739j = num;
    }

    public Account m3587b() {
        return this.f1730a != null ? this.f1730a : new Account("<<default account>>", "com.google");
    }

    public Set<Scope> m3588c() {
        return this.f1731b;
    }

    public Set<Scope> m3589d() {
        return this.f1732c;
    }

    public Map<C0834a<?>, C0899a> m3590e() {
        return this.f1733d;
    }

    public String m3591f() {
        return this.f1736g;
    }

    public String m3592g() {
        return this.f1737h;
    }

    public as m3593h() {
        return this.f1738i;
    }

    public Integer m3594i() {
        return this.f1739j;
    }
}
