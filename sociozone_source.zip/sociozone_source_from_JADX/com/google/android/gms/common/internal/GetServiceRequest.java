package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.C0849j;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0859u.C0860a;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Collection;

public class GetServiceRequest extends AbstractSafeParcelable {
    public static final Creator<GetServiceRequest> CREATOR = new C0906o();
    final int f1629a;
    final int f1630b;
    int f1631c;
    String f1632d;
    IBinder f1633e;
    Scope[] f1634f;
    Bundle f1635g;
    Account f1636h;
    long f1637i;

    public GetServiceRequest(int i) {
        this.f1629a = 3;
        this.f1631c = C0849j.f1606b;
        this.f1630b = i;
    }

    GetServiceRequest(int i, int i2, int i3, String str, IBinder iBinder, Scope[] scopeArr, Bundle bundle, Account account, long j) {
        this.f1629a = i;
        this.f1630b = i2;
        this.f1631c = i3;
        this.f1632d = str;
        if (i < 2) {
            this.f1636h = m3427a(iBinder);
        } else {
            this.f1633e = iBinder;
            this.f1636h = account;
        }
        this.f1634f = scopeArr;
        this.f1635g = bundle;
        this.f1637i = j;
    }

    private Account m3427a(IBinder iBinder) {
        return iBinder != null ? C0861a.m3446a(C0860a.m3445a(iBinder)) : null;
    }

    public GetServiceRequest m3428a(Account account) {
        this.f1636h = account;
        return this;
    }

    public GetServiceRequest m3429a(Bundle bundle) {
        this.f1635g = bundle;
        return this;
    }

    public GetServiceRequest m3430a(C0859u c0859u) {
        if (c0859u != null) {
            this.f1633e = c0859u.asBinder();
        }
        return this;
    }

    public GetServiceRequest m3431a(String str) {
        this.f1632d = str;
        return this;
    }

    public GetServiceRequest m3432a(Collection<Scope> collection) {
        this.f1634f = (Scope[]) collection.toArray(new Scope[collection.size()]);
        return this;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0906o.m3607a(this, parcel, i);
    }
}
