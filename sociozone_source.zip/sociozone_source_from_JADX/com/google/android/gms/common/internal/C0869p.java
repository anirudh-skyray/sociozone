package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.C0850b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0867i.C0876b;
import com.google.android.gms.common.internal.C0867i.C0877c;
import com.google.android.gms.common.internal.C0909q.C0868a;
import java.util.Set;

public abstract class C0869p<T extends IInterface> extends C0867i<T> implements C0829f, C0868a {
    private final C0900l f1684d;
    private final Set<Scope> f1685e;
    private final Account f1686f;

    class C09071 implements C0876b {
        final /* synthetic */ C0817b f1749a;

        C09071(C0817b c0817b) {
            this.f1749a = c0817b;
        }

        public void mo926a(int i) {
            this.f1749a.mo1018a(i);
        }

        public void mo927a(Bundle bundle) {
            this.f1749a.mo1019a(bundle);
        }
    }

    class C09082 implements C0877c {
        final /* synthetic */ C0818c f1750a;

        C09082(C0818c c0818c) {
            this.f1750a = c0818c;
        }

        public void mo928a(ConnectionResult connectionResult) {
            this.f1750a.mo1003a(connectionResult);
        }
    }

    protected C0869p(Context context, Looper looper, int i, C0900l c0900l, C0817b c0817b, C0818c c0818c) {
        this(context, looper, C0910r.m3621a(context), C0850b.m3382a(), i, c0900l, (C0817b) C0864b.m3454a((Object) c0817b), (C0818c) C0864b.m3454a((Object) c0818c));
    }

    protected C0869p(Context context, Looper looper, C0910r c0910r, C0850b c0850b, int i, C0900l c0900l, C0817b c0817b, C0818c c0818c) {
        super(context, looper, c0910r, c0850b, i, C0869p.m3515a(c0817b), C0869p.m3516a(c0818c), c0900l.m3592g());
        this.f1684d = c0900l;
        this.f1686f = c0900l.m3585a();
        this.f1685e = m3517b(c0900l.m3589d());
    }

    private static C0876b m3515a(C0817b c0817b) {
        return c0817b == null ? null : new C09071(c0817b);
    }

    private static C0877c m3516a(C0818c c0818c) {
        return c0818c == null ? null : new C09082(c0818c);
    }

    private Set<Scope> m3517b(Set<Scope> set) {
        Set<Scope> a = m3518a((Set) set);
        for (Scope contains : a) {
            if (!set.contains(contains)) {
                throw new IllegalStateException("Expanding scopes is not permitted, use implied scopes instead");
            }
        }
        return a;
    }

    protected Set<Scope> m3518a(Set<Scope> set) {
        return set;
    }

    public final Account mo908o() {
        return this.f1686f;
    }

    protected final Set<Scope> mo909v() {
        return this.f1685e;
    }
}
