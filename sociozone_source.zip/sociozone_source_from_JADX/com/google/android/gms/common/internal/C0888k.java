package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public abstract class C0888k {
    public static final C0888k f1706a = C0888k.m3562a((CharSequence) "\t\n\u000b\f\r     　 ᠎ ").mo923a(C0888k.m3561a(' ', ' '));
    public static final C0888k f1707b = C0888k.m3562a((CharSequence) "\t\n\u000b\f\r     　").mo923a(C0888k.m3561a(' ', ' ')).mo923a(C0888k.m3561a(' ', ' '));
    public static final C0888k f1708c = C0888k.m3561a('\u0000', '');
    public static final C0888k f1709d;
    public static final C0888k f1710e = C0888k.m3561a('\t', '\r').mo923a(C0888k.m3561a('\u001c', ' ')).mo923a(C0888k.m3560a(' ')).mo923a(C0888k.m3560a('᠎')).mo923a(C0888k.m3561a(' ', ' ')).mo923a(C0888k.m3561a(' ', '​')).mo923a(C0888k.m3561a(' ', ' ')).mo923a(C0888k.m3560a(' ')).mo923a(C0888k.m3560a('　'));
    public static final C0888k f1711f = new C08891();
    public static final C0888k f1712g = new C08957();
    public static final C0888k f1713h = new C08968();
    public static final C0888k f1714i = new C08979();
    public static final C0888k f1715j = new C0888k() {
        public boolean mo922b(char c) {
            return Character.isLowerCase(c);
        }
    };
    public static final C0888k f1716k = C0888k.m3561a('\u0000', '\u001f').mo923a(C0888k.m3561a('', ''));
    public static final C0888k f1717l = C0888k.m3561a('\u0000', ' ').mo923a(C0888k.m3561a('', ' ')).mo923a(C0888k.m3560a('­')).mo923a(C0888k.m3561a('؀', '؃')).mo923a(C0888k.m3562a((CharSequence) "۝܏ ឴឵᠎")).mo923a(C0888k.m3561a(' ', '‏')).mo923a(C0888k.m3561a(' ', ' ')).mo923a(C0888k.m3561a(' ', '⁤')).mo923a(C0888k.m3561a('⁪', '⁯')).mo923a(C0888k.m3560a('　')).mo923a(C0888k.m3561a('?', '')).mo923a(C0888k.m3562a((CharSequence) "﻿￹￺￻"));
    public static final C0888k f1718m = C0888k.m3561a('\u0000', 'ӹ').mo923a(C0888k.m3560a('־')).mo923a(C0888k.m3561a('א', 'ת')).mo923a(C0888k.m3560a('׳')).mo923a(C0888k.m3560a('״')).mo923a(C0888k.m3561a('؀', 'ۿ')).mo923a(C0888k.m3561a('ݐ', 'ݿ')).mo923a(C0888k.m3561a('฀', '๿')).mo923a(C0888k.m3561a('Ḁ', '₯')).mo923a(C0888k.m3561a('℀', '℺')).mo923a(C0888k.m3561a('ﭐ', '﷿')).mo923a(C0888k.m3561a('ﹰ', '﻿')).mo923a(C0888k.m3561a('｡', 'ￜ'));
    public static final C0888k f1719n = new C0888k() {
        public C0888k mo923a(C0888k c0888k) {
            C0864b.m3454a((Object) c0888k);
            return this;
        }

        public boolean mo922b(char c) {
            return true;
        }

        public boolean mo924b(CharSequence charSequence) {
            C0864b.m3454a((Object) charSequence);
            return true;
        }
    };
    public static final C0888k f1720o = new C08902();

    class C08891 extends C0888k {
        C08891() {
        }

        public boolean mo922b(char c) {
            return Character.isDigit(c);
        }
    }

    class C08902 extends C0888k {
        C08902() {
        }

        public C0888k mo923a(C0888k c0888k) {
            return (C0888k) C0864b.m3454a((Object) c0888k);
        }

        public boolean mo922b(char c) {
            return false;
        }

        public boolean mo924b(CharSequence charSequence) {
            return charSequence.length() == 0;
        }
    }

    class C08913 extends C0888k {
        final /* synthetic */ char f1721p;

        C08913(char c) {
            this.f1721p = c;
        }

        public C0888k mo923a(C0888k c0888k) {
            return c0888k.mo922b(this.f1721p) ? c0888k : super.mo923a(c0888k);
        }

        public boolean mo922b(char c) {
            return c == this.f1721p;
        }
    }

    class C08924 extends C0888k {
        final /* synthetic */ char f1722p;
        final /* synthetic */ char f1723q;

        C08924(char c, char c2) {
            this.f1722p = c;
            this.f1723q = c2;
        }

        public boolean mo922b(char c) {
            return c == this.f1722p || c == this.f1723q;
        }
    }

    class C08935 extends C0888k {
        final /* synthetic */ char[] f1724p;

        C08935(char[] cArr) {
            this.f1724p = cArr;
        }

        public boolean mo922b(char c) {
            return Arrays.binarySearch(this.f1724p, c) >= 0;
        }
    }

    class C08946 extends C0888k {
        final /* synthetic */ char f1725p;
        final /* synthetic */ char f1726q;

        C08946(char c, char c2) {
            this.f1725p = c;
            this.f1726q = c2;
        }

        public boolean mo922b(char c) {
            return this.f1725p <= c && c <= this.f1726q;
        }
    }

    class C08957 extends C0888k {
        C08957() {
        }

        public boolean mo922b(char c) {
            return Character.isLetter(c);
        }
    }

    class C08968 extends C0888k {
        C08968() {
        }

        public boolean mo922b(char c) {
            return Character.isLetterOrDigit(c);
        }
    }

    class C08979 extends C0888k {
        C08979() {
        }

        public boolean mo922b(char c) {
            return Character.isUpperCase(c);
        }
    }

    private static class C0898a extends C0888k {
        List<C0888k> f1727p;

        C0898a(List<C0888k> list) {
            this.f1727p = list;
        }

        public C0888k mo923a(C0888k c0888k) {
            List arrayList = new ArrayList(this.f1727p);
            arrayList.add((C0888k) C0864b.m3454a((Object) c0888k));
            return new C0898a(arrayList);
        }

        public boolean mo922b(char c) {
            for (C0888k b : this.f1727p) {
                if (b.mo922b(c)) {
                    return true;
                }
            }
            return false;
        }
    }

    static {
        C0888k a = C0888k.m3561a('0', '9');
        C0888k c0888k = a;
        for (char c : "٠۰߀०০੦૦୦௦౦೦൦๐໐༠၀႐០᠐᥆᧐᭐᮰᱀᱐꘠꣐꤀꩐０".toCharArray()) {
            c0888k = c0888k.mo923a(C0888k.m3561a(c, (char) (c + 9)));
        }
        f1709d = c0888k;
    }

    public static C0888k m3560a(char c) {
        return new C08913(c);
    }

    public static C0888k m3561a(char c, char c2) {
        C0864b.m3462b(c2 >= c);
        return new C08946(c, c2);
    }

    public static C0888k m3562a(CharSequence charSequence) {
        switch (charSequence.length()) {
            case 0:
                return f1720o;
            case 1:
                return C0888k.m3560a(charSequence.charAt(0));
            case 2:
                return new C08924(charSequence.charAt(0), charSequence.charAt(1));
            default:
                char[] toCharArray = charSequence.toString().toCharArray();
                Arrays.sort(toCharArray);
                return new C08935(toCharArray);
        }
    }

    public C0888k mo923a(C0888k c0888k) {
        return new C0898a(Arrays.asList(new C0888k[]{this, (C0888k) C0864b.m3454a((Object) c0888k)}));
    }

    public abstract boolean mo922b(char c);

    public boolean mo924b(CharSequence charSequence) {
        for (int length = charSequence.length() - 1; length >= 0; length--) {
            if (!mo922b(charSequence.charAt(length))) {
                return false;
            }
        }
        return true;
    }
}
