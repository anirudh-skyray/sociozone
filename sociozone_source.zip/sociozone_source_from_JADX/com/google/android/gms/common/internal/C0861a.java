package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Binder;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.C0854l;
import com.google.android.gms.common.internal.C0859u.C0860a;

public class C0861a extends C0860a {
    int f1653a;

    public static Account m3446a(C0859u c0859u) {
        Account account = null;
        if (c0859u != null) {
            long clearCallingIdentity = Binder.clearCallingIdentity();
            try {
                account = c0859u.mo907a();
            } catch (RemoteException e) {
                Log.w("AccountAccessor", "Remote account accessor probably died");
            } finally {
                Binder.restoreCallingIdentity(clearCallingIdentity);
            }
        }
        return account;
    }

    public Account mo907a() {
        int callingUid = Binder.getCallingUid();
        if (callingUid != this.f1653a) {
            if (C0854l.m3404b(null, callingUid)) {
                this.f1653a = callingUid;
            } else {
                throw new SecurityException("Caller is not GooglePlayServices");
            }
        }
        return null;
    }

    public boolean equals(Object obj) {
        Account account = null;
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof C0861a)) {
            return false;
        }
        C0861a c0861a = (C0861a) obj;
        return account.equals(account);
    }
}
