package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0872g implements Creator<ValidateAccountRequest> {
    static void m3527a(ValidateAccountRequest validateAccountRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, validateAccountRequest.f1647a);
        C0917b.m3673a(parcel, 2, validateAccountRequest.m3440a());
        C0917b.m3676a(parcel, 3, validateAccountRequest.f1648b, false);
        C0917b.m3684a(parcel, 4, validateAccountRequest.m3441b(), i, false);
        C0917b.m3675a(parcel, 5, validateAccountRequest.m3443d(), false);
        C0917b.m3679a(parcel, 6, validateAccountRequest.m3442c(), false);
        C0917b.m3670a(parcel, a);
    }

    public ValidateAccountRequest m3528a(Parcel parcel) {
        int i = 0;
        String str = null;
        int b = C0916a.m3653b(parcel);
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 3:
                    iBinder = C0916a.m3665k(parcel, a);
                    break;
                case 4:
                    scopeArr = (Scope[]) C0916a.m3655b(parcel, a, Scope.CREATOR);
                    break;
                case 5:
                    bundle = C0916a.m3666l(parcel, a);
                    break;
                case 6:
                    str = C0916a.m3664j(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ValidateAccountRequest(i2, i, iBinder, scopeArr, bundle, str);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public ValidateAccountRequest[] m3529a(int i) {
        return new ValidateAccountRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3528a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3529a(i);
    }
}
