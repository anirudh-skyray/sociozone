package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.IBinder;
import android.os.Message;
import com.google.android.gms.common.stats.C0939b;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

final class C0914s extends C0910r implements Callback {
    private final HashMap<C0911a, C0913b> f1774a = new HashMap();
    private final Context f1775b;
    private final Handler f1776c;
    private final C0939b f1777d;
    private final long f1778e;

    private static final class C0911a {
        private final String f1762a;
        private final String f1763b;
        private final ComponentName f1764c = null;

        public C0911a(String str, String str2) {
            this.f1762a = C0864b.m3456a(str);
            this.f1763b = C0864b.m3456a(str2);
        }

        public Intent m3624a() {
            return this.f1762a != null ? new Intent(this.f1762a).setPackage(this.f1763b) : new Intent().setComponent(this.f1764c);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof C0911a)) {
                return false;
            }
            C0911a c0911a = (C0911a) obj;
            return ab.m3453a(this.f1762a, c0911a.f1762a) && ab.m3453a(this.f1764c, c0911a.f1764c);
        }

        public int hashCode() {
            return ab.m3451a(this.f1762a, this.f1764c);
        }

        public String toString() {
            return this.f1762a == null ? this.f1764c.flattenToString() : this.f1762a;
        }
    }

    private final class C0913b {
        final /* synthetic */ C0914s f1766a;
        private final C0912a f1767b = new C0912a(this);
        private final Set<ServiceConnection> f1768c = new HashSet();
        private int f1769d = 2;
        private boolean f1770e;
        private IBinder f1771f;
        private final C0911a f1772g;
        private ComponentName f1773h;

        public class C0912a implements ServiceConnection {
            final /* synthetic */ C0913b f1765a;

            public C0912a(C0913b c0913b) {
                this.f1765a = c0913b;
            }

            public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
                synchronized (this.f1765a.f1766a.f1774a) {
                    this.f1765a.f1771f = iBinder;
                    this.f1765a.f1773h = componentName;
                    for (ServiceConnection onServiceConnected : this.f1765a.f1768c) {
                        onServiceConnected.onServiceConnected(componentName, iBinder);
                    }
                    this.f1765a.f1769d = 1;
                }
            }

            public void onServiceDisconnected(ComponentName componentName) {
                synchronized (this.f1765a.f1766a.f1774a) {
                    this.f1765a.f1771f = null;
                    this.f1765a.f1773h = componentName;
                    for (ServiceConnection onServiceDisconnected : this.f1765a.f1768c) {
                        onServiceDisconnected.onServiceDisconnected(componentName);
                    }
                    this.f1765a.f1769d = 2;
                }
            }
        }

        public C0913b(C0914s c0914s, C0911a c0911a) {
            this.f1766a = c0914s;
            this.f1772g = c0911a;
        }

        public void m3630a(ServiceConnection serviceConnection, String str) {
            this.f1766a.f1777d.m3839a(this.f1766a.f1775b, serviceConnection, str, this.f1772g.m3624a());
            this.f1768c.add(serviceConnection);
        }

        @TargetApi(14)
        public void m3631a(String str) {
            this.f1769d = 3;
            this.f1770e = this.f1766a.f1777d.m3841a(this.f1766a.f1775b, str, this.f1772g.m3624a(), this.f1767b, 129);
            if (!this.f1770e) {
                this.f1769d = 2;
                try {
                    this.f1766a.f1777d.m3838a(this.f1766a.f1775b, this.f1767b);
                } catch (IllegalArgumentException e) {
                }
            }
        }

        public boolean m3632a() {
            return this.f1770e;
        }

        public boolean m3633a(ServiceConnection serviceConnection) {
            return this.f1768c.contains(serviceConnection);
        }

        public int m3634b() {
            return this.f1769d;
        }

        public void m3635b(ServiceConnection serviceConnection, String str) {
            this.f1766a.f1777d.m3842b(this.f1766a.f1775b, serviceConnection);
            this.f1768c.remove(serviceConnection);
        }

        public void m3636b(String str) {
            this.f1766a.f1777d.m3838a(this.f1766a.f1775b, this.f1767b);
            this.f1770e = false;
            this.f1769d = 2;
        }

        public boolean m3637c() {
            return this.f1768c.isEmpty();
        }

        public IBinder m3638d() {
            return this.f1771f;
        }

        public ComponentName m3639e() {
            return this.f1773h;
        }
    }

    C0914s(Context context) {
        this.f1775b = context.getApplicationContext();
        this.f1776c = new Handler(context.getMainLooper(), this);
        this.f1777d = C0939b.m3827a();
        this.f1778e = 5000;
    }

    private boolean m3641a(C0911a c0911a, ServiceConnection serviceConnection, String str) {
        boolean a;
        C0864b.m3455a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f1774a) {
            C0913b c0913b = (C0913b) this.f1774a.get(c0911a);
            if (c0913b != null) {
                this.f1776c.removeMessages(0, c0913b);
                if (!c0913b.m3633a(serviceConnection)) {
                    c0913b.m3630a(serviceConnection, str);
                    switch (c0913b.m3634b()) {
                        case 1:
                            serviceConnection.onServiceConnected(c0913b.m3639e(), c0913b.m3638d());
                            break;
                        case 2:
                            c0913b.m3631a(str);
                            break;
                        default:
                            break;
                    }
                }
                String valueOf = String.valueOf(c0911a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 81).append("Trying to bind a GmsServiceConnection that was already connected before.  config=").append(valueOf).toString());
            }
            c0913b = new C0913b(this, c0911a);
            c0913b.m3630a(serviceConnection, str);
            c0913b.m3631a(str);
            this.f1774a.put(c0911a, c0913b);
            a = c0913b.m3632a();
        }
        return a;
    }

    private void m3643b(C0911a c0911a, ServiceConnection serviceConnection, String str) {
        C0864b.m3455a((Object) serviceConnection, (Object) "ServiceConnection must not be null");
        synchronized (this.f1774a) {
            C0913b c0913b = (C0913b) this.f1774a.get(c0911a);
            String valueOf;
            if (c0913b == null) {
                valueOf = String.valueOf(c0911a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 50).append("Nonexistent connection status for service config: ").append(valueOf).toString());
            } else if (c0913b.m3633a(serviceConnection)) {
                c0913b.m3635b(serviceConnection, str);
                if (c0913b.m3637c()) {
                    this.f1776c.sendMessageDelayed(this.f1776c.obtainMessage(0, c0913b), this.f1778e);
                }
            } else {
                valueOf = String.valueOf(c0911a);
                throw new IllegalStateException(new StringBuilder(String.valueOf(valueOf).length() + 76).append("Trying to unbind a GmsServiceConnection  that was not bound before.  config=").append(valueOf).toString());
            }
        }
    }

    public boolean mo929a(String str, String str2, ServiceConnection serviceConnection, String str3) {
        return m3641a(new C0911a(str, str2), serviceConnection, str3);
    }

    public void mo930b(String str, String str2, ServiceConnection serviceConnection, String str3) {
        m3643b(new C0911a(str, str2), serviceConnection, str3);
    }

    public boolean handleMessage(Message message) {
        switch (message.what) {
            case 0:
                C0913b c0913b = (C0913b) message.obj;
                synchronized (this.f1774a) {
                    if (c0913b.m3637c()) {
                        if (c0913b.m3632a()) {
                            c0913b.m3636b("GmsClientSupervisor");
                        }
                        this.f1774a.remove(c0913b.f1772g);
                    }
                }
                return true;
            default:
                return false;
        }
    }
}
