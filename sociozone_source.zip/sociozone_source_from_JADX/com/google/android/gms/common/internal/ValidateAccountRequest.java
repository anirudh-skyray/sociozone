package com.google.android.gms.common.internal;

import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

@Deprecated
public class ValidateAccountRequest extends AbstractSafeParcelable {
    public static final Creator<ValidateAccountRequest> CREATOR = new C0872g();
    final int f1647a;
    final IBinder f1648b;
    private final int f1649c;
    private final Scope[] f1650d;
    private final Bundle f1651e;
    private final String f1652f;

    ValidateAccountRequest(int i, int i2, IBinder iBinder, Scope[] scopeArr, Bundle bundle, String str) {
        this.f1647a = i;
        this.f1649c = i2;
        this.f1648b = iBinder;
        this.f1650d = scopeArr;
        this.f1651e = bundle;
        this.f1652f = str;
    }

    public int m3440a() {
        return this.f1649c;
    }

    public Scope[] m3441b() {
        return this.f1650d;
    }

    public String m3442c() {
        return this.f1652f;
    }

    public Bundle m3443d() {
        return this.f1651e;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0872g.m3527a(this, parcel, i);
    }
}
