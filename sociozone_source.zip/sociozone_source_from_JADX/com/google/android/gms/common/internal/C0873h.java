package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0873h implements Creator<AuthAccountRequest> {
    static void m3530a(AuthAccountRequest authAccountRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, authAccountRequest.f1624a);
        C0917b.m3676a(parcel, 2, authAccountRequest.f1625b, false);
        C0917b.m3684a(parcel, 3, authAccountRequest.f1626c, i, false);
        C0917b.m3678a(parcel, 4, authAccountRequest.f1627d, false);
        C0917b.m3678a(parcel, 5, authAccountRequest.f1628e, false);
        C0917b.m3670a(parcel, a);
    }

    public AuthAccountRequest m3531a(Parcel parcel) {
        Integer num = null;
        int b = C0916a.m3653b(parcel);
        int i = 0;
        Integer num2 = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    iBinder = C0916a.m3665k(parcel, a);
                    break;
                case 3:
                    scopeArr = (Scope[]) C0916a.m3655b(parcel, a, Scope.CREATOR);
                    break;
                case 4:
                    num2 = C0916a.m3660f(parcel, a);
                    break;
                case 5:
                    num = C0916a.m3660f(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new AuthAccountRequest(i, iBinder, scopeArr, num2, num);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public AuthAccountRequest[] m3532a(int i) {
        return new AuthAccountRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3531a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3532a(i);
    }
}
