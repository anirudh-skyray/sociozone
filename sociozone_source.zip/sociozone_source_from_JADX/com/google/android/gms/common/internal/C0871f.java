package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.res.Resources;
import com.google.android.gms.C0795a.C0791b;

public class C0871f {
    private final Resources f1688a;
    private final String f1689b = this.f1688a.getResourcePackageName(C0791b.common_google_play_services_unknown_issue);

    public C0871f(Context context) {
        C0864b.m3454a((Object) context);
        this.f1688a = context.getResources();
    }

    public String m3526a(String str) {
        int identifier = this.f1688a.getIdentifier(str, "string", this.f1689b);
        return identifier == 0 ? null : this.f1688a.getString(identifier);
    }
}
