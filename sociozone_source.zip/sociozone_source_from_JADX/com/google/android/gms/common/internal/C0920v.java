package com.google.android.gms.common.internal;

import android.os.IInterface;
import android.os.RemoteException;

public interface C0920v extends IInterface {
    void m3695a() throws RemoteException;
}
