package com.google.android.gms.common.internal;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.ag;
import android.util.Log;
import com.google.android.gms.p023d.ap;

public class aa {
    private static Object f1654a = new Object();
    private static boolean f1655b;
    private static String f1656c;
    private static int f1657d;

    public static int m3448a(Context context) {
        m3449b(context);
        return f1657d;
    }

    private static void m3449b(Context context) {
        synchronized (f1654a) {
            if (f1655b) {
                return;
            }
            f1655b = true;
            try {
                Bundle bundle = ap.m3917b(context).m3914a(context.getPackageName(), (int) ag.FLAG_HIGH_PRIORITY).metaData;
                if (bundle == null) {
                    return;
                }
                f1656c = bundle.getString("com.google.app.id");
                f1657d = bundle.getInt("com.google.android.gms.version");
            } catch (Throwable e) {
                Log.wtf("MetadataValueReader", "This should never happen.", e);
            }
        }
    }
}
