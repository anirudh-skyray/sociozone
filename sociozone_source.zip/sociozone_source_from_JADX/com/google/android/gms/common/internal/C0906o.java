package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C0906o implements Creator<GetServiceRequest> {
    static void m3607a(GetServiceRequest getServiceRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, getServiceRequest.f1629a);
        C0917b.m3673a(parcel, 2, getServiceRequest.f1630b);
        C0917b.m3673a(parcel, 3, getServiceRequest.f1631c);
        C0917b.m3679a(parcel, 4, getServiceRequest.f1632d, false);
        C0917b.m3676a(parcel, 5, getServiceRequest.f1633e, false);
        C0917b.m3684a(parcel, 6, getServiceRequest.f1634f, i, false);
        C0917b.m3675a(parcel, 7, getServiceRequest.f1635g, false);
        C0917b.m3677a(parcel, 8, getServiceRequest.f1636h, i, false);
        C0917b.m3674a(parcel, 9, getServiceRequest.f1637i);
        C0917b.m3670a(parcel, a);
    }

    public GetServiceRequest m3608a(Parcel parcel) {
        int i = 0;
        Account account = null;
        int b = C0916a.m3653b(parcel);
        long j = 0;
        Bundle bundle = null;
        Scope[] scopeArr = null;
        IBinder iBinder = null;
        String str = null;
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i3 = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 3:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 4:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 5:
                    iBinder = C0916a.m3665k(parcel, a);
                    break;
                case 6:
                    scopeArr = (Scope[]) C0916a.m3655b(parcel, a, Scope.CREATOR);
                    break;
                case 7:
                    bundle = C0916a.m3666l(parcel, a);
                    break;
                case 8:
                    account = (Account) C0916a.m3650a(parcel, a, Account.CREATOR);
                    break;
                case 9:
                    j = C0916a.m3661g(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GetServiceRequest(i3, i2, i, str, iBinder, scopeArr, bundle, account, j);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public GetServiceRequest[] m3609a(int i) {
        return new GetServiceRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3608a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3609a(i);
    }
}
