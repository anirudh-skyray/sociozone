package com.google.android.gms.common.internal;

import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountRequest extends AbstractSafeParcelable {
    public static final Creator<AuthAccountRequest> CREATOR = new C0873h();
    final int f1624a;
    final IBinder f1625b;
    final Scope[] f1626c;
    Integer f1627d;
    Integer f1628e;

    AuthAccountRequest(int i, IBinder iBinder, Scope[] scopeArr, Integer num, Integer num2) {
        this.f1624a = i;
        this.f1625b = iBinder;
        this.f1626c = scopeArr;
        this.f1627d = num;
        this.f1628e = num2;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0873h.m3530a(this, parcel, i);
    }
}
