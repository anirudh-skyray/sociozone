package com.google.android.gms.common.internal;

import android.content.Context;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.C0834a.C0831h;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;

public class C0870e<T extends IInterface> extends C0869p<T> {
    private final C0831h<T> f1687d;

    public C0870e(Context context, Looper looper, int i, C0817b c0817b, C0818c c0818c, C0900l c0900l, C0831h<T> c0831h) {
        super(context, looper, i, c0900l, c0817b, c0818c);
        this.f1687d = c0831h;
    }

    protected T mo910a(IBinder iBinder) {
        return this.f1687d.m3336a(iBinder);
    }

    protected void mo911a(int i, T t) {
        this.f1687d.m3338a(i, t);
    }

    protected String mo912i() {
        return this.f1687d.m3337a();
    }

    protected String mo913j() {
        return this.f1687d.m3339b();
    }

    public C0831h<T> mo914k() {
        return this.f1687d;
    }
}
