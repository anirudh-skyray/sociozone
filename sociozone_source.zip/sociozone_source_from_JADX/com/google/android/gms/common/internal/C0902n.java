package com.google.android.gms.common.internal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.google.android.gms.p023d.aa;

public abstract class C0902n implements OnClickListener {

    class C09031 extends C0902n {
        final /* synthetic */ Activity f1740a;
        final /* synthetic */ Intent f1741b;
        final /* synthetic */ int f1742c;

        C09031(Activity activity, Intent intent, int i) {
            this.f1740a = activity;
            this.f1741b = intent;
            this.f1742c = i;
        }

        public void mo925a() {
            this.f1740a.startActivityForResult(this.f1741b, this.f1742c);
        }
    }

    class C09042 extends C0902n {
        final /* synthetic */ Fragment f1743a;
        final /* synthetic */ Intent f1744b;
        final /* synthetic */ int f1745c;

        C09042(Fragment fragment, Intent intent, int i) {
            this.f1743a = fragment;
            this.f1744b = intent;
            this.f1745c = i;
        }

        public void mo925a() {
            this.f1743a.startActivityForResult(this.f1744b, this.f1745c);
        }
    }

    class C09053 extends C0902n {
        final /* synthetic */ aa f1746a;
        final /* synthetic */ Intent f1747b;
        final /* synthetic */ int f1748c;

        C09053(aa aaVar, Intent intent, int i) {
            this.f1746a = aaVar;
            this.f1747b = intent;
            this.f1748c = i;
        }

        @TargetApi(11)
        public void mo925a() {
            this.f1746a.startActivityForResult(this.f1747b, this.f1748c);
        }
    }

    public static C0902n m3600a(Activity activity, Intent intent, int i) {
        return new C09031(activity, intent, i);
    }

    public static C0902n m3601a(Fragment fragment, Intent intent, int i) {
        return new C09042(fragment, intent, i);
    }

    public static C0902n m3602a(aa aaVar, Intent intent, int i) {
        return new C09053(aaVar, intent, i);
    }

    public abstract void mo925a();

    public void onClick(DialogInterface dialogInterface, int i) {
        try {
            mo925a();
            dialogInterface.dismiss();
        } catch (ActivityNotFoundException e) {
            Log.e("DialogRedirect", "Can't redirect to app settings for Google Play services");
        }
    }
}
