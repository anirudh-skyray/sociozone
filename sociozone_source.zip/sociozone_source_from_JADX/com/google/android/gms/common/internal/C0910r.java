package com.google.android.gms.common.internal;

import android.content.Context;
import android.content.ServiceConnection;

public abstract class C0910r {
    private static final Object f1760a = new Object();
    private static C0910r f1761b;

    public static C0910r m3621a(Context context) {
        synchronized (f1760a) {
            if (f1761b == null) {
                f1761b = new C0914s(context.getApplicationContext());
            }
        }
        return f1761b;
    }

    public abstract boolean mo929a(String str, String str2, ServiceConnection serviceConnection, String str3);

    public abstract void mo930b(String str, String str2, ServiceConnection serviceConnection, String str3);
}
