package com.google.android.gms.common.internal;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public final class ab {

    public static final class C0863a {
        private final List<String> f1658a;
        private final Object f1659b;

        private C0863a(Object obj) {
            this.f1659b = C0864b.m3454a(obj);
            this.f1658a = new ArrayList();
        }

        public C0863a m3450a(String str, Object obj) {
            List list = this.f1658a;
            String str2 = (String) C0864b.m3454a((Object) str);
            String valueOf = String.valueOf(String.valueOf(obj));
            list.add(new StringBuilder((String.valueOf(str2).length() + 1) + String.valueOf(valueOf).length()).append(str2).append("=").append(valueOf).toString());
            return this;
        }

        public String toString() {
            StringBuilder append = new StringBuilder(100).append(this.f1659b.getClass().getSimpleName()).append('{');
            int size = this.f1658a.size();
            for (int i = 0; i < size; i++) {
                append.append((String) this.f1658a.get(i));
                if (i < size - 1) {
                    append.append(", ");
                }
            }
            return append.append('}').toString();
        }
    }

    public static int m3451a(Object... objArr) {
        return Arrays.hashCode(objArr);
    }

    public static C0863a m3452a(Object obj) {
        return new C0863a(obj);
    }

    public static boolean m3453a(Object obj, Object obj2) {
        return obj == obj2 || (obj != null && obj.equals(obj2));
    }
}
