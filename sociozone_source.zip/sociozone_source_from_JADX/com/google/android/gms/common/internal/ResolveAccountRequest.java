package com.google.android.gms.common.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ResolveAccountRequest extends AbstractSafeParcelable {
    public static final Creator<ResolveAccountRequest> CREATOR = new C0865c();
    final int f1638a;
    private final Account f1639b;
    private final int f1640c;
    private final GoogleSignInAccount f1641d;

    ResolveAccountRequest(int i, Account account, int i2, GoogleSignInAccount googleSignInAccount) {
        this.f1638a = i;
        this.f1639b = account;
        this.f1640c = i2;
        this.f1641d = googleSignInAccount;
    }

    public ResolveAccountRequest(Account account, int i, GoogleSignInAccount googleSignInAccount) {
        this(2, account, i, googleSignInAccount);
    }

    public Account m3433a() {
        return this.f1639b;
    }

    public int m3434b() {
        return this.f1640c;
    }

    public GoogleSignInAccount m3435c() {
        return this.f1641d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0865c.m3464a(this, parcel, i);
    }
}
