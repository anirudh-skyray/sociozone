package com.google.android.gms.common;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.text.TextUtils;
import com.google.android.gms.common.internal.C0918t;
import com.google.android.gms.common.p022a.C0808e;

public class C0849j {
    private static final C0849j f1605a = new C0849j();
    public static final int f1606b = C0854l.f1611b;

    C0849j() {
    }

    public static C0849j m3371b() {
        return f1605a;
    }

    private String m3372b(Context context, String str) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("gcore_");
        stringBuilder.append(f1606b);
        stringBuilder.append("-");
        if (!TextUtils.isEmpty(str)) {
            stringBuilder.append(str);
        }
        stringBuilder.append("-");
        if (context != null) {
            stringBuilder.append(context.getPackageName());
        }
        stringBuilder.append("-");
        if (context != null) {
            try {
                stringBuilder.append(context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode);
            } catch (NameNotFoundException e) {
            }
        }
        return stringBuilder.toString();
    }

    public int mo898a(Context context) {
        int b = C0854l.m3401b(context);
        return C0854l.m3406c(context, b) ? 18 : b;
    }

    public PendingIntent mo899a(Context context, int i, int i2) {
        return mo900a(context, i, i2, null);
    }

    public PendingIntent mo900a(Context context, int i, int i2, String str) {
        if (C0808e.m3262a(context) && i == 2) {
            i = 42;
        }
        Intent a = mo901a(context, i, str);
        return a == null ? null : PendingIntent.getActivity(context, i2, a, 268435456);
    }

    public Intent mo901a(Context context, int i, String str) {
        switch (i) {
            case 1:
            case 2:
                return C0918t.m3692a("com.google.android.gms", m3372b(context, str));
            case 3:
                return C0918t.m3691a("com.google.android.gms");
            case 42:
                return C0918t.m3690a();
            default:
                return null;
        }
    }

    public boolean mo902a(int i) {
        return C0854l.m3403b(i);
    }

    public boolean mo903a(Context context, int i) {
        return C0854l.m3406c(context, i);
    }

    public boolean m3379a(Context context, String str) {
        return C0854l.m3399a(context, str);
    }

    @Deprecated
    public Intent mo904b(int i) {
        return mo901a(null, i, null);
    }

    public void m3381b(Context context) {
        C0854l.m3408e(context);
    }
}
