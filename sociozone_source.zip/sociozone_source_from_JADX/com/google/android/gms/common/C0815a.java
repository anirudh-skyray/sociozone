package com.google.android.gms.common;

import android.annotation.TargetApi;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.FragmentManager;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import com.google.android.gms.common.internal.C0864b;

@TargetApi(11)
public class C0815a extends DialogFragment {
    private Dialog f1552a = null;
    private OnCancelListener f1553b = null;

    public static C0815a m3282a(Dialog dialog, OnCancelListener onCancelListener) {
        C0815a c0815a = new C0815a();
        Dialog dialog2 = (Dialog) C0864b.m3455a((Object) dialog, (Object) "Cannot display null dialog");
        dialog2.setOnCancelListener(null);
        dialog2.setOnDismissListener(null);
        c0815a.f1552a = dialog2;
        if (onCancelListener != null) {
            c0815a.f1553b = onCancelListener;
        }
        return c0815a;
    }

    public void onCancel(DialogInterface dialogInterface) {
        if (this.f1553b != null) {
            this.f1553b.onCancel(dialogInterface);
        }
    }

    public Dialog onCreateDialog(Bundle bundle) {
        if (this.f1552a == null) {
            setShowsDialog(false);
        }
        return this.f1552a;
    }

    public void show(FragmentManager fragmentManager, String str) {
        super.show(fragmentManager, str);
    }
}
