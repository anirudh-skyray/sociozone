package com.google.android.gms.p017a.p018a;

import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager.NameNotFoundException;
import android.util.Log;
import com.google.android.gms.common.C0849j;
import com.google.android.gms.common.C0851c;
import com.google.android.gms.common.C0853d;
import com.google.android.gms.common.C0857h;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.stats.C0939b;
import com.google.android.gms.p023d.C0962c;
import com.google.android.gms.p023d.C0962c.C0964a;
import java.io.IOException;
import java.lang.ref.WeakReference;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class C0794a {
    C0857h f1502a;
    C0962c f1503b;
    boolean f1504c;
    Object f1505d = new Object();
    C0793b f1506e;
    final long f1507f;
    private final Context f1508g;

    public static final class C0792a {
        private final String f1496a;
        private final boolean f1497b;

        public C0792a(String str, boolean z) {
            this.f1496a = str;
            this.f1497b = z;
        }

        public String m3199a() {
            return this.f1496a;
        }

        public boolean m3200b() {
            return this.f1497b;
        }

        public String toString() {
            String str = this.f1496a;
            return new StringBuilder(String.valueOf(str).length() + 7).append("{").append(str).append("}").append(this.f1497b).toString();
        }
    }

    static class C0793b extends Thread {
        CountDownLatch f1498a = new CountDownLatch(1);
        boolean f1499b = false;
        private WeakReference<C0794a> f1500c;
        private long f1501d;

        public C0793b(C0794a c0794a, long j) {
            this.f1500c = new WeakReference(c0794a);
            this.f1501d = j;
            start();
        }

        private void m3201c() {
            C0794a c0794a = (C0794a) this.f1500c.get();
            if (c0794a != null) {
                c0794a.m3210b();
                this.f1499b = true;
            }
        }

        public void m3202a() {
            this.f1498a.countDown();
        }

        public boolean m3203b() {
            return this.f1499b;
        }

        public void run() {
            try {
                if (!this.f1498a.await(this.f1501d, TimeUnit.MILLISECONDS)) {
                    m3201c();
                }
            } catch (InterruptedException e) {
                m3201c();
            }
        }
    }

    public C0794a(Context context, long j) {
        C0864b.m3454a((Object) context);
        this.f1508g = context;
        this.f1504c = false;
        this.f1507f = j;
    }

    static C0857h m3204a(Context context) throws IOException, C0851c, C0853d {
        try {
            context.getPackageManager().getPackageInfo("com.android.vending", 0);
            switch (C0849j.m3371b().mo898a(context)) {
                case 0:
                case 2:
                    ServiceConnection c0857h = new C0857h();
                    Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
                    intent.setPackage("com.google.android.gms");
                    try {
                        if (C0939b.m3827a().m3840a(context, intent, c0857h, 1)) {
                            return c0857h;
                        }
                        throw new IOException("Connection failure");
                    } catch (Throwable th) {
                        IOException iOException = new IOException(th);
                    }
                default:
                    throw new IOException("Google Play services not available");
            }
        } catch (NameNotFoundException e) {
            throw new C0851c(9);
        }
    }

    static C0962c m3205a(Context context, C0857h c0857h) throws IOException {
        try {
            return C0964a.m3945a(c0857h.m3423a(10000, TimeUnit.MILLISECONDS));
        } catch (InterruptedException e) {
            throw new IOException("Interrupted exception");
        } catch (Throwable th) {
            IOException iOException = new IOException(th);
        }
    }

    public static C0792a m3206b(Context context) throws IOException, IllegalStateException, C0851c, C0853d {
        C0794a c0794a = new C0794a(context, -1);
        try {
            c0794a.m3209a(false);
            C0792a a = c0794a.m3208a();
            return a;
        } finally {
            c0794a.m3210b();
        }
    }

    private void m3207c() {
        synchronized (this.f1505d) {
            if (this.f1506e != null) {
                this.f1506e.m3202a();
                try {
                    this.f1506e.join();
                } catch (InterruptedException e) {
                }
            }
            if (this.f1507f > 0) {
                this.f1506e = new C0793b(this, this.f1507f);
            }
        }
    }

    public C0792a m3208a() throws IOException {
        C0792a c0792a;
        C0864b.m3461b("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (!this.f1504c) {
                synchronized (this.f1505d) {
                    if (this.f1506e == null || !this.f1506e.m3203b()) {
                        throw new IOException("AdvertisingIdClient is not connected.");
                    }
                }
                try {
                    m3209a(false);
                    if (!this.f1504c) {
                        throw new IOException("AdvertisingIdClient cannot reconnect.");
                    }
                } catch (Throwable e) {
                    Log.i("AdvertisingIdClient", "GMS remote exception ", e);
                    throw new IOException("Remote exception");
                } catch (Throwable e2) {
                    throw new IOException("AdvertisingIdClient cannot reconnect.", e2);
                }
            }
            C0864b.m3454a(this.f1502a);
            C0864b.m3454a(this.f1503b);
            c0792a = new C0792a(this.f1503b.mo995a(), this.f1503b.mo998a(true));
        }
        m3207c();
        return c0792a;
    }

    protected void m3209a(boolean z) throws IOException, IllegalStateException, C0851c, C0853d {
        C0864b.m3461b("Calling this from your main thread can lead to deadlock");
        synchronized (this) {
            if (this.f1504c) {
                m3210b();
            }
            this.f1502a = C0794a.m3204a(this.f1508g);
            this.f1503b = C0794a.m3205a(this.f1508g, this.f1502a);
            this.f1504c = true;
            if (z) {
                m3207c();
            }
        }
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m3210b() {
        /*
        r3 = this;
        r0 = "Calling this from your main thread can lead to deadlock";
        com.google.android.gms.common.internal.C0864b.m3461b(r0);
        monitor-enter(r3);
        r0 = r3.f1508g;	 Catch:{ all -> 0x002a }
        if (r0 == 0) goto L_0x000e;
    L_0x000a:
        r0 = r3.f1502a;	 Catch:{ all -> 0x002a }
        if (r0 != 0) goto L_0x0010;
    L_0x000e:
        monitor-exit(r3);	 Catch:{ all -> 0x002a }
    L_0x000f:
        return;
    L_0x0010:
        r0 = r3.f1504c;	 Catch:{ IllegalArgumentException -> 0x002d }
        if (r0 == 0) goto L_0x001f;
    L_0x0014:
        r0 = com.google.android.gms.common.stats.C0939b.m3827a();	 Catch:{ IllegalArgumentException -> 0x002d }
        r1 = r3.f1508g;	 Catch:{ IllegalArgumentException -> 0x002d }
        r2 = r3.f1502a;	 Catch:{ IllegalArgumentException -> 0x002d }
        r0.m3838a(r1, r2);	 Catch:{ IllegalArgumentException -> 0x002d }
    L_0x001f:
        r0 = 0;
        r3.f1504c = r0;	 Catch:{ all -> 0x002a }
        r0 = 0;
        r3.f1503b = r0;	 Catch:{ all -> 0x002a }
        r0 = 0;
        r3.f1502a = r0;	 Catch:{ all -> 0x002a }
        monitor-exit(r3);	 Catch:{ all -> 0x002a }
        goto L_0x000f;
    L_0x002a:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x002a }
        throw r0;
    L_0x002d:
        r0 = move-exception;
        r1 = "AdvertisingIdClient";
        r2 = "AdvertisingIdClient unbindService failed.";
        android.util.Log.i(r1, r2, r0);	 Catch:{ all -> 0x002a }
        goto L_0x001f;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.a.a.a.b():void");
    }

    protected void finalize() throws Throwable {
        m3210b();
        super.finalize();
    }
}
