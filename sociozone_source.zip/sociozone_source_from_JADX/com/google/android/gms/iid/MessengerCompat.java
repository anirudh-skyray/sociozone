package com.google.android.gms.iid;

import android.os.Build.VERSION;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.os.RemoteException;
import com.google.android.gms.iid.C1033d.C1035a;

public class MessengerCompat implements Parcelable {
    public static final Creator<MessengerCompat> CREATOR = new C10291();
    Messenger f2096a;
    C1033d f2097b;

    class C10291 implements Creator<MessengerCompat> {
        C10291() {
        }

        public MessengerCompat m4279a(Parcel parcel) {
            IBinder readStrongBinder = parcel.readStrongBinder();
            return readStrongBinder != null ? new MessengerCompat(readStrongBinder) : null;
        }

        public MessengerCompat[] m4280a(int i) {
            return new MessengerCompat[i];
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m4279a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m4280a(i);
        }
    }

    public MessengerCompat(IBinder iBinder) {
        if (VERSION.SDK_INT >= 21) {
            this.f2096a = new Messenger(iBinder);
        } else {
            this.f2097b = C1035a.m4306a(iBinder);
        }
    }

    public IBinder m4281a() {
        return this.f2096a != null ? this.f2096a.getBinder() : this.f2097b.asBinder();
    }

    public void m4282a(Message message) throws RemoteException {
        if (this.f2096a != null) {
            this.f2096a.send(message);
        } else {
            this.f2097b.mo1058a(message);
        }
    }

    public int describeContents() {
        return 0;
    }

    public boolean equals(Object obj) {
        boolean z = false;
        if (obj != null) {
            try {
                z = m4281a().equals(((MessengerCompat) obj).m4281a());
            } catch (ClassCastException e) {
            }
        }
        return z;
    }

    public int hashCode() {
        return m4281a().hashCode();
    }

    public void writeToParcel(Parcel parcel, int i) {
        if (this.f2096a != null) {
            parcel.writeStrongBinder(this.f2096a.getBinder());
        } else {
            parcel.writeStrongBinder(this.f2097b.asBinder());
        }
    }
}
