package com.google.android.gms.iid;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.util.Base64;
import android.util.Log;
import com.google.android.gms.common.p022a.C0813j;
import java.io.File;
import java.io.IOException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

public class C1038f {
    SharedPreferences f2131a;
    Context f2132b;

    public C1038f(Context context) {
        this(context, "com.google.android.gms.appid");
    }

    public C1038f(Context context, String str) {
        this.f2132b = context;
        this.f2131a = context.getSharedPreferences(str, 4);
        String valueOf = String.valueOf(str);
        String valueOf2 = String.valueOf("-no-backup");
        m4326g(valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf));
    }

    private String m4325b(String str, String str2, String str3) {
        String valueOf = String.valueOf("|T|");
        return new StringBuilder((((String.valueOf(str).length() + 1) + String.valueOf(valueOf).length()) + String.valueOf(str2).length()) + String.valueOf(str3).length()).append(str).append(valueOf).append(str2).append("|").append(str3).toString();
    }

    private void m4326g(String str) {
        File file = new File(C0813j.m3278a(this.f2132b), str);
        if (!file.exists()) {
            try {
                if (file.createNewFile() && !m4333a()) {
                    Log.i("InstanceID/Store", "App restored, clearing state");
                    C1031b.m4297a(this.f2132b, this);
                }
            } catch (IOException e) {
                if (Log.isLoggable("InstanceID/Store", 3)) {
                    String str2 = "InstanceID/Store";
                    String str3 = "Error creating file in no backup dir: ";
                    String valueOf = String.valueOf(e.getMessage());
                    Log.d(str2, valueOf.length() != 0 ? str3.concat(valueOf) : new String(str3));
                }
            }
        }
    }

    synchronized String m4327a(String str) {
        return this.f2131a.getString(str, null);
    }

    synchronized String m4328a(String str, String str2) {
        SharedPreferences sharedPreferences;
        String valueOf;
        sharedPreferences = this.f2131a;
        valueOf = String.valueOf("|S|");
        return sharedPreferences.getString(new StringBuilder(((String.valueOf(str).length() + 0) + String.valueOf(valueOf).length()) + String.valueOf(str2).length()).append(str).append(valueOf).append(str2).toString(), null);
    }

    public synchronized String m4329a(String str, String str2, String str3) {
        return this.f2131a.getString(m4325b(str, str2, str3), null);
    }

    synchronized KeyPair m4330a(String str, long j) {
        KeyPair a;
        a = C1032c.m4303a();
        Editor edit = this.f2131a.edit();
        m4331a(edit, str, "|P|", C1030a.m4286a(a.getPublic().getEncoded()));
        m4331a(edit, str, "|K|", C1030a.m4286a(a.getPrivate().getEncoded()));
        m4331a(edit, str, "cre", Long.toString(j));
        edit.commit();
        return a;
    }

    synchronized void m4331a(Editor editor, String str, String str2, String str3) {
        String valueOf = String.valueOf("|S|");
        editor.putString(new StringBuilder(((String.valueOf(str).length() + 0) + String.valueOf(valueOf).length()) + String.valueOf(str2).length()).append(str).append(valueOf).append(str2).toString(), str3);
    }

    public synchronized void m4332a(String str, String str2, String str3, String str4, String str5) {
        String b = m4325b(str, str2, str3);
        Editor edit = this.f2131a.edit();
        edit.putString(b, str4);
        edit.putString("appVersion", str5);
        edit.putString("lastToken", Long.toString(System.currentTimeMillis() / 1000));
        edit.commit();
    }

    public boolean m4333a() {
        return this.f2131a.getAll().isEmpty();
    }

    public synchronized void m4334b() {
        this.f2131a.edit().clear().commit();
    }

    public synchronized void m4335b(String str) {
        Editor edit = this.f2131a.edit();
        for (String str2 : this.f2131a.getAll().keySet()) {
            if (str2.startsWith(str)) {
                edit.remove(str2);
            }
        }
        edit.commit();
    }

    public KeyPair m4336c(String str) {
        return m4339f(str);
    }

    void m4337d(String str) {
        m4335b(String.valueOf(str).concat("|"));
    }

    public void m4338e(String str) {
        m4335b(String.valueOf(str).concat("|T|"));
    }

    KeyPair m4339f(String str) {
        Object e;
        String a = m4328a(str, "|P|");
        String a2 = m4328a(str, "|K|");
        if (a2 == null) {
            return null;
        }
        try {
            byte[] decode = Base64.decode(a, 8);
            byte[] decode2 = Base64.decode(a2, 8);
            KeyFactory instance = KeyFactory.getInstance("RSA");
            return new KeyPair(instance.generatePublic(new X509EncodedKeySpec(decode)), instance.generatePrivate(new PKCS8EncodedKeySpec(decode2)));
        } catch (InvalidKeySpecException e2) {
            e = e2;
            a = String.valueOf(e);
            Log.w("InstanceID/Store", new StringBuilder(String.valueOf(a).length() + 19).append("Invalid key stored ").append(a).toString());
            C1031b.m4297a(this.f2132b, this);
            return null;
        } catch (NoSuchAlgorithmException e3) {
            e = e3;
            a = String.valueOf(e);
            Log.w("InstanceID/Store", new StringBuilder(String.valueOf(a).length() + 19).append("Invalid key stored ").append(a).toString());
            C1031b.m4297a(this.f2132b, this);
            return null;
        }
    }
}
