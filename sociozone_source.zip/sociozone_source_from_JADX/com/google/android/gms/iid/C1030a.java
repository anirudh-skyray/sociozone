package com.google.android.gms.iid;

import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Looper;
import android.util.Base64;
import android.util.Log;
import java.io.IOException;
import java.security.KeyPair;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;

public class C1030a {
    static Map<String, C1030a> f2098a = new HashMap();
    static String f2099f;
    private static C1038f f2100g;
    private static C1037e f2101h;
    Context f2102b;
    KeyPair f2103c;
    String f2104d = "";
    long f2105e;

    protected C1030a(Context context, String str, Bundle bundle) {
        this.f2102b = context.getApplicationContext();
        this.f2104d = str;
    }

    static int m4283a(Context context) {
        int i = 0;
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionCode;
        } catch (NameNotFoundException e) {
            String valueOf = String.valueOf(e);
            Log.w("InstanceID", new StringBuilder(String.valueOf(valueOf).length() + 38).append("Never happens: can't find own package ").append(valueOf).toString());
            return i;
        }
    }

    public static synchronized C1030a m4284a(Context context, Bundle bundle) {
        C1030a c1030a;
        synchronized (C1030a.class) {
            String string = bundle == null ? "" : bundle.getString("subtype");
            String str = string == null ? "" : string;
            Context applicationContext = context.getApplicationContext();
            if (f2100g == null) {
                f2100g = new C1038f(applicationContext);
                f2101h = new C1037e(applicationContext);
            }
            f2099f = Integer.toString(C1030a.m4283a(applicationContext));
            c1030a = (C1030a) f2098a.get(str);
            if (c1030a == null) {
                c1030a = new C1030a(applicationContext, str, bundle);
                f2098a.put(str, c1030a);
            }
        }
        return c1030a;
    }

    static String m4285a(KeyPair keyPair) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA1").digest(keyPair.getPublic().getEncoded());
            digest[0] = (byte) (((digest[0] & 15) + 112) & 255);
            return Base64.encodeToString(digest, 0, 8, 11);
        } catch (NoSuchAlgorithmException e) {
            Log.w("InstanceID", "Unexpected error, device missing required alghorithms");
            return null;
        }
    }

    static String m4286a(byte[] bArr) {
        return Base64.encodeToString(bArr, 11);
    }

    static String m4287b(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
        } catch (NameNotFoundException e) {
            String valueOf = String.valueOf(e);
            Log.w("InstanceID", new StringBuilder(String.valueOf(valueOf).length() + 38).append("Never happens: can't find own package ").append(valueOf).toString());
            return null;
        }
    }

    public static C1030a m4288c(Context context) {
        return C1030a.m4284a(context, null);
    }

    public String m4289a(String str, String str2, Bundle bundle) throws IOException {
        Object obj = null;
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        }
        Object obj2 = 1;
        String a = m4295e() ? null : f2100g.m4329a(this.f2104d, str, str2);
        if (a == null) {
            if (bundle == null) {
                bundle = new Bundle();
            }
            if (bundle.getString("ttl") != null) {
                obj2 = null;
            }
            if (!"jwt".equals(bundle.getString("type"))) {
                obj = obj2;
            }
            a = m4291b(str, str2, bundle);
            if (!(a == null || r1 == null)) {
                f2100g.m4332a(this.f2104d, str, str2, a, f2099f);
            }
        }
        return a;
    }

    KeyPair m4290a() {
        if (this.f2103c == null) {
            this.f2103c = f2100g.m4336c(this.f2104d);
        }
        if (this.f2103c == null) {
            this.f2105e = System.currentTimeMillis();
            this.f2103c = f2100g.m4330a(this.f2104d, this.f2105e);
        }
        return this.f2103c;
    }

    public String m4291b(String str, String str2, Bundle bundle) throws IOException {
        if (str2 != null) {
            bundle.putString("scope", str2);
        }
        bundle.putString("sender", str);
        String str3 = "".equals(this.f2104d) ? str : this.f2104d;
        if (!bundle.containsKey("legacy.register")) {
            bundle.putString("subscription", str);
            bundle.putString("subtype", str3);
            bundle.putString("X-subscription", str);
            bundle.putString("X-subtype", str3);
        }
        return f2101h.m4322b(f2101h.m4316a(bundle, m4290a()));
    }

    public void m4292b() {
        this.f2105e = 0;
        f2100g.m4337d(this.f2104d);
        this.f2103c = null;
    }

    public C1038f m4293c() {
        return f2100g;
    }

    public C1037e m4294d() {
        return f2101h;
    }

    boolean m4295e() {
        String a = f2100g.m4327a("appVersion");
        if (a == null || !a.equals(f2099f)) {
            return true;
        }
        a = f2100g.m4327a("lastToken");
        if (a == null) {
            return true;
        }
        return (System.currentTimeMillis() / 1000) - Long.valueOf(Long.parseLong(a)).longValue() > 604800;
    }
}
