package com.google.android.gms.iid;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.ConditionVariable;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcelable;
import android.os.Process;
import android.os.RemoteException;
import android.os.SystemClock;
import android.text.TextUtils;
import android.util.Log;
import java.io.IOException;
import java.security.KeyPair;
import java.security.PrivateKey;
import java.security.Signature;
import java.security.interfaces.RSAPrivateKey;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class C1037e {
    static String f2116a = null;
    static int f2117b = 0;
    static int f2118c = 0;
    static int f2119d = 0;
    Context f2120e;
    Map<String, Object> f2121f = new HashMap();
    Messenger f2122g;
    Messenger f2123h;
    MessengerCompat f2124i;
    PendingIntent f2125j;
    long f2126k;
    long f2127l;
    int f2128m;
    int f2129n;
    long f2130o;

    public C1037e(Context context) {
        this.f2120e = context;
    }

    public static String m4307a(Context context) {
        ApplicationInfo applicationInfo;
        if (f2116a != null) {
            return f2116a;
        }
        f2117b = Process.myUid();
        PackageManager packageManager = context.getPackageManager();
        for (ResolveInfo resolveInfo : packageManager.queryIntentServices(new Intent("com.google.android.c2dm.intent.REGISTER"), 0)) {
            if (packageManager.checkPermission("com.google.android.c2dm.permission.RECEIVE", resolveInfo.serviceInfo.packageName) == 0) {
                try {
                    ApplicationInfo applicationInfo2 = packageManager.getApplicationInfo(resolveInfo.serviceInfo.packageName, 0);
                    Log.w("InstanceID/Rpc", "Found " + applicationInfo2.uid);
                    f2118c = applicationInfo2.uid;
                    f2116a = resolveInfo.serviceInfo.packageName;
                    return f2116a;
                } catch (NameNotFoundException e) {
                }
            } else {
                String valueOf = String.valueOf(resolveInfo.serviceInfo.packageName);
                String valueOf2 = String.valueOf("com.google.android.c2dm.intent.REGISTER");
                Log.w("InstanceID/Rpc", new StringBuilder((String.valueOf(valueOf).length() + 56) + String.valueOf(valueOf2).length()).append("Possible malicious package ").append(valueOf).append(" declares ").append(valueOf2).append(" without permission").toString());
            }
        }
        Log.w("InstanceID/Rpc", "Failed to resolve REGISTER intent, falling back");
        try {
            applicationInfo = packageManager.getApplicationInfo("com.google.android.gms", 0);
            f2116a = applicationInfo.packageName;
            f2118c = applicationInfo.uid;
            return f2116a;
        } catch (NameNotFoundException e2) {
            try {
                applicationInfo = packageManager.getApplicationInfo("com.google.android.gsf", 0);
                f2116a = applicationInfo.packageName;
                f2118c = applicationInfo.uid;
                return f2116a;
            } catch (NameNotFoundException e3) {
                Log.w("InstanceID/Rpc", "Both Google Play Services and legacy GSF package are missing");
                return null;
            }
        }
    }

    static String m4308a(KeyPair keyPair, String... strArr) {
        String str = null;
        try {
            byte[] bytes = TextUtils.join("\n", strArr).getBytes("UTF-8");
            try {
                PrivateKey privateKey = keyPair.getPrivate();
                Signature instance = Signature.getInstance(privateKey instanceof RSAPrivateKey ? "SHA256withRSA" : "SHA256withECDSA");
                instance.initSign(privateKey);
                instance.update(bytes);
                str = C1030a.m4286a(instance.sign());
            } catch (Throwable e) {
                Log.e("InstanceID/Rpc", "Unable to sign registration request", e);
            }
        } catch (Throwable e2) {
            Log.e("InstanceID/Rpc", "Unable to encode string", e2);
        }
        return str;
    }

    private void m4309a(Object obj) {
        synchronized (getClass()) {
            for (String str : this.f2121f.keySet()) {
                Object obj2 = this.f2121f.get(str);
                this.f2121f.put(str, obj);
                m4310a(obj2, obj);
            }
        }
    }

    private void m4310a(Object obj, Object obj2) {
        if (obj instanceof ConditionVariable) {
            ((ConditionVariable) obj).open();
        }
        if (obj instanceof Messenger) {
            Messenger messenger = (Messenger) obj;
            Message obtain = Message.obtain();
            obtain.obj = obj2;
            try {
                messenger.send(obtain);
            } catch (RemoteException e) {
                String valueOf = String.valueOf(e);
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 24).append("Failed to send response ").append(valueOf).toString());
            }
        }
    }

    private void m4311a(String str) {
        if ("com.google.android.gsf".equals(f2116a)) {
            this.f2128m++;
            if (this.f2128m >= 3) {
                if (this.f2128m == 3) {
                    this.f2129n = new Random().nextInt(1000) + 1000;
                }
                this.f2129n *= 2;
                this.f2130o = SystemClock.elapsedRealtime() + ((long) this.f2129n);
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(str).length() + 31).append("Backoff due to ").append(str).append(" for ").append(this.f2129n).toString());
            }
        }
    }

    private void m4312a(String str, Object obj) {
        synchronized (getClass()) {
            Object obj2 = this.f2121f.get(str);
            this.f2121f.put(str, obj);
            m4310a(obj2, obj);
        }
    }

    private static int m4313b(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(C1037e.m4307a(context), 0).versionCode;
        } catch (NameNotFoundException e) {
            return -1;
        }
    }

    private Intent m4314b(Bundle bundle, KeyPair keyPair) throws IOException {
        Intent intent;
        ConditionVariable conditionVariable = new ConditionVariable();
        String b = C1037e.m4315b();
        synchronized (getClass()) {
            this.f2121f.put(b, conditionVariable);
        }
        m4320a(bundle, keyPair, b);
        conditionVariable.block(30000);
        synchronized (getClass()) {
            Object remove = this.f2121f.remove(b);
            if (remove instanceof Intent) {
                intent = (Intent) remove;
            } else if (remove instanceof String) {
                throw new IOException((String) remove);
            } else {
                String valueOf = String.valueOf(remove);
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 12).append("No response ").append(valueOf).toString());
                throw new IOException("TIMEOUT");
            }
        }
        return intent;
    }

    public static synchronized String m4315b() {
        String num;
        synchronized (C1037e.class) {
            int i = f2119d;
            f2119d = i + 1;
            num = Integer.toString(i);
        }
        return num;
    }

    Intent m4316a(Bundle bundle, KeyPair keyPair) throws IOException {
        Intent b = m4314b(bundle, keyPair);
        return (b == null || !b.hasExtra("google.messenger")) ? b : m4314b(bundle, keyPair);
    }

    void m4317a() {
        if (this.f2122g == null) {
            C1037e.m4307a(this.f2120e);
            this.f2122g = new Messenger(new Handler(this, Looper.getMainLooper()) {
                final /* synthetic */ C1037e f2115a;

                public void handleMessage(Message message) {
                    this.f2115a.m4321a(message);
                }
            });
        }
    }

    synchronized void m4318a(Intent intent) {
        if (this.f2125j == null) {
            Intent intent2 = new Intent();
            intent2.setPackage("com.google.example.invalidpackage");
            this.f2125j = PendingIntent.getBroadcast(this.f2120e, 0, intent2, 0);
        }
        intent.putExtra("app", this.f2125j);
    }

    protected void m4319a(Intent intent, String str) {
        this.f2126k = SystemClock.elapsedRealtime();
        intent.putExtra("kid", new StringBuilder(String.valueOf(str).length() + 5).append("|ID|").append(str).append("|").toString());
        intent.putExtra("X-kid", new StringBuilder(String.valueOf(str).length() + 5).append("|ID|").append(str).append("|").toString());
        boolean equals = "com.google.android.gsf".equals(f2116a);
        String stringExtra = intent.getStringExtra("useGsf");
        if (stringExtra != null) {
            equals = "1".equals(stringExtra);
        }
        if (Log.isLoggable("InstanceID/Rpc", 3)) {
            String valueOf = String.valueOf(intent.getExtras());
            Log.d("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 8).append("Sending ").append(valueOf).toString());
        }
        if (this.f2123h != null) {
            intent.putExtra("google.messenger", this.f2122g);
            Message obtain = Message.obtain();
            obtain.obj = intent;
            try {
                this.f2123h.send(obtain);
                return;
            } catch (RemoteException e) {
                if (Log.isLoggable("InstanceID/Rpc", 3)) {
                    Log.d("InstanceID/Rpc", "Messenger failed, fallback to startService");
                }
            }
        }
        if (equals) {
            Intent intent2 = new Intent("com.google.android.gms.iid.InstanceID");
            intent2.setPackage(this.f2120e.getPackageName());
            intent2.putExtra("GSF", intent);
            this.f2120e.startService(intent2);
            return;
        }
        intent.putExtra("google.messenger", this.f2122g);
        intent.putExtra("messenger2", "1");
        if (this.f2124i != null) {
            Message obtain2 = Message.obtain();
            obtain2.obj = intent;
            try {
                this.f2124i.m4282a(obtain2);
                return;
            } catch (RemoteException e2) {
                if (Log.isLoggable("InstanceID/Rpc", 3)) {
                    Log.d("InstanceID/Rpc", "Messenger failed, fallback to startService");
                }
            }
        }
        this.f2120e.startService(intent);
    }

    void m4320a(Bundle bundle, KeyPair keyPair, String str) throws IOException {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (this.f2130o == 0 || elapsedRealtime > this.f2130o) {
            m4317a();
            if (f2116a == null) {
                throw new IOException("MISSING_INSTANCEID_SERVICE");
            }
            this.f2126k = SystemClock.elapsedRealtime();
            Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
            intent.setPackage(f2116a);
            bundle.putString("gmsv", Integer.toString(C1037e.m4313b(this.f2120e)));
            bundle.putString("osv", Integer.toString(VERSION.SDK_INT));
            bundle.putString("app_ver", Integer.toString(C1030a.m4283a(this.f2120e)));
            bundle.putString("app_ver_name", C1030a.m4287b(this.f2120e));
            bundle.putString("cliv", "1");
            bundle.putString("appid", C1030a.m4285a(keyPair));
            bundle.putString("pub2", C1030a.m4286a(keyPair.getPublic().getEncoded()));
            bundle.putString("sig", C1037e.m4308a(keyPair, this.f2120e.getPackageName(), r1));
            intent.putExtras(bundle);
            m4318a(intent);
            m4319a(intent, str);
            return;
        }
        elapsedRealtime = this.f2130o - elapsedRealtime;
        Log.w("InstanceID/Rpc", "Backoff mode, next request attempt: " + elapsedRealtime + " interval: " + this.f2129n);
        throw new IOException("RETRY_LATER");
    }

    public void m4321a(Message message) {
        if (message != null) {
            if (message.obj instanceof Intent) {
                Intent intent = (Intent) message.obj;
                intent.setExtrasClassLoader(MessengerCompat.class.getClassLoader());
                if (intent.hasExtra("google.messenger")) {
                    Parcelable parcelableExtra = intent.getParcelableExtra("google.messenger");
                    if (parcelableExtra instanceof MessengerCompat) {
                        this.f2124i = (MessengerCompat) parcelableExtra;
                    }
                    if (parcelableExtra instanceof Messenger) {
                        this.f2123h = (Messenger) parcelableExtra;
                    }
                }
                m4324d((Intent) message.obj);
                return;
            }
            Log.w("InstanceID/Rpc", "Dropping invalid message");
        }
    }

    String m4322b(Intent intent) throws IOException {
        if (intent == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        String stringExtra = intent.getStringExtra("registration_id");
        if (stringExtra == null) {
            stringExtra = intent.getStringExtra("unregistered");
        }
        intent.getLongExtra("Retry-After", 0);
        String valueOf;
        if (stringExtra != null) {
            if (stringExtra == null) {
                return stringExtra;
            }
            stringExtra = intent.getStringExtra("error");
            if (stringExtra == null) {
                throw new IOException(stringExtra);
            }
            valueOf = String.valueOf(intent.getExtras());
            Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 29).append("Unexpected response from GCM ").append(valueOf).toString(), new Throwable());
            throw new IOException("SERVICE_NOT_AVAILABLE");
        } else if (stringExtra == null) {
            return stringExtra;
        } else {
            stringExtra = intent.getStringExtra("error");
            if (stringExtra == null) {
                valueOf = String.valueOf(intent.getExtras());
                Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 29).append("Unexpected response from GCM ").append(valueOf).toString(), new Throwable());
                throw new IOException("SERVICE_NOT_AVAILABLE");
            }
            throw new IOException(stringExtra);
        }
    }

    void m4323c(Intent intent) {
        String stringExtra = intent.getStringExtra("error");
        if (stringExtra == null) {
            String valueOf = String.valueOf(intent.getExtras());
            Log.w("InstanceID/Rpc", new StringBuilder(String.valueOf(valueOf).length() + 49).append("Unexpected response, no error or registration id ").append(valueOf).toString());
            return;
        }
        if (Log.isLoggable("InstanceID/Rpc", 3)) {
            valueOf = "InstanceID/Rpc";
            String str = "Received InstanceID error ";
            String valueOf2 = String.valueOf(stringExtra);
            Log.d(valueOf, valueOf2.length() != 0 ? str.concat(valueOf2) : new String(str));
        }
        if (stringExtra.startsWith("|")) {
            String[] split = stringExtra.split("\\|");
            if (!"ID".equals(split[1])) {
                String str2 = "InstanceID/Rpc";
                String str3 = "Unexpected structured response ";
                valueOf2 = String.valueOf(stringExtra);
                Log.w(str2, valueOf2.length() != 0 ? str3.concat(valueOf2) : new String(str3));
            }
            if (split.length > 2) {
                valueOf2 = split[2];
                valueOf = split[3];
                if (valueOf.startsWith(":")) {
                    valueOf = valueOf.substring(1);
                }
            } else {
                valueOf = "UNKNOWN";
                valueOf2 = null;
            }
            intent.putExtra("error", valueOf);
        } else {
            valueOf2 = null;
            valueOf = stringExtra;
        }
        if (valueOf2 == null) {
            m4309a((Object) valueOf);
        } else {
            m4312a(valueOf2, (Object) valueOf);
        }
        long longExtra = intent.getLongExtra("Retry-After", 0);
        if (longExtra > 0) {
            this.f2127l = SystemClock.elapsedRealtime();
            this.f2129n = ((int) longExtra) * 1000;
            this.f2130o = SystemClock.elapsedRealtime() + ((long) this.f2129n);
            Log.w("InstanceID/Rpc", "Explicit request from server to backoff: " + this.f2129n);
        } else if ("SERVICE_NOT_AVAILABLE".equals(valueOf) || "AUTHENTICATION_FAILED".equals(valueOf)) {
            m4311a(valueOf);
        }
    }

    public void m4324d(Intent intent) {
        if (intent != null) {
            String action = intent.getAction();
            String stringExtra;
            String valueOf;
            if ("com.google.android.c2dm.intent.REGISTRATION".equals(action) || "com.google.android.gms.iid.InstanceID".equals(action)) {
                action = intent.getStringExtra("registration_id");
                stringExtra = action == null ? intent.getStringExtra("unregistered") : action;
                if (stringExtra == null) {
                    m4323c(intent);
                    return;
                }
                this.f2126k = SystemClock.elapsedRealtime();
                this.f2130o = 0;
                this.f2128m = 0;
                this.f2129n = 0;
                if (Log.isLoggable("InstanceID/Rpc", 3)) {
                    valueOf = String.valueOf(intent.getExtras());
                    Log.d("InstanceID/Rpc", new StringBuilder((String.valueOf(stringExtra).length() + 16) + String.valueOf(valueOf).length()).append("AppIDResponse: ").append(stringExtra).append(" ").append(valueOf).toString());
                }
                action = null;
                if (stringExtra.startsWith("|")) {
                    String[] split = stringExtra.split("\\|");
                    if (!"ID".equals(split[1])) {
                        String str = "InstanceID/Rpc";
                        String str2 = "Unexpected structured response ";
                        action = String.valueOf(stringExtra);
                        Log.w(str, action.length() != 0 ? str2.concat(action) : new String(str2));
                    }
                    stringExtra = split[2];
                    if (split.length > 4) {
                        if ("SYNC".equals(split[3])) {
                            C1031b.m4296a(this.f2120e);
                        } else if ("RST".equals(split[3])) {
                            C1031b.m4297a(this.f2120e, C1030a.m4288c(this.f2120e).m4293c());
                            intent.removeExtra("registration_id");
                            m4312a(stringExtra, (Object) intent);
                            return;
                        }
                    }
                    action = split[split.length - 1];
                    if (action.startsWith(":")) {
                        action = action.substring(1);
                    }
                    intent.putExtra("registration_id", action);
                    action = stringExtra;
                }
                if (action == null) {
                    m4309a((Object) intent);
                } else {
                    m4312a(action, (Object) intent);
                }
            } else if (Log.isLoggable("InstanceID/Rpc", 3)) {
                stringExtra = "InstanceID/Rpc";
                valueOf = "Unexpected response ";
                action = String.valueOf(intent.getAction());
                Log.d(stringExtra, action.length() != 0 ? valueOf.concat(action) : new String(valueOf));
            }
        } else if (Log.isLoggable("InstanceID/Rpc", 3)) {
            Log.d("InstanceID/Rpc", "Unexpected response: null");
        }
    }
}
