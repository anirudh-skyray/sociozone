package com.google.android.gms.iid;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.IBinder;
import android.support.v4.content.C0216j;
import android.util.Log;

public class C1031b extends Service {
    static String f2106a = "action";
    private static String f2107f = "google.com/iid";
    private static String f2108g = "CMD";
    private static String f2109h = "gcm.googleapis.com/refresh";
    MessengerCompat f2110b;
    BroadcastReceiver f2111c;
    int f2112d;
    int f2113e;

    static void m4296a(Context context) {
        Intent intent = new Intent("com.google.android.gms.iid.InstanceID");
        intent.setPackage(context.getPackageName());
        intent.putExtra(f2108g, "SYNC");
        context.startService(intent);
    }

    static void m4297a(Context context, C1038f c1038f) {
        c1038f.m4334b();
        Intent intent = new Intent("com.google.android.gms.iid.InstanceID");
        intent.putExtra(f2108g, "RST");
        intent.setPackage(context.getPackageName());
        context.startService(intent);
    }

    void m4298a() {
        synchronized (this) {
            this.f2112d--;
            if (this.f2112d == 0) {
                stopSelf(this.f2113e);
            }
            if (Log.isLoggable("InstanceID", 3)) {
                int i = this.f2112d;
                Log.d("InstanceID", "Stop " + i + " " + this.f2113e);
            }
        }
    }

    void m4299a(int i) {
        synchronized (this) {
            this.f2112d++;
            if (i > this.f2113e) {
                this.f2113e = i;
            }
        }
    }

    public void m4300a(Intent intent) {
        C1030a c;
        String stringExtra = intent.getStringExtra("subtype");
        if (stringExtra == null) {
            c = C1030a.m4288c(this);
        } else {
            Bundle bundle = new Bundle();
            bundle.putString("subtype", stringExtra);
            c = C1030a.m4284a(this, bundle);
        }
        String stringExtra2 = intent.getStringExtra(f2108g);
        if (intent.getStringExtra("error") == null && intent.getStringExtra("registration_id") == null) {
            if (Log.isLoggable("InstanceID", 3)) {
                String valueOf = String.valueOf(intent.getExtras());
                Log.d("InstanceID", new StringBuilder(((String.valueOf(stringExtra).length() + 18) + String.valueOf(stringExtra2).length()) + String.valueOf(valueOf).length()).append("Service command ").append(stringExtra).append(" ").append(stringExtra2).append(" ").append(valueOf).toString());
            }
            if (intent.getStringExtra("unregistered") != null) {
                C1038f c2 = c.m4293c();
                if (stringExtra == null) {
                    stringExtra = "";
                }
                c2.m4338e(stringExtra);
                c.m4294d().m4324d(intent);
                return;
            } else if (f2109h.equals(intent.getStringExtra("from"))) {
                c.m4293c().m4338e(stringExtra);
                m4301a(false);
                return;
            } else if ("RST".equals(stringExtra2)) {
                c.m4292b();
                m4301a(true);
                return;
            } else if ("RST_FULL".equals(stringExtra2)) {
                if (!c.m4293c().m4333a()) {
                    c.m4293c().m4334b();
                    m4301a(true);
                    return;
                }
                return;
            } else if ("SYNC".equals(stringExtra2)) {
                c.m4293c().m4338e(stringExtra);
                m4301a(false);
                return;
            } else if (!"PING".equals(stringExtra2)) {
                return;
            } else {
                return;
            }
        }
        if (Log.isLoggable("InstanceID", 3)) {
            stringExtra2 = "InstanceID";
            String str = "Register result in service ";
            stringExtra = String.valueOf(stringExtra);
            Log.d(stringExtra2, stringExtra.length() != 0 ? str.concat(stringExtra) : new String(str));
        }
        c.m4294d().m4324d(intent);
    }

    public void m4301a(boolean z) {
        m4302b();
    }

    public void m4302b() {
    }

    public IBinder onBind(Intent intent) {
        return (intent == null || !"com.google.android.gms.iid.InstanceID".equals(intent.getAction())) ? null : this.f2110b.m4281a();
    }

    public void onCreate() {
        IntentFilter intentFilter = new IntentFilter("com.google.android.c2dm.intent.REGISTRATION");
        intentFilter.addCategory(getPackageName());
        registerReceiver(this.f2111c, intentFilter, "com.google.android.c2dm.permission.RECEIVE", null);
    }

    public void onDestroy() {
        unregisterReceiver(this.f2111c);
    }

    public int onStartCommand(Intent intent, int i, int i2) {
        m4299a(i2);
        if (intent == null) {
            m4298a();
            return 2;
        }
        try {
            if ("com.google.android.gms.iid.InstanceID".equals(intent.getAction())) {
                if (VERSION.SDK_INT <= 18) {
                    Intent intent2 = (Intent) intent.getParcelableExtra("GSF");
                    if (intent2 != null) {
                        startService(intent2);
                        return 1;
                    }
                }
                m4300a(intent);
            }
            m4298a();
            if (intent.getStringExtra("from") != null) {
                C0216j.m792a(intent);
            }
            return 2;
        } finally {
            m4298a();
        }
    }
}
