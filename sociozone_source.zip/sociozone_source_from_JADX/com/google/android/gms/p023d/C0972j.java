package com.google.android.gms.p023d;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import android.util.Pair;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0837c;
import com.google.android.gms.common.api.C0837c.C0836a;
import com.google.android.gms.common.api.C0838d;
import com.google.android.gms.common.api.C0839f;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0920v;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.concurrent.CountDownLatch;

public abstract class C0972j<R extends C0819e> extends C0837c<R> {
    static final ThreadLocal<Boolean> f1925a = new C09811();
    protected final C0982a<R> f1926b;
    protected final WeakReference<GoogleApiClient> f1927c;
    private final Object f1928d;
    private final CountDownLatch f1929e;
    private final ArrayList<C0836a> f1930f;
    private C0839f<? super R> f1931g;
    private R f1932h;
    private C0983b f1933i;
    private volatile boolean f1934j;
    private boolean f1935k;
    private boolean f1936l;
    private C0920v f1937m;
    private volatile aj<R> f1938n;
    private boolean f1939o;

    class C09811 extends ThreadLocal<Boolean> {
        C09811() {
        }

        protected Boolean m4021a() {
            return Boolean.valueOf(false);
        }

        protected /* synthetic */ Object initialValue() {
            return m4021a();
        }
    }

    public static class C0982a<R extends C0819e> extends Handler {
        public C0982a() {
            this(Looper.getMainLooper());
        }

        public C0982a(Looper looper) {
            super(looper);
        }

        public void m4022a() {
            removeMessages(2);
        }

        public void m4023a(C0839f<? super R> c0839f, R r) {
            sendMessage(obtainMessage(1, new Pair(c0839f, r)));
        }

        protected void m4024b(C0839f<? super R> c0839f, R r) {
            try {
                c0839f.mo991a(r);
            } catch (RuntimeException e) {
                C0972j.m3989c((C0819e) r);
                throw e;
            }
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    Pair pair = (Pair) message.obj;
                    m4024b((C0839f) pair.first, (C0819e) pair.second);
                    return;
                case 2:
                    ((C0972j) message.obj).m3994c(Status.f1579d);
                    return;
                default:
                    Log.wtf("BasePendingResult", "Don't know how to handle message: " + message.what, new Exception());
                    return;
            }
        }
    }

    private final class C0983b {
        final /* synthetic */ C0972j f1948a;

        private C0983b(C0972j c0972j) {
            this.f1948a = c0972j;
        }

        protected void finalize() throws Throwable {
            C0972j.m3989c(this.f1948a.f1932h);
            super.finalize();
        }
    }

    @Deprecated
    C0972j() {
        this.f1928d = new Object();
        this.f1929e = new CountDownLatch(1);
        this.f1930f = new ArrayList();
        this.f1939o = false;
        this.f1926b = new C0982a(Looper.getMainLooper());
        this.f1927c = new WeakReference(null);
    }

    protected C0972j(GoogleApiClient googleApiClient) {
        this.f1928d = new Object();
        this.f1929e = new CountDownLatch(1);
        this.f1930f = new ArrayList();
        this.f1939o = false;
        this.f1926b = new C0982a(googleApiClient != null ? googleApiClient.mo1045a() : Looper.getMainLooper());
        this.f1927c = new WeakReference(googleApiClient);
    }

    private void mo1014a(R r) {
        this.f1932h = r;
        this.f1937m = null;
        this.f1929e.countDown();
        Status a = this.f1932h.mo897a();
        if (this.f1935k) {
            this.f1931g = null;
        } else if (this.f1931g != null) {
            this.f1926b.m4022a();
            this.f1926b.m4023a(this.f1931g, mo1013b());
        } else if (this.f1932h instanceof C0838d) {
            this.f1933i = new C0983b();
        }
        Iterator it = this.f1930f.iterator();
        while (it.hasNext()) {
            ((C0836a) it.next()).m3349a(a);
        }
        this.f1930f.clear();
    }

    private R mo1013b() {
        R r;
        boolean z = true;
        synchronized (this.f1928d) {
            if (this.f1934j) {
                z = false;
            }
            C0864b.m3459a(z, (Object) "Result has already been consumed.");
            C0864b.m3459a(m3996f(), (Object) "Result is not ready.");
            r = this.f1932h;
            this.f1932h = null;
            this.f1931g = null;
            this.f1934j = true;
        }
        mo1016e();
        return r;
    }

    public static void m3989c(C0819e c0819e) {
        if (c0819e instanceof C0838d) {
            try {
                ((C0838d) c0819e).m3352a();
            } catch (Throwable e) {
                String valueOf = String.valueOf(c0819e);
                Log.w("BasePendingResult", new StringBuilder(String.valueOf(valueOf).length() + 18).append("Unable to release ").append(valueOf).toString(), e);
            }
        }
    }

    public Integer mo988a() {
        return null;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public final void mo989a(com.google.android.gms.common.api.C0839f<? super R> r6) {
        /*
        r5 = this;
        r0 = 1;
        r1 = 0;
        r3 = r5.f1928d;
        monitor-enter(r3);
        if (r6 != 0) goto L_0x000c;
    L_0x0007:
        r0 = 0;
        r5.f1931g = r0;	 Catch:{ all -> 0x0027 }
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
    L_0x000b:
        return;
    L_0x000c:
        r2 = r5.f1934j;	 Catch:{ all -> 0x0027 }
        if (r2 != 0) goto L_0x002a;
    L_0x0010:
        r2 = r0;
    L_0x0011:
        r4 = "Result has already been consumed.";
        com.google.android.gms.common.internal.C0864b.m3459a(r2, r4);	 Catch:{ all -> 0x0027 }
        r2 = r5.f1938n;	 Catch:{ all -> 0x0027 }
        if (r2 != 0) goto L_0x002c;
    L_0x001a:
        r1 = "Cannot set callbacks if then() has been called.";
        com.google.android.gms.common.internal.C0864b.m3459a(r0, r1);	 Catch:{ all -> 0x0027 }
        r0 = r5.m3999i();	 Catch:{ all -> 0x0027 }
        if (r0 == 0) goto L_0x002e;
    L_0x0025:
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        goto L_0x000b;
    L_0x0027:
        r0 = move-exception;
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        throw r0;
    L_0x002a:
        r2 = r1;
        goto L_0x0011;
    L_0x002c:
        r0 = r1;
        goto L_0x001a;
    L_0x002e:
        r0 = r5.m3996f();	 Catch:{ all -> 0x0027 }
        if (r0 == 0) goto L_0x003f;
    L_0x0034:
        r0 = r5.f1926b;	 Catch:{ all -> 0x0027 }
        r1 = r5.mo1013b();	 Catch:{ all -> 0x0027 }
        r0.m4023a(r6, r1);	 Catch:{ all -> 0x0027 }
    L_0x003d:
        monitor-exit(r3);	 Catch:{ all -> 0x0027 }
        goto L_0x000b;
    L_0x003f:
        r5.f1931g = r6;	 Catch:{ all -> 0x0027 }
        goto L_0x003d;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.j.a(com.google.android.gms.common.api.f):void");
    }

    protected abstract R mo1012b(Status status);

    public final void m3993b(R r) {
        boolean z = true;
        synchronized (this.f1928d) {
            if (this.f1936l || this.f1935k || (m3996f() && m4001k())) {
                C0972j.m3989c((C0819e) r);
                return;
            }
            C0864b.m3459a(!m3996f(), (Object) "Results have already been set");
            if (this.f1934j) {
                z = false;
            }
            C0864b.m3459a(z, (Object) "Result has already been consumed");
            mo1014a((C0819e) r);
        }
    }

    public final void m3994c(Status status) {
        synchronized (this.f1928d) {
            if (!m3996f()) {
                m3993b(mo1012b(status));
                this.f1936l = true;
            }
        }
    }

    protected void mo1016e() {
    }

    public final boolean m3996f() {
        return this.f1929e.getCount() == 0;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void m3997g() {
        /*
        r2 = this;
        r1 = r2.f1928d;
        monitor-enter(r1);
        r0 = r2.f1935k;	 Catch:{ all -> 0x0029 }
        if (r0 != 0) goto L_0x000b;
    L_0x0007:
        r0 = r2.f1934j;	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x000d;
    L_0x000b:
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
    L_0x000c:
        return;
    L_0x000d:
        r0 = r2.f1937m;	 Catch:{ all -> 0x0029 }
        if (r0 == 0) goto L_0x0016;
    L_0x0011:
        r0 = r2.f1937m;	 Catch:{ RemoteException -> 0x002c }
        r0.m3695a();	 Catch:{ RemoteException -> 0x002c }
    L_0x0016:
        r0 = r2.f1932h;	 Catch:{ all -> 0x0029 }
        com.google.android.gms.p023d.C0972j.m3989c(r0);	 Catch:{ all -> 0x0029 }
        r0 = 1;
        r2.f1935k = r0;	 Catch:{ all -> 0x0029 }
        r0 = com.google.android.gms.common.api.Status.f1580e;	 Catch:{ all -> 0x0029 }
        r0 = r2.mo1012b(r0);	 Catch:{ all -> 0x0029 }
        r2.mo1014a(r0);	 Catch:{ all -> 0x0029 }
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        goto L_0x000c;
    L_0x0029:
        r0 = move-exception;
        monitor-exit(r1);	 Catch:{ all -> 0x0029 }
        throw r0;
    L_0x002c:
        r0 = move-exception;
        goto L_0x0016;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.j.g():void");
    }

    public boolean m3998h() {
        boolean i;
        synchronized (this.f1928d) {
            if (((GoogleApiClient) this.f1927c.get()) == null || !this.f1939o) {
                m3997g();
            }
            i = m3999i();
        }
        return i;
    }

    public boolean m3999i() {
        boolean z;
        synchronized (this.f1928d) {
            z = this.f1935k;
        }
        return z;
    }

    public void m4000j() {
        boolean z = this.f1939o || ((Boolean) f1925a.get()).booleanValue();
        this.f1939o = z;
    }

    boolean m4001k() {
        return false;
    }
}
