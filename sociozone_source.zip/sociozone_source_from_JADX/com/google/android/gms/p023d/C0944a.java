package com.google.android.gms.p023d;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.ComponentCallbacks2;
import android.content.res.Configuration;
import android.os.Bundle;
import com.google.firebase.C1107a;
import java.util.concurrent.atomic.AtomicBoolean;

@TargetApi(14)
public class C0944a implements ActivityLifecycleCallbacks, ComponentCallbacks2 {
    private static final C0944a f1834a = new C0944a();
    private final AtomicBoolean f1835b = new AtomicBoolean();
    private boolean f1836c;

    private C0944a() {
    }

    public static void m3846a(Application application) {
        application.registerActivityLifecycleCallbacks(f1834a);
        application.registerComponentCallbacks(f1834a);
        f1834a.f1836c = true;
    }

    public void onActivityCreated(Activity activity, Bundle bundle) {
        if (this.f1835b.compareAndSet(true, false)) {
            C1107a.m4658a(false);
        }
    }

    public void onActivityDestroyed(Activity activity) {
    }

    public void onActivityPaused(Activity activity) {
    }

    public void onActivityResumed(Activity activity) {
        if (this.f1835b.compareAndSet(true, false)) {
            C1107a.m4658a(false);
        }
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    public void onActivityStarted(Activity activity) {
    }

    public void onActivityStopped(Activity activity) {
    }

    public void onConfigurationChanged(Configuration configuration) {
    }

    public void onLowMemory() {
    }

    public void onTrimMemory(int i) {
        if (i == 20 && this.f1835b.compareAndSet(false, true)) {
            C1107a.m4658a(true);
        }
    }
}
