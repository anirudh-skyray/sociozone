package com.google.android.gms.p023d;

public interface ac {
    Object m3857a();
}
