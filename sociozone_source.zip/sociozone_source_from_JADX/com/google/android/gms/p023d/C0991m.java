package com.google.android.gms.p023d;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0845l;
import java.util.Iterator;

public class C0991m extends C0970i {
    protected void mo1009a(ConnectionResult connectionResult, int i) {
        C1023u c1023u = null;
        c1023u.m4270b(connectionResult, i);
    }

    public void mo1007b() {
        Object obj = null;
        super.mo1007b();
        Iterator it = obj.iterator();
        while (it.hasNext()) {
            ((C0845l) it.next()).m3359a();
        }
        obj.clear();
        obj.m4267a(this);
    }

    protected void mo1011c() {
        C1023u c1023u = null;
        c1023u.m4269b();
    }
}
