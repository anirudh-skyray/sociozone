package com.google.android.gms.p023d;

import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0864b;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class C0971f extends C0970i {
    private final SparseArray<C0968a> f1924e = new SparseArray();

    private class C0968a implements C0818c {
        public final int f1913a;
        public final GoogleApiClient f1914b;
        public final C0818c f1915c;
        final /* synthetic */ C0971f f1916d;

        public C0968a(C0971f c0971f, int i, GoogleApiClient googleApiClient, C0818c c0818c) {
            this.f1916d = c0971f;
            this.f1913a = i;
            this.f1914b = googleApiClient;
            this.f1915c = c0818c;
            googleApiClient.mo1049a((C0818c) this);
        }

        public void m3956a() {
            this.f1914b.mo1052b((C0818c) this);
            this.f1914b.disconnect();
        }

        public void mo1003a(ConnectionResult connectionResult) {
            String valueOf = String.valueOf(connectionResult);
            Log.d("AutoManageHelper", new StringBuilder(String.valueOf(valueOf).length() + 27).append("beginFailureResolution for ").append(valueOf).toString());
            this.f1916d.m3975b(connectionResult, this.f1913a);
        }

        public void m3958a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
            printWriter.append(str).append("GoogleApiClient #").print(this.f1913a);
            printWriter.println(":");
            this.f1914b.mo1051a(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
        }
    }

    private C0971f(aa aaVar) {
        super(aaVar);
        this.d.mo987a("AutoManageHelper", (C0969z) this);
    }

    public static C0971f m3978a(C1028y c1028y) {
        aa b = C0969z.m3959b(c1028y);
        C0971f c0971f = (C0971f) b.mo986a("AutoManageHelper", C0971f.class);
        return c0971f != null ? c0971f : new C0971f(b);
    }

    public void mo1004a() {
        super.mo1004a();
        boolean z = this.a;
        String valueOf = String.valueOf(this.f1924e);
        Log.d("AutoManageHelper", new StringBuilder(String.valueOf(valueOf).length() + 14).append("onStart ").append(z).append(" ").append(valueOf).toString());
        if (!this.b) {
            for (int i = 0; i < this.f1924e.size(); i++) {
                ((C0968a) this.f1924e.valueAt(i)).f1914b.connect();
            }
        }
    }

    public void m3980a(int i) {
        C0968a c0968a = (C0968a) this.f1924e.get(i);
        this.f1924e.remove(i);
        if (c0968a != null) {
            c0968a.m3956a();
        }
    }

    public void m3981a(int i, GoogleApiClient googleApiClient, C0818c c0818c) {
        C0864b.m3455a((Object) googleApiClient, (Object) "GoogleApiClient instance cannot be null");
        C0864b.m3459a(this.f1924e.indexOfKey(i) < 0, "Already managing a GoogleApiClient with id " + i);
        Log.d("AutoManageHelper", "starting AutoManage for client " + i + " " + this.a + " " + this.b);
        this.f1924e.put(i, new C0968a(this, i, googleApiClient, c0818c));
        if (this.a && !this.b) {
            String valueOf = String.valueOf(googleApiClient);
            Log.d("AutoManageHelper", new StringBuilder(String.valueOf(valueOf).length() + 11).append("connecting ").append(valueOf).toString());
            googleApiClient.connect();
        }
    }

    protected void mo1009a(ConnectionResult connectionResult, int i) {
        Log.w("AutoManageHelper", "Unresolved error while connecting client. Stopping auto-manage.");
        if (i < 0) {
            Log.wtf("AutoManageHelper", "AutoManageLifecycleHelper received onErrorResolutionFailed callback but no failing client ID is set", new Exception());
            return;
        }
        C0968a c0968a = (C0968a) this.f1924e.get(i);
        if (c0968a != null) {
            m3980a(i);
            C0818c c0818c = c0968a.f1915c;
            if (c0818c != null) {
                c0818c.mo1003a(connectionResult);
            }
        }
    }

    public void mo1010a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        for (int i = 0; i < this.f1924e.size(); i++) {
            ((C0968a) this.f1924e.valueAt(i)).m3958a(str, fileDescriptor, printWriter, strArr);
        }
    }

    public void mo1007b() {
        super.mo1007b();
        for (int i = 0; i < this.f1924e.size(); i++) {
            ((C0968a) this.f1924e.valueAt(i)).f1914b.disconnect();
        }
    }

    protected void mo1011c() {
        for (int i = 0; i < this.f1924e.size(); i++) {
            ((C0968a) this.f1924e.valueAt(i)).f1914b.connect();
        }
    }
}
