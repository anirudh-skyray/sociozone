package com.google.android.gms.p023d;

import android.content.Context;
import com.google.firebase.C1107a;
import java.util.concurrent.atomic.AtomicReference;

public class C0961b {
    private static final AtomicReference<C0961b> f1906a = new AtomicReference();

    C0961b(Context context) {
    }

    public static C0961b m3935a(Context context) {
        f1906a.compareAndSet(null, new C0961b(context));
        return (C0961b) f1906a.get();
    }

    public void m3936a(C1107a c1107a) {
    }
}
