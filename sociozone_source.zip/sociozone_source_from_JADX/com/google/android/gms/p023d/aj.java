package com.google.android.gms.p023d;

import android.os.Handler;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0837c;
import com.google.android.gms.common.api.C0838d;
import com.google.android.gms.common.api.C0839f;
import com.google.android.gms.common.api.C0840g;
import com.google.android.gms.common.api.C0841h;
import com.google.android.gms.common.api.C0842i;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0864b;
import java.lang.ref.WeakReference;

public class aj<R extends C0819e> extends C0842i<R> implements C0839f<R> {
    private C0841h<? super R, ? extends C0819e> f1858a;
    private aj<? extends C0819e> f1859b;
    private volatile C0840g<? super R> f1860c;
    private C0837c<R> f1861d;
    private final Object f1862e;
    private Status f1863f;
    private final WeakReference<GoogleApiClient> f1864g;
    private final C0948a f1865h;
    private boolean f1866i;

    private final class C0948a extends Handler {
        final /* synthetic */ aj f1857a;

        public void handleMessage(Message message) {
            switch (message.what) {
                case 0:
                    C0837c c0837c = (C0837c) message.obj;
                    synchronized (this.f1857a.f1862e) {
                        if (c0837c == null) {
                            this.f1857a.f1859b.m3874a(new Status(13, "Transform returned null"));
                        } else if (c0837c instanceof ag) {
                            this.f1857a.f1859b.m3874a(((ag) c0837c).m3863b());
                        } else {
                            this.f1857a.f1859b.m3886a(c0837c);
                        }
                    }
                    return;
                case 1:
                    RuntimeException runtimeException = (RuntimeException) message.obj;
                    String str = "TransformedResultImpl";
                    String str2 = "Runtime exception on the transformation worker thread: ";
                    String valueOf = String.valueOf(runtimeException.getMessage());
                    Log.e(str, valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
                    throw runtimeException;
                default:
                    Log.e("TransformedResultImpl", "TransformationResultHandler received unknown message type: " + message.what);
                    return;
            }
        }
    }

    private void m3874a(Status status) {
        synchronized (this.f1862e) {
            this.f1863f = status;
            m3879b(this.f1863f);
        }
    }

    private void m3878b() {
        if (this.f1858a != null || this.f1860c != null) {
            GoogleApiClient googleApiClient = (GoogleApiClient) this.f1864g.get();
            if (!(this.f1866i || this.f1858a == null || googleApiClient == null)) {
                googleApiClient.mo1050a(this);
                this.f1866i = true;
            }
            if (this.f1863f != null) {
                m3879b(this.f1863f);
            } else if (this.f1861d != null) {
                this.f1861d.mo989a(this);
            }
        }
    }

    private void m3879b(Status status) {
        synchronized (this.f1862e) {
            if (this.f1858a != null) {
                Status a = this.f1858a.m3356a(status);
                C0864b.m3455a((Object) a, (Object) "onFailure must not return null");
                this.f1859b.m3874a(a);
            } else if (m3882c()) {
                this.f1860c.m3354a(status);
            }
        }
    }

    private void m3880b(C0819e c0819e) {
        if (c0819e instanceof C0838d) {
            try {
                ((C0838d) c0819e).m3352a();
            } catch (Throwable e) {
                String valueOf = String.valueOf(c0819e);
                Log.w("TransformedResultImpl", new StringBuilder(String.valueOf(valueOf).length() + 18).append("Unable to release ").append(valueOf).toString(), e);
            }
        }
    }

    private boolean m3882c() {
        return (this.f1860c == null || ((GoogleApiClient) this.f1864g.get()) == null) ? false : true;
    }

    void m3885a() {
        this.f1860c = null;
    }

    public void m3886a(C0837c<?> c0837c) {
        synchronized (this.f1862e) {
            this.f1861d = c0837c;
            m3878b();
        }
    }

    public void mo991a(final R r) {
        synchronized (this.f1862e) {
            if (!r.mo897a().m3320e()) {
                m3874a(r.mo897a());
                m3880b((C0819e) r);
            } else if (this.f1858a != null) {
                af.m3860a().submit(new Runnable(this) {
                    final /* synthetic */ aj f1856b;

                    public void run() {
                        GoogleApiClient googleApiClient;
                        try {
                            C0972j.f1925a.set(Boolean.valueOf(true));
                            this.f1856b.f1865h.sendMessage(this.f1856b.f1865h.obtainMessage(0, this.f1856b.f1858a.m3357a(r)));
                            C0972j.f1925a.set(Boolean.valueOf(false));
                            this.f1856b.m3880b(r);
                            googleApiClient = (GoogleApiClient) this.f1856b.f1864g.get();
                            if (googleApiClient != null) {
                                googleApiClient.mo1053b(this.f1856b);
                            }
                        } catch (RuntimeException e) {
                            this.f1856b.f1865h.sendMessage(this.f1856b.f1865h.obtainMessage(1, e));
                            C0972j.f1925a.set(Boolean.valueOf(false));
                            this.f1856b.m3880b(r);
                            googleApiClient = (GoogleApiClient) this.f1856b.f1864g.get();
                            if (googleApiClient != null) {
                                googleApiClient.mo1053b(this.f1856b);
                            }
                        } catch (Throwable th) {
                            Throwable th2 = th;
                            C0972j.f1925a.set(Boolean.valueOf(false));
                            this.f1856b.m3880b(r);
                            googleApiClient = (GoogleApiClient) this.f1856b.f1864g.get();
                            if (googleApiClient != null) {
                                googleApiClient.mo1053b(this.f1856b);
                            }
                        }
                    }
                });
            } else if (m3882c()) {
                this.f1860c.m3355b(r);
            }
        }
    }
}
