package com.google.android.gms.p023d;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

public final class C1024v extends BroadcastReceiver {
    protected Context f2092a;
    private final C0978a f2093b;

    public static abstract class C0978a {
        public abstract void mo1017a();
    }

    public C1024v(C0978a c0978a) {
        this.f2093b = c0978a;
    }

    public synchronized void m4271a() {
        if (this.f2092a != null) {
            this.f2092a.unregisterReceiver(this);
        }
        this.f2092a = null;
    }

    public void m4272a(Context context) {
        this.f2092a = context;
    }

    public void onReceive(Context context, Intent intent) {
        Uri data = intent.getData();
        Object obj = null;
        if (data != null) {
            obj = data.getSchemeSpecificPart();
        }
        if ("com.google.android.gms".equals(obj)) {
            this.f2093b.mo1017a();
            m4271a();
        }
    }
}
