package com.google.android.gms.p023d;

import com.google.android.gms.common.api.C0834a.C0820a.C0824d;

public final class as implements C0824d {
    public static final as f1899a = new C0960a().m3928a();
    private final boolean f1900b;
    private final boolean f1901c;
    private final String f1902d;
    private final boolean f1903e;
    private final String f1904f;
    private final boolean f1905g;

    public static final class C0960a {
        public as m3928a() {
            return new as(false, false, null, false, null, false);
        }
    }

    private as(boolean z, boolean z2, String str, boolean z3, String str2, boolean z4) {
        this.f1900b = z;
        this.f1901c = z2;
        this.f1902d = str;
        this.f1903e = z3;
        this.f1905g = z4;
        this.f1904f = str2;
    }

    public boolean m3929a() {
        return this.f1900b;
    }

    public boolean m3930b() {
        return this.f1901c;
    }

    public String m3931c() {
        return this.f1902d;
    }

    public boolean m3932d() {
        return this.f1903e;
    }

    public String m3933e() {
        return this.f1904f;
    }

    public boolean m3934f() {
        return this.f1905g;
    }
}
