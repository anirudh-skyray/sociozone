package com.google.android.gms.p023d;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public abstract class C1018t {
    private static final ExecutorService f2057a = Executors.newFixedThreadPool(2, new am("GAC_Executor"));

    public static ExecutorService m4216a() {
        return f2057a;
    }
}
