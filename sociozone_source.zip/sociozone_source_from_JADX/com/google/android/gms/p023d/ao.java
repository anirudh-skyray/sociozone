package com.google.android.gms.p023d;

import android.annotation.TargetApi;
import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.p022a.C0810g;

public class ao {
    protected final Context f1888a;

    public ao(Context context) {
        this.f1888a = context;
    }

    public ApplicationInfo m3914a(String str, int i) throws NameNotFoundException {
        return this.f1888a.getPackageManager().getApplicationInfo(str, i);
    }

    @TargetApi(19)
    public boolean m3915a(int i, String str) {
        if (C0810g.m3272f()) {
            try {
                ((AppOpsManager) this.f1888a.getSystemService("appops")).checkPackage(i, str);
                return true;
            } catch (SecurityException e) {
                return false;
            }
        }
        String[] packagesForUid = this.f1888a.getPackageManager().getPackagesForUid(i);
        if (str == null || packagesForUid == null) {
            return false;
        }
        for (Object equals : packagesForUid) {
            if (str.equals(equals)) {
                return true;
            }
        }
        return false;
    }

    public PackageInfo m3916b(String str, int i) throws NameNotFoundException {
        return this.f1888a.getPackageManager().getPackageInfo(str, i);
    }
}
