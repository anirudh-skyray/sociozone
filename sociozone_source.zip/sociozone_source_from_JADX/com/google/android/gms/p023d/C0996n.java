package com.google.android.gms.p023d;

import android.os.Bundle;
import android.os.DeadObjectException;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0870e;
import com.google.android.gms.p023d.C0976h.C0975a;
import com.google.android.gms.p023d.C1017s.C0992a;

public class C0996n implements C0995r {
    private final C1017s f1972a;
    private boolean f1973b = false;

    public C0996n(C1017s c1017s) {
        this.f1972a = c1017s;
    }

    private <A extends C0827c> void m4090b(C0975a<? extends C0819e, A> c0975a) throws DeadObjectException {
        this.f1972a.f2048g.f2025i.m3895a((C0975a) c0975a);
        C0827c b = this.f1972a.f2048g.m4189b(c0975a.mo1013b());
        if (b.m3329b() || !this.f1972a.f2043b.containsKey(c0975a.mo1013b())) {
            if (b instanceof C0870e) {
                b = ((C0870e) b).mo914k();
            }
            c0975a.m4010a(b);
            return;
        }
        c0975a.m4009a(new Status(17));
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1030a(T t) {
        try {
            m4090b(t);
        } catch (DeadObjectException e) {
            this.f1972a.m4207a(new C0992a(this, this) {
                final /* synthetic */ C0996n f1970a;

                public void mo1029a() {
                    this.f1970a.mo1032a(1);
                }
            });
        }
        return t;
    }

    public void mo1031a() {
    }

    public void mo1032a(int i) {
        this.f1972a.m4205a(null);
        this.f1972a.f2049h.mo1020a(i, this.f1973b);
    }

    public void mo1033a(Bundle bundle) {
    }

    public void mo1034a(ConnectionResult connectionResult, C0834a<?> c0834a, int i) {
    }

    public boolean mo1035b() {
        if (this.f1973b) {
            return false;
        }
        if (this.f1972a.f2048g.m4196g()) {
            this.f1973b = true;
            for (aj a : this.f1972a.f2048g.f2024h) {
                a.m3885a();
            }
            return false;
        }
        this.f1972a.m4205a(null);
        return true;
    }

    public void mo1036c() {
        if (this.f1973b) {
            this.f1973b = false;
            this.f1972a.m4207a(new C0992a(this, this) {
                final /* synthetic */ C0996n f1971a;

                public void mo1029a() {
                    this.f1971a.f1972a.f2049h.mo1021a(null);
                }
            });
        }
    }

    void m4098d() {
        if (this.f1973b) {
            this.f1973b = false;
            this.f1972a.f2048g.f2025i.m3894a();
            mo1035b();
        }
    }
}
