package com.google.android.gms.p023d;

import android.content.Context;

public class ap {
    private static ap f1889b = new ap();
    private ao f1890a = null;

    public static ao m3917b(Context context) {
        return f1889b.m3918a(context);
    }

    public synchronized ao m3918a(Context context) {
        if (this.f1890a == null) {
            if (context.getApplicationContext() != null) {
                context = context.getApplicationContext();
            }
            this.f1890a = new ao(context);
        }
        return this.f1890a;
    }
}
