package com.google.android.gms.p023d;

import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0820a;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.internal.ab;

public final class C0967e<O extends C0820a> {
    private final C0834a<O> f1911a;
    private final O f1912b;

    public C0828d<?> m3954a() {
        return this.f1911a.m3345d();
    }

    public String m3955b() {
        return this.f1911a.m3347f();
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (!(obj instanceof C0967e)) {
            return false;
        }
        C0967e c0967e = (C0967e) obj;
        return ab.m3453a(this.f1911a, c0967e.f1911a) && ab.m3453a(this.f1912b, c0967e.f1912b);
    }

    public int hashCode() {
        return ab.m3451a(this.f1911a, this.f1912b);
    }
}
