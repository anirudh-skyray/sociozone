package com.google.android.gms.p023d;

import android.app.Activity;
import android.support.v4.app.C0164q;

public class C1028y {
    private final Object f2095a;

    public boolean m4276a() {
        return this.f2095a instanceof C0164q;
    }

    public Activity m4277b() {
        return (Activity) this.f2095a;
    }

    public C0164q m4278c() {
        return (C0164q) this.f2095a;
    }
}
