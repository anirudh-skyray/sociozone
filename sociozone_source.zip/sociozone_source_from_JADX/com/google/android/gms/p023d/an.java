package com.google.android.gms.p023d;

import android.os.Process;

class an implements Runnable {
    private final Runnable f1886a;
    private final int f1887b;

    public an(Runnable runnable, int i) {
        this.f1886a = runnable;
        this.f1887b = i;
    }

    public void run() {
        Process.setThreadPriority(this.f1887b);
        this.f1886a.run();
    }
}
