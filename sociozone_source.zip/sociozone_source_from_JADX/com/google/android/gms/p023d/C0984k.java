package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0864b;

public class C0984k implements C0817b, C0818c {
    public final C0834a<?> f1949a;
    private final int f1950b;
    private C1017s f1951c;

    public C0984k(C0834a<?> c0834a, int i) {
        this.f1949a = c0834a;
        this.f1950b = i;
    }

    private void m4025a() {
        C0864b.m3455a(this.f1951c, (Object) "Callbacks must be attached to a GoogleApiClient instance before connecting the client.");
    }

    public void mo1018a(int i) {
        m4025a();
        this.f1951c.m4203a(i);
    }

    public void mo1019a(Bundle bundle) {
        m4025a();
        this.f1951c.m4204a(bundle);
    }

    public void mo1003a(ConnectionResult connectionResult) {
        m4025a();
        this.f1951c.m4206a(connectionResult, this.f1949a, this.f1950b);
    }

    public void m4029a(C1017s c1017s) {
        this.f1951c = c1017s;
    }
}
