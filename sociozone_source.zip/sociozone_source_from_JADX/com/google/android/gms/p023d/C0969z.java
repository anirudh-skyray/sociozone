package com.google.android.gms.p023d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import java.io.FileDescriptor;
import java.io.PrintWriter;

public class C0969z {
    protected final aa f1917d;

    protected C0969z(aa aaVar) {
        this.f1917d = aaVar;
    }

    protected static aa m3959b(C1028y c1028y) {
        return c1028y.m4276a() ? ai.m3866a(c1028y.m4278c()) : ab.m3851a(c1028y.m4277b());
    }

    public void mo1004a() {
    }

    public void mo1005a(int i, int i2, Intent intent) {
    }

    public void mo1006a(Bundle bundle) {
    }

    public void mo1010a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
    }

    public void mo1007b() {
    }

    public void mo1008b(Bundle bundle) {
    }

    public Activity m3966e() {
        return this.f1917d.mo985a();
    }
}
