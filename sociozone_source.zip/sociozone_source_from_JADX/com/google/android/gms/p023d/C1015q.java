package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.C0850b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.common.internal.C0909q;
import com.google.android.gms.common.internal.C0909q.C0868a;
import com.google.android.gms.p023d.C0976h.C0975a;
import com.google.android.gms.p023d.C0989x.C0986a;
import com.google.android.gms.p023d.C1024v.C0978a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.io.Writer;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.locks.Lock;

public final class C1015q extends GoogleApiClient implements C0986a {
    final Queue<C0975a<?, ?>> f2017a = new LinkedList();
    C1024v f2018b;
    final Map<C0828d<?>, C0829f> f2019c;
    Set<Scope> f2020d = new HashSet();
    final C0900l f2021e;
    final Map<C0834a<?>, Integer> f2022f;
    final C0826b<? extends ar, as> f2023g;
    Set<aj> f2024h = null;
    final ak f2025i;
    private final Lock f2026j;
    private final C0909q f2027k;
    private C0989x f2028l = null;
    private final int f2029m;
    private final Context f2030n;
    private final Looper f2031o;
    private volatile boolean f2032p;
    private long f2033q = 120000;
    private long f2034r = 5000;
    private final C1013a f2035s;
    private final C0850b f2036t;
    private final ae f2037u = new ae();
    private final ArrayList<C0984k> f2038v;
    private Integer f2039w = null;
    private final C0868a f2040x = new C10121(this);

    class C10121 implements C0868a {
        final /* synthetic */ C1015q f2014a;

        C10121(C1015q c1015q) {
            this.f2014a = c1015q;
        }

        public boolean mo1043b() {
            return this.f2014a.mo1054b();
        }

        public Bundle mo1044s() {
            return null;
        }
    }

    final class C1013a extends Handler {
        final /* synthetic */ C1015q f2015a;

        C1013a(C1015q c1015q, Looper looper) {
            this.f2015a = c1015q;
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    this.f2015a.m4178l();
                    return;
                case 2:
                    this.f2015a.m4177k();
                    return;
                default:
                    Log.w("GoogleApiClientImpl", "Unknown message id: " + message.what);
                    return;
            }
        }
    }

    static class C1014b extends C0978a {
        private WeakReference<C1015q> f2016a;

        C1014b(C1015q c1015q) {
            this.f2016a = new WeakReference(c1015q);
        }

        public void mo1017a() {
            C1015q c1015q = (C1015q) this.f2016a.get();
            if (c1015q != null) {
                c1015q.m4177k();
            }
        }
    }

    public C1015q(Context context, Lock lock, Looper looper, C0900l c0900l, C0850b c0850b, C0826b<? extends ar, as> c0826b, Map<C0834a<?>, Integer> map, List<C0817b> list, List<C0818c> list2, Map<C0828d<?>, C0829f> map2, int i, int i2, ArrayList<C0984k> arrayList) {
        this.f2030n = context;
        this.f2026j = lock;
        this.f2027k = new C0909q(looper, this.f2040x);
        this.f2031o = looper;
        this.f2035s = new C1013a(this, looper);
        this.f2036t = c0850b;
        this.f2029m = i;
        if (this.f2029m >= 0) {
            this.f2039w = Integer.valueOf(i2);
        }
        this.f2022f = map;
        this.f2019c = map2;
        this.f2038v = arrayList;
        this.f2025i = new ak(this.f2019c);
        for (C0817b a : list) {
            this.f2027k.m3617a(a);
        }
        for (C0818c a2 : list2) {
            this.f2027k.m3618a(a2);
        }
        this.f2021e = c0900l;
        this.f2023g = c0826b;
    }

    public static int m4171a(Iterable<C0829f> iterable, boolean z) {
        int i = 0;
        int i2 = 0;
        for (C0829f c0829f : iterable) {
            if (c0829f.mo1118d()) {
                i2 = 1;
            }
            i = c0829f.m3333f() ? 1 : i;
        }
        return i2 != 0 ? (i == 0 || !z) ? 1 : 2 : 3;
    }

    static String m4173b(int i) {
        switch (i) {
            case 1:
                return "SIGN_IN_MODE_REQUIRED";
            case 2:
                return "SIGN_IN_MODE_OPTIONAL";
            case 3:
                return "SIGN_IN_MODE_NONE";
            default:
                return "UNKNOWN";
        }
    }

    private void m4175c(int i) {
        if (this.f2039w == null) {
            this.f2039w = Integer.valueOf(i);
        } else if (this.f2039w.intValue() != i) {
            String valueOf = String.valueOf(C1015q.m4173b(i));
            String valueOf2 = String.valueOf(C1015q.m4173b(this.f2039w.intValue()));
            throw new IllegalStateException(new StringBuilder((String.valueOf(valueOf).length() + 51) + String.valueOf(valueOf2).length()).append("Cannot use sign-in mode: ").append(valueOf).append(". Mode was already set to ").append(valueOf2).toString());
        }
        if (this.f2028l == null) {
            Object obj = null;
            Object obj2 = null;
            for (C0829f c0829f : this.f2019c.values()) {
                if (c0829f.mo1118d()) {
                    obj2 = 1;
                }
                obj = c0829f.m3333f() ? 1 : obj;
            }
            switch (this.f2039w.intValue()) {
                case 1:
                    if (obj2 == null) {
                        throw new IllegalStateException("SIGN_IN_MODE_REQUIRED cannot be used on a GoogleApiClient that does not contain any authenticated APIs. Use connect() instead.");
                    } else if (obj != null) {
                        throw new IllegalStateException("Cannot use SIGN_IN_MODE_REQUIRED with GOOGLE_SIGN_IN_API. Use connect(SIGN_IN_MODE_OPTIONAL) instead.");
                    }
                    break;
                case 2:
                    if (obj2 != null) {
                        this.f2028l = C0990l.m4046a(this.f2030n, this, this.f2026j, this.f2031o, this.f2036t, this.f2019c, this.f2021e, this.f2022f, this.f2023g, this.f2038v);
                        return;
                    }
                    break;
            }
            this.f2028l = new C1017s(this.f2030n, this, this.f2026j, this.f2031o, this.f2036t, this.f2019c, this.f2021e, this.f2022f, this.f2023g, this.f2038v, this);
        }
    }

    private void m4176j() {
        this.f2027k.m3619b();
        this.f2028l.mo1024a();
    }

    private void m4177k() {
        this.f2026j.lock();
        try {
            if (m4193d()) {
                m4176j();
            }
            this.f2026j.unlock();
        } catch (Throwable th) {
            this.f2026j.unlock();
        }
    }

    private void m4178l() {
        this.f2026j.lock();
        try {
            if (m4195f()) {
                m4176j();
            }
            this.f2026j.unlock();
        } catch (Throwable th) {
            this.f2026j.unlock();
        }
    }

    public Looper mo1045a() {
        return this.f2031o;
    }

    public <C extends C0829f> C mo1046a(C0828d<C> c0828d) {
        Object obj = (C0829f) this.f2019c.get(c0828d);
        C0864b.m3455a(obj, (Object) "Appropriate Api was not requested.");
        return obj;
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1047a(T t) {
        C0864b.m3463b(t.mo1013b() != null, "This task can not be executed (it's probably a Batch or malformed)");
        boolean containsKey = this.f2019c.containsKey(t.mo1013b());
        String f = t.m4016c() != null ? t.m4016c().m3347f() : "the API";
        C0864b.m3463b(containsKey, new StringBuilder(String.valueOf(f).length() + 65).append("GoogleApiClient is not configured to use ").append(f).append(" required for this call.").toString());
        this.f2026j.lock();
        try {
            if (this.f2028l == null) {
                throw new IllegalStateException("GoogleApiClient is not connected yet.");
            }
            if (m4193d()) {
                this.f2017a.add(t);
                while (!this.f2017a.isEmpty()) {
                    C0975a c0975a = (C0975a) this.f2017a.remove();
                    this.f2025i.m3895a(c0975a);
                    c0975a.m4009a(Status.f1578c);
                }
            } else {
                t = this.f2028l.mo1023a(t);
                this.f2026j.unlock();
            }
            return t;
        } finally {
            this.f2026j.unlock();
        }
    }

    public void mo1048a(int i) {
        boolean z = true;
        this.f2026j.lock();
        if (!(i == 3 || i == 1 || i == 2)) {
            z = false;
        }
        try {
            C0864b.m3463b(z, "Illegal sign-in mode: " + i);
            m4175c(i);
            m4176j();
        } finally {
            this.f2026j.unlock();
        }
    }

    public void mo1020a(int i, boolean z) {
        if (i == 1 && !z) {
            m4194e();
        }
        this.f2025i.m3897b();
        this.f2027k.m3614a(i);
        this.f2027k.m3613a();
        if (i == 2) {
            m4176j();
        }
    }

    public void mo1021a(Bundle bundle) {
        while (!this.f2017a.isEmpty()) {
            mo1047a((C0975a) this.f2017a.remove());
        }
        this.f2027k.m3615a(bundle);
    }

    public void mo1022a(ConnectionResult connectionResult) {
        if (!this.f2036t.mo903a(this.f2030n, connectionResult.m3253c())) {
            m4195f();
        }
        if (!m4193d()) {
            this.f2027k.m3616a(connectionResult);
            this.f2027k.m3613a();
        }
    }

    public void mo1049a(C0818c c0818c) {
        this.f2027k.m3618a(c0818c);
    }

    public void mo1050a(aj ajVar) {
        this.f2026j.lock();
        try {
            if (this.f2024h == null) {
                this.f2024h = new HashSet();
            }
            this.f2024h.add(ajVar);
        } finally {
            this.f2026j.unlock();
        }
    }

    public void mo1051a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append(str).append("mContext=").println(this.f2030n);
        printWriter.append(str).append("mResuming=").print(this.f2032p);
        printWriter.append(" mWorkQueue.size()=").print(this.f2017a.size());
        this.f2025i.m3896a(printWriter);
        if (this.f2028l != null) {
            this.f2028l.mo1025a(str, fileDescriptor, printWriter, strArr);
        }
    }

    <C extends C0829f> C m4189b(C0828d<?> c0828d) {
        Object obj = (C0829f) this.f2019c.get(c0828d);
        C0864b.m3455a(obj, (Object) "Appropriate Api was not requested.");
        return obj;
    }

    public void mo1052b(C0818c c0818c) {
        this.f2027k.m3620b(c0818c);
    }

    public void mo1053b(aj ajVar) {
        this.f2026j.lock();
        try {
            if (this.f2024h == null) {
                Log.wtf("GoogleApiClientImpl", "Attempted to remove pending transform when no transforms are registered.", new Exception());
            } else if (!this.f2024h.remove(ajVar)) {
                Log.wtf("GoogleApiClientImpl", "Failed to remove pending transform - this may lead to memory leaks!", new Exception());
            } else if (!m4196g()) {
                this.f2028l.mo1028d();
            }
            this.f2026j.unlock();
        } catch (Throwable th) {
            this.f2026j.unlock();
        }
    }

    public boolean mo1054b() {
        return this.f2028l != null && this.f2028l.mo1027c();
    }

    public void connect() {
        boolean z = false;
        this.f2026j.lock();
        try {
            if (this.f2029m >= 0) {
                if (this.f2039w != null) {
                    z = true;
                }
                C0864b.m3459a(z, (Object) "Sign-in mode should have been set explicitly by auto-manage.");
            } else if (this.f2039w == null) {
                this.f2039w = Integer.valueOf(C1015q.m4171a(this.f2019c.values(), false));
            } else if (this.f2039w.intValue() == 2) {
                throw new IllegalStateException("Cannot call connect() when SignInMode is set to SIGN_IN_MODE_OPTIONAL. Call connect(SIGN_IN_MODE_OPTIONAL) instead.");
            }
            mo1048a(this.f2039w.intValue());
        } finally {
            this.f2026j.unlock();
        }
    }

    boolean m4193d() {
        return this.f2032p;
    }

    public void disconnect() {
        this.f2026j.lock();
        try {
            this.f2025i.m3894a();
            if (this.f2028l != null) {
                this.f2028l.mo1026b();
            }
            this.f2037u.m3859a();
            for (C0975a c0975a : this.f2017a) {
                c0975a.m4012a(null);
                c0975a.m3997g();
            }
            this.f2017a.clear();
            if (this.f2028l != null) {
                m4195f();
                this.f2027k.m3613a();
                this.f2026j.unlock();
            }
        } finally {
            this.f2026j.unlock();
        }
    }

    void m4194e() {
        if (!m4193d()) {
            this.f2032p = true;
            if (this.f2018b == null) {
                this.f2018b = this.f2036t.m3389a(this.f2030n.getApplicationContext(), new C1014b(this));
            }
            this.f2035s.sendMessageDelayed(this.f2035s.obtainMessage(1), this.f2033q);
            this.f2035s.sendMessageDelayed(this.f2035s.obtainMessage(2), this.f2034r);
        }
    }

    boolean m4195f() {
        if (!m4193d()) {
            return false;
        }
        this.f2032p = false;
        this.f2035s.removeMessages(2);
        this.f2035s.removeMessages(1);
        if (this.f2018b != null) {
            this.f2018b.m4271a();
            this.f2018b = null;
        }
        return true;
    }

    boolean m4196g() {
        boolean z = false;
        this.f2026j.lock();
        try {
            if (this.f2024h != null) {
                if (!this.f2024h.isEmpty()) {
                    z = true;
                }
                this.f2026j.unlock();
            }
            return z;
        } finally {
            this.f2026j.unlock();
        }
    }

    String m4197h() {
        Writer stringWriter = new StringWriter();
        mo1051a("", null, new PrintWriter(stringWriter), null);
        return stringWriter.toString();
    }

    public int m4198i() {
        return System.identityHashCode(this);
    }
}
