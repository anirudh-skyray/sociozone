package com.google.android.gms.p023d;

import java.util.Collections;
import java.util.Set;
import java.util.WeakHashMap;

public class ae {
    private final Set<ad<?>> f1845a = Collections.newSetFromMap(new WeakHashMap());

    public void m3859a() {
        for (ad a : this.f1845a) {
            a.m3858a();
        }
        this.f1845a.clear();
    }
}
