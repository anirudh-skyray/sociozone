package com.google.android.gms.p023d;

import android.support.v4.p011e.C0232a;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0843k;
import com.google.android.gms.common.api.C0844j;
import com.google.android.gms.common.api.Status;
import java.util.Set;

public final class C0973g extends C0972j<C0843k> {
    private int f1940d;
    private boolean f1941e;

    private void m4002a(ConnectionResult connectionResult) {
        C0232a c0232a = null;
        for (int i = 0; i < c0232a.size(); i++) {
            m4004a((C0967e) c0232a.m845b(i), connectionResult);
        }
    }

    protected C0843k m4003a(Status status) {
        C0843k c0843k;
        synchronized (null) {
            try {
                m4002a(new ConnectionResult(8));
                C0232a c0232a = null;
                if (c0232a.size() != 1) {
                    c0843k = new C0843k(status, null);
                }
            } finally {
            }
        }
        return c0843k;
    }

    public void m4004a(C0967e<?> c0967e, ConnectionResult connectionResult) {
        synchronized (null) {
            C0232a c0232a = null;
            try {
                c0232a.put(c0967e, connectionResult);
                this.f1940d--;
                boolean b = connectionResult.m3252b();
                if (!b) {
                    this.f1941e = b;
                }
                if (this.f1940d == 0) {
                    Status status = this.f1941e ? new Status(13) : Status.f1576a;
                    c0232a = null;
                    m3993b(c0232a.size() == 1 ? new C0844j(status, null) : new C0843k(status, null));
                }
            } finally {
            }
        }
    }

    protected /* synthetic */ C0819e mo1012b(Status status) {
        return m4003a(status);
    }

    public Set<C0967e<?>> mo1013b() {
        C0232a c0232a = null;
        return c0232a.keySet();
    }
}
