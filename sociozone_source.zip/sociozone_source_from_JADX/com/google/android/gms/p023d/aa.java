package com.google.android.gms.p023d;

import android.app.Activity;
import android.content.Intent;

public interface aa {
    Activity mo985a();

    <T extends C0969z> T mo986a(String str, Class<T> cls);

    void mo987a(String str, C0969z c0969z);

    void startActivityForResult(Intent intent, int i);
}
