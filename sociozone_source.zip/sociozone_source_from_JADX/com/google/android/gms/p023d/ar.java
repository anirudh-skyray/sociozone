package com.google.android.gms.p023d;

import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.internal.C0859u;
import com.google.android.gms.signin.internal.C1005d;

public interface ar extends C0829f {
    void mo1116a(C0859u c0859u, boolean z);

    void mo1117a(C1005d c1005d);

    void mo914k();

    void mo1119l();
}
