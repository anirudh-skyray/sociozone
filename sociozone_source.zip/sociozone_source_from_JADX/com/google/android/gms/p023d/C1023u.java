package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.Handler.Callback;
import android.os.Message;
import android.os.Process;
import android.support.v4.p011e.C0232a;
import android.util.Log;
import android.util.SparseArray;
import com.google.android.gms.common.C0850b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0820a;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.C0834a.C0832i;
import com.google.android.gms.common.api.C0845l;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0867i.C0879f;
import com.google.android.gms.common.internal.C0870e;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.p023d.C0965d.C0966a;
import com.google.android.gms.p023d.C0976h.C0975a;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class C1023u implements Callback {
    private static final Object f2076d = new Object();
    private static C1023u f2077e;
    private long f2078a;
    private long f2079b;
    private long f2080c;
    private final Context f2081f;
    private final C0850b f2082g;
    private int f2083h;
    private final SparseArray<C1021c<?>> f2084i;
    private final Map<C0967e<?>, C1021c<?>> f2085j;
    private C0991m f2086k;
    private final Set<C0967e<?>> f2087l;
    private final Handler f2088m;
    private final ReferenceQueue<C0845l<?>> f2089n;
    private final SparseArray<C1019a> f2090o;
    private C1020b f2091p;

    private final class C1019a extends PhantomReference<C0845l<?>> {
        final /* synthetic */ C1023u f2058a;
        private final int f2059b;

        public C1019a(C1023u c1023u, C0845l c0845l, int i, ReferenceQueue<C0845l<?>> referenceQueue) {
            this.f2058a = c1023u;
            super(c0845l, referenceQueue);
            this.f2059b = i;
        }

        public void m4218a() {
            this.f2058a.f2088m.sendMessage(this.f2058a.f2088m.obtainMessage(2, this.f2059b, 2));
        }
    }

    private static final class C1020b extends Thread {
        private final ReferenceQueue<C0845l<?>> f2060a;
        private final SparseArray<C1019a> f2061b;
        private final AtomicBoolean f2062c = new AtomicBoolean();

        public C1020b(ReferenceQueue<C0845l<?>> referenceQueue, SparseArray<C1019a> sparseArray) {
            super("GoogleApiCleanup");
            this.f2060a = referenceQueue;
            this.f2061b = sparseArray;
        }

        public void run() {
            this.f2062c.set(true);
            Process.setThreadPriority(10);
            while (this.f2062c.get()) {
                try {
                    C1019a c1019a = (C1019a) this.f2060a.remove();
                    this.f2061b.remove(c1019a.f2059b);
                    c1019a.m4218a();
                } catch (InterruptedException e) {
                } finally {
                    this.f2062c.set(false);
                }
            }
        }
    }

    private class C1021c<O extends C0820a> implements C0817b, C0818c {
        final /* synthetic */ C1023u f2063a;
        private final Queue<C0965d> f2064b = new LinkedList();
        private final C0829f f2065c;
        private final C0827c f2066d;
        private final C0967e<O> f2067e;
        private final SparseArray<ak> f2068f = new SparseArray();
        private final Set<C0973g> f2069g = new HashSet();
        private final SparseArray<Map<Object, C0975a>> f2070h = new SparseArray();
        private boolean f2071i;
        private ConnectionResult f2072j = null;

        public C1021c(C1023u c1023u, C0845l<O> c0845l) {
            this.f2063a = c1023u;
            this.f2065c = m4220a((C0845l) c0845l);
            if (this.f2065c instanceof C0870e) {
                this.f2066d = ((C0870e) this.f2065c).mo914k();
            } else {
                this.f2066d = this.f2065c;
            }
            this.f2067e = c0845l.m3362d();
        }

        private C0829f m4220a(C0845l c0845l) {
            C0834a b = c0845l.m3360b();
            if (!b.m3346e()) {
                return c0845l.m3360b().m3343b().mo994a(c0845l.m3363e(), this.f2063a.f2088m.getLooper(), C0900l.m3584a(c0845l.m3363e()), c0845l.m3361c(), this, this);
            }
            C0832i c = b.m3344c();
            return new C0870e(c0845l.m3363e(), this.f2063a.f2088m.getLooper(), c.m3340b(), this, this, C0900l.m3584a(c0845l.m3363e()), c.m3341b(c0845l.m3361c()));
        }

        private void m4221a(Status status) {
            for (C0965d a : this.f2064b) {
                a.mo1000a(status);
            }
            this.f2064b.clear();
        }

        private void m4224b(ConnectionResult connectionResult) {
            for (C0973g a : this.f2069g) {
                a.m4004a(this.f2067e, connectionResult);
            }
            this.f2069g.clear();
        }

        private void m4225b(C0965d c0965d) {
            c0965d.mo999a(this.f2068f);
            Map map;
            if (c0965d.f1909b == 3) {
                try {
                    Map map2;
                    map = (Map) this.f2070h.get(c0965d.f1908a);
                    if (map == null) {
                        C0232a c0232a = new C0232a(1);
                        this.f2070h.put(c0965d.f1908a, c0232a);
                        map2 = c0232a;
                    } else {
                        map2 = map;
                    }
                    C0975a c0975a = ((C0966a) c0965d).f1910c;
                    map2.put(((ac) c0975a).m3857a(), c0975a);
                } catch (ClassCastException e) {
                    throw new IllegalStateException("Listener registration methods must implement ListenerApiMethod");
                }
            } else if (c0965d.f1909b == 4) {
                try {
                    map = (Map) this.f2070h.get(c0965d.f1908a);
                    ac acVar = (ac) ((C0966a) c0965d).f1910c;
                    if (map != null) {
                        map.remove(acVar.m3857a());
                    } else {
                        Log.w("GoogleApiManager", "Received call to unregister a listener without a matching registration call.");
                    }
                } catch (ClassCastException e2) {
                    throw new IllegalStateException("Listener unregistration methods must implement ListenerApiMethod");
                }
            }
            try {
                c0965d.mo1001a(this.f2066d);
            } catch (DeadObjectException e3) {
                this.f2065c.mo1105a();
                mo1018a(1);
            }
        }

        private void m4229e() {
            if (this.f2071i) {
                m4234j();
            }
        }

        private void m4230f() {
            if (this.f2071i) {
                this.f2063a.f2088m.removeMessages(9, this.f2067e);
                this.f2063a.f2088m.removeMessages(8, this.f2067e);
                this.f2071i = false;
            }
        }

        private void m4231g() {
            if (this.f2071i) {
                m4230f();
                m4221a(this.f2063a.f2082g.mo898a(this.f2063a.f2081f) == 18 ? new Status(8, "Connection timed out while waiting for Google Play services update to complete.") : new Status(8, "API failed to connect while resuming due to an unknown error."));
                this.f2065c.mo1105a();
            }
        }

        private void m4232h() {
            this.f2063a.f2088m.removeMessages(10, this.f2067e);
            this.f2063a.f2088m.sendMessageDelayed(this.f2063a.f2088m.obtainMessage(10, this.f2067e), this.f2063a.f2080c);
        }

        private void m4233i() {
            if (this.f2065c.m3329b() && this.f2070h.size() == 0) {
                for (int i = 0; i < this.f2068f.size(); i++) {
                    if (((ak) this.f2068f.get(this.f2068f.keyAt(i))).m3898c()) {
                        m4232h();
                        return;
                    }
                }
                this.f2065c.mo1105a();
            }
        }

        private void m4234j() {
            if (!this.f2065c.m3329b() && !this.f2065c.m3330c()) {
                if (this.f2065c.m3332e() && this.f2063a.f2083h != 0) {
                    this.f2063a.f2083h = this.f2063a.f2082g.mo898a(this.f2063a.f2081f);
                    if (this.f2063a.f2083h != 0) {
                        mo1003a(new ConnectionResult(this.f2063a.f2083h, null));
                        return;
                    }
                }
                this.f2065c.m3326a(new C1022d(this.f2063a, this.f2065c, this.f2067e));
            }
        }

        public void m4235a() {
            while (this.f2065c.m3329b() && !this.f2064b.isEmpty()) {
                m4225b((C0965d) this.f2064b.remove());
            }
        }

        public void mo1018a(int i) {
            m4242b();
            this.f2071i = true;
            this.f2063a.f2088m.sendMessageDelayed(Message.obtain(this.f2063a.f2088m, 8, this.f2067e), this.f2063a.f2078a);
            this.f2063a.f2088m.sendMessageDelayed(Message.obtain(this.f2063a.f2088m, 9, this.f2067e), this.f2063a.f2079b);
            this.f2063a.f2083h = -1;
        }

        public void m4237a(int i, boolean z) {
            Iterator it = this.f2064b.iterator();
            while (it.hasNext()) {
                C0965d c0965d = (C0965d) it.next();
                if (c0965d.f1908a == i && c0965d.f1909b != 1 && c0965d.mo1002a()) {
                    it.remove();
                }
            }
            ((ak) this.f2068f.get(i)).m3894a();
            this.f2070h.delete(i);
            if (!z) {
                this.f2068f.remove(i);
                this.f2063a.f2090o.remove(i);
                if (this.f2068f.size() == 0 && this.f2064b.isEmpty()) {
                    m4230f();
                    this.f2065c.mo1105a();
                    this.f2063a.f2085j.remove(this.f2067e);
                    synchronized (C1023u.f2076d) {
                        this.f2063a.f2087l.remove(this.f2067e);
                    }
                }
            }
        }

        public void mo1019a(Bundle bundle) {
            m4242b();
            m4224b(ConnectionResult.f1539a);
            m4230f();
            for (int i = 0; i < this.f2070h.size(); i++) {
                for (C0975a a : ((Map) this.f2070h.get(this.f2070h.keyAt(i))).values()) {
                    try {
                        a.m4010a(this.f2066d);
                    } catch (DeadObjectException e) {
                        this.f2065c.mo1105a();
                        mo1018a(1);
                    }
                }
            }
            m4235a();
            m4232h();
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        public void mo1003a(com.google.android.gms.common.ConnectionResult r6) {
            /*
            r5 = this;
            r5.m4242b();
            r0 = r5.f2063a;
            r1 = -1;
            r0.f2083h = r1;
            r5.m4224b(r6);
            r0 = r5.f2068f;
            r1 = 0;
            r0 = r0.keyAt(r1);
            r1 = r5.f2064b;
            r1 = r1.isEmpty();
            if (r1 == 0) goto L_0x001e;
        L_0x001b:
            r5.f2072j = r6;
        L_0x001d:
            return;
        L_0x001e:
            r1 = com.google.android.gms.p023d.C1023u.f2076d;
            monitor-enter(r1);
            r2 = r5.f2063a;	 Catch:{ all -> 0x0044 }
            r2 = null;	 Catch:{ all -> 0x0044 }
            if (r2 == 0) goto L_0x0047;
        L_0x002b:
            r2 = r5.f2063a;	 Catch:{ all -> 0x0044 }
            r2 = r2.f2087l;	 Catch:{ all -> 0x0044 }
            r3 = r5.f2067e;	 Catch:{ all -> 0x0044 }
            r2 = r2.contains(r3);	 Catch:{ all -> 0x0044 }
            if (r2 == 0) goto L_0x0047;
        L_0x0039:
            r2 = r5.f2063a;	 Catch:{ all -> 0x0044 }
            r2 = null;	 Catch:{ all -> 0x0044 }
            r2.m3975b(r6, r0);	 Catch:{ all -> 0x0044 }
            monitor-exit(r1);	 Catch:{ all -> 0x0044 }
            goto L_0x001d;
        L_0x0044:
            r0 = move-exception;
            monitor-exit(r1);	 Catch:{ all -> 0x0044 }
            throw r0;
        L_0x0047:
            monitor-exit(r1);	 Catch:{ all -> 0x0044 }
            r1 = r5.f2063a;
            r0 = r1.m4268a(r6, r0);
            if (r0 != 0) goto L_0x001d;
        L_0x0050:
            r0 = r6.m3253c();
            r1 = 18;
            if (r0 != r1) goto L_0x005b;
        L_0x0058:
            r0 = 1;
            r5.f2071i = r0;
        L_0x005b:
            r0 = r5.f2071i;
            if (r0 == 0) goto L_0x007d;
        L_0x005f:
            r0 = r5.f2063a;
            r0 = r0.f2088m;
            r1 = r5.f2063a;
            r1 = r1.f2088m;
            r2 = 8;
            r3 = r5.f2067e;
            r1 = android.os.Message.obtain(r1, r2, r3);
            r2 = r5.f2063a;
            r2 = r2.f2078a;
            r0.sendMessageDelayed(r1, r2);
            goto L_0x001d;
        L_0x007d:
            r0 = new com.google.android.gms.common.api.Status;
            r1 = 17;
            r2 = r5.f2067e;
            r2 = r2.m3955b();
            r2 = java.lang.String.valueOf(r2);
            r3 = new java.lang.StringBuilder;
            r4 = java.lang.String.valueOf(r2);
            r4 = r4.length();
            r4 = r4 + 38;
            r3.<init>(r4);
            r4 = "API: ";
            r3 = r3.append(r4);
            r2 = r3.append(r2);
            r3 = " is not available on this device.";
            r2 = r2.append(r3);
            r2 = r2.toString();
            r0.<init>(r1, r2);
            r5.m4221a(r0);
            goto L_0x001d;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.u.c.a(com.google.android.gms.common.ConnectionResult):void");
        }

        public void m4240a(C0965d c0965d) {
            if (this.f2065c.m3329b()) {
                m4225b(c0965d);
                m4232h();
                return;
            }
            this.f2064b.add(c0965d);
            if (this.f2072j == null || !this.f2072j.m3251a()) {
                m4234j();
            } else {
                mo1003a(this.f2072j);
            }
        }

        public void m4241a(C0973g c0973g) {
            this.f2069g.add(c0973g);
        }

        public void m4242b() {
            this.f2072j = null;
        }

        public void m4243b(int i) {
            this.f2068f.put(i, new ak(this.f2067e.m3954a(), this.f2065c));
        }

        ConnectionResult m4244c() {
            return this.f2072j;
        }

        boolean m4245d() {
            return this.f2065c.m3329b();
        }
    }

    private class C1022d implements C0879f {
        final /* synthetic */ C1023u f2073a;
        private final C0829f f2074b;
        private final C0967e<?> f2075c;

        public C1022d(C1023u c1023u, C0829f c0829f, C0967e<?> c0967e) {
            this.f2073a = c1023u;
            this.f2074b = c0829f;
            this.f2075c = c0967e;
        }

        public void mo919a(ConnectionResult connectionResult) {
            if (connectionResult.m3252b()) {
                this.f2074b.m3327a(null, Collections.emptySet());
            } else {
                ((C1021c) this.f2073a.f2085j.get(this.f2075c)).mo1003a(connectionResult);
            }
        }
    }

    public static C1023u m4249a() {
        C1023u c1023u;
        synchronized (f2076d) {
            c1023u = f2077e;
        }
        return c1023u;
    }

    private void m4250a(C0845l<?> c0845l, int i) {
        C0967e d = c0845l.m3362d();
        if (!this.f2085j.containsKey(d)) {
            this.f2085j.put(d, new C1021c(this, c0845l));
        }
        C1021c c1021c = (C1021c) this.f2085j.get(d);
        c1021c.m4243b(i);
        this.f2084i.put(i, c1021c);
        c1021c.m4234j();
        this.f2090o.put(i, new C1019a(this, c0845l, i, this.f2089n));
        if (this.f2091p == null || !this.f2091p.f2062c.get()) {
            this.f2091p = new C1020b(this.f2089n, this.f2090o);
            this.f2091p.start();
        }
    }

    private void m4251a(C0965d c0965d) {
        ((C1021c) this.f2084i.get(c0965d.f1908a)).m4240a(c0965d);
    }

    private void m4253b(int i, boolean z) {
        C1021c c1021c = (C1021c) this.f2084i.get(i);
        if (c1021c != null) {
            if (!z) {
                this.f2084i.delete(i);
            }
            c1021c.m4237a(i, z);
            return;
        }
        Log.wtf("GoogleApiManager", "onRelease received for unknown instance: " + i, new Exception());
    }

    private void m4257d() {
        for (C1021c c1021c : this.f2085j.values()) {
            c1021c.m4242b();
            c1021c.m4234j();
        }
    }

    public void m4265a(int i, boolean z) {
        this.f2088m.sendMessage(this.f2088m.obtainMessage(7, i, z ? 1 : 2));
    }

    public void m4266a(C0973g c0973g) {
        for (C0967e c0967e : c0973g.mo1013b()) {
            C1021c c1021c = (C1021c) this.f2085j.get(c0967e);
            if (c1021c == null) {
                c0973g.m3997g();
                return;
            } else if (c1021c.m4245d()) {
                c0973g.m4004a(c0967e, ConnectionResult.f1539a);
            } else if (c1021c.m4244c() != null) {
                c0973g.m4004a(c0967e, c1021c.m4244c());
            } else {
                c1021c.m4241a(c0973g);
            }
        }
    }

    public void m4267a(C0991m c0991m) {
        synchronized (f2076d) {
            if (c0991m == null) {
                this.f2086k = null;
                this.f2087l.clear();
            }
        }
    }

    boolean m4268a(ConnectionResult connectionResult, int i) {
        if (!connectionResult.m3251a() && !this.f2082g.mo902a(connectionResult.m3253c())) {
            return false;
        }
        this.f2082g.m3390a(this.f2081f, connectionResult, i);
        return true;
    }

    public void m4269b() {
        this.f2088m.sendMessage(this.f2088m.obtainMessage(3));
    }

    public void m4270b(ConnectionResult connectionResult, int i) {
        if (!m4268a(connectionResult, i)) {
            this.f2088m.sendMessage(this.f2088m.obtainMessage(5, i, 0));
        }
    }

    public boolean handleMessage(Message message) {
        boolean z = false;
        switch (message.what) {
            case 1:
                m4266a((C0973g) message.obj);
                break;
            case 2:
            case 7:
                int i = message.arg1;
                if (message.arg2 == 1) {
                    z = true;
                }
                m4253b(i, z);
                break;
            case 3:
                m4257d();
                break;
            case 4:
                m4251a((C0965d) message.obj);
                break;
            case 5:
                if (this.f2084i.get(message.arg1) != null) {
                    ((C1021c) this.f2084i.get(message.arg1)).m4221a(new Status(17, "Error resolution was canceled by the user."));
                    break;
                }
                break;
            case 6:
                m4250a((C0845l) message.obj, message.arg1);
                break;
            case 8:
                if (this.f2085j.containsKey(message.obj)) {
                    ((C1021c) this.f2085j.get(message.obj)).m4229e();
                    break;
                }
                break;
            case 9:
                if (this.f2085j.containsKey(message.obj)) {
                    ((C1021c) this.f2085j.get(message.obj)).m4231g();
                    break;
                }
                break;
            case 10:
                if (this.f2085j.containsKey(message.obj)) {
                    ((C1021c) this.f2085j.get(message.obj)).m4233i();
                    break;
                }
                break;
            default:
                Log.w("GoogleApiManager", "Unknown message id: " + message.what);
                return false;
        }
        return true;
    }
}
