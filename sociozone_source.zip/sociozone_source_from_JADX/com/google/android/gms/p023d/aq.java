package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.app.ag;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0820a.C0821a;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0830g;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.signin.internal.C1103g;

public final class aq {
    public static final C0830g<C1103g> f1891a = new C0830g();
    public static final C0830g<C1103g> f1892b = new C0830g();
    public static final C0826b<C1103g, as> f1893c = new C09561();
    static final C0826b<C1103g, C0958a> f1894d = new C09572();
    public static final Scope f1895e = new Scope("profile");
    public static final Scope f1896f = new Scope(ag.CATEGORY_EMAIL);
    public static final C0834a<as> f1897g = new C0834a("SignIn.API", f1893c, f1891a);
    public static final C0834a<C0958a> f1898h = new C0834a("SignIn.INTERNAL_API", f1894d, f1892b);

    class C09561 extends C0826b<C1103g, as> {
        C09561() {
        }

        public C1103g m3920a(Context context, Looper looper, C0900l c0900l, as asVar, C0817b c0817b, C0818c c0818c) {
            return new C1103g(context, looper, true, c0900l, asVar == null ? as.f1899a : asVar, c0817b, c0818c);
        }
    }

    class C09572 extends C0826b<C1103g, C0958a> {
        C09572() {
        }

        public C1103g m3922a(Context context, Looper looper, C0900l c0900l, C0958a c0958a, C0817b c0817b, C0818c c0818c) {
            return new C1103g(context, looper, false, c0900l, c0958a.m3923a(), c0817b, c0818c);
        }
    }

    public static class C0958a implements C0821a {
        public Bundle m3923a() {
            return null;
        }
    }
}
