package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.util.Log;
import com.google.android.gms.common.C0849j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0859u;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0867i.C0879f;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.common.internal.C0900l.C0899a;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.p023d.C0976h.C0975a;
import com.google.android.gms.p023d.C1017s.C0992a;
import com.google.android.gms.signin.internal.C1007b;
import com.google.android.gms.signin.internal.SignInResponse;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Future;
import java.util.concurrent.locks.Lock;

public class C1010o implements C0995r {
    private final C1017s f1992a;
    private final Lock f1993b;
    private final Context f1994c;
    private final C0849j f1995d;
    private ConnectionResult f1996e;
    private int f1997f;
    private int f1998g = 0;
    private int f1999h;
    private final Bundle f2000i = new Bundle();
    private final Set<C0828d> f2001j = new HashSet();
    private ar f2002k;
    private int f2003l;
    private boolean f2004m;
    private boolean f2005n;
    private C0859u f2006o;
    private boolean f2007p;
    private boolean f2008q;
    private final C0900l f2009r;
    private final Map<C0834a<?>, Integer> f2010s;
    private final C0826b<? extends ar, as> f2011t;
    private ArrayList<Future<?>> f2012u = new ArrayList();

    class C09971 implements Runnable {
        final /* synthetic */ C1010o f1974a;

        C09971(C1010o c1010o) {
            this.f1974a = c1010o;
        }

        public void run() {
            this.f1974a.f1995d.m3381b(this.f1974a.f1994c);
        }
    }

    private static class C0998a implements C0879f {
        private final WeakReference<C1010o> f1975a;
        private final C0834a<?> f1976b;
        private final int f1977c;

        public C0998a(C1010o c1010o, C0834a<?> c0834a, int i) {
            this.f1975a = new WeakReference(c1010o);
            this.f1976b = c0834a;
            this.f1977c = i;
        }

        public void mo919a(ConnectionResult connectionResult) {
            boolean z = false;
            C1010o c1010o = (C1010o) this.f1975a.get();
            if (c1010o != null) {
                if (Looper.myLooper() == c1010o.f1992a.f2048g.mo1045a()) {
                    z = true;
                }
                C0864b.m3459a(z, (Object) "onReportServiceBinding must be called on the GoogleApiClient handler thread");
                c1010o.f1993b.lock();
                try {
                    if (c1010o.m4133b(0)) {
                        if (!connectionResult.m3252b()) {
                            c1010o.m4132b(connectionResult, this.f1976b, this.f1977c);
                        }
                        if (c1010o.m4140d()) {
                            c1010o.m4141e();
                        }
                        c1010o.f1993b.unlock();
                    }
                } finally {
                    c1010o.f1993b.unlock();
                }
            }
        }
    }

    private abstract class C1001f implements Runnable {
        final /* synthetic */ C1010o f1982b;

        private C1001f(C1010o c1010o) {
            this.f1982b = c1010o;
        }

        protected abstract void mo1037a();

        public void run() {
            this.f1982b.f1993b.lock();
            try {
                if (!Thread.interrupted()) {
                    mo1037a();
                    this.f1982b.f1993b.unlock();
                }
            } catch (RuntimeException e) {
                this.f1982b.f1992a.m4208a(e);
            } finally {
                this.f1982b.f1993b.unlock();
            }
        }
    }

    private class C1002b extends C1001f {
        final /* synthetic */ C1010o f1983a;
        private final Map<C0829f, C0998a> f1984c;

        public C1002b(C1010o c1010o, Map<C0829f, C0998a> map) {
            this.f1983a = c1010o;
            super();
            this.f1984c = map;
        }

        public void mo1037a() {
            int i;
            int i2 = 1;
            int i3 = 0;
            int i4 = 1;
            int i5 = 0;
            for (C0829f c0829f : this.f1984c.keySet()) {
                if (!c0829f.m3332e()) {
                    i = 0;
                    i4 = i5;
                } else if (((C0998a) this.f1984c.get(c0829f)).f1977c == 0) {
                    i = 1;
                    break;
                } else {
                    i = i4;
                    i4 = 1;
                }
                i5 = i4;
                i4 = i;
            }
            i2 = i5;
            i = 0;
            if (i2 != 0) {
                i3 = this.f1983a.f1995d.mo898a(this.f1983a.f1994c);
            }
            if (i3 == 0 || (r0 == 0 && i4 == 0)) {
                if (this.f1983a.f2004m) {
                    this.f1983a.f2002k.mo1119l();
                }
                for (C0829f c0829f2 : this.f1984c.keySet()) {
                    final C0879f c0879f = (C0879f) this.f1984c.get(c0829f2);
                    if (!c0829f2.m3332e() || i3 == 0) {
                        c0829f2.m3326a(c0879f);
                    } else {
                        this.f1983a.f1992a.m4207a(new C0992a(this, this.f1983a) {
                            final /* synthetic */ C1002b f1981b;

                            public void mo1029a() {
                                c0879f.mo919a(new ConnectionResult(16, null));
                            }
                        });
                    }
                }
                return;
            }
            final ConnectionResult connectionResult = new ConnectionResult(i3, null);
            this.f1983a.f1992a.m4207a(new C0992a(this, this.f1983a) {
                final /* synthetic */ C1002b f1979b;

                public void mo1029a() {
                    this.f1979b.f1983a.m4138c(connectionResult);
                }
            });
        }
    }

    private class C1003c extends C1001f {
        final /* synthetic */ C1010o f1985a;
        private final ArrayList<C0829f> f1986c;

        public C1003c(C1010o c1010o, ArrayList<C0829f> arrayList) {
            this.f1985a = c1010o;
            super();
            this.f1986c = arrayList;
        }

        public void mo1037a() {
            this.f1985a.f1992a.f2048g.f2020d = this.f1985a.m4151j();
            Iterator it = this.f1986c.iterator();
            while (it.hasNext()) {
                ((C0829f) it.next()).m3327a(this.f1985a.f2006o, this.f1985a.f1992a.f2048g.f2020d);
            }
        }
    }

    private static class C1008d extends C1007b {
        private final WeakReference<C1010o> f1990a;

        C1008d(C1010o c1010o) {
            this.f1990a = new WeakReference(c1010o);
        }

        public void mo1041a(final SignInResponse signInResponse) {
            final C1010o c1010o = (C1010o) this.f1990a.get();
            if (c1010o != null) {
                c1010o.f1992a.m4207a(new C0992a(this, c1010o) {
                    final /* synthetic */ C1008d f1989c;

                    public void mo1029a() {
                        c1010o.m4126a(signInResponse);
                    }
                });
            }
        }
    }

    private class C1009e implements C0817b, C0818c {
        final /* synthetic */ C1010o f1991a;

        private C1009e(C1010o c1010o) {
            this.f1991a = c1010o;
        }

        public void mo1018a(int i) {
        }

        public void mo1019a(Bundle bundle) {
            this.f1991a.f2002k.mo1117a(new C1008d(this.f1991a));
        }

        public void mo1003a(ConnectionResult connectionResult) {
            this.f1991a.f1993b.lock();
            try {
                if (this.f1991a.m4134b(connectionResult)) {
                    this.f1991a.m4148h();
                    this.f1991a.m4141e();
                } else {
                    this.f1991a.m4138c(connectionResult);
                }
                this.f1991a.f1993b.unlock();
            } catch (Throwable th) {
                this.f1991a.f1993b.unlock();
            }
        }
    }

    public C1010o(C1017s c1017s, C0900l c0900l, Map<C0834a<?>, Integer> map, C0849j c0849j, C0826b<? extends ar, as> c0826b, Lock lock, Context context) {
        this.f1992a = c1017s;
        this.f2009r = c0900l;
        this.f2010s = map;
        this.f1995d = c0849j;
        this.f2011t = c0826b;
        this.f1993b = lock;
        this.f1994c = context;
    }

    private void m4126a(SignInResponse signInResponse) {
        if (m4133b(0)) {
            ConnectionResult a = signInResponse.m4597a();
            if (a.m3252b()) {
                ResolveAccountResponse b = signInResponse.m4598b();
                ConnectionResult b2 = b.m3437b();
                if (b2.m3252b()) {
                    this.f2005n = true;
                    this.f2006o = b.m3436a();
                    this.f2007p = b.m3438c();
                    this.f2008q = b.m3439d();
                    m4141e();
                    return;
                }
                String valueOf = String.valueOf(b2);
                Log.wtf("GoogleApiClientConnecting", new StringBuilder(String.valueOf(valueOf).length() + 48).append("Sign-in succeeded with resolve account failure: ").append(valueOf).toString(), new Exception());
                m4138c(b2);
            } else if (m4134b(a)) {
                m4148h();
                m4141e();
            } else {
                m4138c(a);
            }
        }
    }

    private void m4127a(boolean z) {
        if (this.f2002k != null) {
            if (this.f2002k.m3329b() && z) {
                this.f2002k.mo914k();
            }
            this.f2002k.mo1105a();
            this.f2006o = null;
        }
    }

    private boolean m4128a(int i, int i2, ConnectionResult connectionResult) {
        return (i2 != 1 || m4129a(connectionResult)) ? this.f1996e == null || i < this.f1997f : false;
    }

    private boolean m4129a(ConnectionResult connectionResult) {
        return connectionResult.m3251a() || this.f1995d.mo904b(connectionResult.m3253c()) != null;
    }

    private void m4132b(ConnectionResult connectionResult, C0834a<?> c0834a, int i) {
        if (i != 2) {
            int a = c0834a.m3342a().m3322a();
            if (m4128a(a, i, connectionResult)) {
                this.f1996e = connectionResult;
                this.f1997f = a;
            }
        }
        this.f1992a.f2043b.put(c0834a.m3345d(), connectionResult);
    }

    private boolean m4133b(int i) {
        if (this.f1998g == i) {
            return true;
        }
        Log.i("GoogleApiClientConnecting", this.f1992a.f2048g.m4197h());
        String valueOf = String.valueOf(m4136c(this.f1998g));
        String valueOf2 = String.valueOf(m4136c(i));
        Log.wtf("GoogleApiClientConnecting", new StringBuilder((String.valueOf(valueOf).length() + 70) + String.valueOf(valueOf2).length()).append("GoogleApiClient connecting is in step ").append(valueOf).append(" but received callback for step ").append(valueOf2).toString(), new Exception());
        m4138c(new ConnectionResult(8, null));
        return false;
    }

    private boolean m4134b(ConnectionResult connectionResult) {
        return this.f2003l != 2 ? this.f2003l == 1 && !connectionResult.m3251a() : true;
    }

    private String m4136c(int i) {
        switch (i) {
            case 0:
                return "STEP_SERVICE_BINDINGS_AND_SIGN_IN";
            case 1:
                return "STEP_GETTING_REMOTE_SERVICE";
            default:
                return "UNKNOWN";
        }
    }

    private void m4138c(ConnectionResult connectionResult) {
        m4149i();
        m4127a(!connectionResult.m3251a());
        this.f1992a.m4205a(connectionResult);
        this.f1992a.f2049h.mo1022a(connectionResult);
    }

    private boolean m4140d() {
        this.f1999h--;
        if (this.f1999h > 0) {
            return false;
        }
        if (this.f1999h < 0) {
            Log.i("GoogleApiClientConnecting", this.f1992a.f2048g.m4197h());
            Log.wtf("GoogleApiClientConnecting", "GoogleApiClient received too many callbacks for the given step. Clients may be in an unexpected state; GoogleApiClient will now disconnect.", new Exception());
            m4138c(new ConnectionResult(8, null));
            return false;
        } else if (this.f1996e == null) {
            return true;
        } else {
            this.f1992a.f2047f = this.f1997f;
            m4138c(this.f1996e);
            return false;
        }
    }

    private void m4141e() {
        if (this.f1999h == 0) {
            if (!this.f2004m || this.f2005n) {
                m4144f();
            }
        }
    }

    private void m4144f() {
        ArrayList arrayList = new ArrayList();
        this.f1998g = 1;
        this.f1999h = this.f1992a.f2042a.size();
        for (C0828d c0828d : this.f1992a.f2042a.keySet()) {
            if (!this.f1992a.f2043b.containsKey(c0828d)) {
                arrayList.add((C0829f) this.f1992a.f2042a.get(c0828d));
            } else if (m4140d()) {
                m4146g();
            }
        }
        if (!arrayList.isEmpty()) {
            this.f2012u.add(C1018t.m4216a().submit(new C1003c(this, arrayList)));
        }
    }

    private void m4146g() {
        this.f1992a.m4214f();
        C1018t.m4216a().execute(new C09971(this));
        if (this.f2002k != null) {
            if (this.f2007p) {
                this.f2002k.mo1116a(this.f2006o, this.f2008q);
            }
            m4127a(false);
        }
        for (C0828d c0828d : this.f1992a.f2043b.keySet()) {
            ((C0829f) this.f1992a.f2042a.get(c0828d)).mo1105a();
        }
        this.f1992a.f2049h.mo1021a(this.f2000i.isEmpty() ? null : this.f2000i);
    }

    private void m4148h() {
        this.f2004m = false;
        this.f1992a.f2048g.f2020d = Collections.emptySet();
        for (C0828d c0828d : this.f2001j) {
            if (!this.f1992a.f2043b.containsKey(c0828d)) {
                this.f1992a.f2043b.put(c0828d, new ConnectionResult(17, null));
            }
        }
    }

    private void m4149i() {
        Iterator it = this.f2012u.iterator();
        while (it.hasNext()) {
            ((Future) it.next()).cancel(true);
        }
        this.f2012u.clear();
    }

    private Set<Scope> m4151j() {
        if (this.f2009r == null) {
            return Collections.emptySet();
        }
        Set<Scope> hashSet = new HashSet(this.f2009r.m3588c());
        Map e = this.f2009r.m3590e();
        for (C0834a c0834a : e.keySet()) {
            if (!this.f1992a.f2043b.containsKey(c0834a.m3345d())) {
                hashSet.addAll(((C0899a) e.get(c0834a)).f1728a);
            }
        }
        return hashSet;
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1030a(T t) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }

    public void mo1031a() {
        this.f1992a.f2043b.clear();
        this.f2004m = false;
        this.f1996e = null;
        this.f1998g = 0;
        this.f2003l = 2;
        this.f2005n = false;
        this.f2007p = false;
        Map hashMap = new HashMap();
        int i = 0;
        for (C0834a c0834a : this.f2010s.keySet()) {
            C0829f c0829f = (C0829f) this.f1992a.f2042a.get(c0834a.m3345d());
            int intValue = ((Integer) this.f2010s.get(c0834a)).intValue();
            int i2 = (c0834a.m3342a().m3322a() == 1 ? 1 : 0) | i;
            if (c0829f.mo1118d()) {
                this.f2004m = true;
                if (intValue < this.f2003l) {
                    this.f2003l = intValue;
                }
                if (intValue != 0) {
                    this.f2001j.add(c0834a.m3345d());
                }
            }
            hashMap.put(c0829f, new C0998a(this, c0834a, intValue));
            i = i2;
        }
        if (i != 0) {
            this.f2004m = false;
        }
        if (this.f2004m) {
            this.f2009r.m3586a(Integer.valueOf(this.f1992a.f2048g.m4198i()));
            C0817b c1009e = new C1009e();
            this.f2002k = (ar) this.f2011t.mo994a(this.f1994c, this.f1992a.f2048g.mo1045a(), this.f2009r, this.f2009r.m3593h(), c1009e, c1009e);
        }
        this.f1999h = this.f1992a.f2042a.size();
        this.f2012u.add(C1018t.m4216a().submit(new C1002b(this, hashMap)));
    }

    public void mo1032a(int i) {
        m4138c(new ConnectionResult(8, null));
    }

    public void mo1033a(Bundle bundle) {
        if (m4133b(1)) {
            if (bundle != null) {
                this.f2000i.putAll(bundle);
            }
            if (m4140d()) {
                m4146g();
            }
        }
    }

    public void mo1034a(ConnectionResult connectionResult, C0834a<?> c0834a, int i) {
        if (m4133b(1)) {
            m4132b(connectionResult, c0834a, i);
            if (m4140d()) {
                m4146g();
            }
        }
    }

    public boolean mo1035b() {
        m4149i();
        m4127a(true);
        this.f1992a.m4205a(null);
        return true;
    }

    public void mo1036c() {
    }
}
