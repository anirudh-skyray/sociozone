package com.google.android.gms.p023d;

import android.app.PendingIntent;
import android.content.Context;
import android.os.Bundle;
import android.os.Looper;
import android.support.v4.p011e.C0232a;
import android.util.Log;
import com.google.android.gms.common.C0849j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.p023d.C0976h.C0975a;
import com.google.android.gms.p023d.C0989x.C0986a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.WeakHashMap;
import java.util.concurrent.locks.Lock;

final class C0990l implements C0989x {
    private final Context f1955a;
    private final C1015q f1956b;
    private final Looper f1957c;
    private final C1017s f1958d;
    private final C1017s f1959e;
    private final Map<C0828d<?>, C1017s> f1960f;
    private final Set<ah> f1961g = Collections.newSetFromMap(new WeakHashMap());
    private final C0829f f1962h;
    private Bundle f1963i;
    private ConnectionResult f1964j = null;
    private ConnectionResult f1965k = null;
    private boolean f1966l = false;
    private final Lock f1967m;
    private int f1968n = 0;

    class C09851 implements Runnable {
        final /* synthetic */ C0990l f1952a;

        public void run() {
            this.f1952a.f1967m.lock();
            try {
                this.f1952a.m4063g();
            } finally {
                this.f1952a.f1967m.unlock();
            }
        }
    }

    private class C0987a implements C0986a {
        final /* synthetic */ C0990l f1953a;

        private C0987a(C0990l c0990l) {
            this.f1953a = c0990l;
        }

        public void mo1020a(int i, boolean z) {
            this.f1953a.f1967m.lock();
            try {
                if (this.f1953a.f1966l || this.f1953a.f1965k == null || !this.f1953a.f1965k.m3252b()) {
                    this.f1953a.f1966l = false;
                    this.f1953a.m4048a(i, z);
                    return;
                }
                this.f1953a.f1966l = true;
                this.f1953a.f1959e.m4203a(i);
                this.f1953a.f1967m.unlock();
            } finally {
                this.f1953a.f1967m.unlock();
            }
        }

        public void mo1021a(Bundle bundle) {
            this.f1953a.f1967m.lock();
            try {
                this.f1953a.m4049a(bundle);
                this.f1953a.f1964j = ConnectionResult.f1539a;
                this.f1953a.m4063g();
            } finally {
                this.f1953a.f1967m.unlock();
            }
        }

        public void mo1022a(ConnectionResult connectionResult) {
            this.f1953a.f1967m.lock();
            try {
                this.f1953a.f1964j = connectionResult;
                this.f1953a.m4063g();
            } finally {
                this.f1953a.f1967m.unlock();
            }
        }
    }

    private class C0988b implements C0986a {
        final /* synthetic */ C0990l f1954a;

        private C0988b(C0990l c0990l) {
            this.f1954a = c0990l;
        }

        public void mo1020a(int i, boolean z) {
            this.f1954a.f1967m.lock();
            try {
                if (this.f1954a.f1966l) {
                    this.f1954a.f1966l = false;
                    this.f1954a.m4048a(i, z);
                    return;
                }
                this.f1954a.f1966l = true;
                this.f1954a.f1958d.m4203a(i);
                this.f1954a.f1967m.unlock();
            } finally {
                this.f1954a.f1967m.unlock();
            }
        }

        public void mo1021a(Bundle bundle) {
            this.f1954a.f1967m.lock();
            try {
                this.f1954a.f1965k = ConnectionResult.f1539a;
                this.f1954a.m4063g();
            } finally {
                this.f1954a.f1967m.unlock();
            }
        }

        public void mo1022a(ConnectionResult connectionResult) {
            this.f1954a.f1967m.lock();
            try {
                this.f1954a.f1965k = connectionResult;
                this.f1954a.m4063g();
            } finally {
                this.f1954a.f1967m.unlock();
            }
        }
    }

    private C0990l(Context context, C1015q c1015q, Lock lock, Looper looper, C0849j c0849j, Map<C0828d<?>, C0829f> map, Map<C0828d<?>, C0829f> map2, C0900l c0900l, C0826b<? extends ar, as> c0826b, C0829f c0829f, ArrayList<C0984k> arrayList, ArrayList<C0984k> arrayList2, Map<C0834a<?>, Integer> map3, Map<C0834a<?>, Integer> map4) {
        this.f1955a = context;
        this.f1956b = c1015q;
        this.f1967m = lock;
        this.f1957c = looper;
        this.f1962h = c0829f;
        this.f1958d = new C1017s(context, this.f1956b, lock, looper, c0849j, map2, null, map4, null, arrayList2, new C0987a());
        this.f1959e = new C1017s(context, this.f1956b, lock, looper, c0849j, map, c0900l, map3, c0826b, arrayList, new C0988b());
        Map c0232a = new C0232a();
        for (C0828d put : map2.keySet()) {
            c0232a.put(put, this.f1958d);
        }
        for (C0828d put2 : map.keySet()) {
            c0232a.put(put2, this.f1959e);
        }
        this.f1960f = Collections.unmodifiableMap(c0232a);
    }

    public static C0990l m4046a(Context context, C1015q c1015q, Lock lock, Looper looper, C0849j c0849j, Map<C0828d<?>, C0829f> map, C0900l c0900l, Map<C0834a<?>, Integer> map2, C0826b<? extends ar, as> c0826b, ArrayList<C0984k> arrayList) {
        C0829f c0829f = null;
        Map c0232a = new C0232a();
        Map c0232a2 = new C0232a();
        for (Entry entry : map.entrySet()) {
            C0829f c0829f2 = (C0829f) entry.getValue();
            if (c0829f2.m3333f()) {
                c0829f = c0829f2;
            }
            if (c0829f2.mo1118d()) {
                c0232a.put((C0828d) entry.getKey(), c0829f2);
            } else {
                c0232a2.put((C0828d) entry.getKey(), c0829f2);
            }
        }
        C0864b.m3459a(!c0232a.isEmpty(), (Object) "CompositeGoogleApiClient should not be used without any APIs that require sign-in.");
        Map c0232a3 = new C0232a();
        Map c0232a4 = new C0232a();
        for (C0834a c0834a : map2.keySet()) {
            C0828d d = c0834a.m3345d();
            if (c0232a.containsKey(d)) {
                c0232a3.put(c0834a, (Integer) map2.get(c0834a));
            } else if (c0232a2.containsKey(d)) {
                c0232a4.put(c0834a, (Integer) map2.get(c0834a));
            } else {
                throw new IllegalStateException("Each API in the apiTypeMap must have a corresponding client in the clients map.");
            }
        }
        ArrayList arrayList2 = new ArrayList();
        ArrayList arrayList3 = new ArrayList();
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            C0984k c0984k = (C0984k) it.next();
            if (c0232a3.containsKey(c0984k.f1949a)) {
                arrayList2.add(c0984k);
            } else if (c0232a4.containsKey(c0984k.f1949a)) {
                arrayList3.add(c0984k);
            } else {
                throw new IllegalStateException("Each ClientCallbacks must have a corresponding API in the apiTypeMap");
            }
        }
        return new C0990l(context, c1015q, lock, looper, c0849j, c0232a, c0232a2, c0900l, c0826b, c0829f, arrayList2, arrayList3, c0232a3, c0232a4);
    }

    private void m4048a(int i, boolean z) {
        this.f1956b.mo1020a(i, z);
        this.f1965k = null;
        this.f1964j = null;
    }

    private void m4049a(Bundle bundle) {
        if (this.f1963i == null) {
            this.f1963i = bundle;
        } else if (bundle != null) {
            this.f1963i.putAll(bundle);
        }
    }

    private void m4050a(ConnectionResult connectionResult) {
        switch (this.f1968n) {
            case 1:
                break;
            case 2:
                this.f1956b.mo1022a(connectionResult);
                break;
            default:
                Log.wtf("CompositeGAC", "Attempted to call failure callbacks in CONNECTION_MODE_NONE. Callbacks should be disabled via GmsClientSupervisor", new Exception());
                break;
        }
        m4065i();
        this.f1968n = 0;
    }

    private static boolean m4056b(ConnectionResult connectionResult) {
        return connectionResult != null && connectionResult.m3252b();
    }

    private boolean m4057b(C0975a<? extends C0819e, ? extends C0827c> c0975a) {
        C0828d b = c0975a.mo1013b();
        C0864b.m3463b(this.f1960f.containsKey(b), "GoogleApiClient is not configured to use the API required for this call.");
        return ((C1017s) this.f1960f.get(b)).equals(this.f1959e);
    }

    private void m4062f() {
        this.f1965k = null;
        this.f1964j = null;
        this.f1958d.mo1024a();
        this.f1959e.mo1024a();
    }

    private void m4063g() {
        if (C0990l.m4056b(this.f1964j)) {
            if (C0990l.m4056b(this.f1965k) || m4066j()) {
                m4064h();
            } else if (this.f1965k == null) {
            } else {
                if (this.f1968n == 1) {
                    m4065i();
                    return;
                }
                m4050a(this.f1965k);
                this.f1958d.mo1026b();
            }
        } else if (this.f1964j != null && C0990l.m4056b(this.f1965k)) {
            this.f1959e.mo1026b();
            m4050a(this.f1964j);
        } else if (this.f1964j != null && this.f1965k != null) {
            ConnectionResult connectionResult = this.f1964j;
            if (this.f1959e.f2047f < this.f1958d.f2047f) {
                connectionResult = this.f1965k;
            }
            m4050a(connectionResult);
        }
    }

    private void m4064h() {
        switch (this.f1968n) {
            case 1:
                break;
            case 2:
                this.f1956b.mo1021a(this.f1963i);
                break;
            default:
                Log.wtf("CompositeGAC", "Attempted to call success callbacks in CONNECTION_MODE_NONE. Callbacks should be disabled via GmsClientSupervisor", new AssertionError());
                break;
        }
        m4065i();
        this.f1968n = 0;
    }

    private void m4065i() {
        for (ah a : this.f1961g) {
            a.m3864a();
        }
        this.f1961g.clear();
    }

    private boolean m4066j() {
        return this.f1965k != null && this.f1965k.m3253c() == 4;
    }

    private PendingIntent m4067k() {
        return this.f1962h == null ? null : PendingIntent.getActivity(this.f1955a, this.f1956b.m4198i(), this.f1962h.m3334g(), 134217728);
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1023a(T t) {
        if (!m4057b((C0975a) t)) {
            return this.f1958d.mo1023a((C0975a) t);
        }
        if (!m4066j()) {
            return this.f1959e.mo1023a((C0975a) t);
        }
        t.m4009a(new Status(4, null, m4067k()));
        return t;
    }

    public void mo1024a() {
        this.f1968n = 2;
        this.f1966l = false;
        m4062f();
    }

    public void mo1025a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        printWriter.append(str).append("authClient").println(":");
        this.f1959e.mo1025a(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
        printWriter.append(str).append("anonClient").println(":");
        this.f1958d.mo1025a(String.valueOf(str).concat("  "), fileDescriptor, printWriter, strArr);
    }

    public void mo1026b() {
        this.f1965k = null;
        this.f1964j = null;
        this.f1968n = 0;
        this.f1958d.mo1026b();
        this.f1959e.mo1026b();
        m4065i();
    }

    public boolean mo1027c() {
        boolean z = true;
        this.f1967m.lock();
        try {
            if (!(this.f1958d.mo1027c() && (m4074e() || m4066j() || this.f1968n == 1))) {
                z = false;
            }
            this.f1967m.unlock();
            return z;
        } catch (Throwable th) {
            this.f1967m.unlock();
        }
    }

    public void mo1028d() {
        this.f1958d.mo1028d();
        this.f1959e.mo1028d();
    }

    public boolean m4074e() {
        return this.f1959e.mo1027c();
    }
}
