package com.google.android.gms.p023d;

import com.google.android.gms.common.internal.C0864b;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

public class am implements ThreadFactory {
    private final String f1882a;
    private final int f1883b;
    private final AtomicInteger f1884c;
    private final ThreadFactory f1885d;

    public am(String str) {
        this(str, 0);
    }

    public am(String str, int i) {
        this.f1884c = new AtomicInteger();
        this.f1885d = Executors.defaultThreadFactory();
        this.f1882a = (String) C0864b.m3455a((Object) str, (Object) "Name must not be null");
        this.f1883b = i;
    }

    public Thread newThread(Runnable runnable) {
        Thread newThread = this.f1885d.newThread(new an(runnable, this.f1883b));
        String str = this.f1882a;
        newThread.setName(new StringBuilder(String.valueOf(str).length() + 13).append(str).append("[").append(this.f1884c.getAndIncrement()).append("]").toString());
        return newThread;
    }
}
