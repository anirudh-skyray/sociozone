package com.google.android.gms.p023d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.C0164q;
import android.support.v4.app.Fragment;
import android.support.v4.p011e.C0232a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Map;
import java.util.Map.Entry;
import java.util.WeakHashMap;

public final class ai extends Fragment implements aa {
    private static WeakHashMap<C0164q, WeakReference<ai>> f1851a = new WeakHashMap();
    private Map<String, C0969z> f1852b = new C0232a();
    private int f1853c = 0;
    private Bundle f1854d;

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public static com.google.android.gms.p023d.ai m3866a(android.support.v4.app.C0164q r3) {
        /*
        r0 = f1851a;
        r0 = r0.get(r3);
        r0 = (java.lang.ref.WeakReference) r0;
        if (r0 == 0) goto L_0x0013;
    L_0x000a:
        r0 = r0.get();
        r0 = (com.google.android.gms.p023d.ai) r0;
        if (r0 == 0) goto L_0x0013;
    L_0x0012:
        return r0;
    L_0x0013:
        r0 = r3.getSupportFragmentManager();	 Catch:{ ClassCastException -> 0x0048 }
        r1 = "SupportLifecycleFragmentImpl";
        r0 = r0.mo136a(r1);	 Catch:{ ClassCastException -> 0x0048 }
        r0 = (com.google.android.gms.p023d.ai) r0;	 Catch:{ ClassCastException -> 0x0048 }
        if (r0 == 0) goto L_0x0027;
    L_0x0021:
        r1 = r0.isRemoving();
        if (r1 == 0) goto L_0x003d;
    L_0x0027:
        r0 = new com.google.android.gms.d.ai;
        r0.<init>();
        r1 = r3.getSupportFragmentManager();
        r1 = r1.mo137a();
        r2 = "SupportLifecycleFragmentImpl";
        r1 = r1.mo104a(r0, r2);
        r1.mo106c();
    L_0x003d:
        r1 = f1851a;
        r2 = new java.lang.ref.WeakReference;
        r2.<init>(r0);
        r1.put(r3, r2);
        goto L_0x0012;
    L_0x0048:
        r0 = move-exception;
        r1 = new java.lang.IllegalStateException;
        r2 = "Fragment with tag SupportLifecycleFragmentImpl is not a SupportLifecycleFragmentImpl";
        r1.<init>(r2, r0);
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.ai.a(android.support.v4.app.q):com.google.android.gms.d.ai");
    }

    private void m3868b(final String str, final C0969z c0969z) {
        if (this.f1853c > 0) {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                final /* synthetic */ ai f1850c;

                public void run() {
                    if (this.f1850c.f1853c >= 1) {
                        c0969z.mo1006a(this.f1850c.f1854d != null ? this.f1850c.f1854d.getBundle(str) : null);
                    }
                    if (this.f1850c.f1853c >= 2) {
                        c0969z.mo1004a();
                    }
                    if (this.f1850c.f1853c >= 3) {
                        c0969z.mo1007b();
                    }
                }
            });
        }
    }

    public /* synthetic */ Activity mo985a() {
        return m3872b();
    }

    public <T extends C0969z> T mo986a(String str, Class<T> cls) {
        return (C0969z) cls.cast(this.f1852b.get(str));
    }

    public void mo987a(String str, C0969z c0969z) {
        if (this.f1852b.containsKey(str)) {
            throw new IllegalArgumentException(new StringBuilder(String.valueOf(str).length() + 59).append("LifecycleCallback with tag ").append(str).append(" already added to this fragment.").toString());
        }
        this.f1852b.put(str, c0969z);
        m3868b(str, c0969z);
    }

    public C0164q m3872b() {
        return getActivity();
    }

    public void dump(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        super.dump(str, fileDescriptor, printWriter, strArr);
        for (C0969z a : this.f1852b.values()) {
            a.mo1010a(str, fileDescriptor, printWriter, strArr);
        }
    }

    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        for (C0969z a : this.f1852b.values()) {
            a.mo1005a(i, i2, intent);
        }
    }

    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.f1853c = 1;
        this.f1854d = bundle;
        for (Entry entry : this.f1852b.entrySet()) {
            ((C0969z) entry.getValue()).mo1006a(bundle != null ? bundle.getBundle((String) entry.getKey()) : null);
        }
    }

    public void onSaveInstanceState(Bundle bundle) {
        super.onSaveInstanceState(bundle);
        if (bundle != null) {
            for (Entry entry : this.f1852b.entrySet()) {
                Bundle bundle2 = new Bundle();
                ((C0969z) entry.getValue()).mo1008b(bundle2);
                bundle.putBundle((String) entry.getKey(), bundle2);
            }
        }
    }

    public void onStart() {
        super.onStop();
        this.f1853c = 2;
        for (C0969z a : this.f1852b.values()) {
            a.mo1004a();
        }
    }

    public void onStop() {
        super.onStop();
        this.f1853c = 3;
        for (C0969z b : this.f1852b.values()) {
            b.mo1007b();
        }
    }
}
