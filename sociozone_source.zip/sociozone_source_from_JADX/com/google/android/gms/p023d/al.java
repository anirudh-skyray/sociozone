package com.google.android.gms.p023d;

public abstract class al<T> {
    private static final Object f1875c = new Object();
    private static C0955a f1876d = null;
    private static int f1877e = 0;
    private static String f1878f = "com.google.android.providers.gsf.permission.READ_GSERVICES";
    protected final String f1879a;
    protected final T f1880b;
    private T f1881g = null;

    class C09521 extends al<Long> {
        C09521(String str, Long l) {
            super(str, l);
        }

        protected /* synthetic */ Object mo993a(String str) {
            return m3906b(str);
        }

        protected Long m3906b(String str) {
            return null.m3912a(this.a, (Long) this.b);
        }
    }

    class C09532 extends al<Integer> {
        C09532(String str, Integer num) {
            super(str, num);
        }

        protected /* synthetic */ Object mo993a(String str) {
            return m3908b(str);
        }

        protected Integer m3908b(String str) {
            return null.m3911a(this.a, (Integer) this.b);
        }
    }

    class C09543 extends al<String> {
        C09543(String str, String str2) {
            super(str, str2);
        }

        protected /* synthetic */ Object mo993a(String str) {
            return m3910b(str);
        }

        protected String m3910b(String str) {
            return null.m3913a(this.a, (String) this.b);
        }
    }

    private interface C0955a {
        Integer m3911a(String str, Integer num);

        Long m3912a(String str, Long l);

        String m3913a(String str, String str2);
    }

    protected al(String str, T t) {
        this.f1879a = str;
        this.f1880b = t;
    }

    public static al<Integer> m3899a(String str, Integer num) {
        return new C09532(str, num);
    }

    public static al<Long> m3900a(String str, Long l) {
        return new C09521(str, l);
    }

    public static al<String> m3901a(String str, String str2) {
        return new C09543(str, str2);
    }

    public final T m3903a() {
        return mo993a(this.f1879a);
    }

    protected abstract T mo993a(String str);
}
