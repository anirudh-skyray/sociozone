package com.google.android.gms.p023d;

import android.os.IBinder;
import android.os.IBinder.DeathRecipient;
import android.os.RemoteException;
import android.support.v4.p011e.C0232a;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.C0846m;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.p023d.C0976h.C0975a;
import java.io.PrintWriter;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.Map;
import java.util.Set;
import java.util.WeakHashMap;

public class ak {
    private static final C0975a<?, ?>[] f1871b = new C0975a[0];
    final Set<C0975a<?, ?>> f1872a;
    private final C0949b f1873c;
    private final Map<C0828d<?>, C0829f> f1874d;

    interface C0949b {
        void mo992a(C0975a<?, ?> c0975a);
    }

    class C09501 implements C0949b {
        final /* synthetic */ ak f1867a;

        C09501(ak akVar) {
            this.f1867a = akVar;
        }

        public void mo992a(C0975a<?, ?> c0975a) {
            this.f1867a.f1872a.remove(c0975a);
            if (c0975a.mo988a() != null && null != null) {
                null.m3364a(c0975a.mo988a().intValue());
            }
        }
    }

    private static class C0951a implements DeathRecipient, C0949b {
        private final WeakReference<C0975a<?, ?>> f1868a;
        private final WeakReference<C0846m> f1869b;
        private final WeakReference<IBinder> f1870c;

        private C0951a(C0975a<?, ?> c0975a, C0846m c0846m, IBinder iBinder) {
            this.f1869b = new WeakReference(c0846m);
            this.f1868a = new WeakReference(c0975a);
            this.f1870c = new WeakReference(iBinder);
        }

        private void m3890a() {
            C0975a c0975a = (C0975a) this.f1868a.get();
            C0846m c0846m = (C0846m) this.f1869b.get();
            if (!(c0846m == null || c0975a == null)) {
                c0846m.m3364a(c0975a.mo988a().intValue());
            }
            IBinder iBinder = (IBinder) this.f1870c.get();
            if (this.f1870c != null) {
                iBinder.unlinkToDeath(this, 0);
            }
        }

        public void mo992a(C0975a<?, ?> c0975a) {
            m3890a();
        }

        public void binderDied() {
            m3890a();
        }
    }

    public ak(C0828d<?> c0828d, C0829f c0829f) {
        this.f1872a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));
        this.f1873c = new C09501(this);
        this.f1874d = new C0232a();
        this.f1874d.put(c0828d, c0829f);
    }

    public ak(Map<C0828d<?>, C0829f> map) {
        this.f1872a = Collections.synchronizedSet(Collections.newSetFromMap(new WeakHashMap()));
        this.f1873c = new C09501(this);
        this.f1874d = map;
    }

    private static void m3893a(C0975a<?, ?> c0975a, C0846m c0846m, IBinder iBinder) {
        if (c0975a.m3996f()) {
            c0975a.m4012a(new C0951a(c0975a, c0846m, iBinder));
        } else if (iBinder == null || !iBinder.isBinderAlive()) {
            c0975a.m4012a(null);
            c0975a.m3997g();
            c0846m.m3364a(c0975a.mo988a().intValue());
        } else {
            C0949b c0951a = new C0951a(c0975a, c0846m, iBinder);
            c0975a.m4012a(c0951a);
            try {
                iBinder.linkToDeath(c0951a, 0);
            } catch (RemoteException e) {
                c0975a.m3997g();
                c0846m.m3364a(c0975a.mo988a().intValue());
            }
        }
    }

    public void m3894a() {
        for (C0975a c0975a : (C0975a[]) this.f1872a.toArray(f1871b)) {
            c0975a.m4012a(null);
            if (c0975a.mo988a() != null) {
                c0975a.m4017d();
                ak.m3893a(c0975a, null, ((C0829f) this.f1874d.get(c0975a.mo1013b())).m3335h());
                this.f1872a.remove(c0975a);
            } else if (c0975a.m3998h()) {
                this.f1872a.remove(c0975a);
            }
        }
    }

    <A extends C0827c> void m3895a(C0975a<? extends C0819e, A> c0975a) {
        this.f1872a.add(c0975a);
        c0975a.m4012a(this.f1873c);
    }

    public void m3896a(PrintWriter printWriter) {
        printWriter.append(" mUnconsumedApiCalls.size()=").println(this.f1872a.size());
    }

    public void m3897b() {
        for (C0975a c : (C0975a[]) this.f1872a.toArray(f1871b)) {
            c.m3994c(new Status(8, "The connection to Google Play services was lost"));
        }
    }

    public boolean m3898c() {
        for (C0975a f : (C0975a[]) this.f1872a.toArray(f1871b)) {
            if (!f.m3996f()) {
                return true;
            }
        }
        return false;
    }
}
