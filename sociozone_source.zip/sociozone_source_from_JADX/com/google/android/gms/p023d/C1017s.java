package com.google.android.gms.p023d;

import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;
import com.google.android.gms.common.C0849j;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.p023d.C0976h.C0975a;
import com.google.android.gms.p023d.C0989x.C0986a;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.locks.Condition;
import java.util.concurrent.locks.Lock;

public class C1017s implements C0989x {
    final Map<C0828d<?>, C0829f> f2042a;
    final Map<C0828d<?>, ConnectionResult> f2043b = new HashMap();
    final C0900l f2044c;
    final Map<C0834a<?>, Integer> f2045d;
    final C0826b<? extends ar, as> f2046e;
    int f2047f;
    final C1015q f2048g;
    final C0986a f2049h;
    private final Lock f2050i;
    private final Condition f2051j;
    private final Context f2052k;
    private final C0849j f2053l;
    private final C1016b f2054m;
    private volatile C0995r f2055n;
    private ConnectionResult f2056o = null;

    static abstract class C0992a {
        private final C0995r f1969a;

        protected C0992a(C0995r c0995r) {
            this.f1969a = c0995r;
        }

        protected abstract void mo1029a();

        public final void m4079a(C1017s c1017s) {
            c1017s.f2050i.lock();
            try {
                if (c1017s.f2055n == this.f1969a) {
                    mo1029a();
                    c1017s.f2050i.unlock();
                }
            } finally {
                c1017s.f2050i.unlock();
            }
        }
    }

    final class C1016b extends Handler {
        final /* synthetic */ C1017s f2041a;

        C1016b(C1017s c1017s, Looper looper) {
            this.f2041a = c1017s;
            super(looper);
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    ((C0992a) message.obj).m4079a(this.f2041a);
                    return;
                case 2:
                    throw ((RuntimeException) message.obj);
                default:
                    Log.w("GACStateManager", "Unknown message id: " + message.what);
                    return;
            }
        }
    }

    public C1017s(Context context, C1015q c1015q, Lock lock, Looper looper, C0849j c0849j, Map<C0828d<?>, C0829f> map, C0900l c0900l, Map<C0834a<?>, Integer> map2, C0826b<? extends ar, as> c0826b, ArrayList<C0984k> arrayList, C0986a c0986a) {
        this.f2052k = context;
        this.f2050i = lock;
        this.f2053l = c0849j;
        this.f2042a = map;
        this.f2044c = c0900l;
        this.f2045d = map2;
        this.f2046e = c0826b;
        this.f2048g = c1015q;
        this.f2049h = c0986a;
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            ((C0984k) it.next()).m4029a(this);
        }
        this.f2054m = new C1016b(this, looper);
        this.f2051j = lock.newCondition();
        this.f2055n = new C1011p(this);
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1023a(T t) {
        t.m4000j();
        return this.f2055n.mo1030a((C0975a) t);
    }

    public void mo1024a() {
        this.f2055n.mo1036c();
    }

    public void m4203a(int i) {
        this.f2050i.lock();
        try {
            this.f2055n.mo1032a(i);
        } finally {
            this.f2050i.unlock();
        }
    }

    public void m4204a(Bundle bundle) {
        this.f2050i.lock();
        try {
            this.f2055n.mo1033a(bundle);
        } finally {
            this.f2050i.unlock();
        }
    }

    void m4205a(ConnectionResult connectionResult) {
        this.f2050i.lock();
        try {
            this.f2056o = connectionResult;
            this.f2055n = new C1011p(this);
            this.f2055n.mo1031a();
            this.f2051j.signalAll();
        } finally {
            this.f2050i.unlock();
        }
    }

    public void m4206a(ConnectionResult connectionResult, C0834a<?> c0834a, int i) {
        this.f2050i.lock();
        try {
            this.f2055n.mo1034a(connectionResult, c0834a, i);
        } finally {
            this.f2050i.unlock();
        }
    }

    void m4207a(C0992a c0992a) {
        this.f2054m.sendMessage(this.f2054m.obtainMessage(1, c0992a));
    }

    void m4208a(RuntimeException runtimeException) {
        this.f2054m.sendMessage(this.f2054m.obtainMessage(2, runtimeException));
    }

    public void mo1025a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr) {
        String concat = String.valueOf(str).concat("  ");
        for (C0834a c0834a : this.f2045d.keySet()) {
            printWriter.append(str).append(c0834a.m3347f()).println(":");
            ((C0829f) this.f2042a.get(c0834a.m3345d())).m3328a(concat, fileDescriptor, printWriter, strArr);
        }
    }

    public void mo1026b() {
        if (this.f2055n.mo1035b()) {
            this.f2043b.clear();
        }
    }

    public boolean mo1027c() {
        return this.f2055n instanceof C0996n;
    }

    public void mo1028d() {
        if (mo1027c()) {
            ((C0996n) this.f2055n).m4098d();
        }
    }

    void m4213e() {
        this.f2050i.lock();
        try {
            this.f2055n = new C1010o(this, this.f2044c, this.f2045d, this.f2053l, this.f2046e, this.f2050i, this.f2052k);
            this.f2055n.mo1031a();
            this.f2051j.signalAll();
        } finally {
            this.f2050i.unlock();
        }
    }

    void m4214f() {
        this.f2050i.lock();
        try {
            this.f2048g.m4195f();
            this.f2055n = new C0996n(this);
            this.f2055n.mo1031a();
            this.f2051j.signalAll();
        } finally {
            this.f2050i.unlock();
        }
    }

    void m4215g() {
        for (C0829f a : this.f2042a.values()) {
            a.mo1105a();
        }
    }
}
