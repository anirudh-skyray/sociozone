package com.google.android.gms.p023d;

public final class ad<L> {
    private volatile L f1844a;

    public void m3858a() {
        this.f1844a = null;
    }
}
