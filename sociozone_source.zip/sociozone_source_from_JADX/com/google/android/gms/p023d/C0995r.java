package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.p023d.C0976h.C0975a;

public interface C0995r {
    <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1030a(T t);

    void mo1031a();

    void mo1032a(int i);

    void mo1033a(Bundle bundle);

    void mo1034a(ConnectionResult connectionResult, C0834a<?> c0834a, int i);

    boolean mo1035b();

    void mo1036c();
}
