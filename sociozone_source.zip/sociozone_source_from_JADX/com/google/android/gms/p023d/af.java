package com.google.android.gms.p023d;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

public abstract class af {
    private static final ExecutorService f1846a = new ThreadPoolExecutor(0, 4, 60, TimeUnit.SECONDS, new LinkedBlockingQueue(), new am("GAC_Transform"));

    public static ExecutorService m3860a() {
        return f1846a;
    }
}
