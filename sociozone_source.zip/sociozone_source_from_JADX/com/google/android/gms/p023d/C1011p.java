package com.google.android.gms.p023d;

import android.os.Bundle;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.p023d.C0976h.C0975a;
import java.util.Collections;

public class C1011p implements C0995r {
    private final C1017s f2013a;

    public C1011p(C1017s c1017s) {
        this.f2013a = c1017s;
    }

    public <A extends C0827c, T extends C0975a<? extends C0819e, A>> T mo1030a(T t) {
        throw new IllegalStateException("GoogleApiClient is not connected yet.");
    }

    public void mo1031a() {
        this.f2013a.m4215g();
        this.f2013a.f2048g.f2020d = Collections.emptySet();
    }

    public void mo1032a(int i) {
    }

    public void mo1033a(Bundle bundle) {
    }

    public void mo1034a(ConnectionResult connectionResult, C0834a<?> c0834a, int i) {
    }

    public boolean mo1035b() {
        return true;
    }

    public void mo1036c() {
        this.f2013a.m4213e();
    }
}
