package com.google.android.gms.p023d;

import android.app.Dialog;
import android.app.PendingIntent;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import com.google.android.gms.common.C0850b;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiActivity;
import com.google.android.gms.p023d.C1024v.C0978a;

public abstract class C0970i extends C0969z implements OnCancelListener {
    protected boolean f1918a;
    protected boolean f1919b;
    protected final C0850b f1920c;
    private ConnectionResult f1921e;
    private int f1922f;
    private final Handler f1923g;

    private class C0980a implements Runnable {
        final /* synthetic */ C0970i f1947a;

        private C0980a(C0970i c0970i) {
            this.f1947a = c0970i;
        }

        public void run() {
            if (!this.f1947a.f1918a) {
                return;
            }
            if (this.f1947a.f1921e.m3251a()) {
                this.f1947a.d.startActivityForResult(GoogleApiActivity.m3287b(this.f1947a.m3966e(), this.f1947a.f1921e.m3254d(), this.f1947a.f1922f, false), 1);
            } else if (this.f1947a.f1920c.mo902a(this.f1947a.f1921e.m3253c())) {
                this.f1947a.f1920c.m3393a(this.f1947a.m3966e(), this.f1947a.d, this.f1947a.f1921e.m3253c(), 2, this.f1947a);
            } else if (this.f1947a.f1921e.m3253c() == 18) {
                final Dialog a = this.f1947a.f1920c.m3384a(this.f1947a.m3966e(), this.f1947a);
                this.f1947a.f1920c.m3389a(this.f1947a.m3966e().getApplicationContext(), new C0978a(this) {
                    final /* synthetic */ C0980a f1946b;

                    public void mo1017a() {
                        this.f1946b.f1947a.m3977d();
                        if (a.isShowing()) {
                            a.dismiss();
                        }
                    }
                });
            } else {
                this.f1947a.mo1009a(this.f1947a.f1921e, this.f1947a.f1922f);
            }
        }
    }

    protected C0970i(aa aaVar) {
        this(aaVar, C0850b.m3382a());
    }

    C0970i(aa aaVar, C0850b c0850b) {
        super(aaVar);
        this.f1922f = -1;
        this.f1923g = new Handler(Looper.getMainLooper());
        this.f1920c = c0850b;
    }

    public void mo1004a() {
        super.mo1004a();
        this.f1918a = true;
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public void mo1005a(int r6, int r7, android.content.Intent r8) {
        /*
        r5 = this;
        r4 = 18;
        r2 = 13;
        r0 = 1;
        r1 = 0;
        switch(r6) {
            case 1: goto L_0x0027;
            case 2: goto L_0x0010;
            default: goto L_0x0009;
        };
    L_0x0009:
        r0 = r1;
    L_0x000a:
        if (r0 == 0) goto L_0x003d;
    L_0x000c:
        r5.m3977d();
    L_0x000f:
        return;
    L_0x0010:
        r2 = r5.f1920c;
        r3 = r5.m3966e();
        r2 = r2.mo898a(r3);
        if (r2 != 0) goto L_0x0047;
    L_0x001c:
        r1 = r5.f1921e;
        r1 = r1.m3253c();
        if (r1 != r4) goto L_0x000a;
    L_0x0024:
        if (r2 != r4) goto L_0x000a;
    L_0x0026:
        goto L_0x000f;
    L_0x0027:
        r3 = -1;
        if (r7 == r3) goto L_0x000a;
    L_0x002a:
        if (r7 != 0) goto L_0x0009;
    L_0x002c:
        if (r8 == 0) goto L_0x0045;
    L_0x002e:
        r0 = "<<ResolutionFailureErrorDetail>>";
        r0 = r8.getIntExtra(r0, r2);
    L_0x0034:
        r2 = new com.google.android.gms.common.ConnectionResult;
        r3 = 0;
        r2.<init>(r0, r3);
        r5.f1921e = r2;
        goto L_0x0009;
    L_0x003d:
        r0 = r5.f1921e;
        r1 = r5.f1922f;
        r5.mo1009a(r0, r1);
        goto L_0x000f;
    L_0x0045:
        r0 = r2;
        goto L_0x0034;
    L_0x0047:
        r0 = r1;
        goto L_0x001c;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.google.android.gms.d.i.a(int, int, android.content.Intent):void");
    }

    public void mo1006a(Bundle bundle) {
        super.mo1006a(bundle);
        if (bundle != null) {
            this.f1919b = bundle.getBoolean("resolving_error", false);
            if (this.f1919b) {
                this.f1922f = bundle.getInt("failed_client_id", -1);
                this.f1921e = new ConnectionResult(bundle.getInt("failed_status"), (PendingIntent) bundle.getParcelable("failed_resolution"));
            }
        }
    }

    protected abstract void mo1009a(ConnectionResult connectionResult, int i);

    public void mo1007b() {
        super.mo1007b();
        this.f1918a = false;
    }

    public void mo1008b(Bundle bundle) {
        super.mo1008b(bundle);
        bundle.putBoolean("resolving_error", this.f1919b);
        if (this.f1919b) {
            bundle.putInt("failed_client_id", this.f1922f);
            bundle.putInt("failed_status", this.f1921e.m3253c());
            bundle.putParcelable("failed_resolution", this.f1921e.m3254d());
        }
    }

    public void m3975b(ConnectionResult connectionResult, int i) {
        if (!this.f1919b) {
            this.f1919b = true;
            this.f1922f = i;
            this.f1921e = connectionResult;
            this.f1923g.post(new C0980a());
        }
    }

    protected abstract void mo1011c();

    protected void m3977d() {
        this.f1922f = -1;
        this.f1919b = false;
        this.f1921e = null;
        mo1011c();
    }

    public void onCancel(DialogInterface dialogInterface) {
        mo1009a(new ConnectionResult(13, null), this.f1922f);
        m3977d();
    }
}
