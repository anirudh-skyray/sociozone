package com.google.android.gms.p023d;

import android.os.DeadObjectException;
import android.os.RemoteException;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0834a.C0828d;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.p023d.ak.C0949b;
import java.util.concurrent.atomic.AtomicReference;

public class C0976h {

    public interface C0974b<R> {
        void mo1015a(R r);
    }

    public static abstract class C0975a<R extends C0819e, A extends C0827c> extends C0972j<R> implements C0974b<R> {
        private final C0828d<A> f1942d;
        private final C0834a<?> f1943e;
        private AtomicReference<C0949b> f1944f = new AtomicReference();

        @Deprecated
        protected C0975a(C0828d<A> c0828d, GoogleApiClient googleApiClient) {
            super((GoogleApiClient) C0864b.m3455a((Object) googleApiClient, (Object) "GoogleApiClient must not be null"));
            this.f1942d = (C0828d) C0864b.m3454a((Object) c0828d);
            this.f1943e = null;
        }

        private void m4008a(RemoteException remoteException) {
            m4009a(new Status(8, remoteException.getLocalizedMessage(), null));
        }

        public final void m4009a(Status status) {
            C0864b.m3463b(!status.m3320e(), "Failed result must not be success");
            C0819e b = mo1012b(status);
            m3993b(b);
            mo1014a(b);
        }

        public final void m4010a(A a) throws DeadObjectException {
            try {
                mo1062b(a);
            } catch (RemoteException e) {
                m4008a(e);
                throw e;
            } catch (RemoteException e2) {
                m4008a(e2);
            }
        }

        protected void mo1014a(R r) {
        }

        public void m4012a(C0949b c0949b) {
            this.f1944f.set(c0949b);
        }

        public /* synthetic */ void mo1015a(Object obj) {
            super.m3993b((C0819e) obj);
        }

        public final C0828d<A> mo1013b() {
            return this.f1942d;
        }

        protected abstract void mo1062b(A a) throws RemoteException;

        public final C0834a<?> m4016c() {
            return this.f1943e;
        }

        public void m4017d() {
            mo989a(null);
        }

        protected void mo1016e() {
            C0949b c0949b = (C0949b) this.f1944f.getAndSet(null);
            if (c0949b != null) {
                c0949b.mo992a(this);
            }
        }
    }
}
