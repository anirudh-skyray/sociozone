package com.google.android.gms.p023d;

import android.os.DeadObjectException;
import android.util.SparseArray;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.p023d.C0976h.C0975a;

public abstract class C0965d {
    public final int f1908a;
    public final int f1909b;

    public static final class C0966a extends C0965d {
        public final C0975a<? extends C0819e, C0827c> f1910c;

        public void mo999a(SparseArray<ak> sparseArray) {
            ak akVar = (ak) sparseArray.get(this.a);
            if (akVar != null) {
                akVar.m3895a(this.f1910c);
            }
        }

        public void mo1000a(Status status) {
            this.f1910c.m4009a(status);
        }

        public void mo1001a(C0827c c0827c) throws DeadObjectException {
            this.f1910c.m4010a(c0827c);
        }

        public boolean mo1002a() {
            return this.f1910c.m3998h();
        }
    }

    public void mo999a(SparseArray<ak> sparseArray) {
    }

    public abstract void mo1000a(Status status);

    public abstract void mo1001a(C0827c c0827c) throws DeadObjectException;

    public boolean mo1002a() {
        return true;
    }
}
