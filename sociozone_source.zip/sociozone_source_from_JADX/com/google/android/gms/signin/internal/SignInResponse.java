package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInResponse extends AbstractSafeParcelable {
    public static final Creator<SignInResponse> CREATOR = new C1105i();
    final int f2266a;
    private final ConnectionResult f2267b;
    private final ResolveAccountResponse f2268c;

    public SignInResponse(int i) {
        this(new ConnectionResult(i, null), null);
    }

    SignInResponse(int i, ConnectionResult connectionResult, ResolveAccountResponse resolveAccountResponse) {
        this.f2266a = i;
        this.f2267b = connectionResult;
        this.f2268c = resolveAccountResponse;
    }

    public SignInResponse(ConnectionResult connectionResult, ResolveAccountResponse resolveAccountResponse) {
        this(1, connectionResult, resolveAccountResponse);
    }

    public ConnectionResult m4597a() {
        return this.f2267b;
    }

    public ResolveAccountResponse m4598b() {
        return this.f2268c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1105i.m4649a(this, parcel, i);
    }
}
