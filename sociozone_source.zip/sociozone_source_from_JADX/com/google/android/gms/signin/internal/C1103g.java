package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.content.Context;
import android.os.Bundle;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.p019a.C0797a;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0859u;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0867i.C0884i;
import com.google.android.gms.common.internal.C0869p;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.p023d.ar;
import com.google.android.gms.p023d.as;
import com.google.android.gms.signin.internal.C1099e.C1101a;

public class C1103g extends C0869p<C1099e> implements ar {
    private final boolean f2271d;
    private final C0900l f2272e;
    private final Bundle f2273f;
    private Integer f2274g;

    public C1103g(Context context, Looper looper, boolean z, C0900l c0900l, Bundle bundle, C0817b c0817b, C0818c c0818c) {
        super(context, looper, 44, c0900l, c0817b, c0818c);
        this.f2271d = z;
        this.f2272e = c0900l;
        this.f2273f = bundle;
        this.f2274g = c0900l.m3594i();
    }

    public C1103g(Context context, Looper looper, boolean z, C0900l c0900l, as asVar, C0817b c0817b, C0818c c0818c) {
        this(context, looper, z, c0900l, C1103g.m4634a(c0900l), c0817b, c0818c);
    }

    public static Bundle m4634a(C0900l c0900l) {
        as h = c0900l.m3593h();
        Integer i = c0900l.m3594i();
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.google.android.gms.signin.internal.clientRequestedAccount", c0900l.m3585a());
        if (i != null) {
            bundle.putInt("com.google.android.gms.common.internal.ClientSettings.sessionId", i.intValue());
        }
        if (h != null) {
            bundle.putBoolean("com.google.android.gms.signin.internal.offlineAccessRequested", h.m3929a());
            bundle.putBoolean("com.google.android.gms.signin.internal.idTokenRequested", h.m3930b());
            bundle.putString("com.google.android.gms.signin.internal.serverClientId", h.m3931c());
            bundle.putBoolean("com.google.android.gms.signin.internal.usePromptModeForAuthCode", true);
            bundle.putBoolean("com.google.android.gms.signin.internal.forceCodeForRefreshToken", h.m3932d());
            bundle.putString("com.google.android.gms.signin.internal.hostedDomain", h.m3933e());
            bundle.putBoolean("com.google.android.gms.signin.internal.waitForAccessTokenRefresh", h.m3934f());
        }
        return bundle;
    }

    private ResolveAccountRequest m4635w() {
        Account b = this.f2272e.m3587b();
        GoogleSignInAccount googleSignInAccount = null;
        if ("<<default account>>".equals(b.name)) {
            googleSignInAccount = C0797a.m3227a(m3504n()).m3229a();
        }
        return new ResolveAccountRequest(b, this.f2274g.intValue(), googleSignInAccount);
    }

    protected /* synthetic */ IInterface mo910a(IBinder iBinder) {
        return m4639b(iBinder);
    }

    public void mo1116a(C0859u c0859u, boolean z) {
        try {
            ((C1099e) m3510t()).mo1110a(c0859u, this.f2274g.intValue(), z);
        } catch (RemoteException e) {
            Log.w("SignInClientImpl", "Remote service probably died when saveDefaultAccount is called");
        }
    }

    public void mo1117a(C1005d c1005d) {
        C0864b.m3455a((Object) c1005d, (Object) "Expecting a valid ISignInCallbacks");
        try {
            ((C1099e) m3510t()).mo1113a(new SignInRequest(m4635w()), c1005d);
        } catch (Throwable e) {
            Log.w("SignInClientImpl", "Remote service probably died when signIn is called");
            try {
                c1005d.mo1041a(new SignInResponse(8));
            } catch (RemoteException e2) {
                Log.wtf("SignInClientImpl", "ISignInCallbacks#onSignInComplete should be executed from the same process, unexpected RemoteException.", e);
            }
        }
    }

    protected C1099e m4639b(IBinder iBinder) {
        return C1101a.m4630a(iBinder);
    }

    public boolean mo1118d() {
        return this.f2271d;
    }

    protected String mo912i() {
        return "com.google.android.gms.signin.service.START";
    }

    protected String mo913j() {
        return "com.google.android.gms.signin.internal.ISignInService";
    }

    public void mo914k() {
        try {
            ((C1099e) m3510t()).mo1106a(this.f2274g.intValue());
        } catch (RemoteException e) {
            Log.w("SignInClientImpl", "Remote service probably died when clearAccountFromSessionStore is called");
        }
    }

    public void mo1119l() {
        m3490a(new C0884i(this));
    }

    protected Bundle mo1061q() {
        if (!m3504n().getPackageName().equals(this.f2272e.m3591f())) {
            this.f2273f.putString("com.google.android.gms.signin.internal.realClientPackageName", this.f2272e.m3591f());
        }
        return this.f2273f;
    }
}
