package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class SignInRequest extends AbstractSafeParcelable {
    public static final Creator<SignInRequest> CREATOR = new C1104h();
    final int f2264a;
    final ResolveAccountRequest f2265b;

    SignInRequest(int i, ResolveAccountRequest resolveAccountRequest) {
        this.f2264a = i;
        this.f2265b = resolveAccountRequest;
    }

    public SignInRequest(ResolveAccountRequest resolveAccountRequest) {
        this(1, resolveAccountRequest);
    }

    public ResolveAccountRequest m4596a() {
        return this.f2265b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1104h.m4646a(this, parcel, i);
    }
}
