package com.google.android.gms.signin.internal;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class AuthAccountResult extends AbstractSafeParcelable implements C0819e {
    public static final Creator<AuthAccountResult> CREATOR = new C1096a();
    final int f2254a;
    private int f2255b;
    private Intent f2256c;

    public AuthAccountResult() {
        this(0, null);
    }

    AuthAccountResult(int i, int i2, Intent intent) {
        this.f2254a = i;
        this.f2255b = i2;
        this.f2256c = intent;
    }

    public AuthAccountResult(int i, Intent intent) {
        this(2, i, intent);
    }

    public Status mo897a() {
        return this.f2255b == 0 ? Status.f1576a : Status.f1580e;
    }

    public int m4591b() {
        return this.f2255b;
    }

    public Intent m4592c() {
        return this.f2256c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1096a.m4599a(this, parcel, i);
    }
}
