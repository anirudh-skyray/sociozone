package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.List;

public class CheckServerAuthResult extends AbstractSafeParcelable {
    public static final Creator<CheckServerAuthResult> CREATOR = new C1097c();
    final int f2257a;
    final boolean f2258b;
    final List<Scope> f2259c;

    CheckServerAuthResult(int i, boolean z, List<Scope> list) {
        this.f2257a = i;
        this.f2258b = z;
        this.f2259c = list;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1097c.m4602a(this, parcel, i);
    }
}
