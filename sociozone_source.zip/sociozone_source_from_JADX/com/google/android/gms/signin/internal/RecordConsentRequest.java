package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class RecordConsentRequest extends AbstractSafeParcelable {
    public static final Creator<RecordConsentRequest> CREATOR = new C1102f();
    final int f2260a;
    private final Account f2261b;
    private final Scope[] f2262c;
    private final String f2263d;

    RecordConsentRequest(int i, Account account, Scope[] scopeArr, String str) {
        this.f2260a = i;
        this.f2261b = account;
        this.f2262c = scopeArr;
        this.f2263d = str;
    }

    public Account m4593a() {
        return this.f2261b;
    }

    public Scope[] m4594b() {
        return this.f2262c;
    }

    public String m4595c() {
        return this.f2263d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1102f.m4631a(this, parcel, i);
    }
}
