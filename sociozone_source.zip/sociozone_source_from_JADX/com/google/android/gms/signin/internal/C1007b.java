package com.google.android.gms.signin.internal;

import android.os.RemoteException;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.signin.internal.C1005d.C1006a;

public class C1007b extends C1006a {
    public void mo1038a(ConnectionResult connectionResult, AuthAccountResult authAccountResult) throws RemoteException {
    }

    public void mo1039a(Status status) throws RemoteException {
    }

    public void mo1040a(Status status, GoogleSignInAccount googleSignInAccount) throws RemoteException {
    }

    public void mo1041a(SignInResponse signInResponse) throws RemoteException {
    }

    public void mo1042b(Status status) throws RemoteException {
    }
}
