package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.ResolveAccountRequest;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1104h implements Creator<SignInRequest> {
    static void m4646a(SignInRequest signInRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, signInRequest.f2264a);
        C0917b.m3677a(parcel, 2, signInRequest.m4596a(), i, false);
        C0917b.m3670a(parcel, a);
    }

    public SignInRequest m4647a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        ResolveAccountRequest resolveAccountRequest = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    resolveAccountRequest = (ResolveAccountRequest) C0916a.m3650a(parcel, a, ResolveAccountRequest.CREATOR);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new SignInRequest(i, resolveAccountRequest);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public SignInRequest[] m4648a(int i) {
        return new SignInRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4647a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4648a(i);
    }
}
