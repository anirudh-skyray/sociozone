package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.internal.ResolveAccountResponse;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1105i implements Creator<SignInResponse> {
    static void m4649a(SignInResponse signInResponse, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, signInResponse.f2266a);
        C0917b.m3677a(parcel, 2, signInResponse.m4597a(), i, false);
        C0917b.m3677a(parcel, 3, signInResponse.m4598b(), i, false);
        C0917b.m3670a(parcel, a);
    }

    public SignInResponse m4650a(Parcel parcel) {
        ResolveAccountResponse resolveAccountResponse = null;
        int b = C0916a.m3653b(parcel);
        int i = 0;
        ConnectionResult connectionResult = null;
        while (parcel.dataPosition() < b) {
            ConnectionResult connectionResult2;
            int e;
            ResolveAccountResponse resolveAccountResponse2;
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    ResolveAccountResponse resolveAccountResponse3 = resolveAccountResponse;
                    connectionResult2 = connectionResult;
                    e = C0916a.m3659e(parcel, a);
                    resolveAccountResponse2 = resolveAccountResponse3;
                    break;
                case 2:
                    e = i;
                    ConnectionResult connectionResult3 = (ConnectionResult) C0916a.m3650a(parcel, a, ConnectionResult.CREATOR);
                    resolveAccountResponse2 = resolveAccountResponse;
                    connectionResult2 = connectionResult3;
                    break;
                case 3:
                    resolveAccountResponse2 = (ResolveAccountResponse) C0916a.m3650a(parcel, a, ResolveAccountResponse.CREATOR);
                    connectionResult2 = connectionResult;
                    e = i;
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    resolveAccountResponse2 = resolveAccountResponse;
                    connectionResult2 = connectionResult;
                    e = i;
                    break;
            }
            i = e;
            connectionResult = connectionResult2;
            resolveAccountResponse = resolveAccountResponse2;
        }
        if (parcel.dataPosition() == b) {
            return new SignInResponse(i, connectionResult, resolveAccountResponse);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public SignInResponse[] m4651a(int i) {
        return new SignInResponse[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4650a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4651a(i);
    }
}
