package com.google.android.gms.signin.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;
import java.util.List;

public class C1097c implements Creator<CheckServerAuthResult> {
    static void m4602a(CheckServerAuthResult checkServerAuthResult, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, checkServerAuthResult.f2257a);
        C0917b.m3682a(parcel, 2, checkServerAuthResult.f2258b);
        C0917b.m3688b(parcel, 3, checkServerAuthResult.f2259c, false);
        C0917b.m3670a(parcel, a);
    }

    public CheckServerAuthResult m4603a(Parcel parcel) {
        boolean z = false;
        int b = C0916a.m3653b(parcel);
        List list = null;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    z = C0916a.m3657c(parcel, a);
                    break;
                case 3:
                    list = C0916a.m3656c(parcel, a, Scope.CREATOR);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new CheckServerAuthResult(i, z, list);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public CheckServerAuthResult[] m4604a(int i) {
        return new CheckServerAuthResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4603a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4604a(i);
    }
}
