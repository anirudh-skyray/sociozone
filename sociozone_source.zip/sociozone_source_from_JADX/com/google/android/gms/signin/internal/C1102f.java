package com.google.android.gms.signin.internal;

import android.accounts.Account;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1102f implements Creator<RecordConsentRequest> {
    static void m4631a(RecordConsentRequest recordConsentRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, recordConsentRequest.f2260a);
        C0917b.m3677a(parcel, 2, recordConsentRequest.m4593a(), i, false);
        C0917b.m3684a(parcel, 3, recordConsentRequest.m4594b(), i, false);
        C0917b.m3679a(parcel, 4, recordConsentRequest.m4595c(), false);
        C0917b.m3670a(parcel, a);
    }

    public RecordConsentRequest m4632a(Parcel parcel) {
        String str = null;
        int b = C0916a.m3653b(parcel);
        int i = 0;
        Scope[] scopeArr = null;
        Account account = null;
        while (parcel.dataPosition() < b) {
            Scope[] scopeArr2;
            Account account2;
            int e;
            String str2;
            int a = C0916a.m3648a(parcel);
            String str3;
            switch (C0916a.m3647a(a)) {
                case 1:
                    str3 = str;
                    scopeArr2 = scopeArr;
                    account2 = account;
                    e = C0916a.m3659e(parcel, a);
                    str2 = str3;
                    break;
                case 2:
                    e = i;
                    Scope[] scopeArr3 = scopeArr;
                    account2 = (Account) C0916a.m3650a(parcel, a, Account.CREATOR);
                    str2 = str;
                    scopeArr2 = scopeArr3;
                    break;
                case 3:
                    account2 = account;
                    e = i;
                    str3 = str;
                    scopeArr2 = (Scope[]) C0916a.m3655b(parcel, a, Scope.CREATOR);
                    str2 = str3;
                    break;
                case 4:
                    str2 = C0916a.m3664j(parcel, a);
                    scopeArr2 = scopeArr;
                    account2 = account;
                    e = i;
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    str2 = str;
                    scopeArr2 = scopeArr;
                    account2 = account;
                    e = i;
                    break;
            }
            i = e;
            account = account2;
            scopeArr = scopeArr2;
            str = str2;
        }
        if (parcel.dataPosition() == b) {
            return new RecordConsentRequest(i, account, scopeArr, str);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public RecordConsentRequest[] m4633a(int i) {
        return new RecordConsentRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4632a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4633a(i);
    }
}
