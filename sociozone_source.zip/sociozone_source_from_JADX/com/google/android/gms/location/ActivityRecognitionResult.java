package com.google.android.gms.location;

import android.os.Bundle;
import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.List;

public class ActivityRecognitionResult extends AbstractSafeParcelable {
    public static final C1040a CREATOR = new C1040a();
    List<DetectedActivity> f2141a;
    long f2142b;
    long f2143c;
    int f2144d;
    Bundle f2145e;
    private final int f2146f;

    public ActivityRecognitionResult(int i, List<DetectedActivity> list, long j, long j2, int i2, Bundle bundle) {
        this.f2146f = i;
        this.f2141a = list;
        this.f2142b = j;
        this.f2143c = j2;
        this.f2144d = i2;
        this.f2145e = bundle;
    }

    private static boolean m4348a(Bundle bundle, Bundle bundle2) {
        if (bundle == null && bundle2 == null) {
            return true;
        }
        if ((bundle == null && bundle2 != null) || (bundle != null && bundle2 == null)) {
            return false;
        }
        if (bundle.size() != bundle2.size()) {
            return false;
        }
        for (String str : bundle.keySet()) {
            if (!bundle2.containsKey(str)) {
                return false;
            }
            if (bundle.get(str) == null) {
                if (bundle2.get(str) != null) {
                    return false;
                }
            } else if (bundle.get(str) instanceof Bundle) {
                if (!m4348a(bundle.getBundle(str), bundle2.getBundle(str))) {
                    return false;
                }
            } else if (!bundle.get(str).equals(bundle2.get(str))) {
                return false;
            }
        }
        return true;
    }

    public int m4349a() {
        return this.f2146f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        ActivityRecognitionResult activityRecognitionResult = (ActivityRecognitionResult) obj;
        return this.f2142b == activityRecognitionResult.f2142b && this.f2143c == activityRecognitionResult.f2143c && this.f2144d == activityRecognitionResult.f2144d && ab.m3453a(this.f2141a, activityRecognitionResult.f2141a) && m4348a(this.f2145e, activityRecognitionResult.f2145e);
    }

    public int hashCode() {
        return ab.m3451a(Long.valueOf(this.f2142b), Long.valueOf(this.f2143c), Integer.valueOf(this.f2144d), this.f2141a, this.f2145e);
    }

    public String toString() {
        String valueOf = String.valueOf(this.f2141a);
        long j = this.f2142b;
        return new StringBuilder(String.valueOf(valueOf).length() + 124).append("ActivityRecognitionResult [probableActivities=").append(valueOf).append(", timeMillis=").append(j).append(", elapsedRealtimeMillis=").append(this.f2143c).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1040a.m4385a(this, parcel, i);
    }
}
