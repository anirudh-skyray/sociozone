package com.google.android.gms.location.internal;

import android.content.Context;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0869p;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.location.internal.C1068h.C1070a;

public class C1053a extends C0869p<C1068h> {
    protected final C1051o<C1068h> f2230d = new C10521(this);
    private final String f2231e;

    class C10521 implements C1051o<C1068h> {
        final /* synthetic */ C1053a f2229a;

        C10521(C1053a c1053a) {
            this.f2229a = c1053a;
        }

        public void mo1059a() {
            this.f2229a.m3508r();
        }

        public C1068h m4436b() throws DeadObjectException {
            return (C1068h) this.f2229a.m3510t();
        }

        public /* synthetic */ IInterface mo1060c() throws DeadObjectException {
            return m4436b();
        }
    }

    public C1053a(Context context, Looper looper, C0817b c0817b, C0818c c0818c, String str, C0900l c0900l) {
        super(context, looper, 23, c0900l, c0817b, c0818c);
        this.f2231e = str;
    }

    protected /* synthetic */ IInterface mo910a(IBinder iBinder) {
        return m4440b(iBinder);
    }

    protected C1068h m4440b(IBinder iBinder) {
        return C1070a.m4532a(iBinder);
    }

    protected String mo912i() {
        return "com.google.android.location.internal.GoogleLocationManagerService.START";
    }

    protected String mo913j() {
        return "com.google.android.gms.location.internal.IGoogleLocationManagerService";
    }

    protected Bundle mo1061q() {
        Bundle bundle = new Bundle();
        bundle.putString("client_name", this.f2231e);
        return bundle;
    }
}
