package com.google.android.gms.location.internal;

import android.content.ContentProviderClient;
import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.location.C1045f;
import com.google.android.gms.location.C1074m;
import com.google.android.gms.location.C1074m.C1075a;
import com.google.android.gms.location.C1078n;
import com.google.android.gms.location.C1078n.C1079a;
import com.google.android.gms.location.LocationAvailability;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import java.util.HashMap;
import java.util.Map;

public class C1081j {
    private final C1051o<C1068h> f2245a;
    private final Context f2246b;
    private ContentProviderClient f2247c = null;
    private boolean f2248d = false;
    private Map<C1045f, C1080c> f2249e = new HashMap();
    private Map<Object, C1076a> f2250f = new HashMap();

    private static class C1076a extends C1075a {
        private Handler f2242a;

        private void m4539a(int i, Object obj) {
            if (this.f2242a == null) {
                Log.e("LocationClientHelper", "Received a data in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = i;
            obtain.obj = obj;
            this.f2242a.sendMessage(obtain);
        }

        public void mo1102a(LocationAvailability locationAvailability) {
            m4539a(1, locationAvailability);
        }

        public void mo1103a(LocationResult locationResult) {
            m4539a(0, locationResult);
        }
    }

    private static class C1077b extends Handler {
        private final C1045f f2243a;

        public C1077b(C1045f c1045f) {
            this.f2243a = c1045f;
        }

        public C1077b(C1045f c1045f, Looper looper) {
            super(looper);
            this.f2243a = c1045f;
        }

        public void handleMessage(Message message) {
            switch (message.what) {
                case 1:
                    this.f2243a.mo1136a(new Location((Location) message.obj));
                    return;
                default:
                    Log.e("LocationClientHelper", "unknown message in LocationHandler.handleMessage");
                    return;
            }
        }
    }

    private static class C1080c extends C1079a {
        private Handler f2244a;

        C1080c(C1045f c1045f, Looper looper) {
            if (looper == null) {
                C0864b.m3459a(Looper.myLooper() != null, (Object) "Can't create handler inside thread that has not called Looper.prepare()");
            }
            this.f2244a = looper == null ? new C1077b(c1045f) : new C1077b(c1045f, looper);
        }

        public void m4544a() {
            this.f2244a = null;
        }

        public void mo1104a(Location location) {
            if (this.f2244a == null) {
                Log.e("LocationClientHelper", "Received a location in client after calling removeLocationUpdates.");
                return;
            }
            Message obtain = Message.obtain();
            obtain.what = 1;
            obtain.obj = location;
            this.f2244a.sendMessage(obtain);
        }
    }

    public C1081j(Context context, C1051o<C1068h> c1051o) {
        this.f2246b = context;
        this.f2245a = c1051o;
    }

    private C1080c m4546a(C1045f c1045f, Looper looper) {
        C1080c c1080c;
        synchronized (this.f2249e) {
            c1080c = (C1080c) this.f2249e.get(c1045f);
            if (c1080c == null) {
                c1080c = new C1080c(c1045f, looper);
            }
            this.f2249e.put(c1045f, c1080c);
        }
        return c1080c;
    }

    public Location m4547a() {
        this.f2245a.mo1059a();
        try {
            return ((C1068h) this.f2245a.mo1060c()).mo1094b(this.f2246b.getPackageName());
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void m4548a(LocationRequest locationRequest, C1045f c1045f, Looper looper, C1058f c1058f) throws RemoteException {
        this.f2245a.mo1059a();
        ((C1068h) this.f2245a.mo1060c()).mo1087a(LocationRequestUpdateData.m4411a(LocationRequestInternal.m4408a(locationRequest), m4546a(c1045f, looper), c1058f));
    }

    public void m4549a(C1045f c1045f, C1058f c1058f) throws RemoteException {
        this.f2245a.mo1059a();
        C0864b.m3455a((Object) c1045f, (Object) "Invalid null listener");
        synchronized (this.f2249e) {
            C1078n c1078n = (C1080c) this.f2249e.remove(c1045f);
            if (c1078n != null) {
                c1078n.m4544a();
                ((C1068h) this.f2245a.mo1060c()).mo1087a(LocationRequestUpdateData.m4413a(c1078n, c1058f));
            }
        }
    }

    public void m4550a(boolean z) throws RemoteException {
        this.f2245a.mo1059a();
        ((C1068h) this.f2245a.mo1060c()).mo1092a(z);
        this.f2248d = z;
    }

    public void m4551b() {
        try {
            synchronized (this.f2249e) {
                for (C1078n c1078n : this.f2249e.values()) {
                    if (c1078n != null) {
                        ((C1068h) this.f2245a.mo1060c()).mo1087a(LocationRequestUpdateData.m4413a(c1078n, null));
                    }
                }
                this.f2249e.clear();
            }
            synchronized (this.f2250f) {
                for (C1074m c1074m : this.f2250f.values()) {
                    if (c1074m != null) {
                        ((C1068h) this.f2245a.mo1060c()).mo1087a(LocationRequestUpdateData.m4412a(c1074m, null));
                    }
                }
                this.f2250f.clear();
            }
        } catch (Throwable e) {
            throw new IllegalStateException(e);
        }
    }

    public void m4552c() {
        if (this.f2248d) {
            try {
                m4550a(false);
            } catch (Throwable e) {
                throw new IllegalStateException(e);
            }
        }
    }
}
