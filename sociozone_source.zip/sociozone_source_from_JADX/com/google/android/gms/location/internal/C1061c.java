package com.google.android.gms.location.internal;

import android.location.Location;
import android.os.RemoteException;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a.C0827c;
import com.google.android.gms.common.api.C0837c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.C1042c;
import com.google.android.gms.location.C1045f;
import com.google.android.gms.location.C1049h;
import com.google.android.gms.location.C1049h.C1048a;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.internal.C1058f.C1059a;
import com.google.android.gms.p023d.C0976h.C0974b;

public class C1061c implements C1042c {

    private static abstract class C1055a extends C1048a<Status> {
        public C1055a(GoogleApiClient googleApiClient) {
            super(googleApiClient);
        }

        public /* synthetic */ C0819e mo1012b(Status status) {
            return m4448d(status);
        }

        public Status m4448d(Status status) {
            return status;
        }
    }

    private static class C1060b extends C1059a {
        private final C0974b<Status> f2237a;

        public C1060b(C0974b<Status> c0974b) {
            this.f2237a = c0974b;
        }

        public void mo1063a(FusedLocationProviderResult fusedLocationProviderResult) {
            this.f2237a.mo1015a(fusedLocationProviderResult.mo897a());
        }
    }

    public Location mo1064a(GoogleApiClient googleApiClient) {
        try {
            return C1049h.m4404a(googleApiClient).mo914k();
        } catch (Exception e) {
            return null;
        }
    }

    public C0837c<Status> mo1065a(GoogleApiClient googleApiClient, final LocationRequest locationRequest, final C1045f c1045f) {
        return googleApiClient.mo1047a(new C1055a(this, googleApiClient) {
            final /* synthetic */ C1061c f2234f;

            protected void m4449a(C1082k c1082k) throws RemoteException {
                c1082k.m4554a(locationRequest, c1045f, null, new C1060b(this));
            }

            protected /* synthetic */ void mo1062b(C0827c c0827c) throws RemoteException {
                m4449a((C1082k) c0827c);
            }
        });
    }

    public C0837c<Status> mo1066a(GoogleApiClient googleApiClient, final C1045f c1045f) {
        return googleApiClient.mo1047a(new C1055a(this, googleApiClient) {
            final /* synthetic */ C1061c f2236e;

            protected void m4451a(C1082k c1082k) throws RemoteException {
                c1082k.m4555a(c1045f, new C1060b(this));
            }

            protected /* synthetic */ void mo1062b(C0827c c0827c) throws RemoteException {
                m4451a((C1082k) c0827c);
            }
        });
    }
}
