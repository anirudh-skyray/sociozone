package com.google.android.gms.location.internal;

import android.os.DeadObjectException;
import android.os.IInterface;

public interface C1051o<T extends IInterface> {
    void mo1059a();

    T mo1060c() throws DeadObjectException;
}
