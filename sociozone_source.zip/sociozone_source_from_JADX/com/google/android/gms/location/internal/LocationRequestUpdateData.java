package com.google.android.gms.location.internal;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.location.C1074m;
import com.google.android.gms.location.C1074m.C1075a;
import com.google.android.gms.location.C1078n;
import com.google.android.gms.location.C1078n.C1079a;
import com.google.android.gms.location.internal.C1058f.C1059a;

public class LocationRequestUpdateData extends AbstractSafeParcelable {
    public static final C1084m CREATOR = new C1084m();
    int f2212a;
    LocationRequestInternal f2213b;
    C1078n f2214c;
    PendingIntent f2215d;
    C1074m f2216e;
    C1058f f2217f;
    private final int f2218g;

    LocationRequestUpdateData(int i, int i2, LocationRequestInternal locationRequestInternal, IBinder iBinder, PendingIntent pendingIntent, IBinder iBinder2, IBinder iBinder3) {
        C1058f c1058f = null;
        this.f2218g = i;
        this.f2212a = i2;
        this.f2213b = locationRequestInternal;
        this.f2214c = iBinder == null ? null : C1079a.m4543a(iBinder);
        this.f2215d = pendingIntent;
        this.f2216e = iBinder2 == null ? null : C1075a.m4538a(iBinder2);
        if (iBinder3 != null) {
            c1058f = C1059a.m4454a(iBinder3);
        }
        this.f2217f = c1058f;
    }

    public static LocationRequestUpdateData m4411a(LocationRequestInternal locationRequestInternal, C1078n c1078n, C1058f c1058f) {
        return new LocationRequestUpdateData(1, 1, locationRequestInternal, c1078n.asBinder(), null, null, c1058f != null ? c1058f.asBinder() : null);
    }

    public static LocationRequestUpdateData m4412a(C1074m c1074m, C1058f c1058f) {
        return new LocationRequestUpdateData(1, 2, null, null, null, c1074m.asBinder(), c1058f != null ? c1058f.asBinder() : null);
    }

    public static LocationRequestUpdateData m4413a(C1078n c1078n, C1058f c1058f) {
        return new LocationRequestUpdateData(1, 2, null, c1078n.asBinder(), null, null, c1058f != null ? c1058f.asBinder() : null);
    }

    int m4414a() {
        return this.f2218g;
    }

    IBinder m4415b() {
        return this.f2214c == null ? null : this.f2214c.asBinder();
    }

    IBinder m4416c() {
        return this.f2216e == null ? null : this.f2216e.asBinder();
    }

    IBinder m4417d() {
        return this.f2217f == null ? null : this.f2217f.asBinder();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1084m.m4560a(this, parcel, i);
    }
}
