package com.google.android.gms.location.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ClientIdentity extends AbstractSafeParcelable {
    public static final C1054b CREATOR = new C1054b();
    public final int f2199a;
    public final String f2200b;
    private final int f2201c;

    ClientIdentity(int i, int i2, String str) {
        this.f2201c = i;
        this.f2199a = i2;
        this.f2200b = str;
    }

    int m4405a() {
        return this.f2201c;
    }

    public boolean equals(Object obj) {
        if (obj == this) {
            return true;
        }
        if (obj == null || !(obj instanceof ClientIdentity)) {
            return false;
        }
        ClientIdentity clientIdentity = (ClientIdentity) obj;
        return clientIdentity.f2199a == this.f2199a && ab.m3453a(clientIdentity.f2200b, this.f2200b);
    }

    public int hashCode() {
        return this.f2199a;
    }

    public String toString() {
        return String.format("%d:%s", new Object[]{Integer.valueOf(this.f2199a), this.f2200b});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1054b.m4444a(this, parcel, i);
    }
}
