package com.google.android.gms.location.internal;

import android.annotation.SuppressLint;
import android.os.Parcel;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Locale;

public class ParcelableGeofence extends AbstractSafeParcelable {
    public static final C1085n CREATOR = new C1085n();
    private final int f2219a;
    private final String f2220b;
    private final long f2221c;
    private final short f2222d;
    private final double f2223e;
    private final double f2224f;
    private final float f2225g;
    private final int f2226h;
    private final int f2227i;
    private final int f2228j;

    public ParcelableGeofence(int i, String str, int i2, short s, double d, double d2, float f, long j, int i3, int i4) {
        m4421a(str);
        m4420a(f);
        m4419a(d, d2);
        int a = m4418a(i2);
        this.f2219a = i;
        this.f2222d = s;
        this.f2220b = str;
        this.f2223e = d;
        this.f2224f = d2;
        this.f2225g = f;
        this.f2221c = j;
        this.f2226h = a;
        this.f2227i = i3;
        this.f2228j = i4;
    }

    private static int m4418a(int i) {
        int i2 = i & 7;
        if (i2 != 0) {
            return i2;
        }
        throw new IllegalArgumentException("No supported transition specified: " + i);
    }

    private static void m4419a(double d, double d2) {
        if (d > 90.0d || d < -90.0d) {
            throw new IllegalArgumentException("invalid latitude: " + d);
        } else if (d2 > 180.0d || d2 < -180.0d) {
            throw new IllegalArgumentException("invalid longitude: " + d2);
        }
    }

    private static void m4420a(float f) {
        if (f <= 0.0f) {
            throw new IllegalArgumentException("invalid radius: " + f);
        }
    }

    private static void m4421a(String str) {
        if (str == null || str.length() > 100) {
            String str2 = "requestId is null or too long: ";
            String valueOf = String.valueOf(str);
            throw new IllegalArgumentException(valueOf.length() != 0 ? str2.concat(valueOf) : new String(str2));
        }
    }

    @SuppressLint({"DefaultLocale"})
    private static String m4422b(int i) {
        switch (i) {
            case 1:
                return "CIRCLE";
            default:
                return null;
        }
    }

    public int m4423a() {
        return this.f2219a;
    }

    public short m4424b() {
        return this.f2222d;
    }

    public double m4425c() {
        return this.f2223e;
    }

    public double m4426d() {
        return this.f2224f;
    }

    public float m4427e() {
        return this.f2225g;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof ParcelableGeofence)) {
            return false;
        }
        ParcelableGeofence parcelableGeofence = (ParcelableGeofence) obj;
        return this.f2225g != parcelableGeofence.f2225g ? false : this.f2223e != parcelableGeofence.f2223e ? false : this.f2224f != parcelableGeofence.f2224f ? false : this.f2222d == parcelableGeofence.f2222d;
    }

    public String m4428f() {
        return this.f2220b;
    }

    public long m4429g() {
        return this.f2221c;
    }

    public int m4430h() {
        return this.f2226h;
    }

    public int hashCode() {
        long doubleToLongBits = Double.doubleToLongBits(this.f2223e);
        int i = ((int) (doubleToLongBits ^ (doubleToLongBits >>> 32))) + 31;
        long doubleToLongBits2 = Double.doubleToLongBits(this.f2224f);
        return (((((((i * 31) + ((int) (doubleToLongBits2 ^ (doubleToLongBits2 >>> 32)))) * 31) + Float.floatToIntBits(this.f2225g)) * 31) + this.f2222d) * 31) + this.f2226h;
    }

    public int m4431i() {
        return this.f2227i;
    }

    public int m4432j() {
        return this.f2228j;
    }

    public String toString() {
        return String.format(Locale.US, "Geofence[%s id:%s transitions:%d %.6f, %.6f %.0fm, resp=%ds, dwell=%dms, @%d]", new Object[]{m4422b(this.f2222d), this.f2220b, Integer.valueOf(this.f2226h), Double.valueOf(this.f2223e), Double.valueOf(this.f2224f), Float.valueOf(this.f2225g), Integer.valueOf(this.f2227i / 1000), Integer.valueOf(this.f2228j), Long.valueOf(this.f2221c)});
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1085n c1085n = CREATOR;
        C1085n.m4563a(this, parcel, i);
    }
}
