package com.google.android.gms.location.internal;

import android.content.Context;
import android.location.Location;
import android.os.Looper;
import android.os.RemoteException;
import android.util.Log;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.location.C1045f;
import com.google.android.gms.location.LocationRequest;

public class C1082k extends C1053a {
    private final C1081j f2251e;

    public C1082k(Context context, Looper looper, C0817b c0817b, C0818c c0818c, String str, C0900l c0900l) {
        super(context, looper, c0817b, c0818c, str, c0900l);
        this.f2251e = new C1081j(context, this.d);
    }

    public void mo1105a() {
        synchronized (this.f2251e) {
            if (m3494b()) {
                try {
                    this.f2251e.m4551b();
                    this.f2251e.m4552c();
                } catch (Throwable e) {
                    Log.e("LocationClientImpl", "Client disconnected before listeners could be cleaned up", e);
                }
            }
            super.mo1105a();
        }
    }

    public void m4554a(LocationRequest locationRequest, C1045f c1045f, Looper looper, C1058f c1058f) throws RemoteException {
        synchronized (this.f2251e) {
            this.f2251e.m4548a(locationRequest, c1045f, looper, c1058f);
        }
    }

    public void m4555a(C1045f c1045f, C1058f c1058f) throws RemoteException {
        this.f2251e.m4549a(c1045f, c1058f);
    }

    public Location mo914k() {
        return this.f2251e.m4547a();
    }
}
