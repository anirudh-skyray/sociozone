package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1085n implements Creator<ParcelableGeofence> {
    static void m4563a(ParcelableGeofence parcelableGeofence, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3679a(parcel, 1, parcelableGeofence.m4428f(), false);
        C0917b.m3674a(parcel, 2, parcelableGeofence.m4429g());
        C0917b.m3681a(parcel, 3, parcelableGeofence.m4424b());
        C0917b.m3671a(parcel, 4, parcelableGeofence.m4425c());
        C0917b.m3671a(parcel, 5, parcelableGeofence.m4426d());
        C0917b.m3672a(parcel, 6, parcelableGeofence.m4427e());
        C0917b.m3673a(parcel, 7, parcelableGeofence.m4430h());
        C0917b.m3673a(parcel, 1000, parcelableGeofence.m4423a());
        C0917b.m3673a(parcel, 8, parcelableGeofence.m4431i());
        C0917b.m3673a(parcel, 9, parcelableGeofence.m4432j());
        C0917b.m3670a(parcel, a);
    }

    public ParcelableGeofence m4564a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        String str = null;
        int i2 = 0;
        short s = (short) 0;
        double d = 0.0d;
        double d2 = 0.0d;
        float f = 0.0f;
        long j = 0;
        int i3 = 0;
        int i4 = -1;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 2:
                    j = C0916a.m3661g(parcel, a);
                    break;
                case 3:
                    s = C0916a.m3658d(parcel, a);
                    break;
                case 4:
                    d = C0916a.m3663i(parcel, a);
                    break;
                case 5:
                    d2 = C0916a.m3663i(parcel, a);
                    break;
                case 6:
                    f = C0916a.m3662h(parcel, a);
                    break;
                case 7:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 8:
                    i3 = C0916a.m3659e(parcel, a);
                    break;
                case 9:
                    i4 = C0916a.m3659e(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ParcelableGeofence(i, str, i2, s, d, d2, f, j, i3, i4);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public ParcelableGeofence[] m4565a(int i) {
        return new ParcelableGeofence[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4564a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4565a(i);
    }
}
