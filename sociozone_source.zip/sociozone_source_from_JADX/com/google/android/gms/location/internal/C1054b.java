package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1054b implements Creator<ClientIdentity> {
    static void m4444a(ClientIdentity clientIdentity, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, clientIdentity.f2199a);
        C0917b.m3679a(parcel, 2, clientIdentity.f2200b, false);
        C0917b.m3673a(parcel, 1000, clientIdentity.m4405a());
        C0917b.m3670a(parcel, a);
    }

    public ClientIdentity m4445a(Parcel parcel) {
        int i = 0;
        int b = C0916a.m3653b(parcel);
        String str = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 1000:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ClientIdentity(i2, i, str);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public ClientIdentity[] m4446a(int i) {
        return new ClientIdentity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4445a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4446a(i);
    }
}
