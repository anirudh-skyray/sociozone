package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class FusedLocationProviderResult extends AbstractSafeParcelable implements C0819e {
    public static final Creator<FusedLocationProviderResult> CREATOR = new C1062d();
    public static final FusedLocationProviderResult f2202a = new FusedLocationProviderResult(Status.f1576a);
    private final int f2203b;
    private final Status f2204c;

    FusedLocationProviderResult(int i, Status status) {
        this.f2203b = i;
        this.f2204c = status;
    }

    public FusedLocationProviderResult(Status status) {
        this(1, status);
    }

    public Status mo897a() {
        return this.f2204c;
    }

    public int m4407b() {
        return this.f2203b;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1062d.m4459a(this, parcel, i);
    }
}
