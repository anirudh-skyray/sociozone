package com.google.android.gms.location.internal;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1062d implements Creator<FusedLocationProviderResult> {
    static void m4459a(FusedLocationProviderResult fusedLocationProviderResult, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3677a(parcel, 1, fusedLocationProviderResult.mo897a(), i, false);
        C0917b.m3673a(parcel, 1000, fusedLocationProviderResult.m4407b());
        C0917b.m3670a(parcel, a);
    }

    public FusedLocationProviderResult m4460a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        Status status = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    status = (Status) C0916a.m3650a(parcel, a, Status.CREATOR);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new FusedLocationProviderResult(i, status);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public FusedLocationProviderResult[] m4461a(int i) {
        return new FusedLocationProviderResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4460a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4461a(i);
    }
}
