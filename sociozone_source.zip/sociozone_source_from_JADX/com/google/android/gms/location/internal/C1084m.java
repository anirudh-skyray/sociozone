package com.google.android.gms.location.internal;

import android.app.PendingIntent;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1084m implements Creator<LocationRequestUpdateData> {
    static void m4560a(LocationRequestUpdateData locationRequestUpdateData, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, locationRequestUpdateData.f2212a);
        C0917b.m3677a(parcel, 2, locationRequestUpdateData.f2213b, i, false);
        C0917b.m3676a(parcel, 3, locationRequestUpdateData.m4415b(), false);
        C0917b.m3677a(parcel, 4, locationRequestUpdateData.f2215d, i, false);
        C0917b.m3676a(parcel, 5, locationRequestUpdateData.m4416c(), false);
        C0917b.m3676a(parcel, 6, locationRequestUpdateData.m4417d(), false);
        C0917b.m3673a(parcel, 1000, locationRequestUpdateData.m4414a());
        C0917b.m3670a(parcel, a);
    }

    public LocationRequestUpdateData m4561a(Parcel parcel) {
        IBinder iBinder = null;
        int b = C0916a.m3653b(parcel);
        int i = 0;
        int i2 = 1;
        IBinder iBinder2 = null;
        PendingIntent pendingIntent = null;
        IBinder iBinder3 = null;
        LocationRequestInternal locationRequestInternal = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    locationRequestInternal = (LocationRequestInternal) C0916a.m3650a(parcel, a, LocationRequestInternal.CREATOR);
                    break;
                case 3:
                    iBinder3 = C0916a.m3665k(parcel, a);
                    break;
                case 4:
                    pendingIntent = (PendingIntent) C0916a.m3650a(parcel, a, PendingIntent.CREATOR);
                    break;
                case 5:
                    iBinder2 = C0916a.m3665k(parcel, a);
                    break;
                case 6:
                    iBinder = C0916a.m3665k(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationRequestUpdateData(i, i2, locationRequestInternal, iBinder3, pendingIntent, iBinder2, iBinder);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationRequestUpdateData[] m4562a(int i) {
        return new LocationRequestUpdateData[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4561a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4562a(i);
    }
}
