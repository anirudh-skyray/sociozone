package com.google.android.gms.location.internal;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.location.LocationRequest;
import java.util.Collections;
import java.util.List;

public class LocationRequestInternal extends AbstractSafeParcelable {
    public static final C1083l CREATOR = new C1083l();
    static final List<ClientIdentity> f2205a = Collections.emptyList();
    LocationRequest f2206b;
    boolean f2207c;
    List<ClientIdentity> f2208d;
    String f2209e;
    boolean f2210f;
    private final int f2211g;

    LocationRequestInternal(int i, LocationRequest locationRequest, boolean z, List<ClientIdentity> list, String str, boolean z2) {
        this.f2211g = i;
        this.f2206b = locationRequest;
        this.f2207c = z;
        this.f2208d = list;
        this.f2209e = str;
        this.f2210f = z2;
    }

    @Deprecated
    public static LocationRequestInternal m4408a(LocationRequest locationRequest) {
        return m4409a(null, locationRequest);
    }

    public static LocationRequestInternal m4409a(String str, LocationRequest locationRequest) {
        return new LocationRequestInternal(1, locationRequest, true, f2205a, str, false);
    }

    int m4410a() {
        return this.f2211g;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof LocationRequestInternal)) {
            return false;
        }
        LocationRequestInternal locationRequestInternal = (LocationRequestInternal) obj;
        return ab.m3453a(this.f2206b, locationRequestInternal.f2206b) && this.f2207c == locationRequestInternal.f2207c && this.f2210f == locationRequestInternal.f2210f && ab.m3453a(this.f2208d, locationRequestInternal.f2208d);
    }

    public int hashCode() {
        return this.f2206b.hashCode();
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(this.f2206b.toString());
        if (this.f2209e != null) {
            stringBuilder.append(" tag=").append(this.f2209e);
        }
        stringBuilder.append(" trigger=").append(this.f2207c);
        stringBuilder.append(" hideAppOps=").append(this.f2210f);
        stringBuilder.append(" clients=").append(this.f2208d);
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1083l.m4557a(this, parcel, i);
    }
}
