package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationSettingsResult extends AbstractSafeParcelable implements C0819e {
    public static final Creator<LocationSettingsResult> CREATOR = new C1094q();
    private final int f2183a;
    private final Status f2184b;
    private final LocationSettingsStates f2185c;

    LocationSettingsResult(int i, Status status, LocationSettingsStates locationSettingsStates) {
        this.f2183a = i;
        this.f2184b = status;
        this.f2185c = locationSettingsStates;
    }

    public Status mo897a() {
        return this.f2184b;
    }

    public int m4376b() {
        return this.f2183a;
    }

    public LocationSettingsStates m4377c() {
        return this.f2185c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1094q.m4584a(this, parcel, i);
    }
}
