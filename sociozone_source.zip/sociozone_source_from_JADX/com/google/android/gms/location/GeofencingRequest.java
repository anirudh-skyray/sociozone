package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.location.internal.ParcelableGeofence;
import java.util.List;

public class GeofencingRequest extends AbstractSafeParcelable {
    public static final Creator<GeofencingRequest> CREATOR = new C1088k();
    private final int f2153a;
    private final List<ParcelableGeofence> f2154b;
    private final int f2155c;

    GeofencingRequest(int i, List<ParcelableGeofence> list, int i2) {
        this.f2153a = i;
        this.f2154b = list;
        this.f2155c = i2;
    }

    public int m4356a() {
        return this.f2153a;
    }

    public List<ParcelableGeofence> m4357b() {
        return this.f2154b;
    }

    public int m4358c() {
        return this.f2155c;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1088k.m4569a(this, parcel, i);
    }
}
