package com.google.android.gms.location;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Comparator;

public class DetectedActivity extends AbstractSafeParcelable {
    public static final C1041b CREATOR = new C1041b();
    public static final Comparator<DetectedActivity> f2147a = new C10391();
    public static final int[] f2148b = new int[]{9, 10};
    public static final int[] f2149c = new int[]{0, 1, 2, 4, 5, 6, 7, 8, 10, 11, 12, 13, 14};
    int f2150d;
    int f2151e;
    private final int f2152f;

    class C10391 implements Comparator<DetectedActivity> {
        C10391() {
        }

        public int m4350a(DetectedActivity detectedActivity, DetectedActivity detectedActivity2) {
            int compareTo = Integer.valueOf(detectedActivity2.m4354b()).compareTo(Integer.valueOf(detectedActivity.m4354b()));
            return compareTo == 0 ? Integer.valueOf(detectedActivity.m4353a()).compareTo(Integer.valueOf(detectedActivity2.m4353a())) : compareTo;
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m4350a((DetectedActivity) obj, (DetectedActivity) obj2);
        }
    }

    public DetectedActivity(int i, int i2, int i3) {
        this.f2152f = i;
        this.f2150d = i2;
        this.f2151e = i3;
    }

    public static String m4351a(int i) {
        switch (i) {
            case 0:
                return "IN_VEHICLE";
            case 1:
                return "ON_BICYCLE";
            case 2:
                return "ON_FOOT";
            case 3:
                return "STILL";
            case 4:
                return "UNKNOWN";
            case 5:
                return "TILTING";
            case 7:
                return "WALKING";
            case 8:
                return "RUNNING";
            default:
                return Integer.toString(i);
        }
    }

    private int m4352b(int i) {
        return i > 15 ? 4 : i;
    }

    public int m4353a() {
        return m4352b(this.f2150d);
    }

    public int m4354b() {
        return this.f2151e;
    }

    public int m4355c() {
        return this.f2152f;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        DetectedActivity detectedActivity = (DetectedActivity) obj;
        return this.f2150d == detectedActivity.f2150d && this.f2151e == detectedActivity.f2151e;
    }

    public int hashCode() {
        return ab.m3451a(Integer.valueOf(this.f2150d), Integer.valueOf(this.f2151e));
    }

    public String toString() {
        String valueOf = String.valueOf(m4351a(m4353a()));
        return new StringBuilder(String.valueOf(valueOf).length() + 48).append("DetectedActivity [type=").append(valueOf).append(", confidence=").append(this.f2151e).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1041b.m4388a(this, parcel, i);
    }
}
