package com.google.android.gms.location;

import android.os.Parcel;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationAvailability extends AbstractSafeParcelable {
    public static final C1044e CREATOR = new C1044e();
    int f2162a;
    int f2163b;
    long f2164c;
    int f2165d;
    private final int f2166e;

    LocationAvailability(int i, int i2, int i3, int i4, long j) {
        this.f2166e = i;
        this.f2165d = i2;
        this.f2162a = i3;
        this.f2163b = i4;
        this.f2164c = j;
    }

    public boolean m4361a() {
        return this.f2165d < 1000;
    }

    int m4362b() {
        return this.f2166e;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof LocationAvailability)) {
            return false;
        }
        LocationAvailability locationAvailability = (LocationAvailability) obj;
        return this.f2165d == locationAvailability.f2165d && this.f2162a == locationAvailability.f2162a && this.f2163b == locationAvailability.f2163b && this.f2164c == locationAvailability.f2164c;
    }

    public int hashCode() {
        return ab.m3451a(Integer.valueOf(this.f2165d), Integer.valueOf(this.f2162a), Integer.valueOf(this.f2163b), Long.valueOf(this.f2164c));
    }

    public String toString() {
        return "LocationAvailability[isLocationAvailable: " + m4361a() + "]";
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1044e.m4394a(this, parcel, i);
    }
}
