package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1046g implements Creator<LocationRequest> {
    static void m4398a(LocationRequest locationRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, locationRequest.f2167a);
        C0917b.m3674a(parcel, 2, locationRequest.f2168b);
        C0917b.m3674a(parcel, 3, locationRequest.f2169c);
        C0917b.m3682a(parcel, 4, locationRequest.f2170d);
        C0917b.m3674a(parcel, 5, locationRequest.f2171e);
        C0917b.m3673a(parcel, 6, locationRequest.f2172f);
        C0917b.m3672a(parcel, 7, locationRequest.f2173g);
        C0917b.m3673a(parcel, 1000, locationRequest.m4366a());
        C0917b.m3674a(parcel, 8, locationRequest.f2174h);
        C0917b.m3670a(parcel, a);
    }

    public LocationRequest m4399a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        int i2 = 102;
        long j = 3600000;
        long j2 = 600000;
        boolean z = false;
        long j3 = Long.MAX_VALUE;
        int i3 = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        float f = 0.0f;
        long j4 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    j = C0916a.m3661g(parcel, a);
                    break;
                case 3:
                    j2 = C0916a.m3661g(parcel, a);
                    break;
                case 4:
                    z = C0916a.m3657c(parcel, a);
                    break;
                case 5:
                    j3 = C0916a.m3661g(parcel, a);
                    break;
                case 6:
                    i3 = C0916a.m3659e(parcel, a);
                    break;
                case 7:
                    f = C0916a.m3662h(parcel, a);
                    break;
                case 8:
                    j4 = C0916a.m3661g(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationRequest(i, i2, j, j2, z, j3, i3, f, j4);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationRequest[] m4400a(int i) {
        return new LocationRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4399a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4400a(i);
    }
}
