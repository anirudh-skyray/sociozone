package com.google.android.gms.location;

import android.os.Parcel;
import android.os.SystemClock;
import com.google.android.gms.common.internal.ab;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationRequest extends AbstractSafeParcelable {
    public static final C1046g CREATOR = new C1046g();
    int f2167a;
    long f2168b;
    long f2169c;
    boolean f2170d;
    long f2171e;
    int f2172f;
    float f2173g;
    long f2174h;
    private final int f2175i;

    public LocationRequest() {
        this.f2175i = 1;
        this.f2167a = 102;
        this.f2168b = 3600000;
        this.f2169c = 600000;
        this.f2170d = false;
        this.f2171e = Long.MAX_VALUE;
        this.f2172f = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        this.f2173g = 0.0f;
        this.f2174h = 0;
    }

    LocationRequest(int i, int i2, long j, long j2, boolean z, long j3, int i3, float f, long j4) {
        this.f2175i = i;
        this.f2167a = i2;
        this.f2168b = j;
        this.f2169c = j2;
        this.f2170d = z;
        this.f2171e = j3;
        this.f2172f = i3;
        this.f2173g = f;
        this.f2174h = j4;
    }

    public static String m4363b(int i) {
        switch (i) {
            case 100:
                return "PRIORITY_HIGH_ACCURACY";
            case 102:
                return "PRIORITY_BALANCED_POWER_ACCURACY";
            case 104:
                return "PRIORITY_LOW_POWER";
            case 105:
                return "PRIORITY_NO_POWER";
            default:
                return "???";
        }
    }

    private static void m4364b(long j) {
        if (j < 0) {
            throw new IllegalArgumentException("invalid interval: " + j);
        }
    }

    private static void m4365c(int i) {
        switch (i) {
            case 100:
            case 102:
            case 104:
            case 105:
                return;
            default:
                throw new IllegalArgumentException("invalid quality: " + i);
        }
    }

    int m4366a() {
        return this.f2175i;
    }

    public LocationRequest m4367a(int i) {
        m4365c(i);
        this.f2167a = i;
        return this;
    }

    public LocationRequest m4368a(long j) {
        m4364b(j);
        this.f2174h = j;
        return this;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof LocationRequest)) {
            return false;
        }
        LocationRequest locationRequest = (LocationRequest) obj;
        return this.f2167a == locationRequest.f2167a && this.f2168b == locationRequest.f2168b && this.f2169c == locationRequest.f2169c && this.f2170d == locationRequest.f2170d && this.f2171e == locationRequest.f2171e && this.f2172f == locationRequest.f2172f && this.f2173g == locationRequest.f2173g;
    }

    public int hashCode() {
        return ab.m3451a(Integer.valueOf(this.f2167a), Long.valueOf(this.f2168b), Long.valueOf(this.f2169c), Boolean.valueOf(this.f2170d), Long.valueOf(this.f2171e), Integer.valueOf(this.f2172f), Float.valueOf(this.f2173g));
    }

    public String toString() {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Request[").append(m4363b(this.f2167a));
        if (this.f2167a != 105) {
            stringBuilder.append(" requested=");
            stringBuilder.append(this.f2168b).append("ms");
        }
        stringBuilder.append(" fastest=");
        stringBuilder.append(this.f2169c).append("ms");
        if (this.f2174h > this.f2168b) {
            stringBuilder.append(" maxWait=");
            stringBuilder.append(this.f2174h).append("ms");
        }
        if (this.f2171e != Long.MAX_VALUE) {
            long elapsedRealtime = this.f2171e - SystemClock.elapsedRealtime();
            stringBuilder.append(" expireIn=");
            stringBuilder.append(elapsedRealtime).append("ms");
        }
        if (this.f2172f != ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED) {
            stringBuilder.append(" num=").append(this.f2172f);
        }
        stringBuilder.append(']');
        return stringBuilder.toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1046g.m4398a(this, parcel, i);
    }
}
