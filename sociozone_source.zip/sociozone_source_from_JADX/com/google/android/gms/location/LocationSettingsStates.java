package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public final class LocationSettingsStates extends AbstractSafeParcelable {
    public static final Creator<LocationSettingsStates> CREATOR = new C1095r();
    private final int f2186a;
    private final boolean f2187b;
    private final boolean f2188c;
    private final boolean f2189d;
    private final boolean f2190e;
    private final boolean f2191f;
    private final boolean f2192g;

    LocationSettingsStates(int i, boolean z, boolean z2, boolean z3, boolean z4, boolean z5, boolean z6) {
        this.f2186a = i;
        this.f2187b = z;
        this.f2188c = z2;
        this.f2189d = z3;
        this.f2190e = z4;
        this.f2191f = z5;
        this.f2192g = z6;
    }

    public int m4378a() {
        return this.f2186a;
    }

    public boolean m4379b() {
        return this.f2187b;
    }

    public boolean m4380c() {
        return this.f2190e;
    }

    public boolean m4381d() {
        return this.f2188c;
    }

    public boolean m4382e() {
        return this.f2191f;
    }

    public boolean m4383f() {
        return this.f2189d;
    }

    public boolean m4384g() {
        return this.f2192g;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1095r.m4587a(this, parcel, i);
    }
}
