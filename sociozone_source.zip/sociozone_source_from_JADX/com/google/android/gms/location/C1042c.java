package com.google.android.gms.location;

import android.location.Location;
import com.google.android.gms.common.api.C0837c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Status;

public interface C1042c {
    Location mo1064a(GoogleApiClient googleApiClient);

    C0837c<Status> mo1065a(GoogleApiClient googleApiClient, LocationRequest locationRequest, C1045f c1045f);

    C0837c<Status> mo1066a(GoogleApiClient googleApiClient, C1045f c1045f);
}
