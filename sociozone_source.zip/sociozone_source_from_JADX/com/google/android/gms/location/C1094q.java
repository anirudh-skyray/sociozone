package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1094q implements Creator<LocationSettingsResult> {
    static void m4584a(LocationSettingsResult locationSettingsResult, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3677a(parcel, 1, locationSettingsResult.mo897a(), i, false);
        C0917b.m3677a(parcel, 2, locationSettingsResult.m4377c(), i, false);
        C0917b.m3673a(parcel, 1000, locationSettingsResult.m4376b());
        C0917b.m3670a(parcel, a);
    }

    public LocationSettingsResult m4585a(Parcel parcel) {
        LocationSettingsStates locationSettingsStates = null;
        int b = C0916a.m3653b(parcel);
        int i = 0;
        Status status = null;
        while (parcel.dataPosition() < b) {
            int i2;
            LocationSettingsStates locationSettingsStates2;
            Status status2;
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i2 = i;
                    Status status3 = (Status) C0916a.m3650a(parcel, a, Status.CREATOR);
                    locationSettingsStates2 = locationSettingsStates;
                    status2 = status3;
                    break;
                case 2:
                    locationSettingsStates2 = (LocationSettingsStates) C0916a.m3650a(parcel, a, LocationSettingsStates.CREATOR);
                    status2 = status;
                    i2 = i;
                    break;
                case 1000:
                    LocationSettingsStates locationSettingsStates3 = locationSettingsStates;
                    status2 = status;
                    i2 = C0916a.m3659e(parcel, a);
                    locationSettingsStates2 = locationSettingsStates3;
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    locationSettingsStates2 = locationSettingsStates;
                    status2 = status;
                    i2 = i;
                    break;
            }
            i = i2;
            status = status2;
            locationSettingsStates = locationSettingsStates2;
        }
        if (parcel.dataPosition() == b) {
            return new LocationSettingsResult(i, status, locationSettingsStates);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationSettingsResult[] m4586a(int i) {
        return new LocationSettingsResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4585a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4586a(i);
    }
}
