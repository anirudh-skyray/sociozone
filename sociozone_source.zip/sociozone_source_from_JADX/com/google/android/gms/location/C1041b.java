package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1041b implements Creator<DetectedActivity> {
    static void m4388a(DetectedActivity detectedActivity, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, detectedActivity.f2150d);
        C0917b.m3673a(parcel, 2, detectedActivity.f2151e);
        C0917b.m3673a(parcel, 1000, detectedActivity.m4355c());
        C0917b.m3670a(parcel, a);
    }

    public DetectedActivity m4389a(Parcel parcel) {
        int i = 0;
        int b = C0916a.m3653b(parcel);
        int i2 = 0;
        int i3 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 1000:
                    i3 = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new DetectedActivity(i3, i2, i);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public DetectedActivity[] m4390a(int i) {
        return new DetectedActivity[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4389a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4390a(i);
    }
}
