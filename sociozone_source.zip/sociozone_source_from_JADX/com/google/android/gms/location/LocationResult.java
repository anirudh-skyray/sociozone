package com.google.android.gms.location;

import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public final class LocationResult extends AbstractSafeParcelable {
    public static final Creator<LocationResult> CREATOR = new C1092o();
    static final List<Location> f2176a = Collections.emptyList();
    private final int f2177b;
    private final List<Location> f2178c;

    LocationResult(int i, List<Location> list) {
        this.f2177b = i;
        this.f2178c = list;
    }

    public List<Location> m4369a() {
        return this.f2178c;
    }

    int m4370b() {
        return this.f2177b;
    }

    public boolean equals(Object obj) {
        if (!(obj instanceof LocationResult)) {
            return false;
        }
        LocationResult locationResult = (LocationResult) obj;
        if (locationResult.f2178c.size() != this.f2178c.size()) {
            return false;
        }
        Iterator it = this.f2178c.iterator();
        for (Location time : locationResult.f2178c) {
            if (((Location) it.next()).getTime() != time.getTime()) {
                return false;
            }
        }
        return true;
    }

    public int hashCode() {
        int i = 17;
        for (Location time : this.f2178c) {
            long time2 = time.getTime();
            i = ((int) (time2 ^ (time2 >>> 32))) + (i * 31);
        }
        return i;
    }

    public String toString() {
        String valueOf = String.valueOf(this.f2178c);
        return new StringBuilder(String.valueOf(valueOf).length() + 27).append("LocationResult[locations: ").append(valueOf).append("]").toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1092o.m4578a(this, parcel, i);
    }
}
