package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import java.util.Collections;
import java.util.List;

public final class LocationSettingsRequest extends AbstractSafeParcelable {
    public static final Creator<LocationSettingsRequest> CREATOR = new C1093p();
    private final int f2179a;
    private final List<LocationRequest> f2180b;
    private final boolean f2181c;
    private final boolean f2182d;

    LocationSettingsRequest(int i, List<LocationRequest> list, boolean z, boolean z2) {
        this.f2179a = i;
        this.f2180b = list;
        this.f2181c = z;
        this.f2182d = z2;
    }

    public int m4371a() {
        return this.f2179a;
    }

    public List<LocationRequest> m4372b() {
        return Collections.unmodifiableList(this.f2180b);
    }

    public boolean m4373c() {
        return this.f2181c;
    }

    public boolean m4374d() {
        return this.f2182d;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1093p.m4581a(this, parcel, i);
    }
}
