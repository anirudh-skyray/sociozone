package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.WorkSource;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1087j implements Creator<ActivityRecognitionRequest> {
    static void m4566a(ActivityRecognitionRequest activityRecognitionRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3674a(parcel, 1, activityRecognitionRequest.m4340a());
        C0917b.m3682a(parcel, 2, activityRecognitionRequest.m4341b());
        C0917b.m3677a(parcel, 3, activityRecognitionRequest.m4342c(), i, false);
        C0917b.m3679a(parcel, 4, activityRecognitionRequest.m4343d(), false);
        C0917b.m3683a(parcel, 5, activityRecognitionRequest.m4344e(), false);
        C0917b.m3682a(parcel, 6, activityRecognitionRequest.m4345f());
        C0917b.m3679a(parcel, 7, activityRecognitionRequest.m4346g(), false);
        C0917b.m3673a(parcel, 1000, activityRecognitionRequest.m4347h());
        C0917b.m3670a(parcel, a);
    }

    public ActivityRecognitionRequest m4567a(Parcel parcel) {
        boolean z = false;
        String str = null;
        int b = C0916a.m3653b(parcel);
        long j = 0;
        int[] iArr = null;
        String str2 = null;
        WorkSource workSource = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    j = C0916a.m3661g(parcel, a);
                    break;
                case 2:
                    z2 = C0916a.m3657c(parcel, a);
                    break;
                case 3:
                    workSource = (WorkSource) C0916a.m3650a(parcel, a, WorkSource.CREATOR);
                    break;
                case 4:
                    str2 = C0916a.m3664j(parcel, a);
                    break;
                case 5:
                    iArr = C0916a.m3667m(parcel, a);
                    break;
                case 6:
                    z = C0916a.m3657c(parcel, a);
                    break;
                case 7:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new ActivityRecognitionRequest(i, j, z2, workSource, str2, iArr, z, str);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public ActivityRecognitionRequest[] m4568a(int i) {
        return new ActivityRecognitionRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4567a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4568a(i);
    }
}
