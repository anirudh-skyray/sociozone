package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;
import java.util.List;

public class C1089l implements Creator<GestureRequest> {
    static void m4572a(GestureRequest gestureRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3680a(parcel, 1, gestureRequest.m4360b(), false);
        C0917b.m3673a(parcel, 1000, gestureRequest.m4359a());
        C0917b.m3670a(parcel, a);
    }

    public GestureRequest m4573a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        List list = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    list = C0916a.m3668n(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GestureRequest(i, list);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public GestureRequest[] m4574a(int i) {
        return new GestureRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4573a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4574a(i);
    }
}
