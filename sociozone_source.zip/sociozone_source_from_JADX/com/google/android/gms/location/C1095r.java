package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1095r implements Creator<LocationSettingsStates> {
    static void m4587a(LocationSettingsStates locationSettingsStates, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3682a(parcel, 1, locationSettingsStates.m4379b());
        C0917b.m3682a(parcel, 2, locationSettingsStates.m4381d());
        C0917b.m3682a(parcel, 3, locationSettingsStates.m4383f());
        C0917b.m3682a(parcel, 4, locationSettingsStates.m4380c());
        C0917b.m3682a(parcel, 5, locationSettingsStates.m4382e());
        C0917b.m3682a(parcel, 6, locationSettingsStates.m4384g());
        C0917b.m3673a(parcel, 1000, locationSettingsStates.m4378a());
        C0917b.m3670a(parcel, a);
    }

    public LocationSettingsStates m4588a(Parcel parcel) {
        boolean z = false;
        int b = C0916a.m3653b(parcel);
        boolean z2 = false;
        boolean z3 = false;
        boolean z4 = false;
        boolean z5 = false;
        boolean z6 = false;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    z6 = C0916a.m3657c(parcel, a);
                    break;
                case 2:
                    z5 = C0916a.m3657c(parcel, a);
                    break;
                case 3:
                    z4 = C0916a.m3657c(parcel, a);
                    break;
                case 4:
                    z3 = C0916a.m3657c(parcel, a);
                    break;
                case 5:
                    z2 = C0916a.m3657c(parcel, a);
                    break;
                case 6:
                    z = C0916a.m3657c(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationSettingsStates(i, z6, z5, z4, z3, z2, z);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationSettingsStates[] m4589a(int i) {
        return new LocationSettingsStates[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4588a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4589a(i);
    }
}
