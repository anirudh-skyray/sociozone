package com.google.android.gms.location;

import android.content.Context;
import android.os.Looper;
import com.google.android.gms.common.api.C0819e;
import com.google.android.gms.common.api.C0834a;
import com.google.android.gms.common.api.C0834a.C0820a.C0823b;
import com.google.android.gms.common.api.C0834a.C0826b;
import com.google.android.gms.common.api.C0834a.C0829f;
import com.google.android.gms.common.api.C0834a.C0830g;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.C0900l;
import com.google.android.gms.location.internal.C1061c;
import com.google.android.gms.location.internal.C1063e;
import com.google.android.gms.location.internal.C1082k;
import com.google.android.gms.location.internal.C1086p;
import com.google.android.gms.p023d.C0976h.C0975a;

public class C1049h {
    public static final C0834a<C0823b> f2193a = new C0834a("LocationServices.API", f2198f, f2197e);
    public static final C1042c f2194b = new C1061c();
    public static final C1043d f2195c = new C1063e();
    public static final C1050i f2196d = new C1086p();
    private static final C0830g<C1082k> f2197e = new C0830g();
    private static final C0826b<C1082k, C0823b> f2198f = new C10471();

    class C10471 extends C0826b<C1082k, C0823b> {
        C10471() {
        }

        public /* synthetic */ C0829f mo994a(Context context, Looper looper, C0900l c0900l, Object obj, C0817b c0817b, C0818c c0818c) {
            return m4402a(context, looper, c0900l, (C0823b) obj, c0817b, c0818c);
        }

        public C1082k m4402a(Context context, Looper looper, C0900l c0900l, C0823b c0823b, C0817b c0817b, C0818c c0818c) {
            return new C1082k(context, looper, c0817b, c0818c, "locationServices", c0900l);
        }
    }

    public static abstract class C1048a<R extends C0819e> extends C0975a<R, C1082k> {
        public C1048a(GoogleApiClient googleApiClient) {
            super(C1049h.f2197e, googleApiClient);
        }
    }

    public static C1082k m4404a(GoogleApiClient googleApiClient) {
        boolean z = true;
        C0864b.m3463b(googleApiClient != null, "GoogleApiClient parameter is required.");
        C1082k c1082k = (C1082k) googleApiClient.mo1046a(f2197e);
        if (c1082k == null) {
            z = false;
        }
        C0864b.m3459a(z, (Object) "GoogleApiClient is not configured to use the LocationServices.API Api. Pass thisinto GoogleApiClient.Builder#addApi() to use this feature.");
        return c1082k;
    }
}
