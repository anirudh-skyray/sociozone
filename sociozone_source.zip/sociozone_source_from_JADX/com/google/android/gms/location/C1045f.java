package com.google.android.gms.location;

import android.location.Location;

public interface C1045f {
    void mo1136a(Location location);
}
