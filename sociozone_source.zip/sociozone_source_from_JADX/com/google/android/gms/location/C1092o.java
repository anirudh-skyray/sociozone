package com.google.android.gms.location;

import android.location.Location;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;
import java.util.List;

public class C1092o implements Creator<LocationResult> {
    static void m4578a(LocationResult locationResult, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3688b(parcel, 1, locationResult.m4369a(), false);
        C0917b.m3673a(parcel, 1000, locationResult.m4370b());
        C0917b.m3670a(parcel, a);
    }

    public LocationResult m4579a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        List list = LocationResult.f2176a;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    list = C0916a.m3656c(parcel, a, Location.CREATOR);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationResult(i, list);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationResult[] m4580a(int i) {
        return new LocationResult[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4579a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4580a(i);
    }
}
