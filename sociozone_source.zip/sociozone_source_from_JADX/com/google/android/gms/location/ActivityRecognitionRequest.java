package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.os.WorkSource;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;

public class ActivityRecognitionRequest extends AbstractSafeParcelable {
    public static final Creator<ActivityRecognitionRequest> CREATOR = new C1087j();
    private final int f2133a;
    private long f2134b;
    private boolean f2135c;
    private WorkSource f2136d;
    private String f2137e;
    private int[] f2138f;
    private boolean f2139g;
    private String f2140h;

    ActivityRecognitionRequest(int i, long j, boolean z, WorkSource workSource, String str, int[] iArr, boolean z2, String str2) {
        this.f2133a = i;
        this.f2134b = j;
        this.f2135c = z;
        this.f2136d = workSource;
        this.f2137e = str;
        this.f2138f = iArr;
        this.f2139g = z2;
        this.f2140h = str2;
    }

    public long m4340a() {
        return this.f2134b;
    }

    public boolean m4341b() {
        return this.f2135c;
    }

    public WorkSource m4342c() {
        return this.f2136d;
    }

    public String m4343d() {
        return this.f2137e;
    }

    public int[] m4344e() {
        return this.f2138f;
    }

    public boolean m4345f() {
        return this.f2139g;
    }

    public String m4346g() {
        return this.f2140h;
    }

    int m4347h() {
        return this.f2133a;
    }

    public void writeToParcel(Parcel parcel, int i) {
        C1087j.m4566a(this, parcel, i);
    }
}
