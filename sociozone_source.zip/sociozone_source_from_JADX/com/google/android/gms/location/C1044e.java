package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;

public class C1044e implements Creator<LocationAvailability> {
    static void m4394a(LocationAvailability locationAvailability, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, locationAvailability.f2162a);
        C0917b.m3673a(parcel, 2, locationAvailability.f2163b);
        C0917b.m3674a(parcel, 3, locationAvailability.f2164c);
        C0917b.m3673a(parcel, 4, locationAvailability.f2165d);
        C0917b.m3673a(parcel, 1000, locationAvailability.m4362b());
        C0917b.m3670a(parcel, a);
    }

    public LocationAvailability m4395a(Parcel parcel) {
        int i = 1;
        int b = C0916a.m3653b(parcel);
        int i2 = 0;
        int i3 = 1000;
        long j = 0;
        int i4 = 1;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i4 = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 3:
                    j = C0916a.m3661g(parcel, a);
                    break;
                case 4:
                    i3 = C0916a.m3659e(parcel, a);
                    break;
                case 1000:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationAvailability(i2, i3, i4, i, j);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationAvailability[] m4396a(int i) {
        return new LocationAvailability[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4395a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4396a(i);
    }
}
