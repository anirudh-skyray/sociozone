package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;
import com.google.android.gms.location.internal.ParcelableGeofence;
import java.util.List;

public class C1088k implements Creator<GeofencingRequest> {
    static void m4569a(GeofencingRequest geofencingRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3688b(parcel, 1, geofencingRequest.m4357b(), false);
        C0917b.m3673a(parcel, 2, geofencingRequest.m4358c());
        C0917b.m3673a(parcel, 1000, geofencingRequest.m4356a());
        C0917b.m3670a(parcel, a);
    }

    public GeofencingRequest m4570a(Parcel parcel) {
        int i = 0;
        int b = C0916a.m3653b(parcel);
        List list = null;
        int i2 = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    list = C0916a.m3656c(parcel, a, ParcelableGeofence.CREATOR);
                    break;
                case 2:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 1000:
                    i2 = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GeofencingRequest(i2, list, i);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public GeofencingRequest[] m4571a(int i) {
        return new GeofencingRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4570a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4571a(i);
    }
}
