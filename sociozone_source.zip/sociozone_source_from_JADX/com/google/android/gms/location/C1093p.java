package com.google.android.gms.location;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;
import java.util.List;

public class C1093p implements Creator<LocationSettingsRequest> {
    static void m4581a(LocationSettingsRequest locationSettingsRequest, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3688b(parcel, 1, locationSettingsRequest.m4372b(), false);
        C0917b.m3682a(parcel, 2, locationSettingsRequest.m4373c());
        C0917b.m3682a(parcel, 3, locationSettingsRequest.m4374d());
        C0917b.m3673a(parcel, 1000, locationSettingsRequest.m4371a());
        C0917b.m3670a(parcel, a);
    }

    public LocationSettingsRequest m4582a(Parcel parcel) {
        boolean z = false;
        int b = C0916a.m3653b(parcel);
        List list = null;
        boolean z2 = false;
        int i = 0;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    list = C0916a.m3656c(parcel, a, LocationRequest.CREATOR);
                    break;
                case 2:
                    z2 = C0916a.m3657c(parcel, a);
                    break;
                case 3:
                    z = C0916a.m3657c(parcel, a);
                    break;
                case 1000:
                    i = C0916a.m3659e(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new LocationSettingsRequest(i, list, z2, z);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public LocationSettingsRequest[] m4583a(int i) {
        return new LocationSettingsRequest[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m4582a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m4583a(i);
    }
}
