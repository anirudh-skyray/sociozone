package com.google.android.gms.p021c;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.os.Messenger;
import android.util.Log;
import com.google.android.gms.iid.C1030a;
import com.google.android.gms.iid.C1037e;
import java.io.IOException;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public class C0803a {
    public static int f1529a = 5000000;
    public static int f1530b = 6500000;
    public static int f1531c = 7000000;
    static C0803a f1532d;
    private static final AtomicInteger f1533i = new AtomicInteger(1);
    final Messenger f1534e = new Messenger(new Handler(this, Looper.getMainLooper()) {
        final /* synthetic */ C0803a f1528a;

        public void handleMessage(Message message) {
            if (message == null || !(message.obj instanceof Intent)) {
                Log.w("GCM", "Dropping invalid message");
            }
            Intent intent = (Intent) message.obj;
            if ("com.google.android.c2dm.intent.REGISTRATION".equals(intent.getAction())) {
                this.f1528a.f1538j.add(intent);
            } else if (!this.f1528a.m3244b(intent)) {
                intent.setPackage(this.f1528a.f1535f.getPackageName());
                this.f1528a.f1535f.sendBroadcast(intent);
            }
        }
    });
    private Context f1535f;
    private PendingIntent f1536g;
    private Map<String, Handler> f1537h = Collections.synchronizedMap(new HashMap());
    private final BlockingQueue<Intent> f1538j = new LinkedBlockingQueue();

    public static synchronized C0803a m3237a(Context context) {
        C0803a c0803a;
        synchronized (C0803a.class) {
            if (f1532d == null) {
                f1532d = new C0803a();
                f1532d.f1535f = context.getApplicationContext();
            }
            c0803a = f1532d;
        }
        return c0803a;
    }

    private String m3238a() {
        String valueOf = String.valueOf("google.rpc");
        String valueOf2 = String.valueOf(String.valueOf(f1533i.getAndIncrement()));
        return valueOf2.length() != 0 ? valueOf.concat(valueOf2) : new String(valueOf);
    }

    static String m3239a(Intent intent, String str) throws IOException {
        if (intent == null) {
            throw new IOException("SERVICE_NOT_AVAILABLE");
        }
        String stringExtra = intent.getStringExtra(str);
        if (stringExtra != null) {
            return stringExtra;
        }
        stringExtra = intent.getStringExtra("error");
        if (stringExtra != null) {
            throw new IOException(stringExtra);
        }
        throw new IOException("SERVICE_NOT_AVAILABLE");
    }

    public static String m3243b(Context context) {
        return C1037e.m4307a(context);
    }

    private boolean m3244b(Intent intent) {
        Object stringExtra = intent.getStringExtra("In-Reply-To");
        if (stringExtra == null && intent.hasExtra("error")) {
            stringExtra = intent.getStringExtra("google.message_id");
        }
        if (stringExtra != null) {
            Handler handler = (Handler) this.f1537h.remove(stringExtra);
            if (handler != null) {
                Message obtain = Message.obtain();
                obtain.obj = intent;
                return handler.sendMessage(obtain);
            }
        }
        return false;
    }

    public static int m3245c(Context context) {
        try {
            return context.getPackageManager().getPackageInfo(C0803a.m3243b(context), 0).versionCode;
        } catch (NameNotFoundException e) {
            return -1;
        }
    }

    @Deprecated
    Intent m3246a(Bundle bundle) throws IOException {
        if (Looper.getMainLooper() == Looper.myLooper()) {
            throw new IOException("MAIN_THREAD");
        } else if (C0803a.m3245c(this.f1535f) < 0) {
            throw new IOException("Google Play Services missing");
        } else {
            if (bundle == null) {
                bundle = new Bundle();
            }
            Intent intent = new Intent("com.google.android.c2dm.intent.REGISTER");
            intent.setPackage(C0803a.m3243b(this.f1535f));
            m3248a(intent);
            intent.putExtra("google.message_id", m3238a());
            intent.putExtras(bundle);
            intent.putExtra("google.messenger", this.f1534e);
            this.f1535f.startService(intent);
            try {
                return (Intent) this.f1538j.poll(30000, TimeUnit.MILLISECONDS);
            } catch (InterruptedException e) {
                throw new IOException(e.getMessage());
            }
        }
    }

    @Deprecated
    public synchronized String m3247a(String... strArr) throws IOException {
        String b;
        b = m3249b(strArr);
        Bundle bundle = new Bundle();
        if (C0803a.m3243b(this.f1535f).contains(".gsf")) {
            bundle.putString("legacy.sender", b);
            b = C1030a.m4288c(this.f1535f).m4289a(b, "GCM", bundle);
        } else {
            bundle.putString("sender", b);
            b = C0803a.m3239a(m3246a(bundle), "registration_id");
        }
        return b;
    }

    synchronized void m3248a(Intent intent) {
        if (this.f1536g == null) {
            Intent intent2 = new Intent();
            intent2.setPackage("com.google.example.invalidpackage");
            this.f1536g = PendingIntent.getBroadcast(this.f1535f, 0, intent2, 0);
        }
        intent.putExtra("app", this.f1536g);
    }

    String m3249b(String... strArr) {
        if (strArr == null || strArr.length == 0) {
            throw new IllegalArgumentException("No senderIds");
        }
        StringBuilder stringBuilder = new StringBuilder(strArr[0]);
        for (int i = 1; i < strArr.length; i++) {
            stringBuilder.append(',').append(strArr[i]);
        }
        return stringBuilder.toString();
    }
}
