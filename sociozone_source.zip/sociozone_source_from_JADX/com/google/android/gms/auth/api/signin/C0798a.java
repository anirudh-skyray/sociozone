package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.safeparcel.C0916a;
import com.google.android.gms.common.internal.safeparcel.C0916a.C0915a;
import com.google.android.gms.common.internal.safeparcel.C0917b;
import java.util.List;

public class C0798a implements Creator<GoogleSignInAccount> {
    static void m3232a(GoogleSignInAccount googleSignInAccount, Parcel parcel, int i) {
        int a = C0917b.m3669a(parcel);
        C0917b.m3673a(parcel, 1, googleSignInAccount.f1511b);
        C0917b.m3679a(parcel, 2, googleSignInAccount.m3215a(), false);
        C0917b.m3679a(parcel, 3, googleSignInAccount.m3217b(), false);
        C0917b.m3679a(parcel, 4, googleSignInAccount.m3218c(), false);
        C0917b.m3679a(parcel, 5, googleSignInAccount.m3219d(), false);
        C0917b.m3677a(parcel, 6, googleSignInAccount.m3222g(), i, false);
        C0917b.m3679a(parcel, 7, googleSignInAccount.m3223h(), false);
        C0917b.m3674a(parcel, 8, googleSignInAccount.m3224i());
        C0917b.m3679a(parcel, 9, googleSignInAccount.m3225j(), false);
        C0917b.m3688b(parcel, 10, googleSignInAccount.f1512c, false);
        C0917b.m3679a(parcel, 11, googleSignInAccount.m3220e(), false);
        C0917b.m3679a(parcel, 12, googleSignInAccount.m3221f(), false);
        C0917b.m3670a(parcel, a);
    }

    public GoogleSignInAccount m3233a(Parcel parcel) {
        int b = C0916a.m3653b(parcel);
        int i = 0;
        String str = null;
        String str2 = null;
        String str3 = null;
        String str4 = null;
        Uri uri = null;
        String str5 = null;
        long j = 0;
        String str6 = null;
        List list = null;
        String str7 = null;
        String str8 = null;
        while (parcel.dataPosition() < b) {
            int a = C0916a.m3648a(parcel);
            switch (C0916a.m3647a(a)) {
                case 1:
                    i = C0916a.m3659e(parcel, a);
                    break;
                case 2:
                    str = C0916a.m3664j(parcel, a);
                    break;
                case 3:
                    str2 = C0916a.m3664j(parcel, a);
                    break;
                case 4:
                    str3 = C0916a.m3664j(parcel, a);
                    break;
                case 5:
                    str4 = C0916a.m3664j(parcel, a);
                    break;
                case 6:
                    uri = (Uri) C0916a.m3650a(parcel, a, Uri.CREATOR);
                    break;
                case 7:
                    str5 = C0916a.m3664j(parcel, a);
                    break;
                case 8:
                    j = C0916a.m3661g(parcel, a);
                    break;
                case 9:
                    str6 = C0916a.m3664j(parcel, a);
                    break;
                case 10:
                    list = C0916a.m3656c(parcel, a, Scope.CREATOR);
                    break;
                case 11:
                    str7 = C0916a.m3664j(parcel, a);
                    break;
                case 12:
                    str8 = C0916a.m3664j(parcel, a);
                    break;
                default:
                    C0916a.m3654b(parcel, a);
                    break;
            }
        }
        if (parcel.dataPosition() == b) {
            return new GoogleSignInAccount(i, str, str2, str3, str4, uri, str5, j, str6, list, str7, str8);
        }
        throw new C0915a("Overread allowed size end=" + b, parcel);
    }

    public GoogleSignInAccount[] m3234a(int i) {
        return new GoogleSignInAccount[i];
    }

    public /* synthetic */ Object createFromParcel(Parcel parcel) {
        return m3233a(parcel);
    }

    public /* synthetic */ Object[] newArray(int i) {
        return m3234a(i);
    }
}
