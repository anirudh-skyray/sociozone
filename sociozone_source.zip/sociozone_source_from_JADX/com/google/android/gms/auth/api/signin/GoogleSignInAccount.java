package com.google.android.gms.auth.api.signin;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.app.ag;
import android.text.TextUtils;
import com.google.android.gms.common.api.Scope;
import com.google.android.gms.common.internal.C0864b;
import com.google.android.gms.common.internal.safeparcel.AbstractSafeParcelable;
import com.google.android.gms.common.p022a.C0806c;
import com.google.android.gms.common.p022a.C0807d;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GoogleSignInAccount extends AbstractSafeParcelable {
    public static final Creator<GoogleSignInAccount> CREATOR = new C0798a();
    public static C0806c f1509a = C0807d.m3260b();
    private static Comparator<Scope> f1510n = new C07961();
    final int f1511b;
    List<Scope> f1512c;
    private String f1513d;
    private String f1514e;
    private String f1515f;
    private String f1516g;
    private Uri f1517h;
    private String f1518i;
    private long f1519j;
    private String f1520k;
    private String f1521l;
    private String f1522m;

    class C07961 implements Comparator<Scope> {
        C07961() {
        }

        public int m3211a(Scope scope, Scope scope2) {
            return scope.m3313a().compareTo(scope2.m3313a());
        }

        public /* synthetic */ int compare(Object obj, Object obj2) {
            return m3211a((Scope) obj, (Scope) obj2);
        }
    }

    GoogleSignInAccount(int i, String str, String str2, String str3, String str4, Uri uri, String str5, long j, String str6, List<Scope> list, String str7, String str8) {
        this.f1511b = i;
        this.f1513d = str;
        this.f1514e = str2;
        this.f1515f = str3;
        this.f1516g = str4;
        this.f1517h = uri;
        this.f1518i = str5;
        this.f1519j = j;
        this.f1520k = str6;
        this.f1512c = list;
        this.f1521l = str7;
        this.f1522m = str8;
    }

    public static GoogleSignInAccount m3212a(String str) throws JSONException {
        if (TextUtils.isEmpty(str)) {
            return null;
        }
        JSONObject jSONObject = new JSONObject(str);
        Object optString = jSONObject.optString("photoUrl", null);
        Uri parse = !TextUtils.isEmpty(optString) ? Uri.parse(optString) : null;
        long parseLong = Long.parseLong(jSONObject.getString("expirationTime"));
        Set hashSet = new HashSet();
        JSONArray jSONArray = jSONObject.getJSONArray("grantedScopes");
        int length = jSONArray.length();
        for (int i = 0; i < length; i++) {
            hashSet.add(new Scope(jSONArray.getString(i)));
        }
        return m3213a(jSONObject.optString("id"), jSONObject.optString("tokenId", null), jSONObject.optString(ag.CATEGORY_EMAIL, null), jSONObject.optString("displayName", null), jSONObject.optString("givenName", null), jSONObject.optString("familyName", null), parse, Long.valueOf(parseLong), jSONObject.getString("obfuscatedIdentifier"), hashSet).m3216b(jSONObject.optString("serverAuthCode", null));
    }

    public static GoogleSignInAccount m3213a(String str, String str2, String str3, String str4, String str5, String str6, Uri uri, Long l, String str7, Set<Scope> set) {
        if (l == null) {
            l = Long.valueOf(f1509a.mo896a() / 1000);
        }
        return new GoogleSignInAccount(3, str, str2, str3, str4, uri, null, l.longValue(), C0864b.m3456a(str7), new ArrayList((Collection) C0864b.m3454a((Object) set)), str5, str6);
    }

    private JSONObject m3214l() {
        JSONObject jSONObject = new JSONObject();
        try {
            if (m3215a() != null) {
                jSONObject.put("id", m3215a());
            }
            if (m3217b() != null) {
                jSONObject.put("tokenId", m3217b());
            }
            if (m3218c() != null) {
                jSONObject.put(ag.CATEGORY_EMAIL, m3218c());
            }
            if (m3219d() != null) {
                jSONObject.put("displayName", m3219d());
            }
            if (m3220e() != null) {
                jSONObject.put("givenName", m3220e());
            }
            if (m3221f() != null) {
                jSONObject.put("familyName", m3221f());
            }
            if (m3222g() != null) {
                jSONObject.put("photoUrl", m3222g().toString());
            }
            if (m3223h() != null) {
                jSONObject.put("serverAuthCode", m3223h());
            }
            jSONObject.put("expirationTime", this.f1519j);
            jSONObject.put("obfuscatedIdentifier", m3225j());
            JSONArray jSONArray = new JSONArray();
            Collections.sort(this.f1512c, f1510n);
            for (Scope a : this.f1512c) {
                jSONArray.put(a.m3313a());
            }
            jSONObject.put("grantedScopes", jSONArray);
            return jSONObject;
        } catch (Throwable e) {
            throw new RuntimeException(e);
        }
    }

    public String m3215a() {
        return this.f1513d;
    }

    public GoogleSignInAccount m3216b(String str) {
        this.f1518i = str;
        return this;
    }

    public String m3217b() {
        return this.f1514e;
    }

    public String m3218c() {
        return this.f1515f;
    }

    public String m3219d() {
        return this.f1516g;
    }

    public String m3220e() {
        return this.f1521l;
    }

    public boolean equals(Object obj) {
        return !(obj instanceof GoogleSignInAccount) ? false : ((GoogleSignInAccount) obj).m3226k().equals(m3226k());
    }

    public String m3221f() {
        return this.f1522m;
    }

    public Uri m3222g() {
        return this.f1517h;
    }

    public String m3223h() {
        return this.f1518i;
    }

    public long m3224i() {
        return this.f1519j;
    }

    public String m3225j() {
        return this.f1520k;
    }

    public String m3226k() {
        return m3214l().toString();
    }

    public void writeToParcel(Parcel parcel, int i) {
        C0798a.m3232a(this, parcel, i);
    }
}
