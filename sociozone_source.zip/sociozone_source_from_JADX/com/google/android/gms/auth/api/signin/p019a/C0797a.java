package com.google.android.gms.auth.api.signin.p019a;

import android.content.Context;
import android.content.SharedPreferences;
import android.text.TextUtils;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.common.internal.C0864b;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import org.json.JSONException;

public class C0797a {
    private static final Lock f1523a = new ReentrantLock();
    private static C0797a f1524b;
    private final Lock f1525c = new ReentrantLock();
    private final SharedPreferences f1526d;

    C0797a(Context context) {
        this.f1526d = context.getSharedPreferences("com.google.android.gms.signin", 0);
    }

    public static C0797a m3227a(Context context) {
        C0864b.m3454a((Object) context);
        f1523a.lock();
        try {
            if (f1524b == null) {
                f1524b = new C0797a(context.getApplicationContext());
            }
            C0797a c0797a = f1524b;
            return c0797a;
        } finally {
            f1523a.unlock();
        }
    }

    private String m3228a(String str, String str2) {
        String valueOf = String.valueOf(":");
        return new StringBuilder(((String.valueOf(str).length() + 0) + String.valueOf(valueOf).length()) + String.valueOf(str2).length()).append(str).append(valueOf).append(str2).toString();
    }

    public GoogleSignInAccount m3229a() {
        return m3230a(m3231b("defaultGoogleSignInAccount"));
    }

    GoogleSignInAccount m3230a(String str) {
        GoogleSignInAccount googleSignInAccount = null;
        if (!TextUtils.isEmpty(str)) {
            String b = m3231b(m3228a("googleSignInAccount", str));
            if (b != null) {
                try {
                    googleSignInAccount = GoogleSignInAccount.m3212a(b);
                } catch (JSONException e) {
                }
            }
        }
        return googleSignInAccount;
    }

    protected String m3231b(String str) {
        this.f1525c.lock();
        try {
            String string = this.f1526d.getString(str, null);
            return string;
        } finally {
            this.f1525c.unlock();
        }
    }
}
