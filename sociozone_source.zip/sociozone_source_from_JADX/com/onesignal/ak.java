package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Bundle;
import android.os.IBinder;
import com.onesignal.C1226z.C1222e;
import com.onesignal.ac.C1131a;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: TrackGooglePurchase */
class ak {
    private static int f2395a = -99;
    private static Class<?> f2396c;
    private ServiceConnection f2397b;
    private Object f2398d;
    private Method f2399e;
    private Method f2400f;
    private Context f2401g;
    private ArrayList<String> f2402h;
    private Editor f2403i;
    private boolean f2404j = true;
    private boolean f2405k = false;

    /* compiled from: TrackGooglePurchase */
    class C11511 implements ServiceConnection {
        final /* synthetic */ ak f2391a;

        C11511(ak this$0) {
            this.f2391a = this$0;
        }

        public void onServiceDisconnected(ComponentName name) {
            ak.f2395a = -99;
            this.f2391a.f2398d = null;
        }

        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                Method asInterfaceMethod = ak.m4831c(Class.forName("com.android.vending.billing.IInAppBillingService$Stub"));
                asInterfaceMethod.setAccessible(true);
                this.f2391a.f2398d = asInterfaceMethod.invoke(null, new Object[]{service});
                this.f2391a.m4832c();
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
    }

    /* compiled from: TrackGooglePurchase */
    class C11522 implements Runnable {
        final /* synthetic */ ak f2392a;

        C11522(ak this$0) {
            this.f2392a = this$0;
        }

        public void run() {
            this.f2392a.f2405k = true;
            try {
                if (this.f2392a.f2399e == null) {
                    this.f2392a.f2399e = ak.m4834d(ak.f2396c);
                    this.f2392a.f2399e.setAccessible(true);
                }
                Bundle ownedItems = (Bundle) this.f2392a.f2399e.invoke(this.f2392a.f2398d, new Object[]{Integer.valueOf(3), this.f2392a.f2401g.getPackageName(), "inapp", null});
                if (ownedItems.getInt("RESPONSE_CODE") == 0) {
                    ArrayList<String> skusToAdd = new ArrayList();
                    ArrayList<String> newPurchaseTokens = new ArrayList();
                    ArrayList<String> ownedSkus = ownedItems.getStringArrayList("INAPP_PURCHASE_ITEM_LIST");
                    ArrayList<String> purchaseDataList = ownedItems.getStringArrayList("INAPP_PURCHASE_DATA_LIST");
                    for (int i = 0; i < purchaseDataList.size(); i++) {
                        String sku = (String) ownedSkus.get(i);
                        String purchaseToken = new JSONObject((String) purchaseDataList.get(i)).getString("purchaseToken");
                        if (!(this.f2392a.f2402h.contains(purchaseToken) || newPurchaseTokens.contains(purchaseToken))) {
                            newPurchaseTokens.add(purchaseToken);
                            skusToAdd.add(sku);
                        }
                    }
                    if (skusToAdd.size() > 0) {
                        this.f2392a.m4823a((ArrayList) skusToAdd, (ArrayList) newPurchaseTokens);
                    } else if (purchaseDataList.size() == 0) {
                        this.f2392a.f2404j = false;
                        this.f2392a.f2403i.putBoolean("ExistingPurchases", false);
                        this.f2392a.f2403i.commit();
                    }
                }
            } catch (Throwable e) {
                e.printStackTrace();
            }
            this.f2392a.f2405k = false;
        }
    }

    ak(Context activity) {
        boolean z = true;
        this.f2401g = activity;
        SharedPreferences prefs = this.f2401g.getSharedPreferences("GTPlayerPurchases", 0);
        this.f2403i = prefs.edit();
        this.f2402h = new ArrayList();
        try {
            JSONArray jsonPurchaseTokens = new JSONArray(prefs.getString("purchaseTokens", "[]"));
            for (int i = 0; i < jsonPurchaseTokens.length(); i++) {
                this.f2402h.add(jsonPurchaseTokens.get(i).toString());
            }
            if (jsonPurchaseTokens.length() != 0) {
                z = false;
            }
            this.f2404j = z;
            if (this.f2404j) {
                this.f2404j = prefs.getBoolean("ExistingPurchases", true);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
        m4838a();
    }

    static boolean m4824a(Context context) {
        if (f2395a == -99) {
            f2395a = context.checkCallingOrSelfPermission("com.android.vending.BILLING");
        }
        try {
            if (f2395a == 0) {
                f2396c = Class.forName("com.android.vending.billing.IInAppBillingService");
            }
            if (f2395a == 0) {
                return true;
            }
            return false;
        } catch (Throwable th) {
            f2395a = 0;
            return false;
        }
    }

    void m4838a() {
        if (this.f2397b == null) {
            this.f2397b = new C11511(this);
            Intent serviceIntent = new Intent("com.android.vending.billing.InAppBillingService.BIND");
            serviceIntent.setPackage("com.android.vending");
            this.f2401g.bindService(serviceIntent, this.f2397b, 1);
        } else if (this.f2398d != null) {
            m4832c();
        }
    }

    private void m4832c() {
        if (!this.f2405k) {
            new Thread(new C11522(this)).start();
        }
    }

    private void m4823a(ArrayList<String> skusToAdd, ArrayList<String> newPurchaseTokens) {
        try {
            if (this.f2400f == null) {
                this.f2400f = m4835e(f2396c);
                this.f2400f.setAccessible(true);
            }
            new Bundle().putStringArrayList("ITEM_ID_LIST", skusToAdd);
            Bundle skuDetails = (Bundle) this.f2400f.invoke(this.f2398d, new Object[]{Integer.valueOf(3), this.f2401g.getPackageName(), "inapp", querySkus});
            if (skuDetails.getInt("RESPONSE_CODE") == 0) {
                String sku;
                ArrayList<String> responseList = skuDetails.getStringArrayList("DETAILS_LIST");
                Map<String, JSONObject> currentSkus = new HashMap();
                Iterator it = responseList.iterator();
                while (it.hasNext()) {
                    JSONObject object = new JSONObject((String) it.next());
                    sku = object.getString("productId");
                    BigDecimal price = new BigDecimal(object.getString("price_amount_micros")).divide(new BigDecimal(1000000));
                    JSONObject jsonItem = new JSONObject();
                    jsonItem.put("sku", sku);
                    jsonItem.put("iso", object.getString("price_currency_code"));
                    jsonItem.put("amount", price.toString());
                    currentSkus.put(sku, jsonItem);
                }
                JSONArray purchasesToReport = new JSONArray();
                it = skusToAdd.iterator();
                while (it.hasNext()) {
                    sku = (String) it.next();
                    if (currentSkus.containsKey(sku)) {
                        purchasesToReport.put(currentSkus.get(sku));
                    }
                }
                if (purchasesToReport.length() > 0) {
                    final ArrayList<String> arrayList = newPurchaseTokens;
                    C1226z.m5065a(purchasesToReport, this.f2404j, new C1131a(this) {
                        final /* synthetic */ ak f2394b;

                        public void mo1133a(String response) {
                            this.f2394b.f2402h.addAll(arrayList);
                            this.f2394b.f2403i.putString("purchaseTokens", this.f2394b.f2402h.toString());
                            this.f2394b.f2403i.remove("ExistingPurchases");
                            this.f2394b.f2403i.commit();
                            this.f2394b.f2404j = false;
                            this.f2394b.f2405k = false;
                        }
                    });
                }
            }
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.WARN, "Failed to track IAP purchases", t);
        }
    }

    private static Method m4831c(Class clazz) {
        for (Method method : clazz.getMethods()) {
            Class<?>[] args = method.getParameterTypes();
            if (args.length == 1 && args[0] == IBinder.class) {
                return method;
            }
        }
        return null;
    }

    private static Method m4834d(Class clazz) {
        for (Method method : clazz.getMethods()) {
            Class<?>[] args = method.getParameterTypes();
            if (args.length == 4 && args[0] == Integer.TYPE && args[1] == String.class && args[2] == String.class && args[3] == String.class) {
                return method;
            }
        }
        return null;
    }

    private static Method m4835e(Class clazz) {
        for (Method method : clazz.getMethods()) {
            Class<?>[] args = method.getParameterTypes();
            Class<?> returnType = method.getReturnType();
            if (args.length == 4 && args[0] == Integer.TYPE && args[1] == String.class && args[2] == String.class && args[3] == Bundle.class && returnType == Bundle.class) {
                return method;
            }
        }
        return null;
    }
}
