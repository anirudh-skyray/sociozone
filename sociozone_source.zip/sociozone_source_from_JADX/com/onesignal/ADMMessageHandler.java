package com.onesignal;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import com.amazon.device.messaging.ADMMessageHandlerBase;
import com.onesignal.C1226z.C1222e;

public class ADMMessageHandler extends ADMMessageHandlerBase {
    public ADMMessageHandler() {
        super("ADMMessageHandler");
    }

    protected void onMessage(Intent intent) {
        Context context = getApplicationContext();
        Bundle bundle = intent.getExtras();
        if (!C1178j.m4914a(context, bundle).m4912a()) {
            C1181l notifJob = new C1181l(context);
            notifJob.f2448b = C1178j.m4925b(bundle);
            C1178j.m4913a(notifJob);
        }
    }

    protected void onRegistered(String newRegistrationId) {
        C1226z.m5060a(C1222e.INFO, "ADM registration ID: " + newRegistrationId);
        af.m4801a(newRegistrationId);
    }

    protected void onRegistrationError(String error) {
        C1226z.m5060a(C1222e.ERROR, "ADM:onRegistrationError: " + error);
        if ("INVALID_SENDER".equals(error)) {
            C1226z.m5060a(C1222e.ERROR, "Please double check that you have a matching package name (NOTE: Case Sensitive), api_key.txt, and the apk was signed with the same Keystore and Alias.");
        }
        af.m4801a(null);
    }

    protected void onUnregistered(String info) {
        C1226z.m5060a(C1222e.INFO, "ADM:onUnregistered: " + info);
    }
}
