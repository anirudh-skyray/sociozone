package com.onesignal;

import android.content.Context;
import com.amazon.device.messaging.ADM;
import com.onesignal.C1226z.C1222e;
import com.onesignal.ae.C1141a;

/* compiled from: PushRegistratorADM */
public class af implements ae {
    private static C1141a f2371a;
    private static boolean f2372b = false;

    public void mo1134a(final Context context, String noKeyNeeded, final C1141a callback) {
        f2371a = callback;
        new Thread(new Runnable(this) {
            final /* synthetic */ af f2370c;

            public void run() {
                ADM adm = new ADM(context);
                String registrationId = adm.getRegistrationId();
                if (registrationId == null) {
                    adm.startRegister();
                } else {
                    C1226z.m5060a(C1222e.DEBUG, "ADM Already registered with ID:" + registrationId);
                    callback.mo1139a(registrationId, 1);
                }
                try {
                    Thread.sleep(30000);
                } catch (InterruptedException e) {
                }
                if (!af.f2372b) {
                    C1226z.m5060a(C1222e.ERROR, "com.onesignal.ADMMessageHandler timed out, please check that your have the receiver, service, and your package name matches(NOTE: Case Sensitive) per the OneSignal instructions.");
                    af.m4801a(null);
                }
            }
        }).start();
    }

    public static void m4801a(String id) {
        if (f2371a != null) {
            f2372b = true;
            f2371a.mo1139a(id, 1);
        }
    }
}
