package com.onesignal;

import android.content.Context;

/* compiled from: AdvertisingIdentifierProvider */
interface C1155d {
    String mo1135a(Context context);
}
