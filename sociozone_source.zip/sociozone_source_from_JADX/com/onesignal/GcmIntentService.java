package com.onesignal;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.C0216j;

public class GcmIntentService extends IntentService {
    public GcmIntentService() {
        super("GcmIntentService");
        setIntentRedelivery(true);
    }

    protected void onHandleIntent(Intent intent) {
        Bundle extras = intent.getExtras();
        if (extras != null) {
            C1178j.m4917a(this, extras, null);
            C0216j.m792a(intent);
        }
    }
}
