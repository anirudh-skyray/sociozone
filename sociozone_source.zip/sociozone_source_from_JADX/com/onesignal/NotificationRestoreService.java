package com.onesignal;

import android.app.IntentService;
import android.content.Intent;
import android.support.v4.content.C0216j;

public class NotificationRestoreService extends IntentService {
    public NotificationRestoreService() {
        super("NotificationRestoreService");
        setIntentRedelivery(true);
    }

    protected void onHandleIntent(Intent intent) {
        C1185o.m4943b(this);
        C0216j.m792a(intent);
    }
}
