package com.onesignal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.os.Bundle;

@TargetApi(14)
/* compiled from: ActivityLifecycleListener */
class C1154b implements ActivityLifecycleCallbacks {
    C1154b() {
    }

    public void onActivityCreated(Activity activity, Bundle savedInstanceState) {
        C1122a.m4700a(activity);
    }

    public void onActivityStarted(Activity activity) {
        C1122a.m4703b(activity);
    }

    public void onActivityResumed(Activity activity) {
        C1122a.m4706c(activity);
    }

    public void onActivityPaused(Activity activity) {
        C1122a.m4707d(activity);
    }

    public void onActivityStopped(Activity activity) {
        C1122a.m4708e(activity);
    }

    public void onActivitySaveInstanceState(Activity activity, Bundle outState) {
    }

    public void onActivityDestroyed(Activity activity) {
        C1122a.m4709f(activity);
    }
}
