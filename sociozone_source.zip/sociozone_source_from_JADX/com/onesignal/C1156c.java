package com.onesignal;

import android.content.Context;
import com.google.android.gms.p017a.p018a.C0794a;
import com.google.android.gms.p017a.p018a.C0794a.C0792a;
import com.onesignal.C1226z.C1222e;

/* compiled from: AdvertisingIdProviderGPS */
class C1156c implements C1155d {
    private static String f2406a;

    C1156c() {
    }

    static String m4840a() {
        return f2406a;
    }

    public String mo1135a(Context appContext) {
        try {
            C0792a adInfo = C0794a.m3206b(appContext);
            if (adInfo.m3200b()) {
                f2406a = "OptedOut";
            } else {
                f2406a = adInfo.m3199a();
            }
            return f2406a;
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.INFO, "Error getting Google Ad id: ", t);
            return null;
        }
    }
}
