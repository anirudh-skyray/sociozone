package com.onesignal;

import org.json.JSONObject;

/* compiled from: OSPermissionStateChanges */
public class C1205w {
    C1204v f2526a;
    C1204v f2527b;

    public JSONObject m5008a() {
        JSONObject mainObj = new JSONObject();
        try {
            mainObj.put("from", this.f2527b.m5007d());
            mainObj.put("to", this.f2526a.m5007d());
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return mainObj;
    }

    public String toString() {
        return m5008a().toString();
    }
}
