package com.onesignal;

class OSSubscriptionChangedInternalObserver {
    OSSubscriptionChangedInternalObserver() {
    }

    public void changed(OSSubscriptionState state) {
        m4671a(state);
    }

    static void m4671a(OSSubscriptionState state) {
        C1206x stateChanges = new C1206x();
        stateChanges.f2529b = C1226z.f2583i;
        stateChanges.f2528a = (OSSubscriptionState) state.clone();
        if (C1226z.m5074b().m5002c(stateChanges)) {
            C1226z.f2583i = (OSSubscriptionState) state.clone();
            C1226z.f2583i.m4675b();
        }
    }
}
