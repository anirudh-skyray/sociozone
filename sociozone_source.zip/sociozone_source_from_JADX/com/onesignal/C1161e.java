package com.onesignal;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.os.Build.VERSION;
import android.os.Process;
import android.util.Log;

/* compiled from: AndroidSupportV4Compat */
class C1161e {

    /* compiled from: AndroidSupportV4Compat */
    static class C1157a {
        static void m4842a(Activity activity, String[] permissions, int requestCode) {
            C1158b.m4843a(activity, permissions, requestCode);
        }
    }

    @TargetApi(23)
    /* compiled from: AndroidSupportV4Compat */
    static class C1158b {
        static void m4843a(Activity activity, String[] permissions, int requestCode) {
            if (activity instanceof C1160d) {
                ((C1160d) activity).m4846a(requestCode);
            }
            activity.requestPermissions(permissions, requestCode);
        }
    }

    /* compiled from: AndroidSupportV4Compat */
    static class C1159c {
        static int m4845a(Context context, String permission) {
            try {
                return context.checkPermission(permission, Process.myPid(), Process.myUid());
            } catch (Throwable th) {
                Log.e("OneSignal", "checkSelfPermission failed, returning PERMISSION_DENIED");
                return -1;
            }
        }

        static int m4844a(Context context, int id) {
            if (VERSION.SDK_INT > 22) {
                return context.getColor(id);
            }
            return context.getResources().getColor(id);
        }
    }

    /* compiled from: AndroidSupportV4Compat */
    interface C1160d {
        void m4846a(int i);
    }
}
