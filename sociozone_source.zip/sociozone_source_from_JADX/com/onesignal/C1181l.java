package com.onesignal;

import android.content.Context;
import android.net.Uri;
import com.onesignal.C1180k.C1179a;
import java.util.Random;
import org.json.JSONObject;

/* compiled from: NotificationGenerationJob */
class C1181l {
    Context f2447a;
    JSONObject f2448b;
    boolean f2449c;
    boolean f2450d;
    Long f2451e;
    CharSequence f2452f;
    CharSequence f2453g;
    Uri f2454h;
    Integer f2455i;
    Integer f2456j;
    Uri f2457k;
    C1179a f2458l;

    C1181l(Context context) {
        this.f2447a = context;
    }

    CharSequence m4929a() {
        if (this.f2453g != null) {
            return this.f2453g;
        }
        return this.f2448b.optString("title", null);
    }

    CharSequence m4931b() {
        if (this.f2452f != null) {
            return this.f2452f;
        }
        return this.f2448b.optString("alert", null);
    }

    Integer m4932c() {
        if (this.f2458l == null) {
            this.f2458l = new C1179a();
        }
        if (this.f2458l.f2446b == null) {
            this.f2458l.f2446b = Integer.valueOf(new Random().nextInt());
        }
        return this.f2458l.f2446b;
    }

    void m4930a(Integer id) {
        if (id != null) {
            if (this.f2458l == null || this.f2458l.f2446b == null) {
                if (this.f2458l == null) {
                    this.f2458l = new C1179a();
                }
                this.f2458l.f2446b = id;
            }
        }
    }
}
