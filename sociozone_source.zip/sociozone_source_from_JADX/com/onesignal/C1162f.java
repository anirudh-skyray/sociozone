package com.onesignal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ag;
import com.onesignal.C1226z.C1222e;
import com.onesignal.shortcutbadger.C1196c;

/* compiled from: BadgeCountUpdater */
class C1162f {
    private static int f2407a = -1;

    private static boolean m4849a(Context context) {
        if (f2407a == -1) {
            try {
                int i;
                if ("DISABLE".equals(context.getPackageManager().getApplicationInfo(context.getPackageName(), ag.FLAG_HIGH_PRIORITY).metaData.getString("com.onesignal.BadgeCount"))) {
                    i = 0;
                } else {
                    i = 1;
                }
                f2407a = i;
            } catch (Throwable t) {
                f2407a = 0;
                C1226z.m5061a(C1222e.ERROR, "Error reading meta-data tag 'com.onesignal.BadgeCount'. Disabling badge setting.", t);
            }
            if (f2407a != 1) {
                return false;
            }
            return true;
        } else if (f2407a == 1) {
            return true;
        } else {
            return false;
        }
    }

    private static boolean m4850b(Context context) {
        return C1162f.m4849a(context) && C1207y.m5013a(context);
    }

    static void m4848a(SQLiteDatabase readableDb, Context context) {
        if (C1162f.m4850b(context)) {
            Cursor cursor = readableDb.query("notification", null, "dismissed = 0 AND opened = 0 AND is_summary = 0 ", null, null, null, null);
            C1162f.m4847a(cursor.getCount(), context);
            cursor.close();
        }
    }

    static void m4847a(int count, Context context) {
        if (C1162f.m4849a(context)) {
            try {
                C1196c.m4953a(context, count);
            } catch (Throwable th) {
            }
        }
    }
}
