package com.onesignal;

import java.lang.ref.WeakReference;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/* compiled from: OSObservable */
class C1203u<ObserverType, StateType> {
    private String f2521a;
    private List<Object> f2522b = new ArrayList();
    private boolean f2523c;

    C1203u(String methodName, boolean fireOnMainThread) {
        this.f2521a = methodName;
        this.f2523c = fireOnMainThread;
    }

    void m5000a(ObserverType observer) {
        this.f2522b.add(new WeakReference(observer));
    }

    void m5001b(ObserverType observer) {
        this.f2522b.add(observer);
    }

    boolean m5002c(final StateType state) {
        boolean notified = false;
        for (Object observer : this.f2522b) {
            Object strongRefObserver;
            if (observer instanceof WeakReference) {
                strongRefObserver = ((WeakReference) observer).get();
            } else {
                strongRefObserver = observer;
            }
            if (strongRefObserver != null) {
                try {
                    final Method method = strongRefObserver.getClass().getDeclaredMethod(this.f2521a, new Class[]{state.getClass()});
                    method.setAccessible(true);
                    if (this.f2523c) {
                        C1207y.m5012a(new Runnable(this) {
                            final /* synthetic */ C1203u f2520d;

                            public void run() {
                                try {
                                    method.invoke(strongRefObserver, new Object[]{state});
                                } catch (Throwable t) {
                                    t.printStackTrace();
                                }
                            }
                        });
                    } else {
                        method.invoke(strongRefObserver, new Object[]{state});
                    }
                    notified = true;
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        }
        return notified;
    }
}
