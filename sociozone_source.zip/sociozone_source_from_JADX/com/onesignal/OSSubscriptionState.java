package com.onesignal;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import org.json.JSONObject;

public class OSSubscriptionState implements Cloneable {
    C1203u<Object, OSSubscriptionState> f2295a = new C1203u("changed", false);
    private boolean f2296b;
    private boolean f2297c;
    private String f2298d;
    private String f2299e;

    OSSubscriptionState(boolean asFrom, boolean permissionAccepted) {
        if (asFrom) {
            SharedPreferences prefs = C1226z.m5091d(C1226z.f2576b);
            this.f2297c = prefs.getBoolean("ONESIGNAL_SUBSCRIPTION_LAST", false);
            this.f2298d = prefs.getString("ONESIGNAL_PLAYER_ID_LAST", null);
            this.f2299e = prefs.getString("ONESIGNAL_PUSH_TOKEN_LAST", null);
            this.f2296b = prefs.getBoolean("ONESIGNAL_PERMISSION_ACCEPTED_LAST", false);
            return;
        }
        this.f2297c = ad.m4781c();
        this.f2298d = C1226z.m5104g();
        this.f2299e = ad.m4784e();
        this.f2296b = permissionAccepted;
    }

    void changed(C1204v state) {
        m4672a(state.m5005b());
    }

    void m4673a(String id) {
        boolean changed = !id.equals(this.f2298d);
        this.f2298d = id;
        if (changed) {
            this.f2295a.m5002c(this);
        }
    }

    void m4676b(String id) {
        if (id != null) {
            boolean changed = !id.equals(this.f2299e);
            this.f2299e = id;
            if (changed) {
                this.f2295a.m5002c(this);
            }
        }
    }

    private void m4672a(boolean set) {
        boolean lastSubscribed = m4674a();
        this.f2296b = set;
        if (lastSubscribed != m4674a()) {
            this.f2295a.m5002c(this);
        }
    }

    public boolean m4674a() {
        return this.f2298d != null && this.f2299e != null && this.f2297c && this.f2296b;
    }

    void m4675b() {
        Editor editor = C1226z.m5091d(C1226z.f2576b).edit();
        editor.putBoolean("ONESIGNAL_SUBSCRIPTION_LAST", this.f2297c);
        editor.putString("ONESIGNAL_PLAYER_ID_LAST", this.f2298d);
        editor.putString("ONESIGNAL_PUSH_TOKEN_LAST", this.f2299e);
        editor.putBoolean("ONESIGNAL_PERMISSION_ACCEPTED_LAST", this.f2296b);
        editor.commit();
    }

    protected Object clone() {
        try {
            return super.clone();
        } catch (Throwable th) {
            return null;
        }
    }

    public JSONObject m4677c() {
        JSONObject mainObj = new JSONObject();
        try {
            if (this.f2298d != null) {
                mainObj.put("userId", this.f2298d);
            } else {
                mainObj.put("userId", JSONObject.NULL);
            }
            if (this.f2299e != null) {
                mainObj.put("pushToken", this.f2299e);
            } else {
                mainObj.put("pushToken", JSONObject.NULL);
            }
            mainObj.put("userSubscriptionSetting", this.f2297c);
            mainObj.put("subscribed", m4674a());
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return mainObj;
    }

    public String toString() {
        return m4677c().toString();
    }
}
