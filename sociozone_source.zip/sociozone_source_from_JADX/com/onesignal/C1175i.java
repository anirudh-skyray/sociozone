package com.onesignal;

import android.content.Context;
import android.content.SharedPreferences.Editor;
import android.location.Location;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.C0837c;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.GoogleApiClient.C0816a;
import com.google.android.gms.common.api.GoogleApiClient.C0817b;
import com.google.android.gms.common.api.GoogleApiClient.C0818c;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.C1045f;
import com.google.android.gms.location.C1049h;
import com.google.android.gms.location.LocationRequest;
import com.onesignal.C1161e.C1159c;
import com.onesignal.C1226z.C1222e;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Arrays;
import java.util.List;

/* compiled from: LocationGMS */
class C1175i {
    static String f2433a;
    private static C1168h f2434b;
    private static Context f2435c;
    private static C1172d f2436d;
    private static C1115c f2437e;
    private static Thread f2438f;
    private static boolean f2439g;
    private static C1174f f2440h;

    /* compiled from: LocationGMS */
    interface C1115c {
        void mo1128a(C1173e c1173e);
    }

    /* compiled from: LocationGMS */
    static class C11691 implements Runnable {
        C11691() {
        }

        public void run() {
            try {
                Thread.sleep(30000);
                C1226z.m5060a(C1222e.WARN, "Location permission exists but GoogleApiClient timed out. Maybe related to mismatch google-play aar versions.");
                C1175i.m4907b();
            } catch (Throwable th) {
            }
        }
    }

    /* compiled from: LocationGMS */
    static class C1170a {
        static C0837c<Status> m4893a(GoogleApiClient googleApiClient, LocationRequest locationRequest, C1045f locationListener) {
            if (googleApiClient.mo1054b()) {
                return C1049h.f2194b.mo1065a(googleApiClient, locationRequest, locationListener);
            }
            return null;
        }

        static C0837c<Status> m4894a(GoogleApiClient googleApiClient, C1045f locationListener) {
            if (googleApiClient.mo1054b()) {
                return C1049h.f2194b.mo1066a(googleApiClient, locationListener);
            }
            return null;
        }

        static Location m4892a(GoogleApiClient googleApiClient) {
            if (googleApiClient.mo1054b()) {
                return C1049h.f2194b.mo1064a(googleApiClient);
            }
            return null;
        }
    }

    /* compiled from: LocationGMS */
    private static class C1171b implements C0817b, C0818c {
        private C1171b() {
        }

        public void mo1019a(Bundle bundle) {
            PermissionsActivity.f2301b = false;
            Location location = C1170a.m4892a(C1175i.f2434b.m4891c());
            if (location != null) {
                C1175i.m4908b(location);
                C1175i.f2434b.m4890b();
                return;
            }
            C1175i.f2440h = new C1174f(C1175i.f2434b.m4891c());
        }

        public void mo1018a(int i) {
            C1175i.m4907b();
        }

        public void mo1003a(ConnectionResult connectionResult) {
            C1175i.m4907b();
        }
    }

    /* compiled from: LocationGMS */
    private static class C1172d extends HandlerThread {
        Handler f2425a = null;

        C1172d() {
            super("OSH_LocationHandlerThread");
            start();
            this.f2425a = new Handler(getLooper());
        }
    }

    /* compiled from: LocationGMS */
    static class C1173e {
        Double f2426a;
        Double f2427b;
        Float f2428c;
        Integer f2429d;
        Boolean f2430e;
        Long f2431f;

        C1173e() {
        }
    }

    /* compiled from: LocationGMS */
    private static class C1174f implements C1045f {
        private GoogleApiClient f2432a;

        C1174f(GoogleApiClient googleApiClient) {
            this.f2432a = googleApiClient;
            C1170a.m4894a(this.f2432a, this);
            LocationRequest locationRequest = new LocationRequest();
            locationRequest.m4368a(20000);
            locationRequest.m4367a(102);
            C1170a.m4893a(this.f2432a, locationRequest, this);
        }

        public void mo1136a(Location location) {
            C1175i.m4908b(location);
            if (this.f2432a.mo1054b()) {
                C1170a.m4894a(this.f2432a, this);
                this.f2432a.disconnect();
            }
        }
    }

    static void m4902a(Context context) {
        if (C1175i.m4910c(context) || !C1226z.f2579e) {
            SyncService.m4687a(context, C1175i.m4906b(context) + ((long) ((C1226z.m5098e() ? 300 : 600) * 1000)));
        }
    }

    private static void m4901a(long time) {
        Editor editor = C1226z.m5091d(f2435c).edit();
        editor.putLong("OS_LAST_LOCATION_TIME", time);
        editor.apply();
    }

    private static long m4906b(Context context) {
        return C1226z.m5091d(context).getLong("OS_LAST_LOCATION_TIME", -600000);
    }

    private static boolean m4910c(Context context) {
        return C1159c.m4845a(context, "android.permission.ACCESS_FINE_LOCATION") == 0 || C1159c.m4845a(context, "android.permission.ACCESS_COARSE_LOCATION") == 0;
    }

    static void m4903a(Context context, boolean promptLocation, C1115c handler) {
        f2435c = context;
        f2437e = handler;
        if (C1226z.f2579e) {
            int locationCoarsePermission = -1;
            int locationFinePermission = C1159c.m4845a(context, "android.permission.ACCESS_FINE_LOCATION");
            if (locationFinePermission == -1) {
                locationCoarsePermission = C1159c.m4845a(context, "android.permission.ACCESS_COARSE_LOCATION");
                f2439g = true;
            }
            if (VERSION.SDK_INT < 23) {
                if (locationFinePermission == 0 || locationCoarsePermission == 0) {
                    C1175i.m4900a();
                    return;
                } else {
                    handler.mo1128a(null);
                    return;
                }
            } else if (locationFinePermission != 0) {
                try {
                    List<String> permissionList = Arrays.asList(context.getPackageManager().getPackageInfo(context.getPackageName(), 4096).requestedPermissions);
                    if (permissionList.contains("android.permission.ACCESS_FINE_LOCATION")) {
                        f2433a = "android.permission.ACCESS_FINE_LOCATION";
                    } else if (permissionList.contains("android.permission.ACCESS_COARSE_LOCATION") && locationCoarsePermission != 0) {
                        f2433a = "android.permission.ACCESS_COARSE_LOCATION";
                    }
                    if (f2433a != null && promptLocation) {
                        PermissionsActivity.m4680a();
                        return;
                    } else if (locationCoarsePermission == 0) {
                        C1175i.m4900a();
                        return;
                    } else {
                        C1175i.m4907b();
                        return;
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                    return;
                }
            } else {
                C1175i.m4900a();
                return;
            }
        }
        C1175i.m4907b();
    }

    static void m4900a() {
        if (f2438f == null) {
            try {
                C1175i.m4911d();
                if (f2436d == null) {
                    f2436d = new C1172d();
                }
                C0818c googleApiClientListener = new C1171b();
                f2434b = new C1168h(new C0816a(f2435c).m3296a(C1049h.f2193a).m3294a((C0817b) googleApiClientListener).m3295a(googleApiClientListener).m3293a(f2436d.f2425a).m3298b());
                f2434b.m4889a();
            } catch (Throwable t) {
                C1226z.m5061a(C1222e.WARN, "Location permission exists but there was an error initializing: ", t);
                C1175i.m4907b();
            }
        }
    }

    private static void m4911d() {
        f2438f = new Thread(new C11691(), "OS_GMS_LOCATION_FALLBACK");
        f2438f.start();
    }

    static void m4907b() {
        PermissionsActivity.f2301b = false;
        C1175i.m4905a(null);
        if (f2434b != null) {
            f2434b.m4890b();
        }
    }

    private static synchronized void m4905a(C1173e point) {
        synchronized (C1175i.class) {
            f2437e.mo1128a(point);
            if (!(f2438f == null || Thread.currentThread().equals(f2438f))) {
                f2438f.interrupt();
            }
            f2438f = null;
        }
    }

    private static void m4908b(Location location) {
        int i = 0;
        C1173e point = new C1173e();
        point.f2428c = Float.valueOf(location.getAccuracy());
        point.f2430e = Boolean.valueOf(!C1226z.m5098e());
        if (!f2439g) {
            i = 1;
        }
        point.f2429d = Integer.valueOf(i);
        point.f2431f = Long.valueOf(location.getTime());
        if (f2439g) {
            point.f2426a = Double.valueOf(new BigDecimal(location.getLatitude()).setScale(7, RoundingMode.HALF_UP).doubleValue());
            point.f2427b = Double.valueOf(new BigDecimal(location.getLongitude()).setScale(7, RoundingMode.HALF_UP).doubleValue());
        } else {
            point.f2426a = Double.valueOf(location.getLatitude());
            point.f2427b = Double.valueOf(location.getLongitude());
        }
        C1175i.m4905a(point);
        C1175i.m4901a(System.currentTimeMillis());
        C1175i.m4902a(f2435c);
    }
}
