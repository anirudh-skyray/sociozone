package com.onesignal;

import android.content.Context;
import com.amazon.device.iap.PurchasingListener;
import com.amazon.device.iap.PurchasingService;
import com.amazon.device.iap.model.ProductDataResponse.RequestStatus;
import com.onesignal.C1226z.C1222e;
import java.lang.reflect.Field;

/* compiled from: TrackAmazonPurchase */
class aj {
    private Context f2386a;
    private boolean f2387b = false;
    private C1150a f2388c;
    private Object f2389d;
    private Field f2390e;

    /* compiled from: TrackAmazonPurchase */
    static /* synthetic */ class C11491 {
        static final /* synthetic */ int[] f2383a = new int[RequestStatus.values().length];

        static {
            try {
                f2383a[RequestStatus.SUCCESSFUL.ordinal()] = 1;
            } catch (NoSuchFieldError e) {
            }
        }
    }

    /* compiled from: TrackAmazonPurchase */
    private class C1150a implements PurchasingListener {
        PurchasingListener f2384a;
        final /* synthetic */ aj f2385b;

        private C1150a(aj ajVar) {
            this.f2385b = ajVar;
        }
    }

    aj(Context context) {
        this.f2386a = context;
        try {
            Class<?> listenerHandlerClass = Class.forName("com.amazon.device.iap.internal.d");
            this.f2389d = listenerHandlerClass.getMethod("d", new Class[0]).invoke(null, new Object[0]);
            this.f2390e = listenerHandlerClass.getDeclaredField("f");
            this.f2390e.setAccessible(true);
            this.f2388c = new C1150a();
            this.f2388c.f2384a = (PurchasingListener) this.f2390e.get(this.f2389d);
            this.f2387b = true;
            m4814b();
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Error adding Amazon IAP listener.", t);
        }
    }

    private void m4814b() {
        PurchasingService.registerListener(this.f2386a, this.f2388c);
    }

    void m4815a() {
        if (this.f2387b) {
            try {
                PurchasingListener curPurchasingListener = (PurchasingListener) this.f2390e.get(this.f2389d);
                if (curPurchasingListener != this.f2388c) {
                    this.f2388c.f2384a = curPurchasingListener;
                    m4814b();
                }
            } catch (Throwable th) {
            }
        }
    }
}
