package com.onesignal;

import android.content.Context;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ag;
import android.support.v4.app.ap;
import android.telephony.TelephonyManager;
import com.onesignal.C1226z.C1222e;
import java.util.Locale;
import java.util.UUID;

/* compiled from: OSUtils */
class C1207y {
    C1207y() {
    }

    int m5016a(int deviceType, String oneSignalAppId) {
        int subscribableStatus = 1;
        try {
            UUID.fromString(oneSignalAppId);
            if ("b2f7f966-d8cc-11e4-bed1-df8f05be55ba".equals(oneSignalAppId) || "5eb5a37e-b458-11e3-ac11-000c2940e62c".equals(oneSignalAppId)) {
                C1226z.m5060a(C1222e.ERROR, "OneSignal Example AppID detected, please update to your app's id found on OneSignal.com");
            }
            if (deviceType == 1) {
                try {
                    Class.forName("com.google.android.gms.c.a");
                } catch (Throwable e) {
                    C1226z.m5061a(C1222e.FATAL, "The GCM Google Play services client library was not found. Please make sure to include it in your project.", e);
                    subscribableStatus = -4;
                }
                try {
                    Class.forName("com.google.android.gms.common.e");
                } catch (Throwable e2) {
                    C1226z.m5061a(C1222e.FATAL, "The GooglePlayServicesUtil class part of Google Play services client library was not found. Include this in your project.", e2);
                    subscribableStatus = -4;
                }
            }
            try {
                Class.forName("android.support.v4.view.q");
                try {
                    Class.forName("android.support.v4.content.j");
                    Class.forName("android.support.v4.app.ap");
                } catch (Throwable e22) {
                    C1226z.m5061a(C1222e.FATAL, "The included Android Support Library v4 is to old or incomplete. Please update your project's android-support-v4.jar to the latest revision.", e22);
                    subscribableStatus = -5;
                }
            } catch (Throwable e222) {
                C1226z.m5061a(C1222e.FATAL, "Could not find the Android Support Library v4. Please make sure android-support-v4.jar has been correctly added to your project.", e222);
                subscribableStatus = -3;
            }
            return subscribableStatus;
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.FATAL, "OneSignal AppId format is invalid.\nExample: 'b2f7f966-d8cc-11e4-bed1-df8f05be55ba'\n", t);
            return -999;
        }
    }

    int m5015a() {
        try {
            Class.forName("com.amazon.device.messaging.ADM");
            return 2;
        } catch (ClassNotFoundException e) {
            return 1;
        }
    }

    Integer m5017b() {
        NetworkInfo netInfo = ((ConnectivityManager) C1226z.f2576b.getSystemService("connectivity")).getActiveNetworkInfo();
        if (netInfo == null) {
            return null;
        }
        int networkType = netInfo.getType();
        if (networkType == 1 || networkType == 9) {
            return Integer.valueOf(0);
        }
        return Integer.valueOf(1);
    }

    String m5018c() {
        String carrierName = ((TelephonyManager) C1226z.f2576b.getSystemService("phone")).getNetworkOperatorName();
        return "".equals(carrierName) ? null : carrierName;
    }

    static String m5010a(Context context, String metaName) {
        try {
            return context.getPackageManager().getApplicationInfo(context.getPackageName(), ag.FLAG_HIGH_PRIORITY).metaData.getString(metaName);
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "", t);
            return null;
        }
    }

    static String m5011a(Context context, String key, String defaultStr) {
        Resources resources = context.getResources();
        int bodyResId = resources.getIdentifier(key, "string", context.getPackageName());
        if (bodyResId != 0) {
            return resources.getString(bodyResId);
        }
        return defaultStr;
    }

    static String m5014d() {
        String lang = Locale.getDefault().getLanguage();
        if (lang.equals("iw")) {
            return "he";
        }
        if (lang.equals("in")) {
            return "id";
        }
        if (lang.equals("ji")) {
            return "yi";
        }
        if (lang.equals("zh")) {
            return lang + "-" + Locale.getDefault().getCountry();
        }
        return lang;
    }

    static boolean m5013a(Context context) {
        try {
            return ap.m443a(C1226z.f2576b).areNotificationsEnabled();
        } catch (Throwable th) {
            return true;
        }
    }

    static void m5012a(Runnable runnable) {
        if (Looper.getMainLooper().getThread() == Thread.currentThread()) {
            runnable.run();
        } else {
            new Handler(Looper.getMainLooper()).post(runnable);
        }
    }
}
