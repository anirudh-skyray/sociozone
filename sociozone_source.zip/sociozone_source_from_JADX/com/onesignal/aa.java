package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.net.Uri;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.support.p001a.C0001a;
import android.support.p001a.C0005b;
import android.support.p001a.C0010d;
import android.support.p001a.C0011e;
import java.util.Random;

/* compiled from: OneSignalChromeTab */
class aa {
    private static boolean f2318a;

    /* compiled from: OneSignalChromeTab */
    private static class C1124a extends C0010d {
        private Context f2316a;
        private String f2317b;

        /* compiled from: OneSignalChromeTab */
        class C11231 extends C0001a {
            final /* synthetic */ C1124a f2315a;

            C11231(C1124a this$0) {
                this.f2315a = this$0;
            }

            public void mo1129a(int navigationEvent, Bundle extras) {
                super.mo1129a(navigationEvent, extras);
            }

            public void mo1130a(String callbackName, Bundle args) {
                super.mo1130a(callbackName, args);
            }
        }

        C1124a(Context context, String params) {
            this.f2316a = context;
            this.f2317b = params;
        }

        public void mo1131a(ComponentName componentName, C0005b customTabsClient) {
            if (customTabsClient != null) {
                customTabsClient.m10a(0);
                C0011e session = customTabsClient.m9a(new C11231(this));
                if (session != null) {
                    session.m15a(Uri.parse("https://onesignal.com/android_frame.html" + this.f2317b), null, null);
                }
            }
        }

        public void onServiceDisconnected(ComponentName name) {
        }
    }

    static void m4714a(Context context, String appId, String userId, String adId) {
        if (VERSION.SDK_INT >= 14 && !f2318a && !C1226z.f2581g && userId != null) {
            try {
                Class.forName("android.support.a.d");
                String params = "?app_id=" + appId + "&user_id=" + userId;
                if (adId != null) {
                    params = params + "&ad_id=" + adId;
                }
                f2318a = C0005b.m8a(context, "com.android.chrome", new C1124a(context, params + "&cbs_id=" + new Random().nextInt(ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED)));
            } catch (ClassNotFoundException e) {
            }
        }
    }
}
