package com.onesignal;

class OSPermissionChangedInternalObserver {
    OSPermissionChangedInternalObserver() {
    }

    void changed(C1204v state) {
        m4669a(state);
        m4670b(state);
    }

    static void m4669a(C1204v state) {
        if (!state.m5005b()) {
            C1162f.m4847a(0, C1226z.f2576b);
        }
        ad.m4777b(C1226z.m5118o());
    }

    static void m4670b(C1204v state) {
        C1205w stateChanges = new C1205w();
        stateChanges.f2527b = C1226z.f2582h;
        stateChanges.f2526a = (C1204v) state.clone();
        if (C1226z.m5050a().m5002c(stateChanges)) {
            C1226z.f2582h = (C1204v) state.clone();
            C1226z.f2582h.m5006c();
        }
    }
}
