package com.onesignal;

import android.app.Activity;
import android.os.Handler;
import android.os.HandlerThread;
import com.onesignal.C1226z.C1222e;

/* compiled from: ActivityLifecycleHandler */
class C1122a {
    static boolean f2311a;
    static Activity f2312b;
    static C1121c f2313c = new C1121c();
    private static C1113a f2314d;

    /* compiled from: ActivityLifecycleHandler */
    interface C1113a {
        void mo1127a(Activity activity);
    }

    /* compiled from: ActivityLifecycleHandler */
    private static class C1120b implements Runnable {
        private boolean f2307a;
        private boolean f2308b;

        private C1120b() {
        }

        public void run() {
            if (C1122a.f2312b == null) {
                this.f2307a = true;
                C1226z.m5073a(false);
                this.f2308b = true;
            }
        }
    }

    /* compiled from: ActivityLifecycleHandler */
    static class C1121c extends HandlerThread {
        Handler f2309a = null;
        private C1120b f2310b;

        C1121c() {
            super("FocusHandlerThread");
            start();
            this.f2309a = new Handler(getLooper());
        }

        void m4695a() {
            if (this.f2310b != null) {
                this.f2310b.f2307a = false;
            }
        }

        void m4697b() {
            this.f2309a.removeCallbacksAndMessages(null);
        }

        void m4696a(C1120b runnable) {
            if (this.f2310b == null || !this.f2310b.f2307a || this.f2310b.f2308b) {
                this.f2310b = runnable;
                this.f2309a.removeCallbacksAndMessages(null);
                this.f2309a.postDelayed(runnable, 2000);
            }
        }

        boolean m4698c() {
            return this.f2310b != null && this.f2310b.f2307a;
        }
    }

    static void m4701a(C1113a activityAvailableListener) {
        if (f2312b != null) {
            activityAvailableListener.mo1127a(f2312b);
            f2314d = activityAvailableListener;
            return;
        }
        f2314d = activityAvailableListener;
    }

    public static void m4704b(C1113a activityAvailableListener) {
        f2314d = null;
    }

    private static void m4710g(Activity activity) {
        f2312b = activity;
        if (f2314d != null) {
            f2314d.mo1127a(f2312b);
        }
    }

    static void m4700a(Activity activity) {
    }

    static void m4703b(Activity activity) {
    }

    static void m4706c(Activity activity) {
        C1122a.m4710g(activity);
        C1122a.m4699a();
        C1122a.m4705c();
    }

    static void m4707d(Activity activity) {
        if (activity == f2312b) {
            f2312b = null;
            C1122a.m4702b();
        }
        C1122a.m4699a();
    }

    static void m4708e(Activity activity) {
        C1226z.m5060a(C1222e.DEBUG, "onActivityStopped: " + activity.getClass().getName());
        if (activity == f2312b) {
            f2312b = null;
            C1122a.m4702b();
        }
        C1122a.m4699a();
    }

    static void m4709f(Activity activity) {
        C1226z.m5060a(C1222e.DEBUG, "onActivityDestroyed: " + activity.getClass().getName());
        if (activity == f2312b) {
            f2312b = null;
            C1122a.m4702b();
        }
        C1122a.m4699a();
    }

    private static void m4699a() {
        C1226z.m5060a(C1222e.DEBUG, "curActivity is NOW: " + (f2312b != null ? "" + f2312b.getClass().getName() + ":" + f2312b : "null"));
    }

    private static void m4702b() {
        f2313c.m4696a(new C1120b());
    }

    private static void m4705c() {
        if (f2313c.m4698c() || f2311a) {
            f2311a = false;
            f2313c.m4695a();
            C1226z.m5094d();
            return;
        }
        f2313c.m4697b();
    }
}
