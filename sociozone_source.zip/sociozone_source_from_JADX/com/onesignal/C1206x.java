package com.onesignal;

import org.json.JSONObject;

/* compiled from: OSSubscriptionStateChanges */
public class C1206x {
    OSSubscriptionState f2528a;
    OSSubscriptionState f2529b;

    public JSONObject m5009a() {
        JSONObject mainObj = new JSONObject();
        try {
            mainObj.put("from", this.f2529b.m4677c());
            mainObj.put("to", this.f2528a.m4677c());
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return mainObj;
    }

    public String toString() {
        return m5009a().toString();
    }
}
