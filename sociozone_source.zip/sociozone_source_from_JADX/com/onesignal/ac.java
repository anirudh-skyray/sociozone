package com.onesignal;

import com.onesignal.C1226z.C1222e;
import java.io.InputStream;
import java.lang.Thread.State;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import org.json.JSONObject;

/* compiled from: OneSignalRestClient */
class ac {

    /* compiled from: OneSignalRestClient */
    static class C1131a {
        C1131a() {
        }

        void mo1133a(String response) {
        }

        void mo1132a(int statusCode, String response, Throwable throwable) {
        }
    }

    private static int m4721a(int timeout) {
        return timeout + 5000;
    }

    static void m4726a(final String url, final JSONObject jsonBody, final C1131a responseHandler) {
        new Thread(new Runnable() {
            public void run() {
                ac.m4730c(url, "PUT", jsonBody, responseHandler, 120000);
            }
        }).start();
    }

    static void m4729b(final String url, final JSONObject jsonBody, final C1131a responseHandler) {
        new Thread(new Runnable() {
            public void run() {
                ac.m4730c(url, "POST", jsonBody, responseHandler, 120000);
            }
        }).start();
    }

    static void m4724a(final String url, final C1131a responseHandler) {
        new Thread(new Runnable() {
            public void run() {
                ac.m4730c(url, null, null, responseHandler, 60000);
            }
        }).start();
    }

    static void m4728b(String url, C1131a responseHandler) {
        m4730c(url, null, null, responseHandler, 60000);
    }

    static void m4731c(String url, JSONObject jsonBody, C1131a responseHandler) {
        m4730c(url, "PUT", jsonBody, responseHandler, 120000);
    }

    static void m4733d(String url, JSONObject jsonBody, C1131a responseHandler) {
        m4730c(url, "POST", jsonBody, responseHandler, 120000);
    }

    private static void m4730c(String url, String method, JSONObject jsonBody, C1131a responseHandler, int timeout) {
        final Thread[] callbackThread = new Thread[1];
        final String str = url;
        final String str2 = method;
        final JSONObject jSONObject = jsonBody;
        final C1131a c1131a = responseHandler;
        final int i = timeout;
        Thread connectionThread = new Thread(new Runnable() {
            public void run() {
                callbackThread[0] = ac.m4732d(str, str2, jSONObject, c1131a, i);
            }
        }, "OS_HTTPConnection");
        connectionThread.start();
        try {
            connectionThread.join((long) m4721a(timeout));
            if (connectionThread.getState() != State.TERMINATED) {
                connectionThread.interrupt();
            }
            if (callbackThread[0] != null) {
                callbackThread[0].join();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private static Thread m4732d(String url, String method, JSONObject jsonBody, C1131a responseHandler, int timeout) {
        Thread callbackThread;
        HttpURLConnection con = null;
        int httpResponse = -1;
        String json = null;
        try {
            C1226z.m5060a(C1222e.DEBUG, "OneSignalRestClient: Making request to: https://onesignal.com/api/v1/" + url);
            con = (HttpURLConnection) new URL("https://onesignal.com/api/v1/" + url).openConnection();
            con.setUseCaches(false);
            con.setConnectTimeout(timeout);
            con.setReadTimeout(timeout);
            if (jsonBody != null) {
                con.setDoInput(true);
            }
            if (method != null) {
                con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                con.setRequestMethod(method);
                con.setDoOutput(true);
            }
            if (jsonBody != null) {
                String strJsonBody = jsonBody.toString();
                C1226z.m5060a(C1222e.DEBUG, "OneSignalRestClient: " + method + " SEND JSON: " + strJsonBody);
                byte[] sendBytes = strJsonBody.getBytes("UTF-8");
                con.setFixedLengthStreamingMode(sendBytes.length);
                con.getOutputStream().write(sendBytes);
            }
            httpResponse = con.getResponseCode();
            C1226z.m5060a(C1222e.VERBOSE, "OneSignalRestClient: After con.getResponseCode  to: https://onesignal.com/api/v1/" + url);
            Scanner scanner;
            if (httpResponse == 200) {
                C1226z.m5060a(C1222e.DEBUG, "OneSignalRestClient: Successfully finished request to: https://onesignal.com/api/v1/" + url);
                scanner = new Scanner(con.getInputStream(), "UTF-8");
                json = scanner.useDelimiter("\\A").hasNext() ? scanner.next() : "";
                scanner.close();
                C1226z.m5060a(C1222e.DEBUG, method + " RECEIVED JSON: " + json);
                callbackThread = m4723a(responseHandler, json);
            } else {
                C1226z.m5060a(C1222e.DEBUG, "OneSignalRestClient: Failed request to: https://onesignal.com/api/v1/" + url);
                InputStream inputStream = con.getErrorStream();
                if (inputStream == null) {
                    inputStream = con.getInputStream();
                }
                if (inputStream != null) {
                    scanner = new Scanner(inputStream, "UTF-8");
                    json = scanner.useDelimiter("\\A").hasNext() ? scanner.next() : "";
                    scanner.close();
                    C1226z.m5060a(C1222e.WARN, "OneSignalRestClient: " + method + " RECEIVED JSON: " + json);
                } else {
                    C1226z.m5060a(C1222e.WARN, "OneSignalRestClient: " + method + " HTTP Code: " + httpResponse + " No response body!");
                }
                callbackThread = m4722a(responseHandler, httpResponse, json, null);
            }
            if (con != null) {
                con.disconnect();
            }
        } catch (Throwable th) {
            if (con != null) {
                con.disconnect();
            }
        }
        return callbackThread;
    }

    private static Thread m4723a(final C1131a handler, final String response) {
        if (handler == null) {
            return null;
        }
        Thread thread = new Thread(new Runnable() {
            public void run() {
                handler.mo1133a(response);
            }
        });
        thread.start();
        return thread;
    }

    private static Thread m4722a(final C1131a handler, final int statusCode, final String response, final Throwable throwable) {
        if (handler == null) {
            return null;
        }
        Thread thread = new Thread(new Runnable() {
            public void run() {
                handler.mo1132a(statusCode, response, throwable);
            }
        });
        thread.start();
        return thread;
    }
}
