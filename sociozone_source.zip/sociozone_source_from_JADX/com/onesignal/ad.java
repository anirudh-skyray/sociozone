package com.onesignal;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Handler;
import android.os.HandlerThread;
import com.onesignal.C1175i.C1173e;
import com.onesignal.C1226z.C1222e;
import com.onesignal.ac.C1131a;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: OneSignalStateSynchronizer */
class ad {
    static HashMap<Integer, C1139b> f2357a = new HashMap();
    private static boolean f2358b = false;
    private static boolean f2359c = false;
    private static C1140c f2360d;
    private static C1140c f2361e;
    private static final Object f2362f = new C11321();
    private static Context f2363g;
    private static final String[] f2364h = new String[]{"lat", "long", "loc_acc", "loc_type", "loc_bg", "ad_id"};
    private static final Set<String> f2365i = new HashSet(Arrays.asList(f2364h));
    private static final Object f2366j = new C11332();
    private static boolean f2367k;

    /* compiled from: OneSignalStateSynchronizer */
    static class C11321 {
        C11321() {
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    static class C11332 {
        C11332() {
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    static class C11365 extends C1131a {
        C11365() {
        }

        void mo1133a(String responseStr) {
            ad.f2367k = true;
            try {
                JSONObject lastGetTagsResponse = new JSONObject(responseStr);
                if (lastGetTagsResponse.has("tags")) {
                    synchronized (ad.f2366j) {
                        JSONObject dependDiff = ad.m4776b(ad.f2360d.f2351b.optJSONObject("tags"), ad.f2361e.f2351b.optJSONObject("tags"), null, null);
                        ad.f2360d.f2351b.put("tags", lastGetTagsResponse.optJSONObject("tags"));
                        ad.f2360d.m4756d();
                        ad.f2361e.m4759a(lastGetTagsResponse, dependDiff);
                        ad.f2361e.m4756d();
                    }
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    static class C1137a {
        public boolean f2344a;
        public JSONObject f2345b;

        C1137a(boolean serverSuccess, JSONObject result) {
            this.f2344a = serverSuccess;
            this.f2345b = result;
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    static class C1139b extends HandlerThread {
        int f2347a;
        Handler f2348b = null;
        int f2349c;

        /* compiled from: OneSignalStateSynchronizer */
        class C11381 implements Runnable {
            final /* synthetic */ C1139b f2346a;

            C11381(C1139b this$0) {
                this.f2346a = this$0;
            }

            public void run() {
                ad.m4769a(false);
            }
        }

        C1139b(int type) {
            super("OSH_NetworkHandlerThread");
            this.f2347a = type;
            start();
            this.f2348b = new Handler(getLooper());
        }

        void m4740a() {
            this.f2349c = 0;
            this.f2348b.removeCallbacksAndMessages(null);
            this.f2348b.postDelayed(m4739d(), 5000);
        }

        private Runnable m4739d() {
            switch (this.f2347a) {
                case 0:
                    return new C11381(this);
                default:
                    return null;
            }
        }

        void m4741b() {
            this.f2348b.removeCallbacksAndMessages(null);
        }

        void m4742c() {
            if (this.f2349c < 3 && !this.f2348b.hasMessages(0)) {
                this.f2349c++;
                this.f2348b.postDelayed(m4739d(), (long) (this.f2349c * 15000));
            }
        }
    }

    /* compiled from: OneSignalStateSynchronizer */
    class C1140c {
        JSONObject f2350a;
        JSONObject f2351b;
        final /* synthetic */ ad f2352c;
        private final int f2353d;
        private final int f2354e;
        private final int f2355f;
        private String f2356g;

        private C1140c(ad this$0, String inPersistKey, boolean load) {
            this.f2352c = this$0;
            this.f2353d = 1;
            this.f2354e = 0;
            this.f2355f = -2;
            this.f2356g = inPersistKey;
            if (load) {
                m4755c();
                return;
            }
            this.f2350a = new JSONObject();
            this.f2351b = new JSONObject();
        }

        private C1140c m4744a(String persistKey) {
            C1140c clonedUserState = new C1140c(this.f2352c, persistKey, false);
            try {
                clonedUserState.f2350a = new JSONObject(this.f2350a.toString());
                clonedUserState.f2351b = new JSONObject(this.f2351b.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
            return clonedUserState;
        }

        private void m4747a() {
            try {
                this.f2351b.put("notification_types", m4750b());
            } catch (JSONException e) {
            }
        }

        private int m4750b() {
            int subscribableStatus = this.f2350a.optInt("subscribableStatus", 1);
            if (subscribableStatus < -2) {
                return subscribableStatus;
            }
            if (!this.f2350a.optBoolean("androidPermission", true)) {
                return 0;
            }
            if (this.f2350a.optBoolean("userSubscribePref", true)) {
                return 1;
            }
            return -2;
        }

        private Set<String> m4754c(C1140c changedTo) {
            try {
                if (!(this.f2350a.optLong("loc_time_stamp") == changedTo.f2350a.getLong("loc_time_stamp") && this.f2351b.optDouble("lat") == changedTo.f2351b.getDouble("lat") && this.f2351b.optDouble("long") == changedTo.f2351b.getDouble("long") && this.f2351b.optDouble("loc_acc") == changedTo.f2351b.getDouble("loc_acc") && this.f2351b.optInt("loc_type ") == changedTo.f2351b.optInt("loc_type"))) {
                    changedTo.f2351b.put("loc_bg", changedTo.f2350a.opt("loc_bg"));
                    return ad.f2365i;
                }
            } catch (Throwable th) {
            }
            return null;
        }

        void m4757a(C1173e point) {
            try {
                this.f2351b.put("lat", point.f2426a);
                this.f2351b.put("long", point.f2427b);
                this.f2351b.put("loc_acc", point.f2428c);
                this.f2351b.put("loc_type", point.f2429d);
                this.f2350a.put("loc_bg", point.f2430e);
                this.f2350a.put("loc_time_stamp", point.f2431f);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private JSONObject m4746a(C1140c newState, boolean isSessionCall) {
            m4747a();
            newState.m4747a();
            JSONObject sendJson = ad.m4776b(this.f2351b, newState.f2351b, null, m4754c(newState));
            if (!isSessionCall && sendJson.toString().equals("{}")) {
                return null;
            }
            try {
                if (sendJson.has("app_id")) {
                    return sendJson;
                }
                sendJson.put("app_id", this.f2351b.optString("app_id"));
                return sendJson;
            } catch (JSONException e) {
                e.printStackTrace();
                return sendJson;
            }
        }

        void m4758a(String key, Object value) {
            try {
                this.f2351b.put(key, value);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        void m4760b(String key, Object value) {
            try {
                this.f2350a.put(key, value);
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }

        private void m4755c() {
            SharedPreferences prefs = C1226z.m5091d(ad.f2363g);
            String dependValuesStr = prefs.getString("ONESIGNAL_USERSTATE_DEPENDVALYES_" + this.f2356g, null);
            if (dependValuesStr == null) {
                this.f2350a = new JSONObject();
                boolean userSubscribePref = true;
                try {
                    int subscribableStatus;
                    if (this.f2356g.equals("CURRENT_STATE")) {
                        subscribableStatus = prefs.getInt("ONESIGNAL_SUBSCRIPTION", 1);
                    } else {
                        subscribableStatus = prefs.getInt("ONESIGNAL_SYNCED_SUBSCRIPTION", 1);
                    }
                    if (subscribableStatus == -2) {
                        subscribableStatus = 1;
                        userSubscribePref = false;
                    }
                    this.f2350a.put("subscribableStatus", subscribableStatus);
                    this.f2350a.put("userSubscribePref", userSubscribePref);
                } catch (JSONException e) {
                }
            } else {
                try {
                    this.f2350a = new JSONObject(dependValuesStr);
                } catch (JSONException e2) {
                    e2.printStackTrace();
                }
            }
            String syncValuesStr = prefs.getString("ONESIGNAL_USERSTATE_SYNCVALYES_" + this.f2356g, null);
            if (syncValuesStr == null) {
                try {
                    this.f2351b = new JSONObject();
                    this.f2351b.put("identifier", prefs.getString("GT_REGISTRATION_ID", null));
                    return;
                } catch (JSONException e22) {
                    e22.printStackTrace();
                    return;
                }
            }
            this.f2351b = new JSONObject(syncValuesStr);
        }

        private void m4756d() {
            synchronized (ad.f2366j) {
                m4752b("pkgs");
                Editor editor = C1226z.m5091d(ad.f2363g).edit();
                editor.putString("ONESIGNAL_USERSTATE_SYNCVALYES_" + this.f2356g, this.f2351b.toString());
                editor.putString("ONESIGNAL_USERSTATE_DEPENDVALYES_" + this.f2356g, this.f2350a.toString());
                editor.commit();
            }
        }

        private void m4752b(String baseKey) {
            if (this.f2351b.has(baseKey + "_d") || !this.f2351b.has(baseKey + "_d")) {
                try {
                    JSONArray orgArray;
                    int i;
                    if (this.f2351b.has(baseKey)) {
                        orgArray = this.f2351b.getJSONArray(baseKey);
                    } else {
                        orgArray = new JSONArray();
                    }
                    JSONArray tempArray = new JSONArray();
                    if (this.f2351b.has(baseKey + "_d")) {
                        String remArrayStr = ad.m4774b(this.f2351b.getJSONArray(baseKey + "_d"));
                        for (i = 0; i < orgArray.length(); i++) {
                            if (!remArrayStr.contains(orgArray.getString(i))) {
                                tempArray.put(orgArray.get(i));
                            }
                        }
                    } else {
                        tempArray = orgArray;
                    }
                    if (this.f2351b.has(baseKey + "_a")) {
                        JSONArray newArray = this.f2351b.getJSONArray(baseKey + "_a");
                        for (i = 0; i < newArray.length(); i++) {
                            tempArray.put(newArray.get(i));
                        }
                    }
                    this.f2351b.put(baseKey, tempArray);
                    this.f2351b.remove(baseKey + "_a");
                    this.f2351b.remove(baseKey + "_d");
                } catch (Throwable th) {
                }
            }
        }

        private void m4753b(JSONObject inDependValues, JSONObject inSyncValues) {
            if (inDependValues != null) {
                ad.m4776b(this.f2350a, inDependValues, this.f2350a, null);
            }
            if (inSyncValues != null) {
                ad.m4776b(this.f2351b, inSyncValues, this.f2351b, null);
                m4759a(inSyncValues, null);
            }
            if (inDependValues != null || inSyncValues != null) {
                m4756d();
            }
        }

        void m4759a(JSONObject inSyncValues, JSONObject omitKeys) {
            synchronized (ad.f2366j) {
                if (inSyncValues.has("tags")) {
                    JSONObject newTags;
                    if (this.f2351b.has("tags")) {
                        try {
                            newTags = new JSONObject(this.f2351b.optString("tags"));
                        } catch (JSONException e) {
                            newTags = new JSONObject();
                        }
                    } else {
                        newTags = new JSONObject();
                    }
                    JSONObject curTags = inSyncValues.optJSONObject("tags");
                    Iterator<String> keys = curTags.keys();
                    while (keys.hasNext()) {
                        String key = (String) keys.next();
                        if ("".equals(curTags.optString(key))) {
                            newTags.remove(key);
                        } else {
                            if (omitKeys != null) {
                                try {
                                    if (omitKeys.has(key)) {
                                    }
                                } catch (Throwable th) {
                                }
                            }
                            newTags.put(key, curTags.optString(key));
                        }
                    }
                    if (newTags.toString().equals("{}")) {
                        this.f2351b.remove("tags");
                    } else {
                        this.f2351b.put("tags", newTags);
                    }
                }
            }
        }
    }

    ad() {
    }

    private static C1140c m4794m() {
        synchronized (f2366j) {
            if (f2361e == null) {
                ad adVar = new ad();
                adVar.getClass();
                f2361e = new C1140c("TOSYNC_STATE", true);
            }
        }
        return f2361e;
    }

    private static JSONObject m4776b(JSONObject cur, JSONObject changedTo, JSONObject baseOutput, Set<String> includeFields) {
        JSONObject c;
        synchronized (f2366j) {
            c = m4780c(cur, changedTo, baseOutput, includeFields);
        }
        return c;
    }

    private static JSONObject m4780c(JSONObject cur, JSONObject changedTo, JSONObject baseOutput, Set<String> includeFields) {
        if (cur == null) {
            return null;
        }
        if (changedTo == null) {
            return baseOutput;
        }
        JSONObject output;
        Iterator<String> keys = changedTo.keys();
        if (baseOutput != null) {
            output = baseOutput;
        } else {
            output = new JSONObject();
        }
        while (keys.hasNext()) {
            try {
                String key = (String) keys.next();
                Object value = changedTo.get(key);
                if (cur.has(key)) {
                    if (value instanceof JSONObject) {
                        JSONObject curValue = cur.getJSONObject(key);
                        JSONObject outValue = null;
                        if (baseOutput != null && baseOutput.has(key)) {
                            outValue = baseOutput.getJSONObject(key);
                        }
                        String returnedJsonStr = m4780c(curValue, (JSONObject) value, outValue, includeFields).toString();
                        if (!returnedJsonStr.equals("{}")) {
                            output.put(key, new JSONObject(returnedJsonStr));
                        }
                    } else if (value instanceof JSONArray) {
                        m4767a(key, (JSONArray) value, cur.getJSONArray(key), output);
                    } else if (includeFields == null || !includeFields.contains(key)) {
                        Object curValue2 = cur.get(key);
                        if (!value.equals(curValue2)) {
                            if (!(curValue2 instanceof Integer) || "".equals(value)) {
                                output.put(key, value);
                            } else if (((Number) curValue2).doubleValue() != ((Number) value).doubleValue()) {
                                output.put(key, value);
                            }
                        }
                    } else {
                        output.put(key, value);
                    }
                } else if (value instanceof JSONObject) {
                    output.put(key, new JSONObject(value.toString()));
                } else if (value instanceof JSONArray) {
                    m4767a(key, (JSONArray) value, null, output);
                } else {
                    output.put(key, value);
                }
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
        return output;
    }

    private static void m4767a(String key, JSONArray newArray, JSONArray curArray, JSONObject output) throws JSONException {
        if (key.endsWith("_a") || key.endsWith("_d")) {
            output.put(key, newArray);
            return;
        }
        int i;
        String arrayStr = m4774b(newArray);
        JSONArray newOutArray = new JSONArray();
        JSONArray remOutArray = new JSONArray();
        String curArrayStr = curArray == null ? null : m4774b(curArray);
        for (i = 0; i < newArray.length(); i++) {
            String arrayValue = (String) newArray.get(i);
            if (curArray == null || !curArrayStr.contains(arrayValue)) {
                newOutArray.put(arrayValue);
            }
        }
        if (curArray != null) {
            for (i = 0; i < curArray.length(); i++) {
                arrayValue = curArray.getString(i);
                if (!arrayStr.contains(arrayValue)) {
                    remOutArray.put(arrayValue);
                }
            }
        }
        if (!newOutArray.toString().equals("[]")) {
            output.put(key + "_a", newOutArray);
        }
        if (!remOutArray.toString().equals("[]")) {
            output.put(key + "_d", remOutArray);
        }
    }

    private static String m4774b(JSONArray jsonArray) {
        String strArray = "[";
        int i = 0;
        while (i < jsonArray.length()) {
            try {
                strArray = strArray + "\"" + jsonArray.getString(i) + "\"";
                i++;
            } catch (Throwable th) {
            }
        }
        return strArray + "]";
    }

    private static JSONObject m4775b(JSONObject jsonObject) {
        if (!jsonObject.has("tags")) {
            return null;
        }
        JSONObject toReturn = new JSONObject();
        synchronized (f2366j) {
            JSONObject keyValues = jsonObject.optJSONObject("tags");
            Iterator<String> keys = keyValues.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                try {
                    Object value = keyValues.get(key);
                    if (!"".equals(value)) {
                        toReturn.put(key, value);
                    }
                } catch (Throwable th) {
                }
            }
        }
        return toReturn;
    }

    static boolean m4770a() {
        boolean unSynced = false;
        for (Entry<Integer, C1139b> handlerThread : f2357a.entrySet()) {
            ((C1139b) handlerThread.getValue()).m4741b();
        }
        if (f2361e != null) {
            if (f2360d.m4746a(f2361e, m4795n()) != null) {
                unSynced = true;
            }
            f2361e.m4756d();
        }
        return unSynced;
    }

    static void m4764a(Context context) {
        f2363g = context;
        synchronized (f2366j) {
            if (f2360d == null) {
                ad adVar = new ad();
                adVar.getClass();
                f2360d = new C1140c("CURRENT_STATE", true);
            }
            if (f2361e == null) {
                adVar = new ad();
                adVar.getClass();
                f2361e = new C1140c("TOSYNC_STATE", true);
            }
        }
    }

    static C1140c m4773b() {
        ad adVar = new ad();
        adVar.getClass();
        return new C1140c("nonPersist", false);
    }

    private static boolean m4795n() {
        return C1226z.m5104g() == null || (f2358b && !f2359c);
    }

    static void m4769a(boolean fromSyncService) {
        String userId = C1226z.m5104g();
        boolean isSessionCall = m4795n();
        final JSONObject jsonBody = f2360d.m4746a(f2361e, isSessionCall);
        final JSONObject dependDiff = m4776b(f2360d.f2350a, f2361e.f2350a, null, null);
        if (jsonBody == null) {
            f2360d.m4753b(dependDiff, null);
            return;
        }
        f2361e.m4756d();
        if (userId == null && !f2358b) {
            return;
        }
        if (!isSessionCall || fromSyncService) {
            ac.m4731c("players/" + userId, jsonBody, new C1131a() {
                void mo1132a(int statusCode, String response, Throwable throwable) {
                    C1226z.m5060a(C1222e.WARN, "Failed last request. statusCode: " + statusCode + "\nresponse: " + response);
                    if (ad.m4778b(statusCode, response, "No user with this id found")) {
                        ad.m4798q();
                    } else {
                        ad.m4772b(Integer.valueOf(0)).m4742c();
                    }
                }

                void mo1133a(String response) {
                    ad.f2360d.m4753b(dependDiff, jsonBody);
                }
            });
            return;
        }
        String urlStr;
        if (userId == null) {
            urlStr = "players";
        } else {
            urlStr = "players/" + userId + "/on_session";
        }
        f2359c = true;
        ac.m4733d(urlStr, jsonBody, new C1131a() {
            void mo1132a(int statusCode, String response, Throwable throwable) {
                ad.f2359c = false;
                C1226z.m5060a(C1222e.WARN, "Failed last request. statusCode: " + statusCode + "\nresponse: " + response);
                if (ad.m4778b(statusCode, response, "not a valid device_type")) {
                    ad.m4798q();
                } else {
                    ad.m4772b(Integer.valueOf(0)).m4742c();
                }
            }

            void mo1133a(String response) {
                ad.f2358b = ad.f2359c = false;
                ad.f2360d.m4753b(dependDiff, jsonBody);
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    if (jsonResponse.has("id")) {
                        String userId = jsonResponse.optString("id");
                        C1226z.m5079b(userId);
                        C1226z.m5060a(C1222e.INFO, "Device registered, UserId = " + userId);
                    } else {
                        C1226z.m5060a(C1222e.INFO, "session sent, UserId = " + C1226z.m5104g());
                    }
                    C1226z.m5117n();
                } catch (Throwable t) {
                    C1226z.m5061a(C1222e.ERROR, "ERROR parsing on_session or create JSON Response.", t);
                }
            }
        });
    }

    private static boolean m4778b(int statusCode, String response, String contains) {
        if (statusCode != 400 || response == null) {
            return false;
        }
        try {
            JSONObject responseJson = new JSONObject(response);
            if (responseJson.has("errors") && responseJson.optString("errors").contains(contains)) {
                return true;
            }
            return false;
        } catch (Throwable t) {
            t.printStackTrace();
            return false;
        }
    }

    private static C1139b m4772b(Integer type) {
        C1139b c1139b;
        synchronized (f2362f) {
            if (!f2357a.containsKey(type)) {
                f2357a.put(type, new C1139b(type.intValue()));
            }
            c1139b = (C1139b) f2357a.get(type);
        }
        return c1139b;
    }

    private static C1140c m4796o() {
        if (f2361e == null) {
            f2361e = f2360d.m4744a("TOSYNC_STATE");
        }
        m4797p();
        return f2361e;
    }

    private static void m4797p() {
        m4772b(Integer.valueOf(0)).m4740a();
    }

    static void m4765a(C1140c postSession, boolean isSession) {
        JSONObject toSync = m4796o().f2351b;
        m4776b(toSync, postSession.f2351b, toSync, null);
        JSONObject dependValues = m4796o().f2350a;
        m4776b(dependValues, postSession.f2350a, dependValues, null);
        boolean z = f2358b || isSession || C1226z.m5104g() == null;
        f2358b = z;
    }

    static void m4768a(JSONObject newTags) {
        JSONObject userStateTags = m4796o().f2351b;
        try {
            m4776b(userStateTags, new JSONObject().put("tags", newTags), userStateTags, null);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    static boolean m4781c() {
        return m4794m().f2350a.optBoolean("userSubscribePref", true);
    }

    static void m4777b(boolean enable) {
        try {
            m4796o().f2350a.put("androidPermission", enable);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    static void m4766a(C1173e point) {
        m4796o().m4757a(point);
    }

    static boolean m4782d() {
        return m4794m().m4750b() > 0;
    }

    static String m4784e() {
        return m4794m().f2351b.optString("identifier", null);
    }

    static C1137a m4779c(boolean fromServer) {
        C1137a c1137a;
        if (fromServer) {
            String userId = C1226z.m5104g();
            ac.m4728b("players/" + userId + "?app_id=" + C1226z.m5101f(), new C11365());
        }
        synchronized (f2366j) {
            c1137a = new C1137a(f2367k, m4775b(m4794m().f2351b));
        }
        return c1137a;
    }

    static void m4786f() {
        C1226z.m5063a(null);
        f2360d.f2351b = new JSONObject();
        f2360d.m4756d();
        C1226z.m5052a(-3660);
    }

    private static void m4798q() {
        m4786f();
        f2358b = true;
        m4797p();
    }
}
