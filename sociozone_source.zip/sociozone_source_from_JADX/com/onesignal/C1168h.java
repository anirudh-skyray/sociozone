package com.onesignal;

import com.google.android.gms.common.api.GoogleApiClient;

/* compiled from: GoogleApiClientCompatProxy */
class C1168h {
    private final GoogleApiClient f2423a;
    private final Class f2424b;

    C1168h(GoogleApiClient googleApiClient) {
        this.f2423a = googleApiClient;
        this.f2424b = googleApiClient.getClass();
    }

    void m4889a() {
        try {
            this.f2424b.getMethod("connect", new Class[0]).invoke(this.f2423a, new Object[0]);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    void m4890b() {
        try {
            this.f2424b.getMethod("disconnect", new Class[0]).invoke(this.f2423a, new Object[0]);
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    GoogleApiClient m4891c() {
        return this.f2423a;
    }
}
