package com.onesignal;

import java.util.List;
import org.json.JSONObject;

/* compiled from: OSNotificationPayload */
public class C1201t {
    public String f2497a;
    public String f2498b;
    public String f2499c;
    public JSONObject f2500d;
    public String f2501e;
    public String f2502f;
    public String f2503g;
    public String f2504h;
    public String f2505i;
    public String f2506j;
    public String f2507k;
    public int f2508l = 1;
    public String f2509m;
    public String f2510n;
    public List<C1199a> f2511o;
    public String f2512p;
    public C1200b f2513q;
    public String f2514r;
    public int f2515s;
    public String f2516t;

    /* compiled from: OSNotificationPayload */
    public static class C1199a {
        public String f2491a;
        public String f2492b;
        public String f2493c;
    }

    /* compiled from: OSNotificationPayload */
    public static class C1200b {
        public String f2494a;
        public String f2495b;
        public String f2496c;
    }
}
