package com.onesignal;

/* compiled from: OSNotificationAction */
public class C1190r {
    public C1189a f2475a;
    public String f2476b;

    /* compiled from: OSNotificationAction */
    public enum C1189a {
        Opened,
        ActionTaken
    }
}
