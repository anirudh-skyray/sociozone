package com.onesignal;

/* compiled from: OSNotificationOpenResult */
public class C1191s {
    public C1188q f2477a;
    public C1190r f2478b;
}
