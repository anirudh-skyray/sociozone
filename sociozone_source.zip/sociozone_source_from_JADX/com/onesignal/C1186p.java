package com.onesignal;

import android.app.NotificationManager;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: NotificationSummaryManager */
class C1186p {
    static void m4945a(android.content.Context r4, android.database.sqlite.SQLiteDatabase r5, java.lang.String r6, boolean r7) {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = 0;
        r0 = com.onesignal.C1186p.m4947b(r4, r5, r6, r7);	 Catch:{ Throwable -> 0x0011, all -> 0x0025 }
        if (r0 == 0) goto L_0x0010;
    L_0x0007:
        r2 = r0.isClosed();
        if (r2 != 0) goto L_0x0010;
    L_0x000d:
        r0.close();
    L_0x0010:
        return;
    L_0x0011:
        r1 = move-exception;
        r2 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x0011, all -> 0x0025 }
        r3 = "Error running updateSummaryNotificationAfterChildRemoved!";	 Catch:{ Throwable -> 0x0011, all -> 0x0025 }
        com.onesignal.C1226z.m5061a(r2, r3, r1);	 Catch:{ Throwable -> 0x0011, all -> 0x0025 }
        if (r0 == 0) goto L_0x0010;
    L_0x001b:
        r2 = r0.isClosed();
        if (r2 != 0) goto L_0x0010;
    L_0x0021:
        r0.close();
        goto L_0x0010;
    L_0x0025:
        r2 = move-exception;
        if (r0 == 0) goto L_0x0031;
    L_0x0028:
        r3 = r0.isClosed();
        if (r3 != 0) goto L_0x0031;
    L_0x002e:
        r0.close();
    L_0x0031:
        throw r2;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.p.a(android.content.Context, android.database.sqlite.SQLiteDatabase, java.lang.String, boolean):void");
    }

    private static void m4946a(android.content.Context r11, java.lang.String r12) {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r9 = com.onesignal.ab.m4715a(r11);
        r8 = 0;
        r1 = 1;
        r4 = new java.lang.String[r1];
        r1 = 0;
        r4[r1] = r12;
        r0 = r9.m4718b();	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r1 = "notification";	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r2 = com.onesignal.C1185o.f2460a;	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r3 = "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0";	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r5 = 0;	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r6 = 0;	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r7 = 0;	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r8 = r0.query(r1, r2, r3, r4, r5, r6, r7);	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        com.onesignal.C1185o.m4942a(r11, r8);	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        if (r8 == 0) goto L_0x002a;
    L_0x0021:
        r1 = r8.isClosed();
        if (r1 != 0) goto L_0x002a;
    L_0x0027:
        r8.close();
    L_0x002a:
        return;
    L_0x002b:
        r10 = move-exception;
        r1 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        r2 = "Error restoring notification records! ";	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        com.onesignal.C1226z.m5061a(r1, r2, r10);	 Catch:{ Throwable -> 0x002b, all -> 0x003f }
        if (r8 == 0) goto L_0x002a;
    L_0x0035:
        r1 = r8.isClosed();
        if (r1 != 0) goto L_0x002a;
    L_0x003b:
        r8.close();
        goto L_0x002a;
    L_0x003f:
        r1 = move-exception;
        if (r8 == 0) goto L_0x004b;
    L_0x0042:
        r2 = r8.isClosed();
        if (r2 != 0) goto L_0x004b;
    L_0x0048:
        r8.close();
    L_0x004b:
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.p.a(android.content.Context, java.lang.String):void");
    }

    private static Cursor m4947b(Context context, SQLiteDatabase writableDb, String group, boolean dismissed) {
        Cursor cursor = writableDb.query("notification", new String[]{"android_notification_id", "created_time"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{group}, null, null, "_id DESC");
        int notifsInGroup = cursor.getCount();
        if (notifsInGroup == 0) {
            cursor.close();
            Integer androidNotifId = C1186p.m4944a(writableDb, group);
            if (androidNotifId != null) {
                ((NotificationManager) context.getSystemService("notification")).cancel(androidNotifId.intValue());
                ContentValues values = new ContentValues();
                values.put(dismissed ? "dismissed" : "opened", Integer.valueOf(1));
                writableDb.update("notification", values, "android_notification_id = " + androidNotifId, null);
            }
        } else if (notifsInGroup == 1) {
            cursor.close();
            if (C1186p.m4944a(writableDb, group) != null) {
                C1186p.m4946a(context, group);
            }
        } else {
            try {
                cursor.moveToFirst();
                Long datetime = Long.valueOf(cursor.getLong(cursor.getColumnIndex("created_time")));
                cursor.close();
                if (C1186p.m4944a(writableDb, group) != null) {
                    C1181l notifJob = new C1181l(context);
                    notifJob.f2449c = true;
                    notifJob.f2451e = datetime;
                    JSONObject payload = new JSONObject();
                    payload.put("grp", group);
                    notifJob.f2448b = payload;
                    C1167g.m4876b(notifJob);
                }
            } catch (JSONException e) {
            }
        }
        return cursor;
    }

    private static Integer m4944a(SQLiteDatabase writableDb, String group) {
        Integer androidNotifId = null;
        Cursor cursor = null;
        try {
            SQLiteDatabase sQLiteDatabase = writableDb;
            cursor = sQLiteDatabase.query("notification", new String[]{"android_notification_id"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 1", new String[]{group}, null, null, null);
            if (cursor.moveToFirst()) {
                androidNotifId = Integer.valueOf(cursor.getInt(cursor.getColumnIndex("android_notification_id")));
                cursor.close();
                if (!(cursor == null || cursor.isClosed())) {
                    cursor.close();
                }
                return androidNotifId;
            }
            cursor.close();
            if (!(cursor == null || cursor.isClosed())) {
                cursor.close();
            }
            return null;
        } catch (Throwable th) {
            if (!(cursor == null || cursor.isClosed())) {
                cursor.close();
            }
        }
    }
}
