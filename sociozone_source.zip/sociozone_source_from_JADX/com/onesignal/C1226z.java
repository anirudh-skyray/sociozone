package com.onesignal;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Base64;
import android.util.Log;
import com.onesignal.C1175i.C1115c;
import com.onesignal.C1175i.C1173e;
import com.onesignal.C1188q.C1187a;
import com.onesignal.C1190r.C1189a;
import com.onesignal.ac.C1131a;
import com.onesignal.ad.C1137a;
import com.onesignal.ad.C1140c;
import com.onesignal.ae.C1141a;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.TimeZone;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: OneSignal */
public class C1226z {
    private static boolean f2558A;
    private static boolean f2559B;
    private static boolean f2560C;
    private static C1173e f2561D;
    private static Collection<JSONArray> f2562E = new ArrayList();
    private static HashSet<String> f2563F = new HashSet();
    private static C1219b f2564G;
    private static boolean f2565H;
    private static boolean f2566I;
    private static boolean f2567J;
    private static JSONObject f2568K;
    private static C1204v f2569L;
    private static C1203u<Object, C1205w> f2570M;
    private static OSSubscriptionState f2571N;
    private static C1203u<Object, C1206x> f2572O;
    private static C1220c f2573P;
    private static int f2574Q = 0;
    static String f2575a;
    static Context f2576b;
    static boolean f2577c;
    public static String f2578d = "native";
    static boolean f2579e = true;
    static C1218a f2580f;
    static boolean f2581g;
    static C1204v f2582h;
    static OSSubscriptionState f2583i;
    private static String f2584j;
    private static boolean f2585k;
    private static C1222e f2586l = C1222e.NONE;
    private static C1222e f2587m = C1222e.WARN;
    private static String f2588n = null;
    private static int f2589o;
    private static boolean f2590p;
    private static C1221d f2591q;
    private static long f2592r = 1;
    private static long f2593s = -1;
    private static ak f2594t;
    private static aj f2595u;
    private static C1155d f2596v = new C1156c();
    private static int f2597w;
    private static C1207y f2598x;
    private static String f2599y;
    private static boolean f2600z;

    /* compiled from: OneSignal */
    static class C12081 implements C1115c {
        C12081() {
        }

        public void mo1128a(C1173e point) {
            C1226z.f2561D = point;
            C1226z.f2558A = true;
            C1226z.m5043M();
        }
    }

    /* compiled from: OneSignal */
    static class C12103 extends C1131a {
        C12103() {
        }

        void mo1132a(int statusCode, String response, Throwable throwable) {
            C1226z.m5080b("sending Notification Opened Failed", statusCode, throwable, response);
        }
    }

    /* compiled from: OneSignal */
    static class C12114 implements C1115c {
        C12114() {
        }

        public void mo1128a(C1173e point) {
            if (point != null) {
                ad.m4766a(point);
            }
        }
    }

    /* compiled from: OneSignal */
    static class C12125 implements C1141a {
        C12125() {
        }

        public void mo1139a(String id, int status) {
            if (status < 1) {
                if (ad.m4784e() == null && (C1226z.f2589o == 1 || C1226z.f2589o < -6)) {
                    C1226z.f2589o = status;
                }
            } else if (C1226z.f2589o < -6) {
                C1226z.f2589o = status;
            }
            C1226z.f2599y = id;
            C1226z.f2600z = true;
            C1226z.m5103g(C1226z.f2576b).m4676b(id);
            C1226z.m5043M();
        }
    }

    /* compiled from: OneSignal */
    static class C12146 extends C1131a {

        /* compiled from: OneSignal */
        class C12131 implements Runnable {
            final /* synthetic */ C12146 f2532a;

            C12131(C12146 this$0) {
                this.f2532a = this$0;
            }

            public void run() {
                try {
                    int sleepTime = (C1226z.f2574Q * 10000) + 30000;
                    if (sleepTime > 90000) {
                        sleepTime = 90000;
                    }
                    C1226z.m5060a(C1222e.INFO, "Failed to get Android parameters, trying again in " + (sleepTime / 1000) + " seconds.");
                    Thread.sleep((long) sleepTime);
                } catch (Throwable th) {
                }
                C1226z.m5122s();
                C1226z.m5040J();
            }
        }

        C12146() {
        }

        void mo1132a(int statusCode, String response, Throwable throwable) {
            new Thread(new C12131(this), "OS_PARAMS_REQUEST").start();
        }

        void mo1133a(String response) {
            try {
                JSONObject responseJson = new JSONObject(response);
                if (responseJson.has("android_sender_id")) {
                    C1226z.f2585k = true;
                    C1226z.f2584j = responseJson.getString("android_sender_id");
                }
                C1226z.f2581g = responseJson.optBoolean("enterp", false);
                C1226z.f2568K = responseJson.getJSONObject("awl_list");
            } catch (Throwable t) {
                t.printStackTrace();
            }
            C1226z.f2559B = true;
            C1226z.m5039I();
        }
    }

    /* compiled from: OneSignal */
    static class C12168 extends C1131a {
        C12168() {
        }

        void mo1132a(int statusCode, String response, Throwable throwable) {
            C1226z.m5080b("sending on_focus Failed", statusCode, throwable, response);
        }

        void mo1133a(String response) {
            C1226z.m5087c(0);
        }
    }

    /* compiled from: OneSignal */
    static class C12179 implements Runnable {
        C12179() {
        }

        public void run() {
            C1140c userState = ad.m4773b();
            Object packageName = C1226z.f2576b.getPackageName();
            PackageManager packageManager = C1226z.f2576b.getPackageManager();
            userState.m4758a("app_id", C1226z.f2575a);
            userState.m4758a("identifier", C1226z.f2599y);
            Object adId = C1226z.f2596v.mo1135a(C1226z.f2576b);
            if (adId != null) {
                userState.m4758a("ad_id", adId);
            }
            userState.m4758a("device_os", VERSION.RELEASE);
            userState.m4758a("timezone", Integer.valueOf(C1226z.m5042L()));
            userState.m4758a("language", C1207y.m5014d());
            userState.m4758a("sdk", (Object) "030508");
            userState.m4758a("sdk_type", C1226z.f2578d);
            userState.m4758a("android_package", packageName);
            userState.m4758a("device_model", Build.MODEL);
            userState.m4758a("device_type", Integer.valueOf(C1226z.f2597w));
            userState.m4760b("subscribableStatus", Integer.valueOf(C1226z.f2589o));
            userState.m4760b("androidPermission", Boolean.valueOf(C1226z.m5118o()));
            try {
                userState.m4758a("game_version", Integer.valueOf(packageManager.getPackageInfo(packageName, 0).versionCode));
            } catch (NameNotFoundException e) {
            }
            try {
                List<PackageInfo> packList = packageManager.getInstalledPackages(0);
                Object pkgs = new JSONArray();
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                for (int i = 0; i < packList.size(); i++) {
                    md.update(((PackageInfo) packList.get(i)).packageName.getBytes());
                    String pck = Base64.encodeToString(md.digest(), 2);
                    if (C1226z.f2568K.has(pck)) {
                        pkgs.put(pck);
                    }
                }
                userState.m4758a("pkgs", pkgs);
            } catch (Throwable th) {
            }
            userState.m4758a("net_type", C1226z.f2598x.m5017b());
            userState.m4758a("carrier", C1226z.f2598x.m5018c());
            userState.m4758a("rooted", Boolean.valueOf(ai.m4813a()));
            if (C1226z.f2561D != null) {
                userState.m4757a(C1226z.f2561D);
            }
            ad.m4765a(userState, C1226z.f2567J);
            C1226z.f2566I = false;
            aa.m4714a(C1226z.f2576b, C1226z.f2575a, C1226z.f2588n, C1156c.m4840a());
        }
    }

    /* compiled from: OneSignal */
    public static class C1218a {
        C1223f f2535a;
        C1224g f2536b;
        boolean f2537c;
        boolean f2538d;
        boolean f2539e;
        boolean f2540f;
        boolean f2541g;
        C1225h f2542h;

        private C1218a() {
            this.f2542h = C1225h.InAppAlert;
        }
    }

    /* compiled from: OneSignal */
    public interface C1219b {
        void mo1169a(JSONObject jSONObject);
    }

    /* compiled from: OneSignal */
    private static class C1220c {
        JSONArray f2543a;
        boolean f2544b;
        C1131a f2545c;

        C1220c(JSONArray toReport) {
            this.f2543a = toReport;
        }
    }

    /* compiled from: OneSignal */
    public interface C1221d {
        void mo1140a(String str, String str2);
    }

    /* compiled from: OneSignal */
    public enum C1222e {
        NONE,
        FATAL,
        ERROR,
        WARN,
        INFO,
        DEBUG,
        VERBOSE
    }

    /* compiled from: OneSignal */
    public interface C1223f {
        void mo1162a(C1191s c1191s);
    }

    /* compiled from: OneSignal */
    public interface C1224g {
        void m5030a(C1188q c1188q);
    }

    /* compiled from: OneSignal */
    public enum C1225h {
        None,
        InAppAlert,
        Notification
    }

    public static void m5114k() {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = f2576b;
        if (r1 != 0) goto L_0x000c;
    L_0x0004:
        r1 = com.onesignal.C1226z.C1222e.ERROR;
        r3 = "OneSignal.init has not been called. Could not clear notifications.";
        com.onesignal.C1226z.m5060a(r1, r3);
    L_0x000b:
        return;
    L_0x000c:
        r1 = f2576b;
        r3 = "notification";
        r11 = r1.getSystemService(r3);
        r11 = (android.app.NotificationManager) r11;
        r1 = f2576b;
        r9 = com.onesignal.ab.m4715a(r1);
        r8 = 0;
        r0 = r9.m4718b();	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r1 = 1;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r2 = new java.lang.String[r1];	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r1 = 0;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r3 = "android_notification_id";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r2[r1] = r3;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r1 = "notification";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r3 = "dismissed = 0 AND opened = 0";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r4 = 0;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r5 = 0;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r6 = 0;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r7 = 0;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r8 = r0.query(r1, r2, r3, r4, r5, r6, r7);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r1 = r8.moveToFirst();	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        if (r1 == 0) goto L_0x004e;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
    L_0x003b:
        r1 = "android_notification_id";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r1 = r8.getColumnIndex(r1);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r10 = r8.getInt(r1);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r11.cancel(r10);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r1 = r8.moveToNext();	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        if (r1 != 0) goto L_0x003b;
    L_0x004e:
        r15 = 0;
        r15 = r9.m4717a();	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r15.beginTransaction();	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r14 = "opened = 0";	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r13 = new android.content.ContentValues;	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r13.<init>();	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r1 = "dismissed";	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r3 = 1;	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r3 = java.lang.Integer.valueOf(r3);	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r13.put(r1, r3);	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r1 = "notification";	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r3 = 0;	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r15.update(r1, r13, r14, r3);	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r15.setTransactionSuccessful();	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        if (r15 == 0) goto L_0x0075;
    L_0x0072:
        r15.endTransaction();	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
    L_0x0075:
        r1 = 0;
        r3 = f2576b;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        com.onesignal.C1162f.m4847a(r1, r3);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        if (r8 == 0) goto L_0x000b;
    L_0x007d:
        r8.close();
        goto L_0x000b;
    L_0x0081:
        r12 = move-exception;
        r1 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r3 = "Error closing transaction! ";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        com.onesignal.C1226z.m5061a(r1, r3, r12);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        goto L_0x0075;
    L_0x008a:
        r12 = move-exception;
        r1 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ all -> 0x00b0 }
        r3 = "Error canceling all notifications! ";	 Catch:{ all -> 0x00b0 }
        com.onesignal.C1226z.m5061a(r1, r3, r12);	 Catch:{ all -> 0x00b0 }
        if (r8 == 0) goto L_0x000b;
    L_0x0094:
        r8.close();
        goto L_0x000b;
    L_0x0099:
        r12 = move-exception;
        r1 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        r3 = "Error marking all notifications as dismissed! ";	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        com.onesignal.C1226z.m5061a(r1, r3, r12);	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        if (r15 == 0) goto L_0x0075;
    L_0x00a3:
        r15.endTransaction();	 Catch:{ Throwable -> 0x0099, all -> 0x00b7, Throwable -> 0x00a7 }
        goto L_0x0075;
    L_0x00a7:
        r12 = move-exception;
        r1 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r3 = "Error closing transaction! ";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        com.onesignal.C1226z.m5061a(r1, r3, r12);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        goto L_0x0075;
    L_0x00b0:
        r1 = move-exception;
        if (r8 == 0) goto L_0x00b6;
    L_0x00b3:
        r8.close();
    L_0x00b6:
        throw r1;
    L_0x00b7:
        r1 = move-exception;
        if (r15 == 0) goto L_0x00bd;
    L_0x00ba:
        r15.endTransaction();	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
    L_0x00bd:
        throw r1;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
    L_0x00be:
        r12 = move-exception;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r3 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        r4 = "Error closing transaction! ";	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        com.onesignal.C1226z.m5061a(r3, r4, r12);	 Catch:{ Throwable -> 0x00be, Throwable -> 0x0081, Throwable -> 0x008a }
        goto L_0x00bd;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.z.k():void");
    }

    static /* synthetic */ int m5122s() {
        int i = f2574Q;
        f2574Q = i + 1;
        return i;
    }

    private static C1204v m5100f(Context context) {
        if (context == null) {
            return null;
        }
        if (f2569L == null) {
            f2569L = new C1204v(false);
            f2569L.f2524a.m5001b(new OSPermissionChangedInternalObserver());
        }
        return f2569L;
    }

    static C1203u<Object, C1205w> m5050a() {
        if (f2570M == null) {
            f2570M = new C1203u("onOSPermissionChanged", true);
        }
        return f2570M;
    }

    private static OSSubscriptionState m5103g(Context context) {
        if (context == null) {
            return null;
        }
        if (f2571N == null) {
            f2571N = new OSSubscriptionState(false, C1226z.m5100f(context).m5005b());
            C1226z.m5100f(context).f2524a.m5000a(f2571N);
            f2571N.f2295a.m5001b(new OSSubscriptionChangedInternalObserver());
        }
        return f2571N;
    }

    static C1203u<Object, C1206x> m5074b() {
        if (f2572O == null) {
            f2572O = new C1203u("onOSSubscriptionChanged", true);
        }
        return f2572O;
    }

    public static C1218a m5085c() {
        if (f2580f == null) {
            f2580f = new C1218a();
        }
        return f2580f;
    }

    public static void m5054a(Context context, String googleProjectNumber, String oneSignalAppId, C1223f notificationOpenedHandler) {
        C1226z.m5055a(context, googleProjectNumber, oneSignalAppId, notificationOpenedHandler, null);
    }

    public static void m5055a(Context context, String googleProjectNumber, String oneSignalAppId, C1223f notificationOpenedHandler, C1224g notificationReceivedHandler) {
        f2580f = C1226z.m5085c();
        f2580f.f2541g = false;
        f2580f.f2535a = notificationOpenedHandler;
        f2580f.f2536b = notificationReceivedHandler;
        if (!f2585k) {
            f2584j = googleProjectNumber;
        }
        f2598x = new C1207y();
        f2597w = f2598x.m5015a();
        f2589o = f2598x.m5016a(f2597w, oneSignalAppId);
        if (f2589o != -999) {
            if (f2577c) {
                if (context != null) {
                    f2576b = context.getApplicationContext();
                }
                if (f2580f.f2535a != null) {
                    C1226z.m5041K();
                    return;
                }
                return;
            }
            boolean contextIsActivity = context instanceof Activity;
            f2590p = contextIsActivity;
            f2575a = oneSignalAppId;
            f2576b = context.getApplicationContext();
            C1226z.m5082b(f2580f.f2540f);
            if (contextIsActivity) {
                C1122a.f2312b = (Activity) context;
                C1185o.m4940a(f2576b);
                C1226z.m5047Q();
            } else {
                C1122a.f2311a = true;
            }
            f2592r = SystemClock.elapsedRealtime();
            ad.m4764a(f2576b);
            if (VERSION.SDK_INT > 13) {
                ((Application) f2576b).registerActivityLifecycleCallbacks(new C1154b());
            } else {
                ActivityLifecycleListenerCompat.startListener();
            }
            try {
                Class.forName("com.amazon.device.iap.PurchasingListener");
                f2595u = new aj(f2576b);
            } catch (ClassNotFoundException e) {
            }
            String oldAppId = C1226z.m5101f();
            if (oldAppId == null) {
                C1162f.m4847a(0, f2576b);
                C1226z.m5097e(f2575a);
            } else if (!oldAppId.equals(f2575a)) {
                C1226z.m5060a(C1222e.DEBUG, "APP ID changed, clearing user id as it is no longer valid.");
                C1226z.m5097e(f2575a);
                ad.m4786f();
            }
            OSPermissionChangedInternalObserver.m4669a(C1226z.m5100f(f2576b));
            if (f2590p || C1226z.m5104g() == null) {
                f2567J = C1226z.m5046P();
                C1226z.m5052a(System.currentTimeMillis());
                C1226z.m5037G();
            }
            if (f2580f.f2535a != null) {
                C1226z.m5041K();
            }
            if (ak.m4824a(f2576b)) {
                f2594t = new ak(f2576b);
            }
            f2577c = true;
        }
    }

    private static void m5037G() {
        boolean z = false;
        if (!f2566I) {
            f2566I = true;
            f2600z = false;
            if (f2567J) {
                f2558A = false;
            }
            C1226z.m5038H();
            C1226z.m5040J();
            if (f2560C || f2580f.f2537c) {
                z = true;
            }
            f2560C = z;
        }
    }

    private static void m5038H() {
        Context context = f2576b;
        boolean z = f2580f.f2537c && !f2560C;
        C1175i.m4903a(context, z, new C12081());
    }

    private static void m5039I() {
        ae pushRegistrator;
        if (f2597w == 2) {
            pushRegistrator = new af();
        } else {
            pushRegistrator = new ag();
        }
        pushRegistrator.mo1134a(f2576b, f2584j, new C12125());
    }

    private static void m5040J() {
        if (f2559B) {
            C1226z.m5039I();
            return;
        }
        C1131a responseHandler = new C12146();
        String awl_url = "apps/" + f2575a + "/android_params.js";
        String userId = C1226z.m5104g();
        if (userId != null) {
            awl_url = awl_url + "?player_id=" + userId;
        }
        C1226z.m5060a(C1222e.DEBUG, "Starting request to get Android parameters.");
        ac.m4724a(awl_url, responseHandler);
    }

    private static void m5041K() {
        for (JSONArray dataArray : f2562E) {
            C1226z.m5081b(dataArray, true, false);
        }
        f2562E.clear();
    }

    private static boolean m5071a(C1222e level) {
        return level.compareTo(f2586l) < 1 || level.compareTo(f2587m) < 1;
    }

    static void m5060a(C1222e level, String message) {
        C1226z.m5061a(level, message, null);
    }

    static void m5061a(final C1222e level, String message, Throwable throwable) {
        String TAG = "OneSignal";
        if (level.compareTo(f2587m) < 1) {
            if (level == C1222e.VERBOSE) {
                Log.v("OneSignal", message, throwable);
            } else if (level == C1222e.DEBUG) {
                Log.d("OneSignal", message, throwable);
            } else if (level == C1222e.INFO) {
                Log.i("OneSignal", message, throwable);
            } else if (level == C1222e.WARN) {
                Log.w("OneSignal", message, throwable);
            } else if (level == C1222e.ERROR || level == C1222e.FATAL) {
                Log.e("OneSignal", message, throwable);
            }
        }
        if (level.compareTo(f2586l) < 1 && C1122a.f2312b != null) {
            try {
                String fullMessage = message + "\n";
                if (throwable != null) {
                    fullMessage = fullMessage + throwable.getMessage();
                    StringWriter sw = new StringWriter();
                    throwable.printStackTrace(new PrintWriter(sw));
                    fullMessage = fullMessage + sw.toString();
                }
                final String finalFullMessage = fullMessage;
                C1207y.m5012a(new Runnable() {
                    public void run() {
                        if (C1122a.f2312b != null) {
                            new Builder(C1122a.f2312b).setTitle(level.toString()).setMessage(finalFullMessage).show();
                        }
                    }
                });
            } catch (Throwable t) {
                Log.e("OneSignal", "Error showing logging message.", t);
            }
        }
    }

    private static void m5080b(String errorString, int statusCode, Throwable throwable, String errorResponse) {
        String jsonError = "";
        if (errorResponse != null && C1226z.m5071a(C1222e.INFO)) {
            jsonError = "\n" + errorResponse + "\n";
        }
        C1226z.m5061a(C1222e.WARN, "HTTP code: " + statusCode + " " + errorString + jsonError, throwable);
    }

    static boolean m5073a(boolean onlySave) {
        boolean z = true;
        f2590p = false;
        if (!f2577c) {
            return false;
        }
        if (f2595u != null) {
            f2595u.m4815a();
        }
        if (f2592r == -1) {
            return false;
        }
        long time_elapsed = (long) ((((double) (SystemClock.elapsedRealtime() - f2592r)) / 1000.0d) + 0.5d);
        f2592r = SystemClock.elapsedRealtime();
        if (time_elapsed < 0 || time_elapsed > 86400) {
            return false;
        }
        if (f2576b == null) {
            C1226z.m5060a(C1222e.ERROR, "Android Context not found, please call OneSignal.init when your app starts.");
            return false;
        }
        C1226z.m5052a(System.currentTimeMillis());
        long totalTimeActive = C1226z.m5115l() + time_elapsed;
        if (onlySave || totalTimeActive < 60 || C1226z.m5104g() == null) {
            C1226z.m5087c(totalTimeActive);
            if (totalTimeActive < 60) {
                z = false;
            }
            return z;
        }
        C1226z.m5053a(totalTimeActive, true);
        return false;
    }

    static void m5053a(long totalTimeActive, boolean synchronous) {
        JSONObject jsonBody = new JSONObject();
        try {
            jsonBody.put("app_id", f2575a);
            jsonBody.put("type", 1);
            jsonBody.put("state", "ping");
            jsonBody.put("active_time", totalTimeActive);
            C1226z.m5088c(jsonBody);
            String url = "players/" + C1226z.m5104g() + "/on_focus";
            C1131a responseHandler = new C12168();
            if (synchronous) {
                ac.m4733d(url, jsonBody, responseHandler);
            } else {
                ac.m4729b(url, jsonBody, responseHandler);
            }
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Generating on_focus:JSON Failed.", t);
        }
    }

    static void m5094d() {
        C1226z.m5047Q();
        f2590p = true;
        f2592r = SystemClock.elapsedRealtime();
        f2567J = C1226z.m5046P();
        C1226z.m5052a(System.currentTimeMillis());
        C1226z.m5037G();
        if (f2594t != null) {
            f2594t.m4838a();
        }
        C1185o.m4940a(f2576b);
        C1226z.m5100f(f2576b).m5004a();
    }

    static boolean m5098e() {
        return f2590p;
    }

    private static void m5088c(JSONObject jsonObj) {
        try {
            jsonObj.put("net_type", f2598x.m5017b());
        } catch (Throwable th) {
        }
    }

    private static int m5042L() {
        TimeZone timezone = Calendar.getInstance().getTimeZone();
        int offset = timezone.getRawOffset();
        if (timezone.inDaylightTime(new Date())) {
            offset += timezone.getDSTSavings();
        }
        return offset / 1000;
    }

    private static void m5043M() {
        C1226z.m5060a(C1222e.DEBUG, "registerUser: registerForPushFired:" + f2600z + ", locationFired: " + f2558A + ", awlFired: " + f2559B);
        if (f2600z && f2558A && f2559B) {
            new Thread(new C12179(), "OS_REG_USER").start();
        }
    }

    public static void m5067a(JSONObject keyValues) {
        if (f2576b == null) {
            C1226z.m5060a(C1222e.ERROR, "You must initialize OneSignal before modifying tags! Omitting this tag operation.");
        } else if (keyValues != null) {
            JSONObject existingKeys = ad.m4779c(false).f2345b;
            JSONObject toSend = new JSONObject();
            Iterator<String> keys = keyValues.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                try {
                    Object value = keyValues.opt(key);
                    if ((value instanceof JSONArray) || (value instanceof JSONObject)) {
                        C1226z.m5060a(C1222e.ERROR, "Omitting key '" + key + "'! sendTags DO NOT supported nested values!");
                    } else if (!keyValues.isNull(key) && !"".equals(value)) {
                        toSend.put(key, value.toString());
                    } else if (existingKeys != null && existingKeys.has(key)) {
                        toSend.put(key, "");
                    }
                } catch (Throwable th) {
                }
            }
            if (!toSend.toString().equals("{}")) {
                ad.m4768a(toSend);
            }
        }
    }

    public static void m5058a(C1219b getTagsHandler) {
        if (f2576b == null) {
            C1226z.m5060a(C1222e.ERROR, "You must initialize OneSignal before getting tags! Omitting this tag operation.");
        } else if (getTagsHandler == null) {
            C1226z.m5060a(C1222e.ERROR, "getTagsHandler is null!");
        } else if (C1226z.m5104g() == null) {
            f2564G = getTagsHandler;
        } else {
            C1226z.m5078b(getTagsHandler);
        }
    }

    private static void m5078b(final C1219b getTagsHandler) {
        if (getTagsHandler != null) {
            new Thread(new Runnable() {
                public void run() {
                    C1137a tags = ad.m4779c(!C1226z.f2565H);
                    if (tags.f2344a) {
                        C1226z.f2565H = true;
                    }
                    if (tags.f2345b == null || tags.toString().equals("{}")) {
                        getTagsHandler.mo1169a(null);
                    } else {
                        getTagsHandler.mo1169a(tags.f2345b);
                    }
                }
            }, "OS_GETTAGS_CALLBACK").start();
        }
    }

    public static void m5059a(C1221d inIdsAvailableHandler) {
        f2591q = inIdsAvailableHandler;
        if (C1226z.m5104g() != null) {
            C1226z.m5045O();
        }
    }

    private static void m5044N() {
        if (f2591q != null) {
            C1207y.m5012a(new Runnable() {
                public void run() {
                    C1226z.m5045O();
                }
            });
        }
    }

    private static synchronized void m5045O() {
        synchronized (C1226z.class) {
            if (f2591q != null) {
                String regId = ad.m4784e();
                if (!ad.m4782d()) {
                    regId = null;
                }
                String userId = C1226z.m5104g();
                if (userId != null) {
                    f2591q.mo1140a(userId, regId);
                    if (regId != null) {
                        f2591q = null;
                    }
                }
            }
        }
    }

    static void m5065a(JSONArray purchases, boolean newAsExisting, C1131a responseHandler) {
        if (C1226z.m5104g() == null) {
            f2573P = new C1220c(purchases);
            f2573P.f2544b = newAsExisting;
            f2573P.f2545c = responseHandler;
            return;
        }
        try {
            JSONObject jsonBody = new JSONObject();
            jsonBody.put("app_id", f2575a);
            if (newAsExisting) {
                jsonBody.put("existing", true);
            }
            jsonBody.put("purchases", purchases);
            ac.m4729b("players/" + C1226z.m5104g() + "/on_purchase", jsonBody, responseHandler);
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Failed to generate JSON for sendPurchases.", t);
        }
    }

    private static boolean m5069a(Context context, JSONArray dataArray) {
        int jsonArraySize = dataArray.length();
        boolean urlOpened = false;
        for (int i = 0; i < jsonArraySize; i++) {
            try {
                JSONObject data = dataArray.getJSONObject(i);
                if (data.has("custom")) {
                    JSONObject customJSON = new JSONObject(data.optString("custom"));
                    if (customJSON.has("u")) {
                        String url = customJSON.optString("u", null);
                        if (!url.contains("://")) {
                            url = "http://" + url;
                        }
                        Intent intent = new Intent("android.intent.action.VIEW", Uri.parse(url.trim()));
                        intent.addFlags(1476919296);
                        context.startActivity(intent);
                        urlOpened = true;
                    }
                }
            } catch (Throwable t) {
                C1226z.m5061a(C1222e.ERROR, "Error parsing JSON item " + i + "/" + jsonArraySize + " for launching a web URL.", t);
            }
        }
        return urlOpened;
    }

    private static void m5081b(JSONArray dataArray, boolean shown, boolean fromAlert) {
        if (f2580f == null || f2580f.f2535a == null) {
            f2562E.add(dataArray);
        } else {
            C1226z.m5057a(C1226z.m5084c(dataArray, shown, fromAlert));
        }
    }

    private static C1191s m5084c(JSONArray dataArray, boolean shown, boolean fromAlert) {
        int jsonArraySize = dataArray.length();
        boolean firstMessage = true;
        C1191s openResult = new C1191s();
        C1188q notification = new C1188q();
        notification.f2466a = C1226z.m5116m();
        notification.f2467b = shown;
        notification.f2468c = dataArray.optJSONObject(0).optInt("notificationId");
        String actionSelected = null;
        for (int i = 0; i < jsonArraySize; i++) {
            try {
                JSONObject data = dataArray.getJSONObject(i);
                notification.f2469d = C1178j.m4915a(data);
                if (actionSelected == null && data.has("actionSelected")) {
                    actionSelected = data.optString("actionSelected", null);
                }
                if (firstMessage) {
                    firstMessage = false;
                } else {
                    if (notification.f2471f == null) {
                        notification.f2471f = new ArrayList();
                    }
                    notification.f2471f.add(notification.f2469d);
                }
            } catch (Throwable t) {
                C1226z.m5061a(C1222e.ERROR, "Error parsing JSON item " + i + "/" + jsonArraySize + " for callback.", t);
            }
        }
        openResult.f2477a = notification;
        openResult.f2478b = new C1190r();
        openResult.f2478b.f2476b = actionSelected;
        openResult.f2478b.f2475a = actionSelected != null ? C1189a.ActionTaken : C1189a.Opened;
        if (fromAlert) {
            openResult.f2477a.f2470e = C1187a.InAppAlert;
        } else {
            openResult.f2477a.f2470e = C1187a.Notification;
        }
        return openResult;
    }

    private static void m5057a(final C1191s openedResult) {
        C1207y.m5012a(new Runnable() {
            public void run() {
                C1226z.f2580f.f2535a.mo1162a(openedResult);
            }
        });
    }

    static void m5066a(JSONArray data, boolean displayed, boolean fromAlert) {
        if (f2580f != null && f2580f.f2536b != null) {
            f2580f.f2536b.m5030a(C1226z.m5084c(data, displayed, fromAlert).f2477a);
        }
    }

    public static void m5056a(Context inContext, JSONArray data, boolean fromAlert) {
        C1226z.m5077b(inContext, data);
        boolean urlOpened = false;
        boolean defaultOpenActionDisabled = "DISABLE".equals(C1207y.m5010a(inContext, "com.onesignal.NotificationOpened.DEFAULT"));
        if (!defaultOpenActionDisabled) {
            urlOpened = C1226z.m5069a(inContext, data);
        }
        C1226z.m5081b(data, true, fromAlert);
        if (!fromAlert && !urlOpened && !defaultOpenActionDisabled) {
            C1226z.m5106h(inContext);
        }
    }

    private static void m5106h(Context inContext) {
        Intent launchIntent = inContext.getPackageManager().getLaunchIntentForPackage(inContext.getPackageName());
        if (launchIntent != null) {
            launchIntent.setFlags(268566528);
            inContext.startActivity(launchIntent);
        }
    }

    private static void m5077b(Context inContext, JSONArray dataArray) {
        for (int i = 0; i < dataArray.length(); i++) {
            try {
                String notificationId = new JSONObject(dataArray.getJSONObject(i).optString("custom", null)).optString("i", null);
                if (!f2563F.contains(notificationId)) {
                    f2563F.add(notificationId);
                    JSONObject jsonBody = new JSONObject();
                    jsonBody.put("app_id", C1226z.m5109i(inContext));
                    jsonBody.put("player_id", C1226z.m5111j(inContext));
                    jsonBody.put("opened", true);
                    ac.m4726a("notifications/" + notificationId, jsonBody, new C12103());
                }
            } catch (Throwable t) {
                C1226z.m5061a(C1222e.ERROR, "Failed to generate JSON to send notification opened.", t);
            }
        }
    }

    private static void m5097e(String appId) {
        if (f2576b != null) {
            Editor editor = C1226z.m5091d(f2576b).edit();
            editor.putString("GT_APP_ID", appId);
            editor.commit();
        }
    }

    static String m5101f() {
        return C1226z.m5109i(f2576b);
    }

    private static String m5109i(Context inContext) {
        if (inContext == null) {
            return "";
        }
        return C1226z.m5091d(inContext).getString("GT_APP_ID", null);
    }

    private static String m5111j(Context inContext) {
        if (inContext == null) {
            return "";
        }
        return C1226z.m5091d(inContext).getString("GT_PLAYER_ID", null);
    }

    static String m5104g() {
        if (f2588n == null && f2576b != null) {
            f2588n = C1226z.m5091d(f2576b).getString("GT_PLAYER_ID", null);
        }
        return f2588n;
    }

    static void m5063a(String inUserId) {
        f2588n = inUserId;
        if (f2576b != null) {
            Editor editor = C1226z.m5091d(f2576b).edit();
            editor.putString("GT_PLAYER_ID", f2588n);
            editor.commit();
        }
    }

    static boolean m5068a(Context context) {
        return C1226z.m5091d(context).getBoolean("OS_FILTER_OTHER_GCM_RECEIVERS", false);
    }

    static void m5082b(boolean set) {
        if (f2576b != null) {
            Editor editor = C1226z.m5091d(f2576b).edit();
            editor.putBoolean("OS_FILTER_OTHER_GCM_RECEIVERS", set);
            editor.commit();
        }
    }

    static void m5079b(String userId) {
        C1226z.m5063a(userId);
        C1226z.m5044N();
        C1226z.m5078b(f2564G);
        C1226z.m5103g(f2576b).m4673a(userId);
        if (f2573P != null) {
            C1226z.m5065a(f2573P.f2543a, f2573P.f2544b, f2573P.f2545c);
            f2573P = null;
        }
        aa.m4714a(f2576b, f2575a, userId, C1156c.m4840a());
    }

    static boolean m5083b(Context context) {
        return C1226z.m5091d(context).getBoolean("GT_VIBRATE_ENABLED", true);
    }

    static boolean m5089c(Context context) {
        return C1226z.m5091d(context).getBoolean("GT_SOUND_ENABLED", true);
    }

    static void m5052a(long time) {
        Editor editor = C1226z.m5091d(f2576b).edit();
        editor.putLong("OS_LAST_SESSION_TIME", time);
        editor.apply();
    }

    private static long m5113k(Context context) {
        return C1226z.m5091d(context).getLong("OS_LAST_SESSION_TIME", -31000);
    }

    public static void m5062a(C1225h displayOption) {
        C1226z.m5085c().f2541g = true;
        C1226z.m5085c().f2542h = displayOption;
    }

    static boolean m5107h() {
        if (f2580f == null || f2580f.f2542h == C1225h.Notification) {
            return true;
        }
        return false;
    }

    static boolean m5110i() {
        if (f2580f != null && f2580f.f2542h == C1225h.InAppAlert) {
            return true;
        }
        return false;
    }

    public static void m5112j() {
        if (f2576b == null) {
            C1226z.m5060a(C1222e.ERROR, "OneSignal.init has not been called. Could not prompt for location.");
            return;
        }
        C1175i.m4903a(f2576b, true, new C12114());
        f2560C = true;
    }

    static long m5115l() {
        if (f2593s == -1 && f2576b != null) {
            f2593s = C1226z.m5091d(f2576b).getLong("GT_UNSENT_ACTIVE_TIME", 0);
        }
        C1226z.m5060a(C1222e.INFO, "GetUnsentActiveTime: " + f2593s);
        return f2593s;
    }

    private static void m5087c(long time) {
        f2593s = time;
        if (f2576b != null) {
            C1226z.m5060a(C1222e.INFO, "SaveUnsentActiveTime: " + f2593s);
            Editor editor = C1226z.m5091d(f2576b).edit();
            editor.putLong("GT_UNSENT_ACTIVE_TIME", time);
            editor.commit();
        }
    }

    static SharedPreferences m5091d(Context context) {
        return context.getSharedPreferences(C1226z.class.getSimpleName(), 0);
    }

    private static boolean m5072a(String id, Context context) {
        if (id == null || "".equals(id)) {
            return false;
        }
        boolean exists = false;
        Cursor cursor = null;
        try {
            cursor = ab.m4715a(context).m4718b().query("notification", new String[]{"notification_id"}, "notification_id = ?", new String[]{id}, null, null, null);
            exists = cursor.moveToFirst();
            if (cursor != null) {
                cursor.close();
            }
        } catch (Throwable th) {
            if (cursor != null) {
                cursor.close();
            }
        }
        if (!exists) {
            return false;
        }
        C1226z.m5060a(C1222e.DEBUG, "Duplicate GCM message received, skip processing of " + id);
        return true;
    }

    static boolean m5070a(Context context, JSONObject jsonPayload) {
        String id = C1226z.m5093d(jsonPayload);
        return id == null || C1226z.m5072a(id, context);
    }

    static String m5051a(Bundle bundle) {
        if (bundle.isEmpty()) {
            return null;
        }
        try {
            if (bundle.containsKey("custom")) {
                JSONObject customJSON = new JSONObject(bundle.getString("custom"));
                if (customJSON.has("i")) {
                    return customJSON.optString("i", null);
                }
                C1226z.m5060a(C1222e.DEBUG, "Not a OneSignal formatted GCM message. No 'i' field in custom.");
                return null;
            }
            C1226z.m5060a(C1222e.DEBUG, "Not a OneSignal formatted GCM message. No 'custom' field in the bundle.");
            return null;
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.DEBUG, "Could not parse bundle, probably not a OneSignal notification.", t);
            return null;
        }
    }

    private static String m5093d(JSONObject jsonPayload) {
        String str = null;
        try {
            str = new JSONObject(jsonPayload.optString("custom")).optString("i", null);
        } catch (Throwable th) {
        }
        return str;
    }

    static boolean m5116m() {
        return f2577c && C1226z.m5098e();
    }

    static void m5117n() {
        f2567J = false;
        C1226z.m5052a(System.currentTimeMillis());
    }

    private static boolean m5046P() {
        return (System.currentTimeMillis() - C1226z.m5113k(f2576b)) / 1000 >= 30;
    }

    private static void m5047Q() {
        Intent intent = new Intent(f2576b, SyncService.class);
        intent.putExtra("task", 0);
        f2576b.startService(intent);
    }

    static boolean m5118o() {
        if (f2580f.f2539e) {
            return C1207y.m5013a(f2576b);
        }
        return true;
    }
}
