package com.onesignal;

import android.app.Activity;
import android.content.Intent;
import android.os.Build.VERSION;
import android.os.Bundle;
import com.onesignal.C1122a.C1113a;
import com.onesignal.C1161e.C1157a;

public class PermissionsActivity extends Activity {
    static boolean f2300a;
    static boolean f2301b;
    private static C1113a f2302c;

    static class C11141 implements C1113a {
        C11141() {
        }

        public void mo1127a(Activity activity) {
            if (!activity.getClass().equals(PermissionsActivity.class)) {
                Intent intent = new Intent(activity, PermissionsActivity.class);
                intent.setFlags(131072);
                activity.startActivity(intent);
            }
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState == null || !savedInstanceState.getBoolean("android:hasCurrentPermissionsRequest", false)) {
            m4681b();
        } else {
            f2300a = true;
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (C1226z.f2577c) {
            m4681b();
        }
    }

    private void m4681b() {
        if (VERSION.SDK_INT < 23) {
            finish();
        } else if (!f2300a) {
            f2300a = true;
            C1157a.m4842a(this, new String[]{C1175i.f2433a}, 2);
        }
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        f2301b = true;
        f2300a = false;
        if (requestCode == 2) {
            if (grantResults.length <= 0 || grantResults[0] != 0) {
                C1175i.m4907b();
            } else {
                C1175i.m4900a();
            }
        }
        C1122a.m4704b(f2302c);
        finish();
    }

    static void m4680a() {
        if (!f2300a && !f2301b) {
            f2302c = new C11141();
            C1122a.m4701a(f2302c);
        }
    }
}
