package com.onesignal;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.app.PendingIntent.CanceledException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import com.google.android.gms.common.C0855e;
import com.google.android.gms.p021c.C0803a;
import com.onesignal.C1226z.C1222e;
import com.onesignal.ae.C1141a;

/* compiled from: PushRegistratorGPS */
public class ag implements ae {
    private static int f2380c = 5;
    private Context f2381a;
    private C1141a f2382b;

    /* compiled from: PushRegistratorGPS */
    class C11451 implements Runnable {
        final /* synthetic */ ag f2377a;

        C11451(ag this$0) {
            this.f2377a = this$0;
        }

        public void run() {
            final Activity activity = C1122a.f2312b;
            if (activity != null && !C1226z.f2580f.f2538d) {
                String alertBodyText = C1207y.m5011a(activity, "onesignal_gms_missing_alert_text", "To receive push notifications please press 'Update' to enable 'Google Play services'.");
                String alertButtonUpdate = C1207y.m5011a(activity, "onesignal_gms_missing_alert_button_update", "Update");
                String alertButtonSkip = C1207y.m5011a(activity, "onesignal_gms_missing_alert_button_skip", "Skip");
                new Builder(activity).setMessage(alertBodyText).setPositiveButton(alertButtonUpdate, new OnClickListener(this) {
                    final /* synthetic */ C11451 f2376b;

                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            C0855e.m3415a(C0855e.m3413a(this.f2376b.f2377a.f2381a), activity, 0).send();
                        } catch (CanceledException e) {
                        } catch (Throwable e2) {
                            e2.printStackTrace();
                        }
                    }
                }).setNegativeButton(alertButtonSkip, new OnClickListener(this) {
                    final /* synthetic */ C11451 f2374b;

                    public void onClick(DialogInterface dialog, int which) {
                        Editor editor = C1226z.m5091d(activity).edit();
                        editor.putBoolean("GT_DO_NOT_SHOW_MISSING_GPS", true);
                        editor.commit();
                    }
                }).setNeutralButton(C1207y.m5011a(activity, "onesignal_gms_missing_alert_button_close", "Close"), null).create().show();
            }
        }
    }

    public void mo1134a(Context context, String googleProjectNumber, C1141a callback) {
        this.f2381a = context;
        this.f2382b = callback;
        if (googleProjectNumber == null || googleProjectNumber.equals("REMOTE")) {
            C1226z.m5060a(C1222e.ERROR, "Missing Google Project number!\nPlease enter a Google Project number / Sender ID on under App Settings > Android > Configuration on the OneSignal dashboard.");
            this.f2382b.mo1139a(null, -6);
            return;
        }
        m4806a(googleProjectNumber);
    }

    private void m4806a(String googleProjectNumber) {
        try {
            if (m4810c()) {
                m4808b(googleProjectNumber);
                return;
            }
            C1226z.m5060a(C1222e.ERROR, "'Google Play services' app not installed or disabled on the device.");
            this.f2382b.mo1139a(null, -7);
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Could not register with GCM due to an error with the AndroidManifest.xml file or with 'Google Play services'.", t);
            this.f2382b.mo1139a(null, -8);
        }
    }

    private boolean m4809b() {
        try {
            PackageManager pm = this.f2381a.getPackageManager();
            String label = (String) pm.getPackageInfo("com.android.vending", 1).applicationInfo.loadLabel(pm);
            if (label == null || label.equals("Market")) {
                return false;
            }
            return true;
        } catch (Throwable th) {
            return false;
        }
    }

    private boolean m4810c() {
        boolean z = false;
        try {
            PackageInfo info = this.f2381a.getPackageManager().getPackageInfo("com.google.android.gms", 1);
            if (!info.applicationInfo.enabled && m4809b()) {
                if (!C1226z.m5091d(this.f2381a).getBoolean("GT_DO_NOT_SHOW_MISSING_GPS", false)) {
                    try {
                        m4811d();
                    } catch (Throwable th) {
                    }
                }
                return z;
            }
            z = info.applicationInfo.enabled;
        } catch (NameNotFoundException e) {
        }
        return z;
    }

    private void m4811d() {
        C1207y.m5012a(new C11451(this));
    }

    private void m4808b(final String googleProjectNumber) {
        new Thread(new Runnable(this) {
            final /* synthetic */ ag f2379b;

            public void run() {
                boolean firedComplete = false;
                int currentRetry = 0;
                while (currentRetry < ag.f2380c) {
                    try {
                        String registrationId = C0803a.m3237a(this.f2379b.f2381a).m3247a(googleProjectNumber);
                        C1226z.m5060a(C1222e.INFO, "Device registered, Google Registration ID = " + registrationId);
                        this.f2379b.f2382b.mo1139a(registrationId, 1);
                        return;
                    } catch (Throwable e) {
                        if (!"SERVICE_NOT_AVAILABLE".equals(e.getMessage())) {
                            C1226z.m5061a(C1222e.ERROR, "Error Getting Google Registration ID", e);
                            if (!firedComplete) {
                                this.f2379b.f2382b.mo1139a(null, -11);
                                return;
                            }
                            return;
                        } else if (currentRetry >= ag.f2380c - 1) {
                            C1226z.m5061a(C1222e.ERROR, "GCM_RETRY_COUNT of " + ag.f2380c + " exceed! Could not get a Google Registration Id", e);
                        } else {
                            C1226z.m5061a(C1222e.INFO, "Google Play services returned SERVICE_NOT_AVAILABLE error. Current retry count: " + currentRetry, e);
                            if (currentRetry == 2) {
                                this.f2379b.f2382b.mo1139a(null, -9);
                                firedComplete = true;
                            }
                            Thread.sleep((long) ((currentRetry + 1) * 10000));
                        }
                    } catch (Throwable th) {
                    }
                }
                return;
                currentRetry++;
            }
        }).start();
    }
}
