package com.onesignal;

import android.app.Activity;
import android.app.Instrumentation;
import android.app.Instrumentation.ActivityMonitor;
import android.app.OnActivityPausedListener;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

class ActivityLifecycleListenerCompat {
    ActivityLifecycleListenerCompat() {
    }

    static void startListener() {
        try {
            Class activityThreadClass = Class.forName("android.app.ActivityThread");
            Object activityThread = activityThreadClass.getMethod("currentActivityThread", new Class[0]).invoke(null, new Object[0]);
            Field instrumentationField = activityThreadClass.getDeclaredField("mInstrumentation");
            instrumentationField.setAccessible(true);
            startMonitorThread(activityThreadClass, activityThread, ((Instrumentation) instrumentationField.get(activityThread)).addMonitor((String) null, null, false));
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private static void startMonitorThread(final Class activityThreadClass, final Object activityThread, final ActivityMonitor allActivitiesMonitor) {
        new Thread(new Runnable() {

            class C11111 implements OnActivityPausedListener {
                C11111() {
                }

                public void onPaused(Activity activity) {
                    C1122a.m4707d(activity);
                }
            }

            public void run() {
                try {
                    OnActivityPausedListener pausedListener = new C11111();
                    Method registerOnActivityPausedListener = activityThreadClass.getMethod("registerOnActivityPausedListener", new Class[]{Activity.class, OnActivityPausedListener.class});
                    while (true) {
                        Activity currentActivity = allActivitiesMonitor.waitForActivity();
                        if (!currentActivity.isFinishing()) {
                            C1122a.m4706c(currentActivity);
                            registerOnActivityPausedListener.invoke(activityThread, new Object[]{currentActivity, pausedListener});
                        }
                    }
                } catch (Throwable t) {
                    t.printStackTrace();
                }
            }
        }, "OS_LIFECYCLE_COMPAT").start();
    }
}
