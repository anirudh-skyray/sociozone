package com.onesignal;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.support.v4.app.ag;
import com.onesignal.C1175i.C1115c;
import com.onesignal.C1175i.C1173e;
import com.onesignal.C1226z.C1222e;

public class SyncService extends Service {
    private static boolean f2306a;

    class C11161 implements C1115c {
        final /* synthetic */ SyncService f2303a;

        C11161(SyncService this$0) {
            this.f2303a = this$0;
        }

        public void mo1128a(C1173e point) {
            if (point != null) {
                ad.m4766a(point);
            }
        }
    }

    class C11182 implements Runnable {
        final /* synthetic */ SyncService f2305a;

        class C11171 implements C1115c {
            final /* synthetic */ C11182 f2304a;

            C11171(C11182 this$1) {
                this.f2304a = this$1;
            }

            public void mo1128a(C1173e point) {
                if (point != null) {
                    ad.m4766a(point);
                }
                ad.m4769a(true);
                SyncService.m4688b();
                this.f2304a.f2305a.stopSelf();
            }
        }

        C11182(SyncService this$0) {
            this.f2305a = this$0;
        }

        public void run() {
            if (C1226z.m5104g() == null) {
                this.f2305a.stopSelf();
                return;
            }
            C1226z.f2575a = C1226z.m5101f();
            ad.m4764a(C1226z.f2576b);
            C1175i.m4903a(C1226z.f2576b, false, new C11171(this));
        }
    }

    private static void m4688b() {
        long unsentTime = C1226z.m5115l();
        if (unsentTime >= 60) {
            C1226z.m5053a(unsentTime, true);
        }
    }

    private void m4689c() {
        if (f2306a) {
            m4690d();
        } else {
            m4691e();
        }
    }

    private void m4690d() {
        C1175i.m4903a(this, false, new C11161(this));
    }

    private void m4691e() {
        C1226z.f2576b = getApplicationContext();
        new Thread(new C11182(this), "OS_SYNCSRV_BG_SYNC").start();
    }

    public void onCreate() {
    }

    public int onStartCommand(Intent intent, int flags, int startId) {
        int task;
        if (intent != null) {
            task = intent.getIntExtra("task", 0);
        } else {
            task = 1;
        }
        if (task == 0) {
            f2306a = true;
        } else if (task == 1) {
            m4689c();
        }
        if (f2306a) {
            return 1;
        }
        return 2;
    }

    public IBinder onBind(Intent intent) {
        return null;
    }

    public void onTaskRemoved(Intent rootIntent) {
        super.onTaskRemoved(rootIntent);
        m4686a(this);
    }

    static void m4686a(Service service) {
        C1226z.m5060a(C1222e.VERBOSE, "Starting SyncService:onTaskRemoved.");
        C1122a.f2313c.m4697b();
        boolean scheduleServerRestart = C1226z.m5073a(true) || ad.m4770a();
        C1226z.m5060a(C1222e.VERBOSE, "Completed SyncService:onTaskRemoved.");
        service.stopSelf();
        if (scheduleServerRestart) {
            m4687a(service, System.currentTimeMillis() + 10000);
        } else {
            C1175i.m4902a((Context) service);
        }
    }

    static void m4687a(Context context, long atTime) {
        C1226z.m5060a(C1222e.VERBOSE, "scheduleServiceSyncTask:atTime: " + atTime);
        Intent intent = new Intent(context, SyncService.class);
        intent.putExtra("task", 1);
        ((AlarmManager) context.getSystemService(ag.CATEGORY_ALARM)).set(0, atTime, PendingIntent.getService(context, 0, intent, 134217728));
    }
}
