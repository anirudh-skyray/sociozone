package com.onesignal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v4.app.ap;
import com.onesignal.C1226z.C1222e;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: NotificationOpenedProcessor */
class C1183n {
    static void m4933a(Context context, Intent intent) {
        if (C1183n.m4936a(intent)) {
            C1183n.m4939c(context, intent);
            C1183n.m4938b(context, intent);
        }
    }

    private static boolean m4936a(Intent intent) {
        return intent.hasExtra("onesignal_data") || intent.hasExtra("summary") || intent.hasExtra("notificationId");
    }

    private static void m4939c(Context context, Intent intent) {
        if (intent.getBooleanExtra("action_button", false)) {
            ap.m443a(context).m447a(intent.getIntExtra("notificationId", 0));
            context.sendBroadcast(new Intent("android.intent.action.CLOSE_SYSTEM_DIALOGS"));
        }
    }

    static void m4938b(Context context, Intent intent) {
        String summaryGroup = intent.getStringExtra("summary");
        boolean dismissed = intent.getBooleanExtra("dismissed", false);
        JSONArray dataArray = null;
        if (!dismissed) {
            try {
                JSONObject jsonData = new JSONObject(intent.getStringExtra("onesignal_data"));
                jsonData.put("notificationId", intent.getIntExtra("notificationId", 0));
                intent.putExtra("onesignal_data", jsonData.toString());
                dataArray = C1178j.m4924b(new JSONObject(intent.getStringExtra("onesignal_data")));
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }
        SQLiteDatabase writableDb = null;
        try {
            writableDb = ab.m4715a(context).m4717a();
            writableDb.beginTransaction();
            if (!(dismissed || summaryGroup == null)) {
                C1183n.m4935a(dataArray, summaryGroup, writableDb);
            }
            C1183n.m4934a(context, intent, writableDb);
            if (summaryGroup == null) {
                String group = intent.getStringExtra("grp");
                if (group != null) {
                    C1186p.m4945a(context, writableDb, group, dismissed);
                }
            }
            writableDb.setTransactionSuccessful();
            if (writableDb != null) {
                try {
                    writableDb.endTransaction();
                } catch (Throwable t2) {
                    C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t2);
                }
            }
        } catch (Throwable e) {
            C1226z.m5061a(C1222e.ERROR, "Error processing notification open or dismiss record! ", e);
            if (writableDb != null) {
                writableDb.endTransaction();
            }
        } catch (Throwable t22) {
            C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t22);
        }
        if (!dismissed) {
            C1226z.m5056a(context, dataArray, intent.getBooleanExtra("from_alert", false));
        }
    }

    private static void m4935a(JSONArray dataArray, String summaryGroup, SQLiteDatabase writableDb) {
        SQLiteDatabase sQLiteDatabase = writableDb;
        Cursor cursor = sQLiteDatabase.query("notification", new String[]{"full_data"}, "group_id = ? AND dismissed = 0 AND opened = 0 AND is_summary = 0", new String[]{summaryGroup}, null, null, null);
        if (cursor.getCount() > 1) {
            cursor.moveToFirst();
            do {
                try {
                    dataArray.put(new JSONObject(cursor.getString(cursor.getColumnIndex("full_data"))));
                } catch (Throwable th) {
                    C1226z.m5060a(C1222e.ERROR, "Could not parse JSON of sub notification in group: " + summaryGroup);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
    }

    private static void m4934a(Context context, Intent intent, SQLiteDatabase writableDb) {
        String whereStr;
        String[] whereArgs = null;
        if (intent.getStringExtra("summary") != null) {
            whereStr = "group_id = ?";
            whereArgs = new String[]{intent.getStringExtra("summary")};
        } else {
            whereStr = "android_notification_id = " + intent.getIntExtra("notificationId", 0);
        }
        writableDb.update("notification", C1183n.m4937b(intent), whereStr, whereArgs);
        C1162f.m4848a(writableDb, context);
    }

    private static ContentValues m4937b(Intent intent) {
        ContentValues values = new ContentValues();
        if (intent.getBooleanExtra("dismissed", false)) {
            values.put("dismissed", Integer.valueOf(1));
        } else {
            values.put("opened", Integer.valueOf(1));
        }
        return values;
    }
}
