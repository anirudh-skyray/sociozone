package com.onesignal;

import android.content.SharedPreferences.Editor;
import org.json.JSONObject;

/* compiled from: OSPermissionState */
public class C1204v implements Cloneable {
    C1203u<Object, C1204v> f2524a = new C1203u("changed", false);
    private boolean f2525b;

    C1204v(boolean asFrom) {
        if (asFrom) {
            this.f2525b = C1226z.m5091d(C1226z.f2576b).getBoolean("ONESIGNAL_ACCEPTED_NOTIFICATION_LAST", false);
        } else {
            m5004a();
        }
    }

    void m5004a() {
        m5003a(C1207y.m5013a(C1226z.f2576b));
    }

    public boolean m5005b() {
        return this.f2525b;
    }

    private void m5003a(boolean set) {
        boolean changed = this.f2525b != set;
        this.f2525b = set;
        if (changed) {
            this.f2524a.m5002c(this);
        }
    }

    void m5006c() {
        Editor editor = C1226z.m5091d(C1226z.f2576b).edit();
        editor.putBoolean("ONESIGNAL_ACCEPTED_NOTIFICATION_LAST", this.f2525b);
        editor.commit();
    }

    protected Object clone() {
        try {
            return super.clone();
        } catch (Throwable th) {
            return null;
        }
    }

    public JSONObject m5007d() {
        JSONObject mainObj = new JSONObject();
        try {
            mainObj.put("enabled", this.f2525b);
        } catch (Throwable t) {
            t.printStackTrace();
        }
        return mainObj;
    }

    public String toString() {
        return m5007d().toString();
    }
}
