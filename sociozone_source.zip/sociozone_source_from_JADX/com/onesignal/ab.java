package com.onesignal;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.SystemClock;
import com.onesignal.C1226z.C1222e;
import java.util.ArrayList;
import java.util.List;

/* compiled from: OneSignalDbHelper */
public class ab extends SQLiteOpenHelper {
    private static ab f2319a;

    private ab(Context context) {
        super(context, "OneSignal.db", null, 2);
    }

    public static synchronized ab m4715a(Context context) {
        ab abVar;
        synchronized (ab.class) {
            if (f2319a == null) {
                f2319a = new ab(context.getApplicationContext());
            }
            abVar = f2319a;
        }
        return abVar;
    }

    synchronized SQLiteDatabase m4717a() {
        int count = 0;
        while (true) {
            try {
                break;
            } catch (Throwable th) {
                count++;
                if (count < 5) {
                    SystemClock.sleep((long) (count * 400));
                }
            }
        }
        return getWritableDatabase();
    }

    synchronized SQLiteDatabase m4718b() {
        int count = 0;
        while (true) {
            try {
                break;
            } catch (Throwable th) {
                count++;
                if (count < 5) {
                    SystemClock.sleep((long) (count * 400));
                }
            }
        }
        return getReadableDatabase();
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE notification (_id INTEGER PRIMARY KEY,notification_id TEXT,android_notification_id INTEGER,group_id TEXT,collapse_id TEXT,is_summary INTEGER DEFAULT 0,opened INTEGER DEFAULT 0,dismissed INTEGER DEFAULT 0,title TEXT,message TEXT,full_data TEXT,created_time TIMESTAMP DEFAULT (strftime('%s', 'now')));");
        db.execSQL("CREATE INDEX notification_notification_id_idx ON notification(notification_id); CREATE INDEX notification_android_notification_id_idx ON notification(android_notification_id); CREATE INDEX notification_group_id_idx ON notification(group_id); CREATE INDEX notification_collapse_id_idx ON notification(collapse_id); CREATE INDEX notification_created_time_idx ON notification(created_time); ");
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        try {
            m4716a(db, oldVersion, newVersion);
        } catch (Throwable e) {
            C1226z.m5061a(C1222e.ERROR, "Error in upgrade, migration may have already run! Skipping!", e);
        }
    }

    private static void m4716a(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 2) {
            db.execSQL("ALTER TABLE notification ADD COLUMN collapse_id TEXT;");
            db.execSQL("CREATE INDEX notification_group_id_idx ON notification(group_id); ");
        }
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        C1226z.m5060a(C1222e.WARN, "SDK version rolled back! Clearing OneSignal.db as it could be in an unexpected state.");
        Cursor cursor = db.rawQuery("SELECT name FROM sqlite_master WHERE type='table'", null);
        try {
            List<String> tables = new ArrayList(cursor.getCount());
            while (cursor.moveToNext()) {
                tables.add(cursor.getString(0));
            }
            for (String table : tables) {
                if (!table.startsWith("sqlite_")) {
                    db.execSQL("DROP TABLE IF EXISTS " + table);
                }
            }
            onCreate(db);
        } finally {
            cursor.close();
        }
    }
}
