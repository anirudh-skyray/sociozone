package com.onesignal;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.C0216j;
import com.onesignal.C1178j.C1177a;

public class GcmBroadcastReceiver extends C0216j {
    private static boolean m4668b(Intent intent) {
        if (!"com.google.android.c2dm.intent.RECEIVE".equals(intent.getAction())) {
            return false;
        }
        String messageType = intent.getStringExtra("message_type");
        if (messageType == null || "gcm".equals(messageType)) {
            return true;
        }
        return false;
    }

    public void onReceive(Context context, Intent intent) {
        Bundle bundle = intent.getExtras();
        if (bundle != null && !"google.com/iid".equals(bundle.getString("from"))) {
            C1177a processedResult = m4667a(context, intent, bundle);
            if (processedResult == null) {
                setResultCode(-1);
            } else if (processedResult.f2444c || processedResult.f2443b) {
                abortBroadcast();
            } else if (processedResult.f2442a && C1226z.m5068a(context)) {
                abortBroadcast();
            } else {
                setResultCode(-1);
            }
        }
    }

    private static C1177a m4667a(Context context, Intent intent, Bundle bundle) {
        if (!m4668b(intent)) {
            return null;
        }
        C1177a processedResult = C1178j.m4914a(context, bundle);
        if (processedResult.m4912a()) {
            return processedResult;
        }
        Intent intentForService = new Intent();
        intentForService.putExtra("json_payload", C1178j.m4925b(bundle).toString());
        intentForService.putExtra("timestamp", System.currentTimeMillis() / 1000);
        intentForService.setComponent(new ComponentName(context.getPackageName(), GcmIntentService.class.getName()));
        C0216j.m791a(context, intentForService);
        return processedResult;
    }
}
