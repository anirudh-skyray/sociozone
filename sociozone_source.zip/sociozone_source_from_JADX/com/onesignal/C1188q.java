package com.onesignal;

import java.util.List;

/* compiled from: OSNotification */
public class C1188q {
    public boolean f2466a;
    public boolean f2467b;
    public int f2468c;
    public C1201t f2469d;
    public C1187a f2470e;
    public List<C1201t> f2471f;

    /* compiled from: OSNotification */
    public enum C1187a {
        Notification,
        InAppAlert,
        None
    }
}
