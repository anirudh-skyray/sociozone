package com.onesignal;

import android.R.drawable;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build.VERSION;
import android.support.v4.app.ag.C0091q;
import android.support.v4.app.ag.C0092b;
import android.support.v4.app.ag.C0093c;
import android.support.v4.app.ag.C0094d;
import android.support.v4.app.ag.C0097g;
import android.support.v4.app.ap;
import android.text.SpannableString;
import android.text.style.StyleSpan;
import android.widget.RemoteViews;
import com.onesignal.C1161e.C1159c;
import com.onesignal.C1226z.C1222e;
import com.onesignal.ah.C1147a;
import com.onesignal.ah.C1148b;
import java.lang.reflect.Field;
import java.math.BigInteger;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Random;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: GenerateNotification */
class C1167g {
    private static Context f2418a = null;
    private static String f2419b = null;
    private static Resources f2420c = null;
    private static Class<?> f2421d;
    private static boolean f2422e;

    /* compiled from: GenerateNotification */
    private static class C1166a {
        C0094d f2416a;
        boolean f2417b;

        private C1166a() {
        }
    }

    private static void m4859a(Context inContext) {
        f2418a = inContext;
        f2419b = f2418a.getPackageName();
        f2420c = f2418a.getResources();
        PackageManager packageManager = f2418a.getPackageManager();
        Intent intent = new Intent(f2418a, NotificationOpenedReceiver.class);
        intent.setPackage(f2418a.getPackageName());
        if (packageManager.queryBroadcastReceivers(intent, 0).size() > 0) {
            f2422e = true;
            f2421d = NotificationOpenedReceiver.class;
            return;
        }
        f2421d = C1182m.class;
    }

    static void m4865a(C1181l notifJob) {
        C1167g.m4859a(notifJob.f2447a);
        if (notifJob.f2449c || !notifJob.f2450d || C1122a.f2312b == null) {
            C1167g.m4883d(notifJob);
        } else {
            C1167g.m4867a(notifJob.f2448b, C1122a.f2312b, notifJob.m4932c().intValue());
        }
    }

    private static void m4867a(final JSONObject gcmJson, final Activity activity, final int notificationId) {
        activity.runOnUiThread(new Runnable() {
            public void run() {
                Builder builder = new Builder(activity);
                builder.setTitle(C1167g.m4874b(gcmJson));
                builder.setMessage(gcmJson.optString("alert"));
                List buttonsLabels = new ArrayList();
                List<String> buttonIds = new ArrayList();
                C1167g.m4875b(activity, gcmJson, buttonsLabels, buttonIds);
                final List<String> finalButtonIds = buttonIds;
                Intent buttonIntent = C1167g.m4872b(notificationId);
                buttonIntent.putExtra("action_button", true);
                buttonIntent.putExtra("from_alert", true);
                buttonIntent.putExtra("onesignal_data", gcmJson.toString());
                if (gcmJson.has("grp")) {
                    buttonIntent.putExtra("grp", gcmJson.optString("grp"));
                }
                final Intent finalButtonIntent = buttonIntent;
                OnClickListener buttonListener = new OnClickListener(this) {
                    final /* synthetic */ C11651 f2410c;

                    public void onClick(DialogInterface dialog, int which) {
                        int index = which + 3;
                        if (finalButtonIds.size() > 1) {
                            try {
                                JSONObject newJsonData = new JSONObject(gcmJson.toString());
                                newJsonData.put("actionSelected", finalButtonIds.get(index));
                                finalButtonIntent.putExtra("onesignal_data", newJsonData.toString());
                                C1183n.m4938b(activity, finalButtonIntent);
                                return;
                            } catch (Throwable th) {
                                return;
                            }
                        }
                        C1183n.m4938b(activity, finalButtonIntent);
                    }
                };
                builder.setOnCancelListener(new OnCancelListener(this) {
                    final /* synthetic */ C11651 f2412b;

                    public void onCancel(DialogInterface dialogInterface) {
                        C1183n.m4938b(activity, finalButtonIntent);
                    }
                });
                for (int i = 0; i < buttonsLabels.size(); i++) {
                    if (i == 0) {
                        builder.setNeutralButton((CharSequence) buttonsLabels.get(i), buttonListener);
                    } else if (i == 1) {
                        builder.setNegativeButton((CharSequence) buttonsLabels.get(i), buttonListener);
                    } else if (i == 2) {
                        builder.setPositiveButton((CharSequence) buttonsLabels.get(i), buttonListener);
                    }
                }
                AlertDialog alertDialog = builder.create();
                alertDialog.setCanceledOnTouchOutside(false);
                alertDialog.show();
            }
        });
    }

    private static CharSequence m4874b(JSONObject gcmBundle) {
        CharSequence title = gcmBundle.optString("title", null);
        return title != null ? title : f2418a.getPackageManager().getApplicationLabel(f2418a.getApplicationInfo());
    }

    private static PendingIntent m4852a(int requestCode, Intent intent) {
        if (f2422e) {
            return PendingIntent.getBroadcast(f2418a, requestCode, intent, 134217728);
        }
        return PendingIntent.getActivity(f2418a, requestCode, intent, 134217728);
    }

    private static Intent m4872b(int notificationId) {
        Intent intent = new Intent(f2418a, f2421d).putExtra("notificationId", notificationId);
        return f2422e ? intent : intent.addFlags(603979776);
    }

    private static Intent m4877c(int notificationId) {
        Intent intent = new Intent(f2418a, f2421d).putExtra("notificationId", notificationId).putExtra("dismissed", true);
        return f2422e ? intent : intent.addFlags(402718720);
    }

    private static C1166a m4880c(C1181l notifJob) {
        int visibility;
        Bitmap largeIcon;
        Bitmap bigPictureIcon;
        Uri soundUri;
        JSONObject gcmBundle = notifJob.f2448b;
        C1166a oneSignalNotificationBuilder = new C1166a();
        int notificationIcon = C1167g.m4881d(gcmBundle);
        int notificationDefaults = 0;
        if (C1226z.m5083b(f2418a)) {
            notificationDefaults = 2;
        }
        CharSequence message = gcmBundle.optString("alert", null);
        C0094d notifBuilder = new C0094d(f2418a).setAutoCancel(true).setSmallIcon(notificationIcon).setContentTitle(C1167g.m4874b(gcmBundle)).setStyle(new C0093c().m324a(message)).setContentText(message).setTicker(message);
        if (notifJob.f2451e != null) {
            try {
                notifBuilder.setWhen(notifJob.f2451e.longValue() * 1000);
            } catch (Throwable th) {
            }
        }
        try {
            BigInteger accentColor = C1167g.m4888g(gcmBundle);
            if (accentColor != null) {
                notifBuilder.setColor(accentColor.intValue());
            }
        } catch (Throwable th2) {
        }
        if (gcmBundle.has("ledc")) {
            try {
                BigInteger ledColor = new BigInteger(gcmBundle.optString("ledc"), 16);
                BigInteger bigInteger;
                try {
                    notifBuilder.setLights(ledColor.intValue(), 2000, 5000);
                    bigInteger = ledColor;
                } catch (Throwable th3) {
                    bigInteger = ledColor;
                    notificationDefaults |= 4;
                    visibility = 1;
                    if (gcmBundle.has("vis")) {
                        visibility = Integer.parseInt(gcmBundle.optString("vis"));
                    }
                    notifBuilder.setVisibility(visibility);
                    largeIcon = C1167g.m4879c(gcmBundle);
                    if (largeIcon != null) {
                        oneSignalNotificationBuilder.f2417b = true;
                        notifBuilder.setLargeIcon(largeIcon);
                    }
                    bigPictureIcon = C1167g.m4882d(gcmBundle.optString("bicon", null));
                    if (bigPictureIcon != null) {
                        notifBuilder.setStyle(new C0092b().m322a(bigPictureIcon).m323a(message));
                    }
                    if (C1167g.m4885e(gcmBundle)) {
                        soundUri = C1167g.m4887f(gcmBundle);
                        if (soundUri != null) {
                            notificationDefaults |= 1;
                        } else {
                            notifBuilder.setSound(soundUri);
                        }
                    }
                    notifBuilder.setDefaults(notificationDefaults);
                    if (gcmBundle.optInt("pri", 0) > 9) {
                        notifBuilder.setPriority(2);
                    }
                    oneSignalNotificationBuilder.f2416a = notifBuilder;
                    return oneSignalNotificationBuilder;
                }
            } catch (Throwable th4) {
                notificationDefaults |= 4;
                visibility = 1;
                if (gcmBundle.has("vis")) {
                    visibility = Integer.parseInt(gcmBundle.optString("vis"));
                }
                notifBuilder.setVisibility(visibility);
                largeIcon = C1167g.m4879c(gcmBundle);
                if (largeIcon != null) {
                    oneSignalNotificationBuilder.f2417b = true;
                    notifBuilder.setLargeIcon(largeIcon);
                }
                bigPictureIcon = C1167g.m4882d(gcmBundle.optString("bicon", null));
                if (bigPictureIcon != null) {
                    notifBuilder.setStyle(new C0092b().m322a(bigPictureIcon).m323a(message));
                }
                if (C1167g.m4885e(gcmBundle)) {
                    soundUri = C1167g.m4887f(gcmBundle);
                    if (soundUri != null) {
                        notifBuilder.setSound(soundUri);
                    } else {
                        notificationDefaults |= 1;
                    }
                }
                notifBuilder.setDefaults(notificationDefaults);
                if (gcmBundle.optInt("pri", 0) > 9) {
                    notifBuilder.setPriority(2);
                }
                oneSignalNotificationBuilder.f2416a = notifBuilder;
                return oneSignalNotificationBuilder;
            }
        }
        notificationDefaults |= 4;
        visibility = 1;
        try {
            if (gcmBundle.has("vis")) {
                visibility = Integer.parseInt(gcmBundle.optString("vis"));
            }
            notifBuilder.setVisibility(visibility);
        } catch (Throwable th5) {
        }
        largeIcon = C1167g.m4879c(gcmBundle);
        if (largeIcon != null) {
            oneSignalNotificationBuilder.f2417b = true;
            notifBuilder.setLargeIcon(largeIcon);
        }
        bigPictureIcon = C1167g.m4882d(gcmBundle.optString("bicon", null));
        if (bigPictureIcon != null) {
            notifBuilder.setStyle(new C0092b().m322a(bigPictureIcon).m323a(message));
        }
        if (C1167g.m4885e(gcmBundle)) {
            soundUri = C1167g.m4887f(gcmBundle);
            if (soundUri != null) {
                notifBuilder.setSound(soundUri);
            } else {
                notificationDefaults |= 1;
            }
        }
        notifBuilder.setDefaults(notificationDefaults);
        if (gcmBundle.optInt("pri", 0) > 9) {
            notifBuilder.setPriority(2);
        }
        oneSignalNotificationBuilder.f2416a = notifBuilder;
        return oneSignalNotificationBuilder;
    }

    private static void m4861a(C0094d builder) {
        builder.setDefaults(0).setSound(null).setVibrate(null).setTicker(null);
    }

    private static void m4883d(C1181l notifJob) {
        Notification notification;
        Random random = new Random();
        int notificationId = notifJob.m4932c().intValue();
        JSONObject gcmBundle = notifJob.f2448b;
        String group = gcmBundle.optString("grp", null);
        C1166a oneSignalNotificationBuilder = C1167g.m4880c(notifJob);
        C0094d notifBuilder = oneSignalNotificationBuilder.f2416a;
        C1167g.m4869a(gcmBundle, notifBuilder, notificationId, null);
        try {
            C1167g.m4868a(gcmBundle, notifBuilder);
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Could not set background notification image!", t);
        }
        if (!(notifJob.f2458l == null || notifJob.f2458l.f2445a == null)) {
            notifJob.f2456j = Integer.valueOf(notifBuilder.mNotification.flags);
            notifJob.f2457k = notifBuilder.mNotification.sound;
            notifBuilder.extend(notifJob.f2458l.f2445a);
            notifJob.f2452f = notifBuilder.mContentText;
            notifJob.f2453g = notifBuilder.mContentTitle;
            if (!notifJob.f2449c) {
                notifJob.f2455i = Integer.valueOf(notifBuilder.mNotification.flags);
                notifJob.f2454h = notifBuilder.mNotification.sound;
            }
        }
        if (notifJob.f2449c) {
            C1167g.m4861a(notifBuilder);
        }
        if (group != null) {
            notifBuilder.setContentIntent(C1167g.m4852a(random.nextInt(), C1167g.m4872b(notificationId).putExtra("onesignal_data", gcmBundle.toString()).putExtra("grp", group)));
            notifBuilder.setDeleteIntent(C1167g.m4852a(random.nextInt(), C1167g.m4877c(notificationId).putExtra("grp", group)));
            notifBuilder.setGroup(group);
            notification = C1167g.m4851a(notifJob, notifBuilder);
            C1167g.m4866a(notifJob, oneSignalNotificationBuilder);
        } else {
            notifBuilder.setContentIntent(C1167g.m4852a(random.nextInt(), C1167g.m4872b(notificationId).putExtra("onesignal_data", gcmBundle.toString())));
            notifBuilder.setDeleteIntent(C1167g.m4852a(random.nextInt(), C1167g.m4877c(notificationId)));
            notification = notifBuilder.build();
        }
        if (group == null || VERSION.SDK_INT > 17) {
            C1167g.m4864a(oneSignalNotificationBuilder, notification);
            ap.m443a(f2418a).m448a(notificationId, notification);
        }
    }

    private static Notification m4851a(C1181l notifJob, C0094d notifBuilder) {
        boolean singleNotifWorkArounds = VERSION.SDK_INT > 17 && VERSION.SDK_INT < 24 && !notifJob.f2449c;
        if (!(!singleNotifWorkArounds || notifJob.f2454h == null || notifJob.f2454h.equals(notifJob.f2457k))) {
            notifBuilder.setSound(null);
        }
        Notification notification = notifBuilder.build();
        if (singleNotifWorkArounds) {
            notifBuilder.setSound(notifJob.f2454h);
        }
        return notification;
    }

    private static void m4864a(C1166a oneSignalNotificationBuilder, Notification notification) {
        if (VERSION.SDK_INT >= 11 && oneSignalNotificationBuilder.f2417b) {
            try {
                Object miuiNotification = Class.forName("android.app.MiuiNotification").newInstance();
                Field customizedIconField = miuiNotification.getClass().getDeclaredField("customizedIcon");
                customizedIconField.setAccessible(true);
                customizedIconField.set(miuiNotification, Boolean.valueOf(true));
                Field extraNotificationField = notification.getClass().getField("extraNotification");
                extraNotificationField.setAccessible(true);
                extraNotificationField.set(notification, miuiNotification);
            } catch (Throwable th) {
            }
        }
    }

    static void m4876b(C1181l notifJob) {
        C1167g.m4859a(notifJob.f2447a);
        C1167g.m4866a(notifJob, null);
    }

    private static void m4866a(C1181l notifJob, C1166a notifBuilder) {
        Throwable th;
        boolean updateSummary = notifJob.f2449c;
        JSONObject gcmBundle = notifJob.f2448b;
        String group = gcmBundle.optString("grp", null);
        Random random = new Random();
        PendingIntent summaryDeleteIntent = C1167g.m4852a(random.nextInt(), C1167g.m4877c(0).putExtra("summary", group));
        Integer summaryNotificationId = null;
        String firstFullData = null;
        Collection<SpannableString> summaryList = null;
        ab dbHelper = ab.m4715a(f2418a);
        Cursor cursor = null;
        try {
            Notification summaryNotification;
            SQLiteDatabase readableDb = dbHelper.m4718b();
            String[] retColumn = new String[]{"android_notification_id", "full_data", "is_summary", "title", "message"};
            String whereStr = "group_id = ? AND dismissed = 0 AND opened = 0";
            String[] whereArgs = new String[]{group};
            if (!(updateSummary || notifJob.m4932c().intValue() == -1)) {
                whereStr = whereStr + " AND android_notification_id <> " + notifJob.m4932c();
            }
            cursor = readableDb.query("notification", retColumn, whereStr, whereArgs, null, null, "_id DESC");
            if (cursor.moveToFirst()) {
                Collection<SpannableString> summaryList2 = new ArrayList();
                do {
                    if (cursor.getInt(cursor.getColumnIndex("is_summary")) == 1) {
                        summaryNotificationId = Integer.valueOf(cursor.getInt(cursor.getColumnIndex("android_notification_id")));
                    } else {
                        try {
                            String title = cursor.getString(cursor.getColumnIndex("title"));
                            if (title == null) {
                                title = "";
                            } else {
                                title = title + " ";
                            }
                            SpannableString spannableString = new SpannableString(title + cursor.getString(cursor.getColumnIndex("message")));
                            if (title.length() > 0) {
                                spannableString.setSpan(new StyleSpan(1), 0, title.length(), 0);
                            }
                            summaryList2.add(spannableString);
                            if (firstFullData == null) {
                                firstFullData = cursor.getString(cursor.getColumnIndex("full_data"));
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        } catch (Throwable th2) {
                            th = th2;
                            summaryList = summaryList2;
                        }
                    }
                } while (cursor.moveToNext());
                if (updateSummary && firstFullData != null) {
                    summaryList = summaryList2;
                    gcmBundle = new JSONObject(firstFullData);
                }
                summaryList = summaryList2;
            }
            if (!(cursor == null || cursor.isClosed())) {
                cursor.close();
            }
            if (summaryNotificationId == null) {
                summaryNotificationId = Integer.valueOf(random.nextInt());
                C1167g.m4863a(dbHelper, group, summaryNotificationId.intValue());
            }
            PendingIntent summaryContentIntent = C1167g.m4852a(random.nextInt(), C1167g.m4854a(summaryNotificationId.intValue(), gcmBundle, group));
            C0094d summaryBuilder;
            if (summaryList == null || ((!updateSummary || summaryList.size() <= 1) && (updateSummary || summaryList.size() <= 0))) {
                summaryBuilder = notifBuilder.f2416a;
                summaryBuilder.mActions.clear();
                C1167g.m4869a(gcmBundle, summaryBuilder, summaryNotificationId.intValue(), group);
                summaryBuilder.setContentIntent(summaryContentIntent).setDeleteIntent(summaryDeleteIntent).setOnlyAlertOnce(updateSummary).setGroup(group).setGroupSummary(true);
                summaryNotification = summaryBuilder.build();
                C1167g.m4864a(notifBuilder, summaryNotification);
            } else {
                int notificationCount = summaryList.size() + (updateSummary ? 0 : 1);
                String summaryMessage = gcmBundle.optString("grp_msg", null);
                if (summaryMessage == null) {
                    summaryMessage = notificationCount + " new messages";
                } else {
                    summaryMessage = summaryMessage.replace("$[notif_count]", "" + notificationCount);
                }
                summaryBuilder = C1167g.m4880c(notifJob).f2416a;
                if (updateSummary) {
                    C1167g.m4861a(summaryBuilder);
                } else {
                    if (notifJob.f2454h != null) {
                        summaryBuilder.setSound(notifJob.f2454h);
                    }
                    if (notifJob.f2455i != null) {
                        summaryBuilder.setDefaults(notifJob.f2455i.intValue());
                    }
                }
                summaryBuilder.setContentIntent(summaryContentIntent).setDeleteIntent(summaryDeleteIntent).setContentTitle(f2418a.getPackageManager().getApplicationLabel(f2418a.getApplicationInfo())).setContentText(summaryMessage).setNumber(notificationCount).setSmallIcon(C1167g.m4871b()).setLargeIcon(C1167g.m4855a()).setOnlyAlertOnce(updateSummary).setGroup(group).setGroupSummary(true);
                if (!updateSummary) {
                    summaryBuilder.setTicker(summaryMessage);
                }
                C0091q inboxStyle = new C0097g();
                if (!updateSummary) {
                    String line1Title = null;
                    if (notifJob.m4929a() != null) {
                        line1Title = notifJob.m4929a().toString();
                    }
                    if (line1Title == null) {
                        line1Title = "";
                    } else {
                        line1Title = line1Title + " ";
                    }
                    CharSequence spannableString2 = new SpannableString(line1Title + notifJob.m4931b().toString());
                    if (line1Title.length() > 0) {
                        spannableString2.setSpan(new StyleSpan(1), 0, line1Title.length(), 0);
                    }
                    inboxStyle.m327b(spannableString2);
                }
                for (SpannableString line : summaryList) {
                    inboxStyle.m327b(line);
                }
                inboxStyle.m326a(summaryMessage);
                summaryBuilder.setStyle(inboxStyle);
                summaryNotification = summaryBuilder.build();
            }
            ap.m443a(f2418a).m448a(summaryNotificationId.intValue(), summaryNotification);
        } catch (Throwable th3) {
            th = th3;
            if (!(cursor == null || cursor.isClosed())) {
                cursor.close();
            }
            throw th;
        }
    }

    private static Intent m4854a(int summaryNotificationId, JSONObject gcmBundle, String group) {
        return C1167g.m4872b(summaryNotificationId).putExtra("onesignal_data", gcmBundle.toString()).putExtra("summary", group);
    }

    private static void m4863a(ab dbHelper, String group, int id) {
        SQLiteDatabase writableDb = null;
        try {
            writableDb = dbHelper.m4717a();
            writableDb.beginTransaction();
            ContentValues values = new ContentValues();
            values.put("android_notification_id", Integer.valueOf(id));
            values.put("group_id", group);
            values.put("is_summary", Integer.valueOf(1));
            writableDb.insertOrThrow("notification", null, values);
            writableDb.setTransactionSuccessful();
            if (writableDb != null) {
                try {
                    writableDb.endTransaction();
                } catch (Throwable t) {
                    C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t);
                }
            }
        } catch (Throwable t2) {
            C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t2);
        }
    }

    private static void m4868a(JSONObject gcmBundle, C0094d notifBuilder) throws Throwable {
        if (VERSION.SDK_INT >= 16) {
            Bitmap bg_image = null;
            JSONObject jsonBgImage = null;
            String jsonStrBgImage = gcmBundle.optString("bg_img", null);
            if (jsonStrBgImage != null) {
                jsonBgImage = new JSONObject(jsonStrBgImage);
                bg_image = C1167g.m4882d(jsonBgImage.optString("img", null));
            }
            if (bg_image == null) {
                bg_image = C1167g.m4873b("onesignal_bgimage_default_image");
            }
            if (bg_image != null) {
                RemoteViews customView = new RemoteViews(f2418a.getPackageName(), C1148b.onesignal_bgimage_notif_layout);
                customView.setTextViewText(C1147a.os_bgimage_notif_title, C1167g.m4874b(gcmBundle));
                customView.setTextViewText(C1147a.os_bgimage_notif_body, gcmBundle.optString("alert"));
                C1167g.m4862a(customView, jsonBgImage, C1147a.os_bgimage_notif_title, "tc", "onesignal_bgimage_notif_title_color");
                C1167g.m4862a(customView, jsonBgImage, C1147a.os_bgimage_notif_body, "bc", "onesignal_bgimage_notif_body_color");
                String alignSetting = null;
                if (jsonBgImage == null || !jsonBgImage.has("img_align")) {
                    int iAlignSetting = f2420c.getIdentifier("onesignal_bgimage_notif_image_align", "string", f2419b);
                    if (iAlignSetting != 0) {
                        alignSetting = f2420c.getString(iAlignSetting);
                    }
                } else {
                    alignSetting = jsonBgImage.getString("img_align");
                }
                if ("right".equals(alignSetting)) {
                    customView.setViewPadding(C1147a.os_bgimage_notif_bgimage_align_layout, -5000, 0, 0, 0);
                    customView.setImageViewBitmap(C1147a.os_bgimage_notif_bgimage_right_aligned, bg_image);
                    customView.setViewVisibility(C1147a.os_bgimage_notif_bgimage_right_aligned, 0);
                    customView.setViewVisibility(C1147a.os_bgimage_notif_bgimage, 2);
                } else {
                    customView.setImageViewBitmap(C1147a.os_bgimage_notif_bgimage, bg_image);
                }
                notifBuilder.setContent(customView);
                notifBuilder.setStyle(null);
            }
        }
    }

    private static void m4862a(RemoteViews customView, JSONObject gcmBundle, int viewId, String colorPayloadKey, String colorDefaultResource) {
        Integer color = C1167g.m4858a(gcmBundle, colorPayloadKey);
        if (color != null) {
            customView.setTextColor(viewId, color.intValue());
            return;
        }
        int colorId = f2420c.getIdentifier(colorDefaultResource, "color", f2419b);
        if (colorId != 0) {
            customView.setTextColor(viewId, C1159c.m4844a(f2418a, colorId));
        }
    }

    private static Integer m4858a(JSONObject gcmBundle, String colorKey) {
        if (gcmBundle != null) {
            try {
                if (gcmBundle.has(colorKey)) {
                    return Integer.valueOf(new BigInteger(gcmBundle.optString(colorKey), 16).intValue());
                }
            } catch (Throwable th) {
            }
        }
        return null;
    }

    private static boolean m4870a(String name) {
        return (name == null || name.matches("^[0-9]")) ? false : true;
    }

    private static Bitmap m4879c(JSONObject gcmBundle) {
        if (VERSION.SDK_INT < 11) {
            return null;
        }
        Bitmap bitmap = C1167g.m4882d(gcmBundle.optString("licon"));
        if (bitmap == null) {
            bitmap = C1167g.m4873b("ic_onesignal_large_icon_default");
        }
        if (bitmap != null) {
            return C1167g.m4856a(bitmap);
        }
        return null;
    }

    private static Bitmap m4855a() {
        if (VERSION.SDK_INT < 11) {
            return null;
        }
        return C1167g.m4856a(C1167g.m4873b("ic_onesignal_large_icon_default"));
    }

    private static Bitmap m4856a(Bitmap bitmap) {
        if (bitmap == null) {
            return null;
        }
        try {
            int systemLargeIconHeight = (int) f2420c.getDimension(17104902);
            int systemLargeIconWidth = (int) f2420c.getDimension(17104901);
            int bitmapHeight = bitmap.getHeight();
            int bitmapWidth = bitmap.getWidth();
            if (bitmapWidth <= systemLargeIconWidth && bitmapHeight <= systemLargeIconHeight) {
                return bitmap;
            }
            int newWidth = systemLargeIconWidth;
            int newHeight = systemLargeIconHeight;
            if (bitmapHeight > bitmapWidth) {
                newWidth = (int) (((float) newHeight) * (((float) bitmapWidth) / ((float) bitmapHeight)));
            } else if (bitmapWidth > bitmapHeight) {
                newHeight = (int) (((float) newWidth) * (((float) bitmapHeight) / ((float) bitmapWidth)));
            }
            return Bitmap.createScaledBitmap(bitmap, newWidth, newHeight, true);
        } catch (Throwable th) {
            return bitmap;
        }
    }

    private static Bitmap m4873b(String bitmapStr) {
        Bitmap bitmap = null;
        try {
            bitmap = BitmapFactory.decodeStream(f2418a.getAssets().open(bitmapStr));
        } catch (Throwable th) {
        }
        if (bitmap != null) {
            return bitmap;
        }
        try {
            for (String extension : Arrays.asList(new String[]{".png", ".webp", ".jpg", ".gif", ".bmp"})) {
                try {
                    bitmap = BitmapFactory.decodeStream(f2418a.getAssets().open(bitmapStr + extension));
                    continue;
                } catch (Throwable th2) {
                    continue;
                }
                if (bitmap != null) {
                    return bitmap;
                }
            }
            int bitmapId = C1167g.m4884e(bitmapStr);
            if (bitmapId != 0) {
                return BitmapFactory.decodeResource(f2420c, bitmapId);
            }
        } catch (Throwable th3) {
        }
        return null;
    }

    private static Bitmap m4878c(String location) {
        try {
            return BitmapFactory.decodeStream(new URL(location).openConnection().getInputStream());
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.WARN, "Could not download image!", t);
            return null;
        }
    }

    private static Bitmap m4882d(String name) {
        if (name == null) {
            return null;
        }
        String trimmedName = name.trim();
        if (trimmedName.startsWith("http://") || trimmedName.startsWith("https://")) {
            return C1167g.m4878c(trimmedName);
        }
        return C1167g.m4873b(name);
    }

    private static int m4884e(String iconName) {
        if (iconName == null) {
            return 0;
        }
        String trimmedIconName = iconName.trim();
        if (!C1167g.m4870a(trimmedIconName)) {
            return 0;
        }
        int notificationIcon = C1167g.m4886f(trimmedIconName);
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        try {
            return drawable.class.getField(iconName).getInt(null);
        } catch (Throwable th) {
            return 0;
        }
    }

    private static int m4881d(JSONObject gcmBundle) {
        int notificationIcon = C1167g.m4884e(gcmBundle.optString("sicon", null));
        return notificationIcon != 0 ? notificationIcon : C1167g.m4871b();
    }

    private static int m4871b() {
        int notificationIcon = C1167g.m4886f("ic_stat_onesignal_default");
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        notificationIcon = C1167g.m4886f("corona_statusbar_icon_default");
        if (notificationIcon != 0) {
            return notificationIcon;
        }
        notificationIcon = C1167g.m4886f("ic_os_notification_fallback_white_24dp");
        return notificationIcon == 0 ? 17301598 : notificationIcon;
    }

    private static int m4886f(String name) {
        return f2420c.getIdentifier(name, "drawable", f2419b);
    }

    private static boolean m4885e(JSONObject gcmBundle) {
        String sound = gcmBundle.optString("sound", null);
        if ("null".equals(sound) || "nil".equals(sound)) {
            return false;
        }
        return C1226z.m5089c(f2418a);
    }

    private static Uri m4887f(JSONObject gcmBundle) {
        int soundId;
        String sound = gcmBundle.optString("sound", null);
        if (C1167g.m4870a(sound)) {
            soundId = f2420c.getIdentifier(sound, "raw", f2419b);
            if (soundId != 0) {
                return Uri.parse("android.resource://" + f2419b + "/" + soundId);
            }
        }
        soundId = f2420c.getIdentifier("onesignal_default_sound", "raw", f2419b);
        if (soundId != 0) {
            return Uri.parse("android.resource://" + f2419b + "/" + soundId);
        }
        return null;
    }

    private static BigInteger m4888g(JSONObject gcmBundle) {
        try {
            if (gcmBundle.has("bgac")) {
                return new BigInteger(gcmBundle.optString("bgac", null), 16);
            }
        } catch (Throwable th) {
        }
        try {
            String defaultColor = C1207y.m5010a(f2418a, "com.onesignal.NotificationAccentColor.DEFAULT");
            if (defaultColor != null) {
                return new BigInteger(defaultColor, 16);
            }
        } catch (Throwable th2) {
        }
        return null;
    }

    private static void m4869a(JSONObject gcmBundle, C0094d mBuilder, int notificationId, String groupSummary) {
        try {
            JSONObject customJson = new JSONObject(gcmBundle.optString("custom"));
            if (customJson.has("a")) {
                JSONObject additionalDataJSON = customJson.getJSONObject("a");
                if (additionalDataJSON.has("actionButtons")) {
                    JSONArray buttons = additionalDataJSON.getJSONArray("actionButtons");
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject button = buttons.optJSONObject(i);
                        JSONObject bundle = new JSONObject(gcmBundle.toString());
                        Intent buttonIntent = C1167g.m4872b(notificationId);
                        buttonIntent.setAction("" + i);
                        buttonIntent.putExtra("action_button", true);
                        bundle.put("actionSelected", button.optString("id"));
                        buttonIntent.putExtra("onesignal_data", bundle.toString());
                        if (groupSummary != null) {
                            buttonIntent.putExtra("summary", groupSummary);
                        } else if (gcmBundle.has("grp")) {
                            buttonIntent.putExtra("grp", gcmBundle.optString("grp"));
                        }
                        PendingIntent buttonPIntent = C1167g.m4852a(notificationId, buttonIntent);
                        int buttonIcon = 0;
                        if (button.has("icon")) {
                            buttonIcon = C1167g.m4884e(button.optString("icon"));
                        }
                        mBuilder.addAction(buttonIcon, button.optString("text"), buttonPIntent);
                    }
                }
            }
        } catch (Throwable t) {
            t.printStackTrace();
        }
    }

    private static void m4875b(Context context, JSONObject gcmBundle, List<String> buttonsLabels, List<String> buttonsIds) {
        try {
            JSONObject customJson = new JSONObject(gcmBundle.optString("custom"));
            if (customJson.has("a")) {
                JSONObject additionalDataJSON = customJson.getJSONObject("a");
                if (additionalDataJSON.has("actionButtons")) {
                    JSONArray buttons = additionalDataJSON.optJSONArray("actionButtons");
                    for (int i = 0; i < buttons.length(); i++) {
                        JSONObject button = buttons.getJSONObject(i);
                        buttonsLabels.add(button.optString("text"));
                        buttonsIds.add(button.optString("id"));
                    }
                }
            }
            if (buttonsLabels.size() < 3) {
                buttonsLabels.add(C1207y.m5011a(context, "onesignal_in_app_alert_ok_button_text", "Ok"));
                buttonsIds.add("__DEFAULT__");
            }
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Failed to parse buttons for alert dialog.", t);
        }
    }
}
