package com.onesignal;

import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v4.content.C0216j;
import com.onesignal.C1180k.C1179a;
import com.onesignal.C1201t.C1199a;
import com.onesignal.C1201t.C1200b;
import com.onesignal.C1226z.C1222e;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: NotificationBundleProcessor */
class C1178j {

    /* compiled from: NotificationBundleProcessor */
    static class C1177a {
        boolean f2442a;
        boolean f2443b;
        boolean f2444c;

        C1177a() {
        }

        boolean m4912a() {
            return !this.f2442a || this.f2443b || this.f2444c;
        }
    }

    private static void m4926b(com.onesignal.C1181l r13) {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r1 = r13.f2449c;
        if (r1 == 0) goto L_0x0005;
    L_0x0004:
        return;
    L_0x0005:
        r1 = r13.f2448b;
        r2 = "collapse_key";
        r1 = r1.has(r2);
        if (r1 == 0) goto L_0x0004;
    L_0x000f:
        r1 = "do_not_collapse";
        r2 = r13.f2448b;
        r3 = "collapse_key";
        r2 = r2.optString(r3);
        r1 = r1.equals(r2);
        if (r1 != 0) goto L_0x0004;
    L_0x001f:
        r1 = r13.f2448b;
        r2 = "collapse_key";
        r9 = r1.optString(r2);
        r1 = r13.f2447a;
        r11 = com.onesignal.ab.m4715a(r1);
        r10 = 0;
        r0 = r11.m4718b();	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r1 = "notification";	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r2 = 1;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r2 = new java.lang.String[r2];	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r3 = 0;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r4 = "android_notification_id";	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r2[r3] = r4;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r3 = "collapse_id = ? AND dismissed = 0 AND opened = 0 ";	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r4 = 1;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r4 = new java.lang.String[r4];	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r5 = 0;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r4[r5] = r9;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r5 = 0;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r6 = 0;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r7 = 0;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r10 = r0.query(r1, r2, r3, r4, r5, r6, r7);	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r1 = r10.moveToFirst();	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        if (r1 == 0) goto L_0x0062;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
    L_0x0051:
        r1 = "android_notification_id";	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r1 = r10.getColumnIndex(r1);	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r8 = r10.getInt(r1);	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r1 = java.lang.Integer.valueOf(r8);	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r13.m4930a(r1);	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
    L_0x0062:
        if (r10 == 0) goto L_0x0004;
    L_0x0064:
        r1 = r10.isClosed();
        if (r1 != 0) goto L_0x0004;
    L_0x006a:
        r10.close();
        goto L_0x0004;
    L_0x006e:
        r12 = move-exception;
        r1 = com.onesignal.C1226z.C1222e.ERROR;	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        r2 = "Could not read DB to find existing collapse_key!";	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        com.onesignal.C1226z.m5061a(r1, r2, r12);	 Catch:{ Throwable -> 0x006e, all -> 0x0082 }
        if (r10 == 0) goto L_0x0004;
    L_0x0078:
        r1 = r10.isClosed();
        if (r1 != 0) goto L_0x0004;
    L_0x007e:
        r10.close();
        goto L_0x0004;
    L_0x0082:
        r1 = move-exception;
        if (r10 == 0) goto L_0x008e;
    L_0x0085:
        r2 = r10.isClosed();
        if (r2 != 0) goto L_0x008e;
    L_0x008b:
        r10.close();
    L_0x008e:
        throw r1;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.onesignal.j.b(com.onesignal.l):void");
    }

    static void m4917a(Context context, Bundle bundle, C1179a overrideSettings) {
        try {
            String jsonStrPayload = bundle.getString("json_payload");
            if (jsonStrPayload == null) {
                C1226z.m5060a(C1222e.ERROR, "json_payload key is nonexistent from bundle passed to ProcessFromGCMIntentService: " + bundle);
                return;
            }
            C1181l notifJob = new C1181l(context);
            notifJob.f2449c = bundle.getBoolean("restoring", false);
            notifJob.f2451e = Long.valueOf(bundle.getLong("timestamp"));
            notifJob.f2448b = new JSONObject(jsonStrPayload);
            if (notifJob.f2449c || !C1226z.m5070a(context, notifJob.f2448b)) {
                if (bundle.containsKey("android_notif_id")) {
                    if (overrideSettings == null) {
                        overrideSettings = new C1179a();
                    }
                    overrideSettings.f2446b = Integer.valueOf(bundle.getInt("android_notif_id"));
                }
                notifJob.f2458l = overrideSettings;
                C1178j.m4913a(notifJob);
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    static int m4913a(C1181l notifJob) {
        boolean z = true;
        if (!(C1226z.m5110i() && C1226z.m5116m())) {
            z = false;
        }
        notifJob.f2450d = z;
        C1178j.m4926b(notifJob);
        C1167g.m4865a(notifJob);
        if (!notifJob.f2449c) {
            C1178j.m4920a(notifJob, false);
            try {
                JSONObject jsonObject = new JSONObject(notifJob.f2448b.toString());
                jsonObject.put("notificationId", notifJob.m4932c());
                C1226z.m5066a(C1178j.m4924b(jsonObject), true, notifJob.f2450d);
            } catch (Throwable th) {
            }
        }
        return notifJob.m4932c().intValue();
    }

    static JSONArray m4916a(Bundle bundle) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(C1178j.m4925b(bundle));
        return jsonArray;
    }

    static void m4918a(Context context, Bundle bundle, boolean opened, int notificationId) {
        C1181l notifJob = new C1181l(context);
        notifJob.f2448b = C1178j.m4925b(bundle);
        notifJob.f2458l = new C1179a();
        notifJob.f2458l.f2446b = Integer.valueOf(notificationId);
        C1178j.m4920a(notifJob, opened);
    }

    static void m4920a(C1181l notifiJob, boolean opened) {
        int i = 1;
        Context context = notifiJob.f2447a;
        JSONObject jsonPayload = notifiJob.f2448b;
        try {
            JSONObject customJSON = new JSONObject(notifiJob.f2448b.optString("custom"));
            SQLiteDatabase writableDb = null;
            try {
                ContentValues values;
                writableDb = ab.m4715a(notifiJob.f2447a).m4717a();
                writableDb.beginTransaction();
                C1178j.m4919a(writableDb);
                if (notifiJob.f2458l.f2446b.intValue() != -1) {
                    String whereStr = "android_notification_id = " + notifiJob.f2458l.f2446b;
                    values = new ContentValues();
                    values.put("dismissed", Integer.valueOf(1));
                    writableDb.update("notification", values, whereStr, null);
                    C1162f.m4848a(writableDb, context);
                }
                values = new ContentValues();
                values.put("notification_id", customJSON.optString("i"));
                if (jsonPayload.has("grp")) {
                    values.put("group_id", jsonPayload.optString("grp"));
                }
                if (jsonPayload.has("collapse_key") && !"do_not_collapse".equals(jsonPayload.optString("collapse_key"))) {
                    values.put("collapse_id", jsonPayload.optString("collapse_key"));
                }
                String str = "opened";
                if (!opened) {
                    i = 0;
                }
                values.put(str, Integer.valueOf(i));
                if (!opened) {
                    values.put("android_notification_id", notifiJob.f2458l.f2446b);
                }
                if (notifiJob.m4929a() != null) {
                    values.put("title", notifiJob.m4929a().toString());
                }
                values.put("message", notifiJob.m4931b().toString());
                values.put("full_data", jsonPayload.toString());
                writableDb.insertOrThrow("notification", null, values);
                if (!opened) {
                    C1162f.m4848a(writableDb, context);
                }
                writableDb.setTransactionSuccessful();
                if (writableDb != null) {
                    try {
                        writableDb.endTransaction();
                    } catch (Throwable t) {
                        C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t);
                    }
                }
            } catch (Throwable e) {
                C1226z.m5061a(C1222e.ERROR, "Error saving notification record! ", e);
                if (writableDb != null) {
                    writableDb.endTransaction();
                }
            } catch (Throwable t2) {
                C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t2);
            }
        } catch (JSONException e2) {
            e2.printStackTrace();
        } catch (Throwable t22) {
            C1226z.m5061a(C1222e.ERROR, "Error closing transaction! ", t22);
        }
    }

    static void m4919a(SQLiteDatabase writableDb) {
        writableDb.delete("notification", "created_time < " + ((System.currentTimeMillis() / 1000) - 604800), null);
    }

    static JSONObject m4925b(Bundle bundle) {
        JSONObject json = new JSONObject();
        for (String key : bundle.keySet()) {
            try {
                json.put(key, bundle.get(key));
            } catch (Throwable e) {
                C1226z.m5061a(C1222e.ERROR, "bundleAsJSONObject error for key: " + key, e);
            }
        }
        return json;
    }

    private static void m4927c(Bundle gcmBundle) {
        if (gcmBundle.containsKey("o")) {
            try {
                JSONObject additionalDataJSON;
                JSONObject customJSON = new JSONObject(gcmBundle.getString("custom"));
                if (customJSON.has("a")) {
                    additionalDataJSON = customJSON.getJSONObject("a");
                } else {
                    additionalDataJSON = new JSONObject();
                }
                JSONArray buttons = new JSONArray(gcmBundle.getString("o"));
                gcmBundle.remove("o");
                for (int i = 0; i < buttons.length(); i++) {
                    String buttonId;
                    JSONObject button = buttons.getJSONObject(i);
                    String buttonText = button.getString("n");
                    button.remove("n");
                    if (button.has("i")) {
                        buttonId = button.getString("i");
                        button.remove("i");
                    } else {
                        buttonId = buttonText;
                    }
                    button.put("id", buttonId);
                    button.put("text", buttonText);
                    if (button.has("p")) {
                        button.put("icon", button.getString("p"));
                        button.remove("p");
                    }
                }
                additionalDataJSON.put("actionButtons", buttons);
                additionalDataJSON.put("actionSelected", "__DEFAULT__");
                if (!customJSON.has("a")) {
                    customJSON.put("a", additionalDataJSON);
                }
                gcmBundle.putString("custom", customJSON.toString());
            } catch (JSONException e) {
                e.printStackTrace();
            }
        }
    }

    static C1201t m4915a(JSONObject currentJsonPayload) {
        C1201t notification = new C1201t();
        try {
            JSONObject customJson = new JSONObject(currentJsonPayload.optString("custom"));
            notification.f2497a = customJson.optString("i");
            notification.f2516t = currentJsonPayload.toString();
            notification.f2500d = customJson.optJSONObject("a");
            notification.f2505i = customJson.optString("u", null);
            notification.f2499c = currentJsonPayload.optString("alert", null);
            notification.f2498b = currentJsonPayload.optString("title", null);
            notification.f2501e = currentJsonPayload.optString("sicon", null);
            notification.f2503g = currentJsonPayload.optString("bicon", null);
            notification.f2502f = currentJsonPayload.optString("licon", null);
            notification.f2506j = currentJsonPayload.optString("sound", null);
            notification.f2509m = currentJsonPayload.optString("grp", null);
            notification.f2510n = currentJsonPayload.optString("grp_msg", null);
            notification.f2504h = currentJsonPayload.optString("bgac", null);
            notification.f2507k = currentJsonPayload.optString("ledc", null);
            String visibility = currentJsonPayload.optString("vis", null);
            if (visibility != null) {
                notification.f2508l = Integer.parseInt(visibility);
            }
            notification.f2512p = currentJsonPayload.optString("from", null);
            notification.f2515s = currentJsonPayload.optInt("pri", 0);
            String collapseKey = currentJsonPayload.optString("collapse_key", null);
            if (!"do_not_collapse".equals(collapseKey)) {
                notification.f2514r = collapseKey;
            }
            C1178j.m4921a(notification);
        } catch (Throwable t) {
            C1226z.m5061a(C1222e.ERROR, "Error assigning OSNotificationPayload values!", t);
        }
        try {
            C1178j.m4922a(notification, currentJsonPayload);
        } catch (Throwable t2) {
            C1226z.m5061a(C1222e.ERROR, "Error assigning OSNotificationPayload.backgroundImageLayout values!", t2);
        }
        return notification;
    }

    private static void m4921a(C1201t notification) throws Throwable {
        if (notification.f2500d != null && notification.f2500d.has("actionButtons")) {
            JSONArray jsonActionButtons = notification.f2500d.getJSONArray("actionButtons");
            notification.f2511o = new ArrayList();
            for (int i = 0; i < jsonActionButtons.length(); i++) {
                JSONObject jsonActionButton = jsonActionButtons.getJSONObject(i);
                C1199a actionButton = new C1199a();
                actionButton.f2491a = jsonActionButton.optString("id", null);
                actionButton.f2492b = jsonActionButton.optString("text", null);
                actionButton.f2493c = jsonActionButton.optString("icon", null);
                notification.f2511o.add(actionButton);
            }
            notification.f2500d.remove("actionSelected");
            notification.f2500d.remove("actionButtons");
        }
    }

    private static void m4922a(C1201t notification, JSONObject currentJsonPayload) throws Throwable {
        String jsonStrBgImage = currentJsonPayload.optString("bg_img", null);
        if (jsonStrBgImage != null) {
            JSONObject jsonBgImage = new JSONObject(jsonStrBgImage);
            notification.f2513q = new C1200b();
            notification.f2513q.f2494a = jsonBgImage.optString("img");
            notification.f2513q.f2495b = jsonBgImage.optString("tc");
            notification.f2513q.f2496c = jsonBgImage.optString("bc");
        }
    }

    static C1177a m4914a(Context context, final Bundle bundle) {
        C1177a result = new C1177a();
        if (C1226z.m5051a(bundle) != null) {
            result.f2442a = true;
            C1178j.m4927c(bundle);
            Intent overrideIntent = C1180k.m4928a(context);
            if (overrideIntent != null) {
                overrideIntent.putExtra("json_payload", C1178j.m4925b(bundle).toString());
                overrideIntent.putExtra("timestamp", System.currentTimeMillis() / 1000);
                C0216j.m791a(context, overrideIntent);
                result.f2443b = true;
            } else {
                result.f2444c = C1226z.m5070a(context, C1178j.m4925b(bundle));
                if (!result.f2444c) {
                    String alert = bundle.getString("alert");
                    boolean z = (alert == null || "".equals(alert)) ? false : true;
                    if (!C1178j.m4923a(z)) {
                        C1178j.m4918a(context, bundle, true, -1);
                        new Thread(new Runnable() {
                            public void run() {
                                C1226z.m5066a(C1178j.m4916a(bundle), false, false);
                            }
                        }, "OS_PROC_BUNDLE").start();
                    }
                }
            }
        }
        return result;
    }

    static boolean m4923a(boolean hasBody) {
        return hasBody && (C1226z.m5107h() || C1226z.m5110i() || !C1226z.m5116m());
    }

    static JSONArray m4924b(JSONObject jsonObject) {
        JSONArray jsonArray = new JSONArray();
        jsonArray.put(jsonObject);
        return jsonArray;
    }
}
