package com.onesignal;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/* compiled from: NotificationOpenedActivity */
public class C1182m extends Activity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        C1183n.m4933a(this, getIntent());
        finish();
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        C1183n.m4933a(this, getIntent());
        finish();
    }
}
