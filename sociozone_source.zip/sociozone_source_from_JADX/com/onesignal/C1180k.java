package com.onesignal;

import android.app.IntentService;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.support.v4.app.ag;
import android.support.v4.app.ag.C0096f;

/* compiled from: NotificationExtenderService */
public abstract class C1180k extends IntentService {

    /* compiled from: NotificationExtenderService */
    public static class C1179a {
        public C0096f f2445a;
        public Integer f2446b;
    }

    static Intent m4928a(Context context) {
        PackageManager packageManager = context.getPackageManager();
        Intent intent = new Intent().setAction("com.onesignal.NotificationExtender").setPackage(context.getPackageName());
        if (packageManager.queryIntentServices(intent, ag.FLAG_HIGH_PRIORITY).size() < 1) {
            return null;
        }
        return intent;
    }
}
