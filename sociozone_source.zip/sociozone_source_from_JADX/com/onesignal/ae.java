package com.onesignal;

import android.content.Context;

/* compiled from: PushRegistrator */
public interface ae {

    /* compiled from: PushRegistrator */
    public interface C1141a {
        void mo1139a(String str, int i);
    }

    void mo1134a(Context context, String str, C1141a c1141a);
}
