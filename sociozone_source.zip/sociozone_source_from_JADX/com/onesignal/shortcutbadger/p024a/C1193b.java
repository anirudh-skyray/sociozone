package com.onesignal.shortcutbadger.p024a;

import android.database.Cursor;
import java.io.Closeable;
import java.io.IOException;

/* compiled from: CloseHelper */
public class C1193b {
    public static void m4949a(Cursor cursor) {
        if (cursor != null && !cursor.isClosed()) {
            cursor.close();
        }
    }

    public static void m4950a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }
}
