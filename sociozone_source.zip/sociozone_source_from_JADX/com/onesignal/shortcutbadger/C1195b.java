package com.onesignal.shortcutbadger;

/* compiled from: ShortcutBadgeException */
public class C1195b extends Exception {
    public C1195b(String message) {
        super(message);
    }

    public C1195b(String message, Exception e) {
        super(message, e);
    }
}
