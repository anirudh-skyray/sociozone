package com.onesignal.shortcutbadger.impl;

import android.annotation.TargetApi;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import com.onesignal.shortcutbadger.p024a.C1192a;
import com.onesignal.shortcutbadger.p024a.C1193b;
import java.io.BufferedReader;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Collections;
import java.util.List;

public class OPPOHomeBader implements C1194a {
    private static int f2483a = -1;

    @TargetApi(11)
    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        if (badgeCount == 0) {
            badgeCount = -1;
        }
        Intent intent = new Intent("com.oppo.unsettledevent");
        intent.putExtra("pakeageName", componentName.getPackageName());
        intent.putExtra("number", badgeCount);
        intent.putExtra("upgradeNumber", badgeCount);
        if (C1192a.m4948a(context, intent)) {
            context.sendBroadcast(intent);
        } else if (m4976b() == 6) {
            try {
                Bundle extras = new Bundle();
                extras.putInt("app_badge_count", badgeCount);
                context.getContentResolver().call(Uri.parse("content://com.android.badge/badge"), "setAppBadgeCount", null, extras);
            } catch (Throwable th) {
                C1195b c1195b = new C1195b("unable to resolve intent: " + intent.toString());
            }
        }
    }

    public List<String> mo1137a() {
        return Collections.singletonList("com.oppo.launcher");
    }

    private int m4976b() {
        int i = f2483a;
        if (i >= 0) {
            return f2483a;
        }
        try {
            i = ((Integer) m4973a(m4972a("com.color.os.ColorBuild"), "getColorOSVERSION", null, null)).intValue();
        } catch (Exception e) {
            i = 0;
        }
        if (i == 0) {
            try {
                String str = m4977b("ro.build.version.opporom");
                if (str.startsWith("V1.4")) {
                    return 3;
                }
                if (str.startsWith("V2.0")) {
                    return 4;
                }
                if (str.startsWith("V2.1")) {
                    return 5;
                }
            } catch (Exception e2) {
            }
        }
        f2483a = i;
        return f2483a;
    }

    private Object m4973a(Class cls, String str, Class[] clsArr, Object[] objArr) {
        Object obj = null;
        if (!(cls == null || m4975a((Object) str))) {
            Method method = m4974a(cls, str, clsArr);
            if (method != null) {
                method.setAccessible(true);
                try {
                    obj = method.invoke(null, objArr);
                } catch (IllegalAccessException e) {
                    e.printStackTrace();
                } catch (InvocationTargetException e2) {
                    e2.printStackTrace();
                }
            }
        }
        return obj;
    }

    private Method m4974a(Class cls, String str, Class[] clsArr) {
        Method method = null;
        if (cls == null || m4975a((Object) str)) {
            return method;
        }
        try {
            cls.getMethods();
            cls.getDeclaredMethods();
            return cls.getDeclaredMethod(str, clsArr);
        } catch (Exception e) {
            try {
                return cls.getMethod(str, clsArr);
            } catch (Exception e2) {
                return cls.getSuperclass() != null ? m4974a(cls.getSuperclass(), str, clsArr) : method;
            }
        }
    }

    private Class m4972a(String str) {
        Class cls = null;
        try {
            cls = Class.forName(str);
        } catch (ClassNotFoundException e) {
        }
        return cls;
    }

    private boolean m4975a(Object obj) {
        return obj == null || obj.toString().equals("") || obj.toString().trim().equals("null");
    }

    private String m4977b(String propName) {
        Throwable th;
        Closeable input = null;
        try {
            Closeable input2 = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec("getprop " + propName).getInputStream()), 1024);
            try {
                String line = input2.readLine();
                input2.close();
                C1193b.m4950a(input2);
                input = input2;
                return line;
            } catch (IOException e) {
                input = input2;
                C1193b.m4950a(input);
                return null;
            } catch (Throwable th2) {
                th = th2;
                input = input2;
                C1193b.m4950a(input);
                throw th;
            }
        } catch (IOException e2) {
            C1193b.m4950a(input);
            return null;
        } catch (Throwable th3) {
            th = th3;
            C1193b.m4950a(input);
            throw th;
        }
    }
}
