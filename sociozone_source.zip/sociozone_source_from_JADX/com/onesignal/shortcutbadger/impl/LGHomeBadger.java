package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import com.onesignal.shortcutbadger.p024a.C1192a;
import java.util.Arrays;
import java.util.List;

@Deprecated
public class LGHomeBadger implements C1194a {
    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        Intent intent = new Intent("android.intent.action.BADGE_COUNT_UPDATE");
        intent.putExtra("badge_count", badgeCount);
        intent.putExtra("badge_count_package_name", componentName.getPackageName());
        intent.putExtra("badge_count_class_name", componentName.getClassName());
        if (C1192a.m4948a(context, intent)) {
            context.sendBroadcast(intent);
            return;
        }
        throw new C1195b("unable to resolve intent: " + intent.toString());
    }

    public List<String> mo1137a() {
        return Arrays.asList(new String[]{"com.lge.launcher", "com.lge.launcher2"});
    }
}
