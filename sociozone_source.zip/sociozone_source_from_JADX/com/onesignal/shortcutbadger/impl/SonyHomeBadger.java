package com.onesignal.shortcutbadger.impl;

import android.content.AsyncQueryHandler;
import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Looper;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import java.util.Arrays;
import java.util.List;

public class SonyHomeBadger implements C1194a {
    private final Uri f2487a = Uri.parse("content://com.sonymobile.home.resourceprovider/badge");
    private AsyncQueryHandler f2488b;

    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        if (m4986a(context)) {
            m4988c(context, componentName, badgeCount);
        } else {
            m4987b(context, componentName, badgeCount);
        }
    }

    public List<String> mo1137a() {
        return Arrays.asList(new String[]{"com.sonyericsson.home", "com.sonymobile.home"});
    }

    private static void m4987b(Context context, ComponentName componentName, int badgeCount) {
        Intent intent = new Intent("com.sonyericsson.home.action.UPDATE_BADGE");
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.PACKAGE_NAME", componentName.getPackageName());
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.ACTIVITY_NAME", componentName.getClassName());
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.MESSAGE", String.valueOf(badgeCount));
        intent.putExtra("com.sonyericsson.home.intent.extra.badge.SHOW_MESSAGE", badgeCount > 0);
        context.sendBroadcast(intent);
    }

    private void m4988c(Context context, ComponentName componentName, int badgeCount) {
        if (badgeCount >= 0) {
            ContentValues contentValues = m4983a(badgeCount, componentName);
            if (Looper.myLooper() == Looper.getMainLooper()) {
                if (this.f2488b == null) {
                    this.f2488b = new AsyncQueryHandler(this, context.getApplicationContext().getContentResolver()) {
                        final /* synthetic */ SonyHomeBadger f2486a;
                    };
                }
                m4984a(contentValues);
                return;
            }
            m4985a(context, contentValues);
        }
    }

    private void m4984a(ContentValues contentValues) {
        this.f2488b.startInsert(0, null, this.f2487a, contentValues);
    }

    private void m4985a(Context context, ContentValues contentValues) {
        context.getApplicationContext().getContentResolver().insert(this.f2487a, contentValues);
    }

    private ContentValues m4983a(int badgeCount, ComponentName componentName) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("badge_count", Integer.valueOf(badgeCount));
        contentValues.put("package_name", componentName.getPackageName());
        contentValues.put("activity_name", componentName.getClassName());
        return contentValues;
    }

    private static boolean m4986a(Context context) {
        if (context.getPackageManager().resolveContentProvider("com.sonymobile.home.resourceprovider", 0) != null) {
            return true;
        }
        return false;
    }
}
