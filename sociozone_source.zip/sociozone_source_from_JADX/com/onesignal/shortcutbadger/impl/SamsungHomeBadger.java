package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build.VERSION;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import com.onesignal.shortcutbadger.p024a.C1193b;
import java.util.Arrays;
import java.util.List;

public class SamsungHomeBadger implements C1194a {
    private static final String[] f2484a = new String[]{"_id", "class"};
    private DefaultBadger f2485b;

    public SamsungHomeBadger() {
        if (VERSION.SDK_INT >= 21) {
            this.f2485b = new DefaultBadger();
        }
    }

    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        if (this.f2485b == null || !this.f2485b.m4961a(context)) {
            Uri mUri = Uri.parse("content://com.sec.badge/apps?notify=true");
            ContentResolver contentResolver = context.getContentResolver();
            try {
                Cursor cursor = contentResolver.query(mUri, f2484a, "package=?", new String[]{componentName.getPackageName()}, null);
                if (cursor != null) {
                    String entryActivityName = componentName.getClassName();
                    boolean entryActivityExist = false;
                    while (cursor.moveToNext()) {
                        int id = cursor.getInt(0);
                        contentResolver.update(mUri, m4980a(componentName, badgeCount, false), "_id=?", new String[]{String.valueOf(id)});
                        if (entryActivityName.equals(cursor.getString(cursor.getColumnIndex("class")))) {
                            entryActivityExist = true;
                        }
                    }
                    if (!entryActivityExist) {
                        contentResolver.insert(mUri, m4980a(componentName, badgeCount, true));
                    }
                }
                C1193b.m4949a(cursor);
            } catch (Throwable th) {
                C1193b.m4949a(null);
            }
        } else {
            this.f2485b.mo1138a(context, componentName, badgeCount);
        }
    }

    private ContentValues m4980a(ComponentName componentName, int badgeCount, boolean isInsert) {
        ContentValues contentValues = new ContentValues();
        if (isInsert) {
            contentValues.put("package", componentName.getPackageName());
            contentValues.put("class", componentName.getClassName());
        }
        contentValues.put("badgecount", Integer.valueOf(badgeCount));
        return contentValues;
    }

    public List<String> mo1137a() {
        return Arrays.asList(new String[]{"com.sec.android.app.launcher", "com.sec.android.app.twlauncher"});
    }
}
