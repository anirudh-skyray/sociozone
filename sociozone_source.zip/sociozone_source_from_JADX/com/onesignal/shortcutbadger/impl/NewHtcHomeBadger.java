package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import com.onesignal.shortcutbadger.p024a.C1192a;
import java.util.Arrays;
import java.util.List;

public class NewHtcHomeBadger implements C1194a {
    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        Intent intent1 = new Intent("com.htc.launcher.action.SET_NOTIFICATION");
        intent1.putExtra("com.htc.launcher.extra.COMPONENT", componentName.flattenToShortString());
        intent1.putExtra("com.htc.launcher.extra.COUNT", badgeCount);
        Intent intent = new Intent("com.htc.launcher.action.UPDATE_SHORTCUT");
        intent.putExtra("packagename", componentName.getPackageName());
        intent.putExtra("count", badgeCount);
        if (C1192a.m4948a(context, intent1) || C1192a.m4948a(context, intent)) {
            context.sendBroadcast(intent1);
            context.sendBroadcast(intent);
            return;
        }
        throw new C1195b("unable to resolve intent: " + intent.toString());
    }

    public List<String> mo1137a() {
        return Arrays.asList(new String[]{"com.htc.launcher"});
    }
}
