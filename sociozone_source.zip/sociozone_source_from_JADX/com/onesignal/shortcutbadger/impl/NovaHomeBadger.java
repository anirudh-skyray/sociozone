package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.ContentValues;
import android.content.Context;
import android.net.Uri;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import java.util.Arrays;
import java.util.List;

public class NovaHomeBadger implements C1194a {
    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        ContentValues contentValues = new ContentValues();
        contentValues.put("tag", componentName.getPackageName() + "/" + componentName.getClassName());
        contentValues.put("count", Integer.valueOf(badgeCount));
        context.getContentResolver().insert(Uri.parse("content://com.teslacoilsw.notifier/unread_count"), contentValues);
    }

    public List<String> mo1137a() {
        return Arrays.asList(new String[]{"com.teslacoilsw.launcher"});
    }
}
