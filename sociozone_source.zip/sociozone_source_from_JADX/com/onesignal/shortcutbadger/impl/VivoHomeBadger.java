package com.onesignal.shortcutbadger.impl;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import com.onesignal.shortcutbadger.C1194a;
import com.onesignal.shortcutbadger.C1195b;
import java.util.Arrays;
import java.util.List;

public class VivoHomeBadger implements C1194a {
    public void mo1138a(Context context, ComponentName componentName, int badgeCount) throws C1195b {
        Intent intent = new Intent("launcher.action.CHANGE_APPLICATION_NOTIFICATION_NUM");
        intent.putExtra("packageName", context.getPackageName());
        intent.putExtra("className", componentName.getClassName());
        intent.putExtra("notificationNum", badgeCount);
        context.sendBroadcast(intent);
    }

    public List<String> mo1137a() {
        return Arrays.asList(new String[]{"com.vivo.launcher"});
    }
}
