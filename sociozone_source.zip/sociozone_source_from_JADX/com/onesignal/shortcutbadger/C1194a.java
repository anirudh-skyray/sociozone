package com.onesignal.shortcutbadger;

import android.content.ComponentName;
import android.content.Context;
import java.util.List;

/* compiled from: Badger */
public interface C1194a {
    List<String> mo1137a();

    void mo1138a(Context context, ComponentName componentName, int i) throws C1195b;
}
