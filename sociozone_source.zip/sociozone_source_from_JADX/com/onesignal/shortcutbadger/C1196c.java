package com.onesignal.shortcutbadger;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.util.Log;
import com.onesignal.shortcutbadger.impl.AdwHomeBadger;
import com.onesignal.shortcutbadger.impl.ApexHomeBadger;
import com.onesignal.shortcutbadger.impl.C1198a;
import com.onesignal.shortcutbadger.impl.DefaultBadger;
import com.onesignal.shortcutbadger.impl.EverythingMeHomeBadger;
import com.onesignal.shortcutbadger.impl.HuaweiHomeBadger;
import com.onesignal.shortcutbadger.impl.NewHtcHomeBadger;
import com.onesignal.shortcutbadger.impl.NovaHomeBadger;
import com.onesignal.shortcutbadger.impl.OPPOHomeBader;
import com.onesignal.shortcutbadger.impl.SamsungHomeBadger;
import com.onesignal.shortcutbadger.impl.SonyHomeBadger;
import com.onesignal.shortcutbadger.impl.VivoHomeBadger;
import com.onesignal.shortcutbadger.impl.ZukHomeBadger;
import java.util.LinkedList;
import java.util.List;

/* compiled from: ShortcutBadger */
public final class C1196c {
    private static final List<Class<? extends C1194a>> f2479a = new LinkedList();
    private static final Object f2480b = new Object();
    private static C1194a f2481c;
    private static ComponentName f2482d;

    static {
        f2479a.add(AdwHomeBadger.class);
        f2479a.add(ApexHomeBadger.class);
        f2479a.add(NewHtcHomeBadger.class);
        f2479a.add(NovaHomeBadger.class);
        f2479a.add(SonyHomeBadger.class);
        f2479a.add(C1198a.class);
        f2479a.add(HuaweiHomeBadger.class);
        f2479a.add(OPPOHomeBader.class);
        f2479a.add(SamsungHomeBadger.class);
        f2479a.add(ZukHomeBadger.class);
        f2479a.add(VivoHomeBadger.class);
        f2479a.add(EverythingMeHomeBadger.class);
    }

    public static void m4953a(Context context, int badgeCount) throws C1195b {
        if (f2481c != null || C1196c.m4954a(context)) {
            try {
                f2481c.mo1138a(context, f2482d, badgeCount);
                return;
            } catch (Exception e) {
                throw new C1195b("Unable to execute badge", e);
            }
        }
        throw new C1195b("No default launcher available");
    }

    private static boolean m4954a(Context context) {
        Intent launchIntent = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
        if (launchIntent == null) {
            Log.e("ShortcutBadger", "Unable to find launch intent for package " + context.getPackageName());
            return false;
        }
        f2482d = launchIntent.getComponent();
        Intent intent = new Intent("android.intent.action.MAIN");
        intent.addCategory("android.intent.category.HOME");
        ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent, 65536);
        if (resolveInfo == null || resolveInfo.activityInfo.name.toLowerCase().contains("resolver")) {
            return false;
        }
        String currentHomePackage = resolveInfo.activityInfo.packageName;
        for (Class<? extends C1194a> badger : f2479a) {
            C1194a shortcutBadger = null;
            try {
                shortcutBadger = (C1194a) badger.newInstance();
            } catch (Exception e) {
            }
            if (shortcutBadger != null && shortcutBadger.mo1137a().contains(currentHomePackage)) {
                f2481c = shortcutBadger;
                break;
            }
        }
        if (f2481c == null) {
            if (Build.MANUFACTURER.equalsIgnoreCase("ZUK")) {
                f2481c = new ZukHomeBadger();
            } else if (Build.MANUFACTURER.equalsIgnoreCase("OPPO")) {
                f2481c = new OPPOHomeBader();
            } else if (Build.MANUFACTURER.equalsIgnoreCase("VIVO")) {
                f2481c = new VivoHomeBadger();
            } else {
                f2481c = new DefaultBadger();
            }
        }
        return true;
    }
}
