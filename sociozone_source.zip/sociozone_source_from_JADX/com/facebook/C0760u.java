package com.facebook;

/* compiled from: RequestOutputStream */
interface C0760u {
    void mo889a(GraphRequest graphRequest);
}
