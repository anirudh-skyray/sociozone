package com.facebook;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.C0214h;

public class CustomTabActivity extends Activity {
    public static final String f949a = (CustomTabActivity.class.getSimpleName() + ".action_customTabRedirect");
    public static final String f950b = (CustomTabActivity.class.getSimpleName() + ".action_destroy");
    private BroadcastReceiver f951c;

    class C05831 extends BroadcastReceiver {
        final /* synthetic */ CustomTabActivity f948a;

        C05831(CustomTabActivity this$0) {
            this.f948a = this$0;
        }

        public void onReceive(Context context, Intent intent) {
            this.f948a.finish();
        }
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = new Intent(this, CustomTabMainActivity.class);
        intent.setAction(f949a);
        intent.putExtra(CustomTabMainActivity.f955c, getIntent().getDataString());
        intent.addFlags(603979776);
        startActivityForResult(intent, 2);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == 0) {
            Intent broadcast = new Intent(f949a);
            broadcast.putExtra(CustomTabMainActivity.f955c, getIntent().getDataString());
            C0214h.m783a((Context) this).m788a(broadcast);
            this.f951c = new C05831(this);
            C0214h.m783a((Context) this).m787a(this.f951c, new IntentFilter(f950b));
        }
    }

    protected void onDestroy() {
        C0214h.m783a((Context) this).m786a(this.f951c);
        super.onDestroy();
    }
}
