package com.facebook;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.support.v4.app.ag;
import android.support.v4.content.C0214h;
import android.util.Log;
import com.facebook.AccessToken.C0582a;
import com.facebook.C0722k.C0643a;
import com.facebook.GraphRequest.C0588b;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0700r;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: AccessTokenManager */
final class C0707b {
    private static volatile C0707b f1265a;
    private final C0214h f1266b;
    private final C0639a f1267c;
    private AccessToken f1268d;
    private AtomicBoolean f1269e = new AtomicBoolean(false);
    private Date f1270f = new Date(0);

    /* compiled from: AccessTokenManager */
    private static class C0645a {
        public String f1137a;
        public int f1138b;

        private C0645a() {
        }
    }

    C0707b(C0214h localBroadcastManager, C0639a accessTokenCache) {
        C0700r.m2830a((Object) localBroadcastManager, "localBroadcastManager");
        C0700r.m2830a((Object) accessTokenCache, "accessTokenCache");
        this.f1266b = localBroadcastManager;
        this.f1267c = accessTokenCache;
    }

    static C0707b m2848a() {
        if (f1265a == null) {
            synchronized (C0707b.class) {
                if (f1265a == null) {
                    f1265a = new C0707b(C0214h.m783a(C0717g.m2880f()), new C0639a());
                }
            }
        }
        return f1265a;
    }

    AccessToken m2858b() {
        return this.f1268d;
    }

    boolean m2859c() {
        AccessToken accessToken = this.f1267c.m2619a();
        if (accessToken == null) {
            return false;
        }
        m2851a(accessToken, false);
        return true;
    }

    void m2857a(AccessToken currentAccessToken) {
        m2851a(currentAccessToken, true);
    }

    private void m2851a(AccessToken currentAccessToken, boolean saveToCache) {
        AccessToken oldAccessToken = this.f1268d;
        this.f1268d = currentAccessToken;
        this.f1269e.set(false);
        this.f1270f = new Date(0);
        if (saveToCache) {
            if (currentAccessToken != null) {
                this.f1267c.m2620a(currentAccessToken);
            } else {
                this.f1267c.m2621b();
                C0699q.m2814b(C0717g.m2880f());
            }
        }
        if (!C0699q.m2806a((Object) oldAccessToken, (Object) currentAccessToken)) {
            m2850a(oldAccessToken, currentAccessToken);
        }
    }

    private void m2850a(AccessToken oldAccessToken, AccessToken currentAccessToken) {
        Intent intent = new Intent("com.facebook.sdk.ACTION_CURRENT_ACCESS_TOKEN_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_ACCESS_TOKEN", oldAccessToken);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_ACCESS_TOKEN", currentAccessToken);
        this.f1266b.m788a(intent);
    }

    void m2860d() {
        if (m2855e()) {
            m2856a(null);
        }
    }

    private boolean m2855e() {
        if (this.f1268d == null) {
            return false;
        }
        Long now = Long.valueOf(new Date().getTime());
        if (!this.f1268d.m2414f().m2861a() || now.longValue() - this.f1270f.getTime() <= 3600000 || now.longValue() - this.f1268d.m2415g().getTime() <= 86400000) {
            return false;
        }
        return true;
    }

    private static GraphRequest m2847a(AccessToken accessToken, C0588b callback) {
        return new GraphRequest(accessToken, "me/permissions", new Bundle(), C0755m.GET, callback);
    }

    private static GraphRequest m2853b(AccessToken accessToken, C0588b callback) {
        Bundle parameters = new Bundle();
        parameters.putString("grant_type", "fb_extend_sso_token");
        return new GraphRequest(accessToken, "oauth/access_token", parameters, C0755m.GET, callback);
    }

    void m2856a(final C0582a callback) {
        if (Looper.getMainLooper().equals(Looper.myLooper())) {
            m2854b(callback);
        } else {
            new Handler(Looper.getMainLooper()).post(new Runnable(this) {
                final /* synthetic */ C0707b f1123b;

                public void run() {
                    this.f1123b.m2854b(callback);
                }
            });
        }
    }

    private void m2854b(C0582a callback) {
        final AccessToken accessToken = this.f1268d;
        if (accessToken == null) {
            if (callback != null) {
                callback.m2402a(new C0709e("No current access token to refresh"));
            }
        } else if (this.f1269e.compareAndSet(false, true)) {
            this.f1270f = new Date();
            final Set<String> permissions = new HashSet();
            final Set<String> declinedPermissions = new HashSet();
            final AtomicBoolean permissionsCallSucceeded = new AtomicBoolean(false);
            final C0645a refreshResult = new C0645a();
            C0722k batch = new C0722k(C0707b.m2847a(accessToken, new C0588b(this) {
                final /* synthetic */ C0707b f1127d;

                public void mo855a(C0723l response) {
                    JSONObject result = response.m2916b();
                    if (result != null) {
                        JSONArray permissionsArray = result.optJSONArray("data");
                        if (permissionsArray != null) {
                            permissionsCallSucceeded.set(true);
                            for (int i = 0; i < permissionsArray.length(); i++) {
                                JSONObject permissionEntry = permissionsArray.optJSONObject(i);
                                if (permissionEntry != null) {
                                    String permission = permissionEntry.optString("permission");
                                    String status = permissionEntry.optString(ag.CATEGORY_STATUS);
                                    if (!(C0699q.m2807a(permission) || C0699q.m2807a(status))) {
                                        status = status.toLowerCase(Locale.US);
                                        if (status.equals("granted")) {
                                            permissions.add(permission);
                                        } else if (status.equals("declined")) {
                                            declinedPermissions.add(permission);
                                        } else {
                                            Log.w("AccessTokenManager", "Unexpected status: " + status);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }), C0707b.m2853b(accessToken, new C0588b(this) {
                final /* synthetic */ C0707b f1129b;

                public void mo855a(C0723l response) {
                    JSONObject data = response.m2916b();
                    if (data != null) {
                        refreshResult.f1137a = data.optString("access_token");
                        refreshResult.f1138b = data.optInt("expires_at");
                    }
                }
            }));
            final C0582a c0582a = callback;
            batch.m2896a(new C0643a(this) {
                final /* synthetic */ C0707b f1136g;

                public void mo859a(C0722k batch) {
                    AccessToken newAccessToken;
                    Throwable th;
                    try {
                        if (C0707b.m2848a().m2858b() == null || C0707b.m2848a().m2858b().m2417i() != accessToken.m2417i()) {
                            if (c0582a != null) {
                                c0582a.m2402a(new C0709e("No current access token to refresh"));
                            }
                            this.f1136g.f1269e.set(false);
                            if (!(c0582a == null || null == null)) {
                                c0582a.m2401a(null);
                            }
                            newAccessToken = null;
                        } else if (!permissionsCallSucceeded.get() && refreshResult.f1137a == null && refreshResult.f1138b == 0) {
                            if (c0582a != null) {
                                c0582a.m2402a(new C0709e("Failed to refresh access token"));
                            }
                            this.f1136g.f1269e.set(false);
                            if (!(c0582a == null || null == null)) {
                                c0582a.m2401a(null);
                            }
                            newAccessToken = null;
                        } else {
                            String str;
                            Collection collection;
                            Collection collection2;
                            Date date;
                            if (refreshResult.f1137a != null) {
                                str = refreshResult.f1137a;
                            } else {
                                str = accessToken.m2410b();
                            }
                            String h = accessToken.m2416h();
                            String i = accessToken.m2417i();
                            if (permissionsCallSucceeded.get()) {
                                collection = permissions;
                            } else {
                                collection = accessToken.m2412d();
                            }
                            if (permissionsCallSucceeded.get()) {
                                collection2 = declinedPermissions;
                            } else {
                                collection2 = accessToken.m2413e();
                            }
                            C0708c f = accessToken.m2414f();
                            if (refreshResult.f1138b != 0) {
                                date = new Date(((long) refreshResult.f1138b) * 1000);
                            } else {
                                date = accessToken.m2411c();
                            }
                            newAccessToken = new AccessToken(str, h, i, collection, collection2, f, date, new Date());
                            try {
                                C0707b.m2848a().m2857a(newAccessToken);
                                this.f1136g.f1269e.set(false);
                                if (c0582a != null && newAccessToken != null) {
                                    c0582a.m2401a(newAccessToken);
                                }
                            } catch (Throwable th2) {
                                th = th2;
                                this.f1136g.f1269e.set(false);
                                c0582a.m2401a(newAccessToken);
                                throw th;
                            }
                        }
                    } catch (Throwable th3) {
                        th = th3;
                        newAccessToken = null;
                        this.f1136g.f1269e.set(false);
                        if (!(c0582a == null || newAccessToken == null)) {
                            c0582a.m2401a(newAccessToken);
                        }
                        throw th;
                    }
                }
            });
            batch.m2906h();
        } else if (callback != null) {
            callback.m2402a(new C0709e("Refresh already in progress"));
        }
    }
}
