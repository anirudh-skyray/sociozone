package com.facebook;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0699q.C0599c;
import com.facebook.p014b.C0700r;
import org.json.JSONException;
import org.json.JSONObject;

public final class Profile implements Parcelable {
    public static final Creator<Profile> CREATOR = new C06012();
    private final String f1016a;
    private final String f1017b;
    private final String f1018c;
    private final String f1019d;
    private final String f1020e;
    private final Uri f1021f;

    static class C06001 implements C0599c {
        C06001() {
        }

        public void mo858a(JSONObject userInfo) {
            String id = userInfo.optString("id");
            if (id != null) {
                String link = userInfo.optString("link");
                Profile.m2522a(new Profile(id, userInfo.optString("first_name"), userInfo.optString("middle_name"), userInfo.optString("last_name"), userInfo.optString("name"), link != null ? Uri.parse(link) : null));
            }
        }

        public void mo857a(C0709e error) {
        }
    }

    static class C06012 implements Creator {
        C06012() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2519a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2520a(i);
        }

        public Profile m2519a(Parcel source) {
            return new Profile(source);
        }

        public Profile[] m2520a(int size) {
            return new Profile[size];
        }
    }

    public static Profile m2521a() {
        return C0759q.m3111a().m3115b();
    }

    public static void m2522a(Profile profile) {
        C0759q.m3111a().m3114a(profile);
    }

    public static void m2523b() {
        AccessToken accessToken = AccessToken.m2403a();
        if (accessToken == null) {
            m2522a(null);
        } else {
            C0699q.m2798a(accessToken.m2410b(), new C06001());
        }
    }

    public Profile(String id, String firstName, String middleName, String lastName, String name, Uri linkUri) {
        C0700r.m2831a(id, "id");
        this.f1016a = id;
        this.f1017b = firstName;
        this.f1018c = middleName;
        this.f1019d = lastName;
        this.f1020e = name;
        this.f1021f = linkUri;
    }

    public boolean equals(Object other) {
        if (this == other) {
            return true;
        }
        if (!(other instanceof Profile)) {
            return false;
        }
        Profile o = (Profile) other;
        if (this.f1016a.equals(o.f1016a) && this.f1017b == null) {
            if (o.f1017b != null) {
                return false;
            }
            return true;
        } else if (this.f1017b.equals(o.f1017b) && this.f1018c == null) {
            if (o.f1018c != null) {
                return false;
            }
            return true;
        } else if (this.f1018c.equals(o.f1018c) && this.f1019d == null) {
            if (o.f1019d != null) {
                return false;
            }
            return true;
        } else if (this.f1019d.equals(o.f1019d) && this.f1020e == null) {
            if (o.f1020e != null) {
                return false;
            }
            return true;
        } else if (!this.f1020e.equals(o.f1020e) || this.f1021f != null) {
            return this.f1021f.equals(o.f1021f);
        } else {
            if (o.f1021f != null) {
                return false;
            }
            return true;
        }
    }

    public int hashCode() {
        int result = this.f1016a.hashCode() + 527;
        if (this.f1017b != null) {
            result = (result * 31) + this.f1017b.hashCode();
        }
        if (this.f1018c != null) {
            result = (result * 31) + this.f1018c.hashCode();
        }
        if (this.f1019d != null) {
            result = (result * 31) + this.f1019d.hashCode();
        }
        if (this.f1020e != null) {
            result = (result * 31) + this.f1020e.hashCode();
        }
        if (this.f1021f != null) {
            return (result * 31) + this.f1021f.hashCode();
        }
        return result;
    }

    JSONObject m2524c() {
        JSONObject jsonObject = new JSONObject();
        try {
            jsonObject.put("id", this.f1016a);
            jsonObject.put("first_name", this.f1017b);
            jsonObject.put("middle_name", this.f1018c);
            jsonObject.put("last_name", this.f1019d);
            jsonObject.put("name", this.f1020e);
            if (this.f1021f == null) {
                return jsonObject;
            }
            jsonObject.put("link_uri", this.f1021f.toString());
            return jsonObject;
        } catch (JSONException e) {
            return null;
        }
    }

    Profile(JSONObject jsonObject) {
        Uri uri = null;
        this.f1016a = jsonObject.optString("id", null);
        this.f1017b = jsonObject.optString("first_name", null);
        this.f1018c = jsonObject.optString("middle_name", null);
        this.f1019d = jsonObject.optString("last_name", null);
        this.f1020e = jsonObject.optString("name", null);
        String linkUriString = jsonObject.optString("link_uri", null);
        if (linkUriString != null) {
            uri = Uri.parse(linkUriString);
        }
        this.f1021f = uri;
    }

    private Profile(Parcel source) {
        this.f1016a = source.readString();
        this.f1017b = source.readString();
        this.f1018c = source.readString();
        this.f1019d = source.readString();
        this.f1020e = source.readString();
        String linkUriString = source.readString();
        this.f1021f = linkUriString == null ? null : Uri.parse(linkUriString);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.f1016a);
        dest.writeString(this.f1017b);
        dest.writeString(this.f1018c);
        dest.writeString(this.f1019d);
        dest.writeString(this.f1020e);
        dest.writeString(this.f1021f == null ? null : this.f1021f.toString());
    }
}
