package com.facebook;

import com.facebook.p014b.C0680l;
import com.facebook.p014b.C0699q;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* compiled from: GraphResponse */
public class C0723l {
    private final HttpURLConnection f1319a;
    private final JSONObject f1320b;
    private final JSONArray f1321c;
    private final FacebookRequestError f1322d;
    private final String f1323e;
    private final GraphRequest f1324f;

    C0723l(GraphRequest request, HttpURLConnection connection, String rawResponse, JSONObject graphObject) {
        this(request, connection, rawResponse, graphObject, null, null);
    }

    C0723l(GraphRequest request, HttpURLConnection connection, String rawResponse, JSONArray graphObjects) {
        this(request, connection, rawResponse, null, graphObjects, null);
    }

    C0723l(GraphRequest request, HttpURLConnection connection, FacebookRequestError error) {
        this(request, connection, null, null, null, error);
    }

    C0723l(GraphRequest request, HttpURLConnection connection, String rawResponse, JSONObject graphObject, JSONArray graphObjects, FacebookRequestError error) {
        this.f1324f = request;
        this.f1319a = connection;
        this.f1323e = rawResponse;
        this.f1320b = graphObject;
        this.f1321c = graphObjects;
        this.f1322d = error;
    }

    public final FacebookRequestError m2915a() {
        return this.f1322d;
    }

    public final JSONObject m2916b() {
        return this.f1320b;
    }

    public String toString() {
        String responseCode;
        try {
            Locale locale = Locale.US;
            String str = "%d";
            Object[] objArr = new Object[1];
            objArr[0] = Integer.valueOf(this.f1319a != null ? this.f1319a.getResponseCode() : 200);
            responseCode = String.format(locale, str, objArr);
        } catch (IOException e) {
            responseCode = "unknown";
        }
        return "{Response: " + " responseCode: " + responseCode + ", graphObject: " + this.f1320b + ", error: " + this.f1322d + "}";
    }

    static List<C0723l> m2912a(HttpURLConnection connection, C0722k requests) {
        List<C0723l> a;
        Closeable stream = null;
        try {
            if (connection.getResponseCode() >= 400) {
                stream = connection.getErrorStream();
            } else {
                stream = connection.getInputStream();
            }
            a = C0723l.m2910a((InputStream) stream, connection, requests);
        } catch (C0709e facebookException) {
            C0680l.m2696a(C0757o.REQUESTS, "Response", "Response <Error>: %s", facebookException);
            a = C0723l.m2914a((List) requests, connection, facebookException);
        } catch (Throwable exception) {
            C0680l.m2696a(C0757o.REQUESTS, "Response", "Response <Error>: %s", exception);
            a = C0723l.m2914a((List) requests, connection, new C0709e(exception));
        } finally {
            C0699q.m2797a(stream);
        }
        return a;
    }

    static List<C0723l> m2910a(InputStream stream, HttpURLConnection connection, C0722k requests) throws C0709e, JSONException, IOException {
        C0680l.m2696a(C0757o.INCLUDE_RAW_RESPONSES, "Response", "Response (raw)\n  Size: %d\n  Response:\n%s\n", Integer.valueOf(C0699q.m2782a(stream).length()), responseString);
        return C0723l.m2911a(C0699q.m2782a(stream), connection, requests);
    }

    static List<C0723l> m2911a(String responseString, HttpURLConnection connection, C0722k requests) throws C0709e, JSONException, IOException {
        C0680l.m2696a(C0757o.REQUESTS, "Response", "Response\n  Id: %s\n  Size: %d\n  Responses:\n%s\n", requests.m2900b(), Integer.valueOf(responseString.length()), C0723l.m2913a(connection, (List) requests, new JSONTokener(responseString).nextValue()));
        return C0723l.m2913a(connection, (List) requests, new JSONTokener(responseString).nextValue());
    }

    private static List<C0723l> m2913a(HttpURLConnection connection, List<GraphRequest> requests, Object object) throws C0709e, JSONException {
        GraphRequest request;
        int numRequests = requests.size();
        List<C0723l> responses = new ArrayList(numRequests);
        Object originalResult = object;
        if (numRequests == 1) {
            request = (GraphRequest) requests.get(0);
            try {
                JSONObject jsonObject = new JSONObject();
                jsonObject.put("body", object);
                jsonObject.put("code", connection != null ? connection.getResponseCode() : 200);
                JSONArray jsonArray = new JSONArray();
                jsonArray.put(jsonObject);
                object = jsonArray;
            } catch (Exception e) {
                responses.add(new C0723l(request, connection, new FacebookRequestError(connection, e)));
            } catch (Exception e2) {
                responses.add(new C0723l(request, connection, new FacebookRequestError(connection, e2)));
            }
        }
        if ((object instanceof JSONArray) && ((JSONArray) object).length() == numRequests) {
            jsonArray = (JSONArray) object;
            for (int i = 0; i < jsonArray.length(); i++) {
                request = (GraphRequest) requests.get(i);
                try {
                    responses.add(C0723l.m2909a(request, connection, jsonArray.get(i), originalResult));
                } catch (Exception e22) {
                    responses.add(new C0723l(request, connection, new FacebookRequestError(connection, e22)));
                } catch (Exception e222) {
                    responses.add(new C0723l(request, connection, new FacebookRequestError(connection, e222)));
                }
            }
            return responses;
        }
        throw new C0709e("Unexpected number of results");
    }

    private static C0723l m2909a(GraphRequest request, HttpURLConnection connection, Object object, Object originalResult) throws JSONException {
        if (object instanceof JSONObject) {
            JSONObject jsonObject = (JSONObject) object;
            FacebookRequestError error = FacebookRequestError.m2426a(jsonObject, originalResult, connection);
            if (error != null) {
                if (error.m2429b() == 190 && C0699q.m2805a(request.m2508f())) {
                    AccessToken.m2407a(null);
                }
                return new C0723l(request, connection, error);
            }
            Object body = C0699q.m2779a(jsonObject, "body", "FACEBOOK_NON_JSON_RESULT");
            if (body instanceof JSONObject) {
                return new C0723l(request, connection, body.toString(), (JSONObject) body);
            }
            if (body instanceof JSONArray) {
                return new C0723l(request, connection, body.toString(), (JSONArray) body);
            }
            object = JSONObject.NULL;
        }
        if (object == JSONObject.NULL) {
            return new C0723l(request, connection, object.toString(), (JSONObject) null);
        }
        throw new C0709e("Got unexpected object type in response, class: " + object.getClass().getSimpleName());
    }

    static List<C0723l> m2914a(List<GraphRequest> requests, HttpURLConnection connection, C0709e error) {
        int count = requests.size();
        List<C0723l> responses = new ArrayList(count);
        for (int i = 0; i < count; i++) {
            responses.add(new C0723l((GraphRequest) requests.get(i), connection, new FacebookRequestError(connection, (Exception) error)));
        }
        return responses;
    }
}
