package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.share.model.ShareOpenGraphValueContainer.C0777a;

public final class ShareOpenGraphAction extends ShareOpenGraphValueContainer<ShareOpenGraphAction, C0778a> {
    public static final Creator<ShareOpenGraphAction> CREATOR = new C07761();

    static class C07761 implements Creator<ShareOpenGraphAction> {
        C07761() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3173a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3174a(i);
        }

        public ShareOpenGraphAction m3173a(Parcel in) {
            return new ShareOpenGraphAction(in);
        }

        public ShareOpenGraphAction[] m3174a(int size) {
            return new ShareOpenGraphAction[size];
        }
    }

    public static final class C0778a extends C0777a<ShareOpenGraphAction, C0778a> {
        public C0778a m3180a(String actionType) {
            m3177a("og:type", actionType);
            return this;
        }

        public ShareOpenGraphAction m3181a() {
            return new ShareOpenGraphAction();
        }

        public C0778a m3179a(ShareOpenGraphAction model) {
            return model == null ? this : ((C0778a) super.mo893a((ShareOpenGraphValueContainer) model)).m3180a(model.m3187a());
        }

        C0778a m3178a(Parcel parcel) {
            return m3179a((ShareOpenGraphAction) parcel.readParcelable(ShareOpenGraphAction.class.getClassLoader()));
        }
    }

    private ShareOpenGraphAction(C0778a builder) {
        super((C0777a) builder);
    }

    ShareOpenGraphAction(Parcel in) {
        super(in);
    }

    public String m3187a() {
        return m3185b("og:type");
    }
}
