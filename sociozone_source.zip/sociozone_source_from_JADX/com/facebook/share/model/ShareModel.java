package com.facebook.share.model;

import android.os.Parcelable;

public interface ShareModel extends Parcelable {
}
