package com.facebook.share.model;

import android.os.Bundle;
import android.os.Parcel;
import java.util.Set;

public abstract class ShareOpenGraphValueContainer<P extends ShareOpenGraphValueContainer, E extends C0777a> implements ShareModel {
    private final Bundle f1479a;

    public static abstract class C0777a<P extends ShareOpenGraphValueContainer, E extends C0777a> {
        private Bundle f1478a = new Bundle();

        public E m3177a(String key, String value) {
            this.f1478a.putString(key, value);
            return this;
        }

        public E mo893a(P model) {
            if (model != null) {
                this.f1478a.putAll(model.m3184b());
            }
            return this;
        }
    }

    protected ShareOpenGraphValueContainer(C0777a<P, E> builder) {
        this.f1479a = (Bundle) builder.f1478a.clone();
    }

    ShareOpenGraphValueContainer(Parcel in) {
        this.f1479a = in.readBundle(C0777a.class.getClassLoader());
    }

    public Object m3183a(String key) {
        return this.f1479a.get(key);
    }

    public String m3185b(String key) {
        return this.f1479a.getString(key);
    }

    public Bundle m3184b() {
        return (Bundle) this.f1479a.clone();
    }

    public Set<String> m3186c() {
        return this.f1479a.keySet();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeBundle(this.f1479a);
    }
}
