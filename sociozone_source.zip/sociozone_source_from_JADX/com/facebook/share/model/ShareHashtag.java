package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public class ShareHashtag implements ShareModel {
    public static final Creator<ShareHashtag> CREATOR = new C07731();
    private final String f1472a;

    static class C07731 implements Creator<ShareHashtag> {
        C07731() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3162a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3163a(i);
        }

        public ShareHashtag m3162a(Parcel in) {
            return new ShareHashtag(in);
        }

        public ShareHashtag[] m3163a(int size) {
            return new ShareHashtag[size];
        }
    }

    public static class C0774a {
        private String f1471a;

        public C0774a m3167a(String hashtag) {
            this.f1471a = hashtag;
            return this;
        }

        public C0774a m3166a(ShareHashtag model) {
            return model == null ? this : m3167a(model.m3169a());
        }

        C0774a m3165a(Parcel parcel) {
            return m3166a((ShareHashtag) parcel.readParcelable(ShareHashtag.class.getClassLoader()));
        }

        public ShareHashtag m3168a() {
            return new ShareHashtag();
        }
    }

    private ShareHashtag(C0774a builder) {
        this.f1472a = builder.f1471a;
    }

    ShareHashtag(Parcel in) {
        this.f1472a = in.readString();
    }

    public String m3169a() {
        return this.f1472a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.f1472a);
    }
}
