package com.facebook.share.model;

import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class SharePhoto extends ShareMedia {
    public static final Creator<SharePhoto> CREATOR = new C07811();
    private final Bitmap f1482a;
    private final Uri f1483b;
    private final boolean f1484c;
    private final String f1485d;

    static class C07811 implements Creator<SharePhoto> {
        C07811() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3193a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3194a(i);
        }

        public SharePhoto m3193a(Parcel source) {
            return new SharePhoto(source);
        }

        public SharePhoto[] m3194a(int size) {
            return new SharePhoto[size];
        }
    }

    SharePhoto(Parcel in) {
        super(in);
        this.f1482a = (Bitmap) in.readParcelable(Bitmap.class.getClassLoader());
        this.f1483b = (Uri) in.readParcelable(Uri.class.getClassLoader());
        this.f1484c = in.readByte() != (byte) 0;
        this.f1485d = in.readString();
    }

    public Uri m3195a() {
        return this.f1483b;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        int i = 0;
        super.writeToParcel(out, flags);
        out.writeParcelable(this.f1482a, 0);
        out.writeParcelable(this.f1483b, 0);
        if (this.f1484c) {
            i = 1;
        }
        out.writeByte((byte) i);
        out.writeString(this.f1485d);
    }
}
