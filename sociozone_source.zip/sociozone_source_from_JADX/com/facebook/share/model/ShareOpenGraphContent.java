package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.share.model.ShareOpenGraphAction.C0778a;

public final class ShareOpenGraphContent extends ShareContent<ShareOpenGraphContent, Object> {
    public static final Creator<ShareOpenGraphContent> CREATOR = new C07791();
    private final ShareOpenGraphAction f1480a;
    private final String f1481b;

    static class C07791 implements Creator<ShareOpenGraphContent> {
        C07791() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3188a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3189a(i);
        }

        public ShareOpenGraphContent m3188a(Parcel in) {
            return new ShareOpenGraphContent(in);
        }

        public ShareOpenGraphContent[] m3189a(int size) {
            return new ShareOpenGraphContent[size];
        }
    }

    ShareOpenGraphContent(Parcel in) {
        super(in);
        this.f1480a = new C0778a().m3178a(in).m3181a();
        this.f1481b = in.readString();
    }

    public ShareOpenGraphAction m3190c() {
        return this.f1480a;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        super.writeToParcel(out, flags);
        out.writeParcelable(this.f1480a, 0);
        out.writeString(this.f1481b);
    }
}
