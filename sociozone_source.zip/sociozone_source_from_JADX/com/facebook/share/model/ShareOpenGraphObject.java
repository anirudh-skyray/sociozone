package com.facebook.share.model;

import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ShareOpenGraphObject extends ShareOpenGraphValueContainer<ShareOpenGraphObject, Object> {
    public static final Creator<ShareOpenGraphObject> CREATOR = new C07801();

    static class C07801 implements Creator<ShareOpenGraphObject> {
        C07801() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3191a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3192a(i);
        }

        public ShareOpenGraphObject m3191a(Parcel in) {
            return new ShareOpenGraphObject(in);
        }

        public ShareOpenGraphObject[] m3192a(int size) {
            return new ShareOpenGraphObject[size];
        }
    }

    ShareOpenGraphObject(Parcel in) {
        super(in);
    }
}
