package com.facebook.share.model;

import android.net.Uri;
import android.os.Parcel;
import com.facebook.share.model.ShareHashtag.C0774a;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public abstract class ShareContent<P extends ShareContent, E> implements ShareModel {
    private final Uri f1466a;
    private final List<String> f1467b;
    private final String f1468c;
    private final String f1469d;
    private final ShareHashtag f1470e;

    protected ShareContent(Parcel in) {
        this.f1466a = (Uri) in.readParcelable(Uri.class.getClassLoader());
        this.f1467b = m3159a(in);
        this.f1468c = in.readString();
        this.f1469d = in.readString();
        this.f1470e = new C0774a().m3165a(in).m3168a();
    }

    public Uri m3160a() {
        return this.f1466a;
    }

    public ShareHashtag m3161b() {
        return this.f1470e;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeParcelable(this.f1466a, 0);
        out.writeStringList(this.f1467b);
        out.writeString(this.f1468c);
        out.writeString(this.f1469d);
        out.writeParcelable(this.f1470e, 0);
    }

    private List<String> m3159a(Parcel in) {
        List<String> list = new ArrayList();
        in.readStringList(list);
        return list.size() == 0 ? null : Collections.unmodifiableList(list);
    }
}
