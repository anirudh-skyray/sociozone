package com.facebook.share.model;

import android.net.Uri;
import android.os.Parcel;
import android.os.Parcelable.Creator;

public final class ShareLinkContent extends ShareContent<ShareLinkContent, Object> {
    public static final Creator<ShareLinkContent> CREATOR = new C07751();
    private final String f1473a;
    private final String f1474b;
    private final Uri f1475c;
    private final String f1476d;

    static class C07751 implements Creator<ShareLinkContent> {
        C07751() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3170a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3171a(i);
        }

        public ShareLinkContent m3170a(Parcel in) {
            return new ShareLinkContent(in);
        }

        public ShareLinkContent[] m3171a(int size) {
            return new ShareLinkContent[size];
        }
    }

    ShareLinkContent(Parcel in) {
        super(in);
        this.f1473a = in.readString();
        this.f1474b = in.readString();
        this.f1475c = (Uri) in.readParcelable(Uri.class.getClassLoader());
        this.f1476d = in.readString();
    }

    public String m3172c() {
        return this.f1476d;
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel out, int flags) {
        super.writeToParcel(out, flags);
        out.writeString(this.f1473a);
        out.writeString(this.f1474b);
        out.writeParcelable(this.f1475c, 0);
        out.writeString(this.f1476d);
    }
}
