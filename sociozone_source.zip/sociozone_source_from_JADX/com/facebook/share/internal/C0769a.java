package com.facebook.share.internal;

import com.facebook.share.model.ShareOpenGraphAction;
import com.facebook.share.model.ShareOpenGraphObject;
import com.facebook.share.model.SharePhoto;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: OpenGraphJSONUtility */
public final class C0769a {

    /* compiled from: OpenGraphJSONUtility */
    public interface C0768a {
        JSONObject mo890a(SharePhoto sharePhoto);
    }

    public static JSONObject m3149a(ShareOpenGraphAction action, C0768a photoJSONProcessor) throws JSONException {
        JSONObject result = new JSONObject();
        for (String key : action.m3186c()) {
            result.put(key, C0769a.m3147a(action.m3183a(key), photoJSONProcessor));
        }
        return result;
    }

    private static JSONObject m3150a(ShareOpenGraphObject object, C0768a photoJSONProcessor) throws JSONException {
        JSONObject result = new JSONObject();
        for (String key : object.m3186c()) {
            result.put(key, C0769a.m3147a(object.m3183a(key), photoJSONProcessor));
        }
        return result;
    }

    private static JSONArray m3148a(List list, C0768a photoJSONProcessor) throws JSONException {
        JSONArray result = new JSONArray();
        for (Object item : list) {
            result.put(C0769a.m3147a(item, photoJSONProcessor));
        }
        return result;
    }

    public static Object m3147a(Object object, C0768a photoJSONProcessor) throws JSONException {
        if (object == null) {
            return JSONObject.NULL;
        }
        if ((object instanceof String) || (object instanceof Boolean) || (object instanceof Double) || (object instanceof Float) || (object instanceof Integer) || (object instanceof Long)) {
            return object;
        }
        if (object instanceof SharePhoto) {
            if (photoJSONProcessor != null) {
                return photoJSONProcessor.mo890a((SharePhoto) object);
            }
            return null;
        } else if (object instanceof ShareOpenGraphObject) {
            return C0769a.m3150a((ShareOpenGraphObject) object, photoJSONProcessor);
        } else {
            if (object instanceof List) {
                return C0769a.m3148a((List) object, photoJSONProcessor);
            }
            throw new IllegalArgumentException("Invalid object found for JSON serialization: " + object.toString());
        }
    }
}
