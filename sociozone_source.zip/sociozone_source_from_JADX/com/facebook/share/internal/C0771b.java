package com.facebook.share.internal;

import android.net.Uri;
import android.util.Pair;
import com.facebook.C0709e;
import com.facebook.share.internal.C0769a.C0768a;
import com.facebook.share.model.ShareOpenGraphContent;
import com.facebook.share.model.SharePhoto;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: ShareInternalUtility */
public final class C0771b {

    /* compiled from: ShareInternalUtility */
    static class C07701 implements C0768a {
        C07701() {
        }

        public JSONObject mo890a(SharePhoto photo) {
            Uri photoUri = photo.m3195a();
            JSONObject photoJSONObject = new JSONObject();
            try {
                photoJSONObject.put("url", photoUri.toString());
                return photoJSONObject;
            } catch (JSONException e) {
                throw new C0709e("Unable to attach images", e);
            }
        }
    }

    public static JSONObject m3154a(ShareOpenGraphContent shareOpenGraphContent) throws JSONException {
        return C0769a.m3149a(shareOpenGraphContent.m3190c(), new C07701());
    }

    public static JSONArray m3153a(JSONArray jsonArray, boolean requireNamespace) throws JSONException {
        JSONArray newArray = new JSONArray();
        for (int i = 0; i < jsonArray.length(); i++) {
            Object value = jsonArray.get(i);
            if (value instanceof JSONArray) {
                value = C0771b.m3153a((JSONArray) value, requireNamespace);
            } else if (value instanceof JSONObject) {
                value = C0771b.m3155a((JSONObject) value, requireNamespace);
            }
            newArray.put(value);
        }
        return newArray;
    }

    public static JSONObject m3155a(JSONObject jsonObject, boolean requireNamespace) {
        if (jsonObject == null) {
            return null;
        }
        try {
            JSONObject newJsonObject = new JSONObject();
            JSONObject data = new JSONObject();
            JSONArray names = jsonObject.names();
            for (int i = 0; i < names.length(); i++) {
                String key = names.getString(i);
                Object value = jsonObject.get(key);
                if (value instanceof JSONObject) {
                    value = C0771b.m3155a((JSONObject) value, true);
                } else if (value instanceof JSONArray) {
                    value = C0771b.m3153a((JSONArray) value, true);
                }
                Pair<String, String> fieldNameAndNamespace = C0771b.m3152a(key);
                String namespace = fieldNameAndNamespace.first;
                String fieldName = fieldNameAndNamespace.second;
                if (requireNamespace) {
                    if (namespace != null && namespace.equals("fbsdk")) {
                        newJsonObject.put(key, value);
                    } else if (namespace == null || namespace.equals("og")) {
                        newJsonObject.put(fieldName, value);
                    } else {
                        data.put(fieldName, value);
                    }
                } else if (namespace == null || !namespace.equals("fb")) {
                    newJsonObject.put(fieldName, value);
                } else {
                    newJsonObject.put(key, value);
                }
            }
            if (data.length() <= 0) {
                return newJsonObject;
            }
            newJsonObject.put("data", data);
            return newJsonObject;
        } catch (JSONException e) {
            throw new C0709e("Failed to create json object from share content");
        }
    }

    public static Pair<String, String> m3152a(String fullName) {
        String fieldName;
        String namespace = null;
        int index = fullName.indexOf(58);
        if (index == -1 || fullName.length() <= index + 1) {
            fieldName = fullName;
        } else {
            namespace = fullName.substring(0, index);
            fieldName = fullName.substring(index + 1);
        }
        return new Pair(namespace, fieldName);
    }
}
