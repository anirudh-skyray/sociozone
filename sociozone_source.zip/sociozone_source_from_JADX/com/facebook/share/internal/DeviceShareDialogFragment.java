package com.facebook.share.internal;

import android.app.Activity;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0159p;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.facebook.C0723l;
import com.facebook.C0755m;
import com.facebook.C0787t.C0783b;
import com.facebook.C0787t.C0784c;
import com.facebook.C0787t.C0785d;
import com.facebook.C0787t.C0786e;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0588b;
import com.facebook.p014b.C0700r;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphContent;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import org.json.JSONObject;

public class DeviceShareDialogFragment extends C0159p {
    private static ScheduledThreadPoolExecutor f1459f;
    private ProgressBar f1460a;
    private TextView f1461b;
    private Dialog f1462c;
    private volatile RequestState f1463d;
    private volatile ScheduledFuture f1464e;
    private ShareContent f1465g;

    class C07641 implements OnClickListener {
        final /* synthetic */ DeviceShareDialogFragment f1454a;

        C07641(DeviceShareDialogFragment this$0) {
            this.f1454a = this$0;
        }

        public void onClick(View v) {
            this.f1454a.f1462c.dismiss();
        }
    }

    class C07652 implements C0588b {
        final /* synthetic */ DeviceShareDialogFragment f1455a;

        C07652(DeviceShareDialogFragment this$0) {
            this.f1455a = this$0;
        }

        public void mo855a(C0723l response) {
            FacebookRequestError error = response.m2915a();
            if (error != null) {
                this.f1455a.m3138a(error);
                return;
            }
            JSONObject jsonObject = response.m2916b();
            RequestState requestState = new RequestState();
            try {
                requestState.m3133a(jsonObject.getString("user_code"));
                requestState.m3132a(jsonObject.getLong("expires_in"));
                this.f1455a.m3139a(requestState);
            } catch (JSONException e) {
                this.f1455a.m3138a(new FacebookRequestError(0, "", "Malformed server response"));
            }
        }
    }

    class C07663 implements Runnable {
        final /* synthetic */ DeviceShareDialogFragment f1456a;

        C07663(DeviceShareDialogFragment this$0) {
            this.f1456a = this$0;
        }

        public void run() {
            this.f1456a.f1462c.dismiss();
        }
    }

    private static class RequestState implements Parcelable {
        public static final Creator<RequestState> CREATOR = new C07671();
        private String f1457a;
        private long f1458b;

        static class C07671 implements Creator<RequestState> {
            C07671() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m3129a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m3130a(i);
            }

            public RequestState m3129a(Parcel in) {
                return new RequestState(in);
            }

            public RequestState[] m3130a(int size) {
                return new RequestState[size];
            }
        }

        RequestState() {
        }

        public String m3131a() {
            return this.f1457a;
        }

        public void m3133a(String userCode) {
            this.f1457a = userCode;
        }

        public long m3134b() {
            return this.f1458b;
        }

        public void m3132a(long expiresIn) {
            this.f1458b = expiresIn;
        }

        protected RequestState(Parcel in) {
            this.f1457a = in.readString();
            this.f1458b = in.readLong();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.f1457a);
            dest.writeLong(this.f1458b);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        if (savedInstanceState != null) {
            RequestState requestState = (RequestState) savedInstanceState.getParcelable("request_state");
            if (requestState != null) {
                m3139a(requestState);
            }
        }
        return view;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        this.f1462c = new Dialog(getActivity(), C0786e.com_facebook_auth_dialog);
        View view = getActivity().getLayoutInflater().inflate(C0784c.com_facebook_device_auth_dialog_fragment, null);
        this.f1460a = (ProgressBar) view.findViewById(C0783b.progress_bar);
        this.f1461b = (TextView) view.findViewById(C0783b.confirmation_code);
        ((Button) view.findViewById(C0783b.cancel_button)).setOnClickListener(new C07641(this));
        ((TextView) view.findViewById(C0783b.com_facebook_device_auth_instructions)).setText(Html.fromHtml(getString(C0785d.com_facebook_device_auth_instructions)));
        this.f1462c.setContentView(view);
        m3143c();
        return this.f1462c;
    }

    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (this.f1464e != null) {
            this.f1464e.cancel(true);
        }
        m3137a(-1, new Intent());
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (this.f1463d != null) {
            outState.putParcelable("request_state", this.f1463d);
        }
    }

    private void m3137a(int resultCode, Intent data) {
        if (isAdded()) {
            Activity activity = getActivity();
            activity.setResult(resultCode, data);
            activity.finish();
        }
    }

    private void m3136a() {
        if (isAdded()) {
            getFragmentManager().mo137a().mo103a(this).mo105b();
        }
    }

    public void m3145a(ShareContent shareContent) {
        this.f1465g = shareContent;
    }

    private Bundle m3142b() {
        ShareContent content = this.f1465g;
        if (content == null) {
            return null;
        }
        if (content instanceof ShareLinkContent) {
            return C0772c.m3157a((ShareLinkContent) content);
        }
        if (content instanceof ShareOpenGraphContent) {
            return C0772c.m3158a((ShareOpenGraphContent) content);
        }
        return null;
    }

    private void m3143c() {
        Bundle parameters = m3142b();
        if (parameters == null || parameters.size() == 0) {
            m3138a(new FacebookRequestError(0, "", "Failed to get share content"));
        }
        parameters.putString("access_token", C0700r.m2834b() + "|" + C0700r.m2837c());
        new GraphRequest(null, "device/share", parameters, C0755m.POST, new C07652(this)).m2512j();
    }

    private void m3138a(FacebookRequestError error) {
        m3136a();
        Intent intent = new Intent();
        intent.putExtra("error", error);
        m3137a(-1, intent);
    }

    private static synchronized ScheduledThreadPoolExecutor m3144d() {
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
        synchronized (DeviceShareDialogFragment.class) {
            if (f1459f == null) {
                f1459f = new ScheduledThreadPoolExecutor(1);
            }
            scheduledThreadPoolExecutor = f1459f;
        }
        return scheduledThreadPoolExecutor;
    }

    private void m3139a(RequestState currentRequestState) {
        this.f1463d = currentRequestState;
        this.f1461b.setText(currentRequestState.m3131a());
        this.f1461b.setVisibility(0);
        this.f1460a.setVisibility(8);
        this.f1464e = m3144d().schedule(new C07663(this), currentRequestState.m3134b(), TimeUnit.SECONDS);
    }
}
