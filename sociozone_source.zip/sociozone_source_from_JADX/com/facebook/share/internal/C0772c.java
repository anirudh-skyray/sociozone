package com.facebook.share.internal;

import android.os.Bundle;
import com.facebook.C0709e;
import com.facebook.p014b.C0699q;
import com.facebook.share.model.ShareContent;
import com.facebook.share.model.ShareHashtag;
import com.facebook.share.model.ShareLinkContent;
import com.facebook.share.model.ShareOpenGraphContent;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: WebDialogParameters */
public class C0772c {
    public static Bundle m3157a(ShareLinkContent shareLinkContent) {
        Bundle params = C0772c.m3156a((ShareContent) shareLinkContent);
        C0699q.m2794a(params, "href", shareLinkContent.m3160a());
        C0699q.m2795a(params, "quote", shareLinkContent.m3172c());
        return params;
    }

    public static Bundle m3158a(ShareOpenGraphContent shareOpenGraphContent) {
        Bundle params = C0772c.m3156a((ShareContent) shareOpenGraphContent);
        C0699q.m2795a(params, "action_type", shareOpenGraphContent.m3190c().m3187a());
        try {
            JSONObject ogJSON = C0771b.m3155a(C0771b.m3154a(shareOpenGraphContent), false);
            if (ogJSON != null) {
                C0699q.m2795a(params, "action_properties", ogJSON.toString());
            }
            return params;
        } catch (JSONException e) {
            throw new C0709e("Unable to serialize the ShareOpenGraphContent to JSON", e);
        }
    }

    public static Bundle m3156a(ShareContent shareContent) {
        Bundle params = new Bundle();
        ShareHashtag shareHashtag = shareContent.m3161b();
        if (shareHashtag != null) {
            C0699q.m2795a(params, "hashtag", shareHashtag.m3169a());
        }
        return params;
    }
}
