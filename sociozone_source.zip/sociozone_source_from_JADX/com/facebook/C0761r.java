package com.facebook;

import android.os.Handler;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;

/* compiled from: ProgressNoopOutputStream */
class C0761r extends OutputStream implements C0760u {
    private final Map<GraphRequest, C0789v> f1440a = new HashMap();
    private final Handler f1441b;
    private GraphRequest f1442c;
    private C0789v f1443d;
    private int f1444e;

    C0761r(Handler callbackHandler) {
        this.f1441b = callbackHandler;
    }

    public void mo889a(GraphRequest currentRequest) {
        this.f1442c = currentRequest;
        this.f1443d = currentRequest != null ? (C0789v) this.f1440a.get(currentRequest) : null;
    }

    int m3118a() {
        return this.f1444e;
    }

    Map<GraphRequest, C0789v> m3121b() {
        return this.f1440a;
    }

    void m3119a(long size) {
        if (this.f1443d == null) {
            this.f1443d = new C0789v(this.f1441b, this.f1442c);
            this.f1440a.put(this.f1442c, this.f1443d);
        }
        this.f1443d.m3198b(size);
        this.f1444e = (int) (((long) this.f1444e) + size);
    }

    public void write(byte[] buffer) {
        m3119a((long) buffer.length);
    }

    public void write(byte[] buffer, int offset, int length) {
        m3119a((long) length);
    }

    public void write(int oneByte) {
        m3119a(1);
    }
}
