package com.facebook;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.C0164q;
import android.support.v4.app.C0167u;
import android.support.v4.app.Fragment;
import android.util.Log;
import com.facebook.C0787t.C0783b;
import com.facebook.C0787t.C0784c;
import com.facebook.login.C0751d;
import com.facebook.p014b.C0669g;
import com.facebook.p014b.C0687m;
import com.facebook.share.internal.DeviceShareDialogFragment;
import com.facebook.share.model.ShareContent;

public class FacebookActivity extends C0164q {
    public static String f959a = "PassThrough";
    private static String f960b = "SingleFragment";
    private static final String f961c = FacebookActivity.class.getName();
    private Fragment f962d;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Intent intent = getIntent();
        if (!C0717g.m2871a()) {
            Log.d(f961c, "Facebook SDK not initialized. Make sure you call sdkInitialize inside your Application's onCreate method.");
            C0717g.m2868a(getApplicationContext());
        }
        setContentView(C0784c.com_facebook_activity_layout);
        if (f959a.equals(intent.getAction())) {
            m2421b();
            return;
        }
        C0167u manager = getSupportFragmentManager();
        Fragment fragment = manager.mo136a(f960b);
        if (fragment == null) {
            Fragment dialogFragment;
            if ("FacebookDialogFragment".equals(intent.getAction())) {
                dialogFragment = new C0669g();
                dialogFragment.setRetainInstance(true);
                dialogFragment.show(manager, f960b);
                fragment = dialogFragment;
            } else if ("DeviceShareDialogFragment".equals(intent.getAction())) {
                dialogFragment = new DeviceShareDialogFragment();
                dialogFragment.setRetainInstance(true);
                dialogFragment.m3145a((ShareContent) intent.getParcelableExtra("content"));
                dialogFragment.show(manager, f960b);
                fragment = dialogFragment;
            } else {
                fragment = new C0751d();
                fragment.setRetainInstance(true);
                manager.mo137a().mo102a(C0783b.com_facebook_fragment_container, fragment, f960b).mo105b();
            }
        }
        this.f962d = fragment;
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (this.f962d != null) {
            this.f962d.onConfigurationChanged(newConfig);
        }
    }

    public Fragment m2422a() {
        return this.f962d;
    }

    private void m2421b() {
        setResult(0, C0687m.m2728a(getIntent(), null, C0687m.m2731a(C0687m.m2741c(getIntent()))));
        finish();
    }
}
