package com.facebook.login;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.facebook.C0787t.C0783b;
import com.facebook.C0787t.C0784c;
import com.facebook.login.LoginClient.C0741a;
import com.facebook.login.LoginClient.C0742b;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.login.LoginClient.Result.C0740a;

/* compiled from: LoginFragment */
public class C0751d extends Fragment {
    private String f1412a;
    private LoginClient f1413b;
    private Request f1414c;

    /* compiled from: LoginFragment */
    class C07491 implements C0742b {
        final /* synthetic */ C0751d f1409a;

        C07491(C0751d this$0) {
            this.f1409a = this$0;
        }

        public void mo884a(Result outcome) {
            this.f1409a.m3089a(outcome);
        }
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            this.f1413b = (LoginClient) savedInstanceState.getParcelable("loginClient");
            this.f1413b.m3047a((Fragment) this);
        } else {
            this.f1413b = new LoginClient((Fragment) this);
        }
        this.f1413b.m3051a(new C07491(this));
        Activity activity = getActivity();
        if (activity != null) {
            m3088a(activity);
            if (activity.getIntent() != null) {
                this.f1414c = (Request) activity.getIntent().getBundleExtra("com.facebook.LoginFragment:Request").getParcelable("request");
            }
        }
    }

    public void onDestroy() {
        this.f1413b.m3059f();
        super.onDestroy();
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        final View view = inflater.inflate(C0784c.com_facebook_login_fragment, container, false);
        this.f1413b.m3050a(new C0741a(this) {
            final /* synthetic */ C0751d f1411b;

            public void mo885a() {
                view.findViewById(C0783b.com_facebook_login_activity_progress_bar).setVisibility(0);
            }

            public void mo886b() {
                view.findViewById(C0783b.com_facebook_login_activity_progress_bar).setVisibility(8);
            }
        });
        return view;
    }

    private void m3089a(Result outcome) {
        this.f1414c = null;
        int resultCode = outcome.f1369a == C0740a.CANCEL ? 0 : -1;
        Bundle bundle = new Bundle();
        bundle.putParcelable("com.facebook.LoginFragment:Result", outcome);
        Intent resultIntent = new Intent();
        resultIntent.putExtras(bundle);
        if (isAdded()) {
            getActivity().setResult(resultCode, resultIntent);
            getActivity().finish();
        }
    }

    public void onResume() {
        super.onResume();
        if (this.f1412a == null) {
            Log.e("LoginFragment", "Cannot call LoginFragment with a null calling package. This can occur if the launchMode of the caller is singleInstance.");
            getActivity().finish();
            return;
        }
        this.f1413b.m3048a(this.f1414c);
    }

    public void onPause() {
        super.onPause();
        getActivity().findViewById(C0783b.com_facebook_login_activity_progress_bar).setVisibility(8);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        this.f1413b.m3052a(requestCode, resultCode, data);
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("loginClient", this.f1413b);
    }

    private void m3088a(Activity activity) {
        ComponentName componentName = activity.getCallingActivity();
        if (componentName != null) {
            this.f1412a = componentName.getPackageName();
        }
    }

    LoginClient m3091a() {
        return this.f1413b;
    }
}
