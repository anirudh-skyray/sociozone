package com.facebook.login;

import android.app.Activity;
import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0164q;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import com.facebook.AccessToken;
import com.facebook.C0709e;
import com.facebook.C0787t.C0785d;
import com.facebook.p014b.C0664e.C0663a;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0700r;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

class LoginClient implements Parcelable {
    public static final Creator<LoginClient> CREATOR = new C07371();
    LoginMethodHandler[] f1375a;
    int f1376b = -1;
    Fragment f1377c;
    C0742b f1378d;
    C0741a f1379e;
    boolean f1380f;
    Request f1381g;
    Map<String, String> f1382h;
    private C0752e f1383i;

    static class C07371 implements Creator {
        C07371() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3013a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3014a(i);
        }

        public LoginClient m3013a(Parcel source) {
            return new LoginClient(source);
        }

        public LoginClient[] m3014a(int size) {
            return new LoginClient[size];
        }
    }

    public static class Request implements Parcelable {
        public static final Creator<Request> CREATOR = new C07381();
        private final C0748c f1357a;
        private Set<String> f1358b;
        private final C0746a f1359c;
        private final String f1360d;
        private final String f1361e;
        private boolean f1362f;
        private String f1363g;

        static class C07381 implements Creator {
            C07381() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m3015a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m3016a(i);
            }

            public Request m3015a(Parcel source) {
                return new Request(source);
            }

            public Request[] m3016a(int size) {
                return new Request[size];
            }
        }

        Set<String> m3017a() {
            return this.f1358b;
        }

        void m3018a(Set<String> permissions) {
            C0700r.m2830a((Object) permissions, "permissions");
            this.f1358b = permissions;
        }

        C0748c m3019b() {
            return this.f1357a;
        }

        C0746a m3020c() {
            return this.f1359c;
        }

        String m3021d() {
            return this.f1360d;
        }

        String m3022e() {
            return this.f1361e;
        }

        boolean m3023f() {
            return this.f1362f;
        }

        String m3024g() {
            return this.f1363g;
        }

        boolean m3025h() {
            for (String permission : this.f1358b) {
                if (C0754f.m3099a(permission)) {
                    return true;
                }
            }
            return false;
        }

        private Request(Parcel parcel) {
            C0748c valueOf;
            boolean z;
            C0746a c0746a = null;
            this.f1362f = false;
            String enumValue = parcel.readString();
            if (enumValue != null) {
                valueOf = C0748c.valueOf(enumValue);
            } else {
                valueOf = null;
            }
            this.f1357a = valueOf;
            ArrayList<String> permissionsList = new ArrayList();
            parcel.readStringList(permissionsList);
            this.f1358b = new HashSet(permissionsList);
            enumValue = parcel.readString();
            if (enumValue != null) {
                c0746a = C0746a.valueOf(enumValue);
            }
            this.f1359c = c0746a;
            this.f1360d = parcel.readString();
            this.f1361e = parcel.readString();
            if (parcel.readByte() != (byte) 0) {
                z = true;
            } else {
                z = false;
            }
            this.f1362f = z;
            this.f1363g = parcel.readString();
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            String str = null;
            dest.writeString(this.f1357a != null ? this.f1357a.name() : null);
            dest.writeStringList(new ArrayList(this.f1358b));
            if (this.f1359c != null) {
                str = this.f1359c.name();
            }
            dest.writeString(str);
            dest.writeString(this.f1360d);
            dest.writeString(this.f1361e);
            dest.writeByte((byte) (this.f1362f ? 1 : 0));
            dest.writeString(this.f1363g);
        }
    }

    public static class Result implements Parcelable {
        public static final Creator<Result> CREATOR = new C07391();
        final C0740a f1369a;
        final AccessToken f1370b;
        final String f1371c;
        final String f1372d;
        final Request f1373e;
        public Map<String, String> f1374f;

        static class C07391 implements Creator {
            C07391() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m3026a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m3027a(i);
            }

            public Result m3026a(Parcel source) {
                return new Result(source);
            }

            public Result[] m3027a(int size) {
                return new Result[size];
            }
        }

        enum C0740a {
            SUCCESS("success"),
            CANCEL("cancel"),
            ERROR("error");
            
            private final String f1368d;

            private C0740a(String loggingValue) {
                this.f1368d = loggingValue;
            }

            String m3028a() {
                return this.f1368d;
            }
        }

        Result(Request request, C0740a code, AccessToken token, String errorMessage, String errorCode) {
            C0700r.m2830a((Object) code, "code");
            this.f1373e = request;
            this.f1370b = token;
            this.f1371c = errorMessage;
            this.f1369a = code;
            this.f1372d = errorCode;
        }

        static Result m3029a(Request request, AccessToken token) {
            return new Result(request, C0740a.SUCCESS, token, null, null);
        }

        static Result m3030a(Request request, String message) {
            return new Result(request, C0740a.CANCEL, null, message, null);
        }

        static Result m3031a(Request request, String errorType, String errorDescription) {
            return m3032a(request, errorType, errorDescription, null);
        }

        static Result m3032a(Request request, String errorType, String errorDescription, String errorCode) {
            return new Result(request, C0740a.ERROR, null, TextUtils.join(": ", C0699q.m2812b(errorType, errorDescription)), errorCode);
        }

        private Result(Parcel parcel) {
            this.f1369a = C0740a.valueOf(parcel.readString());
            this.f1370b = (AccessToken) parcel.readParcelable(AccessToken.class.getClassLoader());
            this.f1371c = parcel.readString();
            this.f1372d = parcel.readString();
            this.f1373e = (Request) parcel.readParcelable(Request.class.getClassLoader());
            this.f1374f = C0699q.m2791a(parcel);
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.f1369a.name());
            dest.writeParcelable(this.f1370b, flags);
            dest.writeString(this.f1371c);
            dest.writeString(this.f1372d);
            dest.writeParcelable(this.f1373e, flags);
            C0699q.m2796a(dest, this.f1374f);
        }
    }

    interface C0741a {
        void mo885a();

        void mo886b();
    }

    public interface C0742b {
        void mo884a(Result result);
    }

    public LoginClient(Fragment fragment) {
        this.f1377c = fragment;
    }

    public Fragment m3046a() {
        return this.f1377c;
    }

    void m3047a(Fragment fragment) {
        if (this.f1377c != null) {
            throw new C0709e("Can't set fragment once it is already set.");
        }
        this.f1377c = fragment;
    }

    C0164q m3053b() {
        return this.f1377c.getActivity();
    }

    public Request m3056c() {
        return this.f1381g;
    }

    public static int m3040d() {
        return C0663a.Login.m2652a();
    }

    void m3048a(Request request) {
        if (!m3058e()) {
            m3054b(request);
        }
    }

    void m3054b(Request request) {
        if (request != null) {
            if (this.f1381g != null) {
                throw new C0709e("Attempted to authorize while a request is pending.");
            } else if (AccessToken.m2403a() == null || m3061h()) {
                this.f1381g = request;
                this.f1375a = m3039c(request);
                m3062i();
            }
        }
    }

    boolean m3058e() {
        return this.f1381g != null && this.f1376b >= 0;
    }

    void m3059f() {
        if (this.f1376b >= 0) {
            m3060g().mo880b();
        }
    }

    LoginMethodHandler m3060g() {
        if (this.f1376b >= 0) {
            return this.f1375a[this.f1376b];
        }
        return null;
    }

    public boolean m3052a(int requestCode, int resultCode, Intent data) {
        if (this.f1381g != null) {
            return m3060g().mo871a(requestCode, resultCode, data);
        }
        return false;
    }

    private LoginMethodHandler[] m3039c(Request request) {
        ArrayList<LoginMethodHandler> handlers = new ArrayList();
        C0748c behavior = request.m3019b();
        if (behavior.m3079a()) {
            handlers.add(new GetTokenLoginMethodHandler(this));
        }
        if (behavior.m3080b()) {
            handlers.add(new KatanaProxyLoginMethodHandler(this));
        }
        if (behavior.m3084f()) {
            handlers.add(new FacebookLiteLoginMethodHandler(this));
        }
        if (behavior.m3083e()) {
            handlers.add(new CustomTabLoginMethodHandler(this));
        }
        if (behavior.m3081c()) {
            handlers.add(new WebViewLoginMethodHandler(this));
        }
        if (behavior.m3082d()) {
            handlers.add(new DeviceAuthMethodHandler(this));
        }
        LoginMethodHandler[] result = new LoginMethodHandler[handlers.size()];
        handlers.toArray(result);
        return result;
    }

    boolean m3061h() {
        if (this.f1380f) {
            return true;
        }
        if (m3045a("android.permission.INTERNET") != 0) {
            Activity activity = m3053b();
            m3055b(Result.m3031a(this.f1381g, activity.getString(C0785d.com_facebook_internet_permission_error_title), activity.getString(C0785d.com_facebook_internet_permission_error_message)));
            return false;
        }
        this.f1380f = true;
        return true;
    }

    void m3062i() {
        if (this.f1376b >= 0) {
            m3037a(m3060g().mo869a(), "skipped", null, null, m3060g().f1325a);
        }
        while (this.f1375a != null && this.f1376b < this.f1375a.length - 1) {
            this.f1376b++;
            if (m3063j()) {
                return;
            }
        }
        if (this.f1381g != null) {
            m3043n();
        }
    }

    private void m3043n() {
        m3055b(Result.m3031a(this.f1381g, "Login attempt failed.", null));
    }

    private void m3038a(String key, String value, boolean accumulate) {
        if (this.f1382h == null) {
            this.f1382h = new HashMap();
        }
        if (this.f1382h.containsKey(key) && accumulate) {
            value = ((String) this.f1382h.get(key)) + "," + value;
        }
        this.f1382h.put(key, value);
    }

    boolean m3063j() {
        boolean z = false;
        LoginMethodHandler handler = m3060g();
        if (!handler.mo882d() || m3061h()) {
            z = handler.mo872a(this.f1381g);
            if (z) {
                m3044o().m3094a(this.f1381g.m3022e(), handler.mo869a());
            } else {
                m3044o().m3097b(this.f1381g.m3022e(), handler.mo869a());
                m3038a("not_tried", handler.mo869a(), true);
            }
        } else {
            m3038a("no_internet_permission", "1", false);
        }
        return z;
    }

    void m3049a(Result outcome) {
        if (outcome.f1370b == null || AccessToken.m2403a() == null) {
            m3055b(outcome);
        } else {
            m3057c(outcome);
        }
    }

    void m3055b(Result outcome) {
        LoginMethodHandler handler = m3060g();
        if (handler != null) {
            m3036a(handler.mo869a(), outcome, handler.f1325a);
        }
        if (this.f1382h != null) {
            outcome.f1374f = this.f1382h;
        }
        this.f1375a = null;
        this.f1376b = -1;
        this.f1381g = null;
        this.f1382h = null;
        m3041d(outcome);
    }

    void m3051a(C0742b onCompletedListener) {
        this.f1378d = onCompletedListener;
    }

    void m3050a(C0741a backgroundProcessingListener) {
        this.f1379e = backgroundProcessingListener;
    }

    int m3045a(String permission) {
        return m3053b().checkCallingOrSelfPermission(permission);
    }

    void m3057c(Result pendingResult) {
        if (pendingResult.f1370b == null) {
            throw new C0709e("Can't validate without a token");
        }
        Result result;
        AccessToken previousToken = AccessToken.m2403a();
        AccessToken newToken = pendingResult.f1370b;
        if (!(previousToken == null || newToken == null)) {
            try {
                if (previousToken.m2417i().equals(newToken.m2417i())) {
                    result = Result.m3029a(this.f1381g, pendingResult.f1370b);
                    m3055b(result);
                }
            } catch (Exception ex) {
                m3055b(Result.m3031a(this.f1381g, "Caught exception", ex.getMessage()));
                return;
            }
        }
        result = Result.m3031a(this.f1381g, "User logged in as different Facebook user.", null);
        m3055b(result);
    }

    private C0752e m3044o() {
        if (this.f1383i == null || !this.f1383i.m3093a().equals(this.f1381g.m3021d())) {
            this.f1383i = new C0752e(m3053b(), this.f1381g.m3021d());
        }
        return this.f1383i;
    }

    private void m3041d(Result outcome) {
        if (this.f1378d != null) {
            this.f1378d.mo884a(outcome);
        }
    }

    void m3064k() {
        if (this.f1379e != null) {
            this.f1379e.mo885a();
        }
    }

    void m3065l() {
        if (this.f1379e != null) {
            this.f1379e.mo886b();
        }
    }

    private void m3036a(String method, Result result, Map<String, String> loggingExtras) {
        m3037a(method, result.f1369a.m3028a(), result.f1371c, result.f1372d, loggingExtras);
    }

    private void m3037a(String method, String result, String errorMessage, String errorCode, Map<String, String> loggingExtras) {
        if (this.f1381g == null) {
            m3044o().m3095a("fb_mobile_login_method_complete", "Unexpected call to logCompleteLogin with null pendingAuthorizationRequest.", method);
        } else {
            m3044o().m3096a(this.f1381g.m3022e(), method, result, errorMessage, errorCode, loggingExtras);
        }
    }

    static String m3042m() {
        JSONObject e2e = new JSONObject();
        try {
            e2e.put("init", System.currentTimeMillis());
        } catch (JSONException e) {
        }
        return e2e.toString();
    }

    public LoginClient(Parcel source) {
        Object[] o = source.readParcelableArray(LoginMethodHandler.class.getClassLoader());
        this.f1375a = new LoginMethodHandler[o.length];
        for (int i = 0; i < o.length; i++) {
            this.f1375a[i] = (LoginMethodHandler) o[i];
            this.f1375a[i].m2924a(this);
        }
        this.f1376b = source.readInt();
        this.f1381g = (Request) source.readParcelable(Request.class.getClassLoader());
        this.f1382h = C0699q.m2791a(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeParcelableArray(this.f1375a, flags);
        dest.writeInt(this.f1376b);
        dest.writeParcelable(this.f1381g, flags);
        C0699q.m2796a(dest, this.f1382h);
    }
}
