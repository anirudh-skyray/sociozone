package com.facebook.login;

/* compiled from: DefaultAudience */
public enum C0746a {
    NONE(null),
    ONLY_ME("only_me"),
    FRIENDS("friends"),
    EVERYONE("everyone");
    
    private final String f1395e;

    private C0746a(String protocol) {
        this.f1395e = protocol;
    }

    public String m3077a() {
        return this.f1395e;
    }
}
