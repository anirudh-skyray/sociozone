package com.facebook.login;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0687m;

class FacebookLiteLoginMethodHandler extends NativeAppLoginMethodHandler {
    public static final Creator<FacebookLiteLoginMethodHandler> CREATOR = new C07321();

    static class C07321 implements Creator {
        C07321() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2987a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2988a(i);
        }

        public FacebookLiteLoginMethodHandler m2987a(Parcel source) {
            return new FacebookLiteLoginMethodHandler(source);
        }

        public FacebookLiteLoginMethodHandler[] m2988a(int size) {
            return new FacebookLiteLoginMethodHandler[size];
        }
    }

    FacebookLiteLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    String mo869a() {
        return "fb_lite_login";
    }

    boolean mo872a(Request request) {
        String e2e = LoginClient.m3042m();
        Intent intent = C0687m.m2727a(this.b.m3053b(), request.m3021d(), request.m3017a(), e2e, request.m3023f(), request.m3025h(), request.m3020c(), m2923a(request.m3022e()));
        m2925a("e2e", e2e);
        return m2994a(intent, LoginClient.m3040d());
    }

    FacebookLiteLoginMethodHandler(Parcel source) {
        super(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}
