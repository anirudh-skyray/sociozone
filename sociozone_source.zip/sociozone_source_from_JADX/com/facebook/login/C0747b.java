package com.facebook.login;

import android.content.Context;
import android.os.Bundle;
import com.facebook.p014b.C0690n;

/* compiled from: GetTokenClient */
final class C0747b extends C0690n {
    C0747b(Context context, String applicationId) {
        super(context, 65536, 65537, 20121101, applicationId);
    }

    protected void mo883a(Bundle data) {
    }
}
