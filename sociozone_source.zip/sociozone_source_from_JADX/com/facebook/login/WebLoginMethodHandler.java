package com.facebook.login;

import android.os.Bundle;
import android.os.Parcel;
import android.text.TextUtils;
import android.webkit.CookieSyncManager;
import com.facebook.AccessToken;
import com.facebook.C0708c;
import com.facebook.C0709e;
import com.facebook.C0711f;
import com.facebook.C0717g;
import com.facebook.C0719i;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.p014b.C0699q;
import java.util.Locale;

abstract class WebLoginMethodHandler extends LoginMethodHandler {
    private String f1327c;

    abstract C0708c a_();

    private static final String m2933e() {
        return "fb" + C0717g.m2883i() + "://authorize";
    }

    WebLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    WebLoginMethodHandler(Parcel source) {
        super(source);
    }

    protected String mo874c() {
        return null;
    }

    protected Bundle m2937b(Request request) {
        Bundle parameters = new Bundle();
        if (!C0699q.m2808a(request.m3017a())) {
            String scope = TextUtils.join(",", request.m3017a());
            parameters.putString("scope", scope);
            m2925a("scope", scope);
        }
        parameters.putString("default_audience", request.m3020c().m3077a());
        parameters.putString("state", m2923a(request.m3022e()));
        AccessToken previousToken = AccessToken.m2403a();
        String previousTokenString = previousToken != null ? previousToken.m2410b() : null;
        if (previousTokenString == null || !previousTokenString.equals(m2934f())) {
            C0699q.m2814b(this.b.m3053b());
            m2925a("access_token", "0");
        } else {
            parameters.putString("access_token", previousTokenString);
            m2925a("access_token", "1");
        }
        return parameters;
    }

    protected Bundle m2935a(Bundle parameters, Request request) {
        parameters.putString("redirect_uri", m2933e());
        parameters.putString("client_id", request.m3021d());
        LoginClient loginClient = this.b;
        parameters.putString("e2e", LoginClient.m3042m());
        parameters.putString("response_type", "token,signed_request");
        parameters.putString("return_scopes", "true");
        parameters.putString("auth_type", "rerequest");
        if (mo874c() != null) {
            parameters.putString("sso", mo874c());
        }
        return parameters;
    }

    protected void m2936a(Request request, Bundle values, C0709e error) {
        Result outcome;
        this.f1327c = null;
        if (values != null) {
            if (values.containsKey("e2e")) {
                this.f1327c = values.getString("e2e");
            }
            try {
                AccessToken token = LoginMethodHandler.m2920a(request.m3017a(), values, a_(), request.m3021d());
                outcome = Result.m3029a(this.b.m3056c(), token);
                CookieSyncManager.createInstance(this.b.m3053b()).sync();
                m2932c(token.m2410b());
            } catch (C0709e ex) {
                outcome = Result.m3031a(this.b.m3056c(), null, ex.getMessage());
            }
        } else if (error instanceof C0711f) {
            outcome = Result.m3030a(this.b.m3056c(), "User canceled log in.");
        } else {
            this.f1327c = null;
            String errorCode = null;
            String errorMessage = error.getMessage();
            if (error instanceof C0719i) {
                errorCode = String.format(Locale.ROOT, "%d", new Object[]{Integer.valueOf(((C0719i) error).m2888a().m2429b())});
                errorMessage = requestError.toString();
            }
            outcome = Result.m3032a(this.b.m3056c(), null, errorMessage, errorCode);
        }
        if (!C0699q.m2807a(this.f1327c)) {
            m2930b(this.f1327c);
        }
        this.b.m3049a(outcome);
    }

    private String m2934f() {
        return this.b.m3053b().getSharedPreferences("com.facebook.login.AuthorizationClient.WebViewAuthHandler.TOKEN_STORE_KEY", 0).getString("TOKEN", "");
    }

    private void m2932c(String token) {
        this.b.m3053b().getSharedPreferences("com.facebook.login.AuthorizationClient.WebViewAuthHandler.TOKEN_STORE_KEY", 0).edit().putString("TOKEN", token).apply();
    }
}
