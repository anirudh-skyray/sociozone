package com.facebook.login;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import com.facebook.login.LoginClient.Result.C0740a;
import com.facebook.p015a.C0628f;
import java.util.Map;
import org.json.JSONObject;

/* compiled from: LoginLogger */
class C0752e {
    private final C0628f f1415a;
    private String f1416b;
    private String f1417c;

    C0752e(Context context, String applicationId) {
        this.f1416b = applicationId;
        this.f1415a = C0628f.m2584c(context, applicationId);
        try {
            PackageManager packageManager = context.getPackageManager();
            if (packageManager != null) {
                PackageInfo facebookInfo = packageManager.getPackageInfo("com.facebook.katana", 0);
                if (facebookInfo != null) {
                    this.f1417c = facebookInfo.versionName;
                }
            }
        } catch (NameNotFoundException e) {
        }
    }

    public String m3093a() {
        return this.f1416b;
    }

    static Bundle m3092a(String authLoggerId) {
        Bundle bundle = new Bundle();
        bundle.putLong("1_timestamp_ms", System.currentTimeMillis());
        bundle.putString("0_auth_logger_id", authLoggerId);
        bundle.putString("3_method", "");
        bundle.putString("2_result", "");
        bundle.putString("5_error_message", "");
        bundle.putString("4_error_code", "");
        bundle.putString("6_extras", "");
        return bundle;
    }

    public void m3094a(String authId, String method) {
        Bundle bundle = C0752e.m3092a(authId);
        bundle.putString("3_method", method);
        this.f1415a.m2594a("fb_mobile_login_method_start", null, bundle);
    }

    public void m3096a(String authId, String method, String result, String errorMessage, String errorCode, Map<String, String> loggingExtras) {
        Bundle bundle = C0752e.m3092a(authId);
        if (result != null) {
            bundle.putString("2_result", result);
        }
        if (errorMessage != null) {
            bundle.putString("5_error_message", errorMessage);
        }
        if (errorCode != null) {
            bundle.putString("4_error_code", errorCode);
        }
        if (!(loggingExtras == null || loggingExtras.isEmpty())) {
            bundle.putString("6_extras", new JSONObject(loggingExtras).toString());
        }
        bundle.putString("3_method", method);
        this.f1415a.m2594a("fb_mobile_login_method_complete", null, bundle);
    }

    public void m3097b(String authId, String method) {
        Bundle bundle = C0752e.m3092a(authId);
        bundle.putString("3_method", method);
        this.f1415a.m2594a("fb_mobile_login_method_not_tried", null, bundle);
    }

    public void m3095a(String eventName, String errorMessage, String method) {
        Bundle bundle = C0752e.m3092a("");
        bundle.putString("2_result", C0740a.ERROR.m3028a());
        bundle.putString("5_error_message", errorMessage);
        bundle.putString("3_method", method);
        this.f1415a.m2594a(eventName, null, bundle);
    }
}
