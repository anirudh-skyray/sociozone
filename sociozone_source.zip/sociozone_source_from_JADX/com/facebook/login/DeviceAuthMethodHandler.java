package com.facebook.login;

import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.AccessToken;
import com.facebook.C0708c;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import java.util.Collection;
import java.util.Date;
import java.util.concurrent.ScheduledThreadPoolExecutor;

class DeviceAuthMethodHandler extends LoginMethodHandler {
    public static final Creator<DeviceAuthMethodHandler> CREATOR = new C07311();
    private static ScheduledThreadPoolExecutor f1350c;

    static class C07311 implements Creator {
        C07311() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2979a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2980a(i);
        }

        public DeviceAuthMethodHandler m2979a(Parcel source) {
            return new DeviceAuthMethodHandler(source);
        }

        public DeviceAuthMethodHandler[] m2980a(int size) {
            return new DeviceAuthMethodHandler[size];
        }
    }

    DeviceAuthMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    boolean mo872a(Request request) {
        m2981b(request);
        return true;
    }

    private void m2981b(Request request) {
        DeviceAuthDialog dialog = new DeviceAuthDialog();
        dialog.show(this.b.m3053b().getSupportFragmentManager(), "login_with_facebook");
        dialog.m2978a(request);
    }

    public void b_() {
        this.b.m3049a(Result.m3030a(this.b.m3056c(), "User canceled log in."));
    }

    public void m2984a(Exception ex) {
        this.b.m3049a(Result.m3031a(this.b.m3056c(), null, ex.getMessage()));
    }

    public void m2985a(String accessToken, String applicationId, String userId, Collection<String> permissions, Collection<String> declinedPermissions, C0708c accessTokenSource, Date expirationTime, Date lastRefreshTime) {
        this.b.m3049a(Result.m3029a(this.b.m3056c(), new AccessToken(accessToken, applicationId, userId, permissions, declinedPermissions, accessTokenSource, expirationTime, lastRefreshTime)));
    }

    public static synchronized ScheduledThreadPoolExecutor m2982c() {
        ScheduledThreadPoolExecutor scheduledThreadPoolExecutor;
        synchronized (DeviceAuthMethodHandler.class) {
            if (f1350c == null) {
                f1350c = new ScheduledThreadPoolExecutor(1);
            }
            scheduledThreadPoolExecutor = f1350c;
        }
        return scheduledThreadPoolExecutor;
    }

    protected DeviceAuthMethodHandler(Parcel parcel) {
        super(parcel);
    }

    String mo869a() {
        return "device_auth";
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}
