package com.facebook.login;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.facebook.C0708c;
import com.facebook.C0709e;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.p014b.C0690n.C0689a;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0699q.C0599c;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

class GetTokenLoginMethodHandler extends LoginMethodHandler {
    public static final Creator<GetTokenLoginMethodHandler> CREATOR = new C07353();
    private C0747b f1356c;

    static class C07353 implements Creator {
        C07353() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3001a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3002a(i);
        }

        public GetTokenLoginMethodHandler m3001a(Parcel source) {
            return new GetTokenLoginMethodHandler(source);
        }

        public GetTokenLoginMethodHandler[] m3002a(int size) {
            return new GetTokenLoginMethodHandler[size];
        }
    }

    GetTokenLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    String mo869a() {
        return "get_token";
    }

    void mo880b() {
        if (this.f1356c != null) {
            this.f1356c.m2753b();
            this.f1356c.m2751a(null);
            this.f1356c = null;
        }
    }

    boolean mo872a(final Request request) {
        this.f1356c = new C0747b(this.b.m3053b(), request.m3021d());
        if (!this.f1356c.m2752a()) {
            return false;
        }
        this.b.m3064k();
        this.f1356c.m2751a(new C0689a(this) {
            final /* synthetic */ GetTokenLoginMethodHandler f1352b;

            public void mo879a(Bundle result) {
                this.f1352b.m3004a(request, result);
            }
        });
        return true;
    }

    void m3004a(Request request, Bundle result) {
        if (this.f1356c != null) {
            this.f1356c.m2751a(null);
        }
        this.f1356c = null;
        this.b.m3065l();
        if (result != null) {
            ArrayList<String> currentPermissions = result.getStringArrayList("com.facebook.platform.extra.PERMISSIONS");
            Set<String> permissions = request.m3017a();
            if (currentPermissions == null || !(permissions == null || currentPermissions.containsAll(permissions))) {
                Set<String> newPermissions = new HashSet();
                for (String permission : permissions) {
                    if (!currentPermissions.contains(permission)) {
                        newPermissions.add(permission);
                    }
                }
                if (!newPermissions.isEmpty()) {
                    m2925a("new_permissions", TextUtils.join(",", newPermissions));
                }
                request.m3018a(newPermissions);
            } else {
                m3008c(request, result);
                return;
            }
        }
        this.b.m3062i();
    }

    void m3007b(Request request, Bundle result) {
        this.b.m3049a(Result.m3029a(this.b.m3056c(), LoginMethodHandler.m2919a(result, C0708c.FACEBOOK_APPLICATION_SERVICE, request.m3021d())));
    }

    void m3008c(final Request request, final Bundle result) {
        String userId = result.getString("com.facebook.platform.extra.USER_ID");
        if (userId == null || userId.isEmpty()) {
            this.b.m3064k();
            C0699q.m2798a(result.getString("com.facebook.platform.extra.ACCESS_TOKEN"), new C0599c(this) {
                final /* synthetic */ GetTokenLoginMethodHandler f1355c;

                public void mo858a(JSONObject userInfo) {
                    try {
                        result.putString("com.facebook.platform.extra.USER_ID", userInfo.getString("id"));
                        this.f1355c.m3007b(request, result);
                    } catch (JSONException ex) {
                        this.f1355c.b.m3055b(Result.m3031a(this.f1355c.b.m3056c(), "Caught exception", ex.getMessage()));
                    }
                }

                public void mo857a(C0709e error) {
                    this.f1355c.b.m3055b(Result.m3031a(this.f1355c.b.m3056c(), "Caught exception", error.getMessage()));
                }
            });
            return;
        }
        m3007b(request, result);
    }

    GetTokenLoginMethodHandler(Parcel source) {
        super(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}
