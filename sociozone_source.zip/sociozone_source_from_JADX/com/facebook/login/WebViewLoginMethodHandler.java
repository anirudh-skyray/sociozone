package com.facebook.login;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0164q;
import com.facebook.C0708c;
import com.facebook.C0709e;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0669g;
import com.facebook.p014b.C0675s;
import com.facebook.p014b.C0675s.C0666c;
import com.facebook.p014b.C0675s.C0705a;

class WebViewLoginMethodHandler extends WebLoginMethodHandler {
    public static final Creator<WebViewLoginMethodHandler> CREATOR = new C07442();
    private C0675s f1388c;
    private String f1389d;

    static class C07442 implements Creator {
        C07442() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3067a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3068a(i);
        }

        public WebViewLoginMethodHandler m3067a(Parcel source) {
            return new WebViewLoginMethodHandler(source);
        }

        public WebViewLoginMethodHandler[] m3068a(int size) {
            return new WebViewLoginMethodHandler[size];
        }
    }

    static class C0745a extends C0705a {
        private String f1386a;
        private boolean f1387b;

        public C0745a(Context context, String applicationId, Bundle parameters) {
            super(context, applicationId, "oauth", parameters);
        }

        public C0745a m3070a(String e2e) {
            this.f1386a = e2e;
            return this;
        }

        public C0745a m3071a(boolean isRerequest) {
            this.f1387b = isRerequest;
            return this;
        }

        public C0675s mo881a() {
            Bundle parameters = m2845e();
            parameters.putString("redirect_uri", "fbconnect://success");
            parameters.putString("client_id", m2842b());
            parameters.putString("e2e", this.f1386a);
            parameters.putString("response_type", "token,signed_request");
            parameters.putString("return_scopes", "true");
            parameters.putString("auth_type", "rerequest");
            return new C0675s(m2843c(), "oauth", parameters, m2844d(), m2846f());
        }
    }

    WebViewLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    String mo869a() {
        return "web_view";
    }

    C0708c a_() {
        return C0708c.WEB_VIEW;
    }

    boolean mo882d() {
        return true;
    }

    void mo880b() {
        if (this.f1388c != null) {
            this.f1388c.cancel();
            this.f1388c = null;
        }
    }

    boolean mo872a(final Request request) {
        Bundle parameters = m2937b(request);
        C0666c listener = new C0666c(this) {
            final /* synthetic */ WebViewLoginMethodHandler f1385b;

            public void mo861a(Bundle values, C0709e error) {
                this.f1385b.m3075b(request, values, error);
            }
        };
        this.f1389d = LoginClient.m3042m();
        m2925a("e2e", this.f1389d);
        C0164q fragmentActivity = this.b.m3053b();
        this.f1388c = new C0745a(fragmentActivity, request.m3021d(), parameters).m3070a(this.f1389d).m3071a(request.m3023f()).m2840a(listener).mo881a();
        C0669g dialogFragment = new C0669g();
        dialogFragment.setRetainInstance(true);
        dialogFragment.m2661a(this.f1388c);
        dialogFragment.show(fragmentActivity.getSupportFragmentManager(), "FacebookDialogFragment");
        return true;
    }

    void m3075b(Request request, Bundle values, C0709e error) {
        super.m2936a(request, values, error);
    }

    WebViewLoginMethodHandler(Parcel source) {
        super(source);
        this.f1389d = source.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.f1389d);
    }
}
