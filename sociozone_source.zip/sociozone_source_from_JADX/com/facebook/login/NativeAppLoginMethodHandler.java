package com.facebook.login;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.os.Bundle;
import android.os.Parcel;
import com.facebook.C0708c;
import com.facebook.C0709e;
import com.facebook.login.LoginClient.Request;
import com.facebook.login.LoginClient.Result;
import com.facebook.p014b.C0692p;
import com.facebook.p014b.C0699q;

abstract class NativeAppLoginMethodHandler extends LoginMethodHandler {
    abstract boolean mo872a(Request request);

    NativeAppLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    NativeAppLoginMethodHandler(Parcel source) {
        super(source);
    }

    boolean mo871a(int requestCode, int resultCode, Intent data) {
        Result outcome;
        Request request = this.b.m3056c();
        if (data == null) {
            outcome = Result.m3030a(request, "Operation canceled");
        } else if (resultCode == 0) {
            outcome = m2991b(request, data);
        } else if (resultCode != -1) {
            outcome = Result.m3031a(request, "Unexpected resultCode from authorization.", null);
        } else {
            outcome = m2989a(request, data);
        }
        if (outcome != null) {
            this.b.m3049a(outcome);
        } else {
            this.b.m3062i();
        }
        return true;
    }

    private Result m2989a(Request request, Intent data) {
        String str = null;
        Bundle extras = data.getExtras();
        String error = m2990a(extras);
        String errorCode = extras.getString("error_code");
        String errorMessage = m2992b(extras);
        String e2e = extras.getString("e2e");
        if (!C0699q.m2807a(e2e)) {
            m2930b(e2e);
        }
        if (error == null && errorCode == null && errorMessage == null) {
            try {
                return Result.m3029a(request, LoginMethodHandler.m2920a(request.m3017a(), extras, C0708c.FACEBOOK_APPLICATION_WEB, request.m3021d()));
            } catch (C0709e ex) {
                return Result.m3031a(request, str, ex.getMessage());
            }
        } else if (C0692p.f1221a.contains(error)) {
            return str;
        } else {
            if (C0692p.f1222b.contains(error)) {
                return Result.m3030a(request, str);
            }
            return Result.m3032a(request, error, errorMessage, errorCode);
        }
    }

    private Result m2991b(Request request, Intent data) {
        Bundle extras = data.getExtras();
        String error = m2990a(extras);
        String errorCode = extras.getString("error_code");
        if ("CONNECTION_FAILURE".equals(errorCode)) {
            return Result.m3032a(request, error, m2992b(extras), errorCode);
        }
        return Result.m3030a(request, error);
    }

    private String m2990a(Bundle extras) {
        String error = extras.getString("error");
        if (error == null) {
            return extras.getString("error_type");
        }
        return error;
    }

    private String m2992b(Bundle extras) {
        String errorMessage = extras.getString("error_message");
        if (errorMessage == null) {
            return extras.getString("error_description");
        }
        return errorMessage;
    }

    protected boolean m2994a(Intent intent, int requestCode) {
        if (intent == null) {
            return false;
        }
        try {
            this.b.m3046a().startActivityForResult(intent, requestCode);
            return true;
        } catch (ActivityNotFoundException e) {
            return false;
        }
    }
}
