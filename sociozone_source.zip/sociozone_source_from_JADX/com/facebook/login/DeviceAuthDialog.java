package com.facebook.login;

import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.app.C0159p;
import android.text.Html;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import com.facebook.AccessToken;
import com.facebook.C0708c;
import com.facebook.C0709e;
import com.facebook.C0717g;
import com.facebook.C0720j;
import com.facebook.C0723l;
import com.facebook.C0755m;
import com.facebook.C0787t.C0783b;
import com.facebook.C0787t.C0784c;
import com.facebook.C0787t.C0785d;
import com.facebook.C0787t.C0786e;
import com.facebook.FacebookActivity;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0588b;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0699q.C0698d;
import com.facebook.p014b.C0700r;
import java.util.Date;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import org.json.JSONObject;

public class DeviceAuthDialog extends C0159p {
    private ProgressBar f1341a;
    private TextView f1342b;
    private DeviceAuthMethodHandler f1343c;
    private AtomicBoolean f1344d = new AtomicBoolean();
    private volatile C0720j f1345e;
    private volatile ScheduledFuture f1346f;
    private volatile RequestState f1347g;
    private Dialog f1348h;
    private boolean f1349i = false;

    class C07251 implements OnClickListener {
        final /* synthetic */ DeviceAuthDialog f1331a;

        C07251(DeviceAuthDialog this$0) {
            this.f1331a = this$0;
        }

        public void onClick(View v) {
            this.f1331a.m2974d();
        }
    }

    class C07262 implements C0588b {
        final /* synthetic */ DeviceAuthDialog f1332a;

        C07262(DeviceAuthDialog this$0) {
            this.f1332a = this$0;
        }

        public void mo855a(C0723l response) {
            if (response.m2915a() != null) {
                this.f1332a.m2963a(response.m2915a().m2433f());
                return;
            }
            JSONObject jsonObject = response.m2916b();
            RequestState requestState = new RequestState();
            try {
                requestState.m2956a(jsonObject.getString("user_code"));
                requestState.m2959b(jsonObject.getString("code"));
                requestState.m2955a(jsonObject.getLong("interval"));
                this.f1332a.m2964a(requestState);
            } catch (Throwable ex) {
                this.f1332a.m2963a(new C0709e(ex));
            }
        }
    }

    class C07273 implements Runnable {
        final /* synthetic */ DeviceAuthDialog f1333a;

        C07273(DeviceAuthDialog this$0) {
            this.f1333a = this$0;
        }

        public void run() {
            this.f1333a.m2962a();
        }
    }

    class C07284 implements C0588b {
        final /* synthetic */ DeviceAuthDialog f1334a;

        C07284(DeviceAuthDialog this$0) {
            this.f1334a = this$0;
        }

        public void mo855a(C0723l response) {
            if (!this.f1334a.f1344d.get()) {
                FacebookRequestError error = response.m2915a();
                if (error != null) {
                    switch (error.m2430c()) {
                        case 1349152:
                        case 1349173:
                            this.f1334a.m2974d();
                            return;
                        case 1349172:
                        case 1349174:
                            this.f1334a.m2970b();
                            return;
                        default:
                            this.f1334a.m2963a(response.m2915a().m2433f());
                            return;
                    }
                }
                try {
                    this.f1334a.m2969a(response.m2916b().getString("access_token"));
                } catch (Throwable ex) {
                    this.f1334a.m2963a(new C0709e(ex));
                }
            }
        }
    }

    private static class RequestState implements Parcelable {
        public static final Creator<RequestState> CREATOR = new C07301();
        private String f1337a;
        private String f1338b;
        private long f1339c;
        private long f1340d;

        static class C07301 implements Creator<RequestState> {
            C07301() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2952a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2953a(i);
            }

            public RequestState m2952a(Parcel in) {
                return new RequestState(in);
            }

            public RequestState[] m2953a(int size) {
                return new RequestState[size];
            }
        }

        RequestState() {
        }

        public String m2954a() {
            return this.f1337a;
        }

        public void m2956a(String userCode) {
            this.f1337a = userCode;
        }

        public String m2957b() {
            return this.f1338b;
        }

        public void m2959b(String requestCode) {
            this.f1338b = requestCode;
        }

        public long m2960c() {
            return this.f1339c;
        }

        public void m2955a(long interval) {
            this.f1339c = interval;
        }

        public void m2958b(long lastPoll) {
            this.f1340d = lastPoll;
        }

        protected RequestState(Parcel in) {
            this.f1337a = in.readString();
            this.f1338b = in.readString();
            this.f1339c = in.readLong();
            this.f1340d = in.readLong();
        }

        public boolean m2961d() {
            if (this.f1340d != 0 && (new Date().getTime() - this.f1340d) - (this.f1339c * 1000) < 0) {
                return true;
            }
            return false;
        }

        public int describeContents() {
            return 0;
        }

        public void writeToParcel(Parcel dest, int flags) {
            dest.writeString(this.f1337a);
            dest.writeString(this.f1338b);
            dest.writeLong(this.f1339c);
            dest.writeLong(this.f1340d);
        }
    }

    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = super.onCreateView(inflater, container, savedInstanceState);
        this.f1343c = (DeviceAuthMethodHandler) ((C0751d) ((FacebookActivity) getActivity()).m2422a()).m3091a().m3060g();
        if (savedInstanceState != null) {
            RequestState requestState = (RequestState) savedInstanceState.getParcelable("request_state");
            if (requestState != null) {
                m2964a(requestState);
            }
        }
        return view;
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        this.f1348h = new Dialog(getActivity(), C0786e.com_facebook_auth_dialog);
        View view = getActivity().getLayoutInflater().inflate(C0784c.com_facebook_device_auth_dialog_fragment, null);
        this.f1341a = (ProgressBar) view.findViewById(C0783b.progress_bar);
        this.f1342b = (TextView) view.findViewById(C0783b.confirmation_code);
        ((Button) view.findViewById(C0783b.cancel_button)).setOnClickListener(new C07251(this));
        ((TextView) view.findViewById(C0783b.com_facebook_device_auth_instructions)).setText(Html.fromHtml(getString(C0785d.com_facebook_device_auth_instructions)));
        this.f1348h.setContentView(view);
        return this.f1348h;
    }

    public void onDismiss(DialogInterface dialog) {
        super.onDismiss(dialog);
        if (!this.f1349i) {
            m2974d();
        }
    }

    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (this.f1347g != null) {
            outState.putParcelable("request_state", this.f1347g);
        }
    }

    public void onDestroy() {
        this.f1349i = true;
        this.f1344d.set(true);
        super.onDestroy();
        if (this.f1345e != null) {
            this.f1345e.cancel(true);
        }
        if (this.f1346f != null) {
            this.f1346f.cancel(true);
        }
    }

    public void m2978a(Request request) {
        Bundle parameters = new Bundle();
        parameters.putString("scope", TextUtils.join(",", request.m3017a()));
        String redirectUriString = request.m3024g();
        if (redirectUriString != null) {
            parameters.putString("redirect_uri", redirectUriString);
        }
        parameters.putString("access_token", C0700r.m2834b() + "|" + C0700r.m2837c());
        new GraphRequest(null, "device/login", parameters, C0755m.POST, new C07262(this)).m2512j();
    }

    private void m2964a(RequestState currentRequestState) {
        this.f1347g = currentRequestState;
        this.f1342b.setText(currentRequestState.m2954a());
        this.f1342b.setVisibility(0);
        this.f1341a.setVisibility(8);
        if (currentRequestState.m2961d()) {
            m2970b();
        } else {
            m2962a();
        }
    }

    private void m2962a() {
        this.f1347g.m2958b(new Date().getTime());
        this.f1345e = m2972c().m2512j();
    }

    private void m2970b() {
        this.f1346f = DeviceAuthMethodHandler.m2982c().schedule(new C07273(this), this.f1347g.m2960c(), TimeUnit.SECONDS);
    }

    private GraphRequest m2972c() {
        Bundle parameters = new Bundle();
        parameters.putString("code", this.f1347g.m2957b());
        return new GraphRequest(null, "device/login_status", parameters, C0755m.POST, new C07284(this));
    }

    private void m2969a(final String accessToken) {
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,permissions");
        new GraphRequest(new AccessToken(accessToken, C0717g.m2883i(), "0", null, null, null, null, null), "me", parameters, C0755m.GET, new C0588b(this) {
            final /* synthetic */ DeviceAuthDialog f1336b;

            public void mo855a(C0723l response) {
                if (!this.f1336b.f1344d.get()) {
                    if (response.m2915a() != null) {
                        this.f1336b.m2963a(response.m2915a().m2433f());
                        return;
                    }
                    try {
                        JSONObject jsonObject = response.m2916b();
                        String userId = jsonObject.getString("id");
                        C0698d permissions = C0699q.m2777a(jsonObject);
                        this.f1336b.f1343c.m2985a(accessToken, C0717g.m2883i(), userId, permissions.m2769a(), permissions.m2770b(), C0708c.DEVICE_AUTH, null, null);
                        this.f1336b.f1348h.dismiss();
                    } catch (Throwable ex) {
                        this.f1336b.m2963a(new C0709e(ex));
                    }
                }
            }
        }).m2512j();
    }

    private void m2963a(C0709e ex) {
        if (this.f1344d.compareAndSet(false, true)) {
            this.f1343c.m2984a((Exception) ex);
            this.f1348h.dismiss();
        }
    }

    private void m2974d() {
        if (this.f1344d.compareAndSet(false, true)) {
            if (this.f1343c != null) {
                this.f1343c.b_();
            }
            this.f1348h.dismiss();
        }
    }
}
