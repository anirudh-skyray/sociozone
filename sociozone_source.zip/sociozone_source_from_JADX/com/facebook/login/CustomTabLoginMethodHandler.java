package com.facebook.login;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.C0708c;
import com.facebook.C0709e;
import com.facebook.C0711f;
import com.facebook.C0717g;
import com.facebook.C0719i;
import com.facebook.CustomTabMainActivity;
import com.facebook.FacebookRequestError;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0699q.C0697b;
import com.facebook.p014b.C0700r;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONException;
import org.json.JSONObject;

public class CustomTabLoginMethodHandler extends WebLoginMethodHandler {
    public static final Creator<CustomTabLoginMethodHandler> CREATOR = new C07241();
    private static final String[] f1328c = new String[]{"com.android.chrome", "com.chrome.beta", "com.chrome.dev"};
    private String f1329d;
    private String f1330e;

    static class C07241 implements Creator {
        C07241() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2917a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2918a(i);
        }

        public CustomTabLoginMethodHandler m2917a(Parcel source) {
            return new CustomTabLoginMethodHandler(source);
        }

        public CustomTabLoginMethodHandler[] m2918a(int size) {
            return new CustomTabLoginMethodHandler[size];
        }
    }

    CustomTabLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
        this.f1330e = C0699q.m2780a(20);
    }

    String mo869a() {
        return "custom_tab";
    }

    C0708c a_() {
        return C0708c.CHROME_CUSTOM_TAB;
    }

    protected String mo874c() {
        return "chrome_custom_tab";
    }

    boolean mo872a(Request request) {
        if (!m2941e()) {
            return false;
        }
        Bundle parameters = m2935a(m2937b(request), request);
        Intent intent = new Intent(this.b.m3053b(), CustomTabMainActivity.class);
        intent.putExtra(CustomTabMainActivity.f953a, parameters);
        intent.putExtra(CustomTabMainActivity.f954b, m2943g());
        this.b.m3046a().startActivityForResult(intent, 1);
        return true;
    }

    private boolean m2941e() {
        return m2942f() && m2943g() != null && C0700r.m2833a(C0717g.m2880f());
    }

    private boolean m2942f() {
        C0697b settings = C0699q.m2816c(C0699q.m2781a(this.b.m3053b()));
        return settings != null && settings.m2767b();
    }

    private String m2943g() {
        if (this.f1329d != null) {
            return this.f1329d;
        }
        Context context = this.b.m3053b();
        List<ResolveInfo> resolveInfos = context.getPackageManager().queryIntentServices(new Intent("android.support.customtabs.action.CustomTabsService"), 0);
        if (resolveInfos != null) {
            Set<String> chromePackages = new HashSet(Arrays.asList(f1328c));
            for (ResolveInfo resolveInfo : resolveInfos) {
                ServiceInfo serviceInfo = resolveInfo.serviceInfo;
                if (serviceInfo != null && chromePackages.contains(serviceInfo.packageName)) {
                    this.f1329d = serviceInfo.packageName;
                    return this.f1329d;
                }
            }
        }
        return null;
    }

    boolean mo871a(int requestCode, int resultCode, Intent data) {
        if (requestCode != 1) {
            return super.mo871a(requestCode, resultCode, data);
        }
        Request request = this.b.m3056c();
        if (resultCode == -1) {
            m2939a(data.getStringExtra(CustomTabMainActivity.f955c), request);
            return true;
        }
        super.m2936a(request, null, new C0711f());
        return false;
    }

    private void m2939a(String url, Request request) {
        if (url != null && url.startsWith(CustomTabMainActivity.m2419a())) {
            Uri uri = Uri.parse(url);
            Bundle values = C0699q.m2810b(uri.getQuery());
            values.putAll(C0699q.m2810b(uri.getFragment()));
            if (m2940a(values)) {
                String error = values.getString("error");
                if (error == null) {
                    error = values.getString("error_type");
                }
                String errorMessage = values.getString("error_msg");
                if (errorMessage == null) {
                    errorMessage = values.getString("error_message");
                }
                if (errorMessage == null) {
                    errorMessage = values.getString("error_description");
                }
                String errorCodeString = values.getString("error_code");
                int errorCode = -1;
                if (!C0699q.m2807a(errorCodeString)) {
                    try {
                        errorCode = Integer.parseInt(errorCodeString);
                    } catch (NumberFormatException e) {
                        errorCode = -1;
                    }
                }
                if (C0699q.m2807a(error) && C0699q.m2807a(errorMessage) && errorCode == -1) {
                    super.m2936a(request, values, null);
                    return;
                } else if (error != null && (error.equals("access_denied") || error.equals("OAuthAccessDeniedException"))) {
                    super.m2936a(request, null, new C0711f());
                    return;
                } else if (errorCode == 4201) {
                    super.m2936a(request, null, new C0711f());
                    return;
                } else {
                    super.m2936a(request, null, new C0719i(new FacebookRequestError(errorCode, error, errorMessage), errorMessage));
                    return;
                }
            }
            super.m2936a(request, null, new C0709e("Invalid state parameter"));
        }
    }

    protected void mo870a(JSONObject param) throws JSONException {
        param.put("7_challenge", this.f1330e);
    }

    private boolean m2940a(Bundle values) {
        boolean z = false;
        try {
            String stateString = values.getString("state");
            if (stateString != null) {
                z = new JSONObject(stateString).getString("7_challenge").equals(this.f1330e);
            }
        } catch (JSONException e) {
        }
        return z;
    }

    public int describeContents() {
        return 0;
    }

    CustomTabLoginMethodHandler(Parcel source) {
        super(source);
        this.f1330e = source.readString();
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
        dest.writeString(this.f1330e);
    }
}
