package com.facebook.login;

/* compiled from: LoginBehavior */
public enum C0748c {
    NATIVE_WITH_FALLBACK(true, true, true, false, true, true),
    NATIVE_ONLY(true, true, false, false, false, true),
    KATANA_ONLY(false, true, false, false, false, false),
    WEB_ONLY(false, false, true, false, true, false),
    WEB_VIEW_ONLY(false, false, true, false, false, false),
    DEVICE_AUTH(false, false, false, true, false, false);
    
    private final boolean f1403g;
    private final boolean f1404h;
    private final boolean f1405i;
    private final boolean f1406j;
    private final boolean f1407k;
    private final boolean f1408l;

    private C0748c(boolean allowsGetTokenAuth, boolean allowsKatanaAuth, boolean allowsWebViewAuth, boolean allowsDeviceAuth, boolean allowsCustomTabAuth, boolean allowsFacebookLiteAuth) {
        this.f1403g = allowsGetTokenAuth;
        this.f1404h = allowsKatanaAuth;
        this.f1405i = allowsWebViewAuth;
        this.f1406j = allowsDeviceAuth;
        this.f1407k = allowsCustomTabAuth;
        this.f1408l = allowsFacebookLiteAuth;
    }

    boolean m3079a() {
        return this.f1403g;
    }

    boolean m3080b() {
        return this.f1404h;
    }

    boolean m3081c() {
        return this.f1405i;
    }

    boolean m3082d() {
        return this.f1406j;
    }

    boolean m3083e() {
        return this.f1407k;
    }

    boolean m3084f() {
        return this.f1408l;
    }
}
