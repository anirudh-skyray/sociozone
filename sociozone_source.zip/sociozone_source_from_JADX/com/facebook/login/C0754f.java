package com.facebook.login;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/* compiled from: LoginManager */
public class C0754f {
    private static final Set<String> f1418a = C0754f.m3098a();

    /* compiled from: LoginManager */
    static class C07531 extends HashSet<String> {
        C07531() {
            add("ads_management");
            add("create_event");
            add("rsvp_event");
        }
    }

    static boolean m3099a(String permission) {
        return permission != null && (permission.startsWith("publish") || permission.startsWith("manage") || f1418a.contains(permission));
    }

    private static Set<String> m3098a() {
        return Collections.unmodifiableSet(new C07531());
    }
}
