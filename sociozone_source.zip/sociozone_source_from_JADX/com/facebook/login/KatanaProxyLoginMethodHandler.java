package com.facebook.login;

import android.content.Intent;
import android.os.Parcel;
import android.os.Parcelable.Creator;
import com.facebook.login.LoginClient.Request;
import com.facebook.p014b.C0687m;

class KatanaProxyLoginMethodHandler extends NativeAppLoginMethodHandler {
    public static final Creator<KatanaProxyLoginMethodHandler> CREATOR = new C07361();

    static class C07361 implements Creator {
        C07361() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m3009a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m3010a(i);
        }

        public KatanaProxyLoginMethodHandler m3009a(Parcel source) {
            return new KatanaProxyLoginMethodHandler(source);
        }

        public KatanaProxyLoginMethodHandler[] m3010a(int size) {
            return new KatanaProxyLoginMethodHandler[size];
        }
    }

    KatanaProxyLoginMethodHandler(LoginClient loginClient) {
        super(loginClient);
    }

    String mo869a() {
        return "katana_proxy_auth";
    }

    boolean mo872a(Request request) {
        String e2e = LoginClient.m3042m();
        Intent intent = C0687m.m2736b(this.b.m3053b(), request.m3021d(), request.m3017a(), e2e, request.m3023f(), request.m3025h(), request.m3020c(), m2923a(request.m3022e()));
        m2925a("e2e", e2e);
        return m2994a(intent, LoginClient.m3040d());
    }

    KatanaProxyLoginMethodHandler(Parcel source) {
        super(source);
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        super.writeToParcel(dest, flags);
    }
}
