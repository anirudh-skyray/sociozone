package com.facebook;

/* compiled from: FacebookDialogException */
public class C0710d extends C0709e {
    private int f1282a;
    private String f1283b;

    public C0710d(String message, int errorCode, String failingUrl) {
        super(message);
        this.f1282a = errorCode;
        this.f1283b = failingUrl;
    }

    public int m2862a() {
        return this.f1282a;
    }

    public String m2863b() {
        return this.f1283b;
    }

    public final String toString() {
        return "{FacebookDialogException: " + "errorCode: " + m2862a() + ", message: " + getMessage() + ", url: " + m2863b() + "}";
    }
}
