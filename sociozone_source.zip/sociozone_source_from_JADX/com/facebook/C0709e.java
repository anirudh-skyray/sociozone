package com.facebook;

/* compiled from: FacebookException */
public class C0709e extends RuntimeException {
    public C0709e(String message) {
        super(message);
    }

    public C0709e(String message, Throwable throwable) {
        super(message, throwable);
    }

    public C0709e(Throwable throwable) {
        super(throwable);
    }

    public String toString() {
        return getMessage();
    }
}
