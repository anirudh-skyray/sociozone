package com.facebook;

import android.os.Handler;
import com.facebook.GraphRequest.C0588b;
import com.facebook.GraphRequest.C0597e;

/* compiled from: RequestProgress */
class C0789v {
    private final GraphRequest f1490a;
    private final Handler f1491b;
    private final long f1492c = C0717g.m2882h();
    private long f1493d;
    private long f1494e;
    private long f1495f;

    C0789v(Handler callbackHandler, GraphRequest request) {
        this.f1490a = request;
        this.f1491b = callbackHandler;
    }

    void m3197a(long size) {
        this.f1493d += size;
        if (this.f1493d >= this.f1494e + this.f1492c || this.f1493d >= this.f1495f) {
            m3196a();
        }
    }

    void m3198b(long size) {
        this.f1495f += size;
    }

    void m3196a() {
        if (this.f1493d > this.f1494e) {
            C0588b callback = this.f1490a.m2509g();
            if (this.f1495f > 0 && (callback instanceof C0597e)) {
                final long currentCopy = this.f1493d;
                final long maxProgressCopy = this.f1495f;
                final C0597e callbackCopy = (C0597e) callback;
                if (this.f1491b == null) {
                    callbackCopy.m2446a(currentCopy, maxProgressCopy);
                } else {
                    this.f1491b.post(new Runnable(this) {
                        final /* synthetic */ C0789v f1489d;

                        public void run() {
                            callbackCopy.m2446a(currentCopy, maxProgressCopy);
                        }
                    });
                }
                this.f1494e = this.f1493d;
            }
        }
    }
}
