package com.facebook;

import android.content.SharedPreferences;
import com.facebook.p014b.C0700r;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: ProfileCache */
final class C0758p {
    private final SharedPreferences f1435a = C0717g.m2880f().getSharedPreferences("com.facebook.AccessTokenManager.SharedPreferences", 0);

    C0758p() {
    }

    Profile m3108a() {
        String jsonString = this.f1435a.getString("com.facebook.ProfileManager.CachedProfile", null);
        if (jsonString != null) {
            try {
                return new Profile(new JSONObject(jsonString));
            } catch (JSONException e) {
            }
        }
        return null;
    }

    void m3109a(Profile profile) {
        C0700r.m2830a((Object) profile, "profile");
        JSONObject jsonObject = profile.m2524c();
        if (jsonObject != null) {
            this.f1435a.edit().putString("com.facebook.ProfileManager.CachedProfile", jsonObject.toString()).apply();
        }
    }

    void m3110b() {
        this.f1435a.edit().remove("com.facebook.ProfileManager.CachedProfile").apply();
    }
}
