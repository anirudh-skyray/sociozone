package com.facebook;

/* compiled from: R */
public final class C0787t {

    /* compiled from: R */
    public static final class C0782a {
        public static final int com_facebook_auth_dialog_background = 2130837580;
        public static final int com_facebook_auth_dialog_cancel_background = 2130837581;
        public static final int com_facebook_auth_dialog_header_background = 2130837582;
        public static final int com_facebook_button_background = 2130837583;
        public static final int com_facebook_button_icon = 2130837584;
        public static final int com_facebook_button_icon_blue = 2130837585;
        public static final int com_facebook_button_icon_white = 2130837586;
        public static final int com_facebook_button_like_background = 2130837587;
        public static final int com_facebook_button_like_icon_selected = 2130837588;
        public static final int com_facebook_button_login_silver_background = 2130837589;
        public static final int com_facebook_button_send_background = 2130837590;
        public static final int com_facebook_button_send_icon_blue = 2130837591;
        public static final int com_facebook_button_send_icon_white = 2130837592;
        public static final int com_facebook_close = 2130837593;
        public static final int com_facebook_favicon_white = 2130837594;
        public static final int com_facebook_profile_picture_blank_portrait = 2130837595;
        public static final int com_facebook_profile_picture_blank_square = 2130837596;
        public static final int com_facebook_send_button_icon = 2130837597;
        public static final int com_facebook_tooltip_black_background = 2130837598;
        public static final int com_facebook_tooltip_black_bottomnub = 2130837599;
        public static final int com_facebook_tooltip_black_topnub = 2130837600;
        public static final int com_facebook_tooltip_black_xout = 2130837601;
        public static final int com_facebook_tooltip_blue_background = 2130837602;
        public static final int com_facebook_tooltip_blue_bottomnub = 2130837603;
        public static final int com_facebook_tooltip_blue_topnub = 2130837604;
        public static final int com_facebook_tooltip_blue_xout = 2130837605;
        public static final int messenger_bubble_large_blue = 2130837662;
        public static final int messenger_bubble_large_white = 2130837663;
        public static final int messenger_bubble_small_blue = 2130837664;
        public static final int messenger_bubble_small_white = 2130837665;
        public static final int messenger_button_blue_bg_round = 2130837666;
        public static final int messenger_button_blue_bg_selector = 2130837667;
        public static final int messenger_button_send_round_shadow = 2130837668;
        public static final int messenger_button_white_bg_round = 2130837669;
        public static final int messenger_button_white_bg_selector = 2130837670;
    }

    /* compiled from: R */
    public static final class C0783b {
        public static final int automatic = 2131558457;
        public static final int bottom = 2131558451;
        public static final int box_count = 2131558449;
        public static final int button = 2131558450;
        public static final int cancel_button = 2131558529;
        public static final int center = 2131558454;
        public static final int com_facebook_body_frame = 2131558531;
        public static final int com_facebook_button_xout = 2131558533;
        public static final int com_facebook_device_auth_instructions = 2131558528;
        public static final int com_facebook_fragment_container = 2131558525;
        public static final int com_facebook_login_activity_progress_bar = 2131558530;
        public static final int com_facebook_tooltip_bubble_view_bottom_pointer = 2131558535;
        public static final int com_facebook_tooltip_bubble_view_text_body = 2131558534;
        public static final int com_facebook_tooltip_bubble_view_top_pointer = 2131558532;
        public static final int confirmation_code = 2131558526;
        public static final int display_always = 2131558458;
        public static final int inline = 2131558452;
        public static final int large = 2131558460;
        public static final int left = 2131558455;
        public static final int messenger_send_button = 2131558539;
        public static final int never_display = 2131558459;
        public static final int normal = 2131558410;
        public static final int open_graph = 2131558446;
        public static final int page = 2131558447;
        public static final int progress_bar = 2131558527;
        public static final int right = 2131558456;
        public static final int small = 2131558461;
        public static final int standard = 2131558441;
        public static final int top = 2131558453;
        public static final int unknown = 2131558448;
    }

    /* compiled from: R */
    public static final class C0784c {
        public static final int com_facebook_activity_layout = 2130903068;
        public static final int com_facebook_device_auth_dialog_fragment = 2130903069;
        public static final int com_facebook_login_fragment = 2130903070;
        public static final int com_facebook_tooltip_bubble = 2130903071;
        public static final int messenger_button_send_blue_large = 2130903081;
        public static final int messenger_button_send_blue_round = 2130903082;
        public static final int messenger_button_send_blue_small = 2130903083;
        public static final int messenger_button_send_white_large = 2130903084;
        public static final int messenger_button_send_white_round = 2130903085;
        public static final int messenger_button_send_white_small = 2130903086;
    }

    /* compiled from: R */
    public static final class C0785d {
        public static final int com_facebook_device_auth_instructions = 2131165203;
        public static final int com_facebook_image_download_unknown_error = 2131165204;
        public static final int com_facebook_internet_permission_error_message = 2131165205;
        public static final int com_facebook_internet_permission_error_title = 2131165206;
        public static final int com_facebook_like_button_liked = 2131165207;
        public static final int com_facebook_like_button_not_liked = 2131165208;
        public static final int com_facebook_loading = 2131165209;
        public static final int com_facebook_loginview_cancel_action = 2131165210;
        public static final int com_facebook_loginview_log_in_button = 2131165211;
        public static final int com_facebook_loginview_log_in_button_long = 2131165212;
        public static final int com_facebook_loginview_log_out_action = 2131165213;
        public static final int com_facebook_loginview_log_out_button = 2131165214;
        public static final int com_facebook_loginview_logged_in_as = 2131165215;
        public static final int com_facebook_loginview_logged_in_using_facebook = 2131165216;
        public static final int com_facebook_send_button_text = 2131165217;
        public static final int com_facebook_share_button_text = 2131165218;
        public static final int com_facebook_tooltip_default = 2131165219;
        public static final int messenger_send_button_text = 2131165251;
    }

    /* compiled from: R */
    public static final class C0786e {
        public static final int Base_CardView = 2131361936;
        public static final int CardView = 2131361927;
        public static final int CardView_Dark = 2131361977;
        public static final int CardView_Light = 2131361978;
        public static final int MessengerButton = 2131361984;
        public static final int MessengerButtonText = 2131361991;
        public static final int MessengerButtonText_Blue = 2131361992;
        public static final int MessengerButtonText_Blue_Large = 2131361993;
        public static final int MessengerButtonText_Blue_Small = 2131361994;
        public static final int MessengerButtonText_White = 2131361995;
        public static final int MessengerButtonText_White_Large = 2131361996;
        public static final int MessengerButtonText_White_Small = 2131361997;
        public static final int MessengerButton_Blue = 2131361985;
        public static final int MessengerButton_Blue_Large = 2131361986;
        public static final int MessengerButton_Blue_Small = 2131361987;
        public static final int MessengerButton_White = 2131361988;
        public static final int MessengerButton_White_Large = 2131361989;
        public static final int MessengerButton_White_Small = 2131361990;
        public static final int com_facebook_auth_dialog = 2131362137;
        public static final int com_facebook_button = 2131362138;
        public static final int com_facebook_button_like = 2131362139;
        public static final int com_facebook_button_send = 2131362140;
        public static final int com_facebook_button_share = 2131362141;
        public static final int com_facebook_loginview_default_style = 2131362142;
        public static final int com_facebook_loginview_silver_style = 2131362143;
        public static final int tooltip_bubble_text = 2131362144;
    }
}
