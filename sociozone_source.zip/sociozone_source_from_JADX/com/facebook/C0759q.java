package com.facebook;

import android.content.Intent;
import android.support.v4.content.C0214h;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0700r;

/* compiled from: ProfileManager */
final class C0759q {
    private static volatile C0759q f1436a;
    private final C0214h f1437b;
    private final C0758p f1438c;
    private Profile f1439d;

    C0759q(C0214h localBroadcastManager, C0758p profileCache) {
        C0700r.m2830a((Object) localBroadcastManager, "localBroadcastManager");
        C0700r.m2830a((Object) profileCache, "profileCache");
        this.f1437b = localBroadcastManager;
        this.f1438c = profileCache;
    }

    static C0759q m3111a() {
        if (f1436a == null) {
            synchronized (C0759q.class) {
                if (f1436a == null) {
                    f1436a = new C0759q(C0214h.m783a(C0717g.m2880f()), new C0758p());
                }
            }
        }
        return f1436a;
    }

    Profile m3115b() {
        return this.f1439d;
    }

    boolean m3116c() {
        Profile profile = this.f1438c.m3108a();
        if (profile == null) {
            return false;
        }
        m3113a(profile, false);
        return true;
    }

    void m3114a(Profile currentProfile) {
        m3113a(currentProfile, true);
    }

    private void m3113a(Profile currentProfile, boolean writeToCache) {
        Profile oldProfile = this.f1439d;
        this.f1439d = currentProfile;
        if (writeToCache) {
            if (currentProfile != null) {
                this.f1438c.m3109a(currentProfile);
            } else {
                this.f1438c.m3110b();
            }
        }
        if (!C0699q.m2806a((Object) oldProfile, (Object) currentProfile)) {
            m3112a(oldProfile, currentProfile);
        }
    }

    private void m3112a(Profile oldProfile, Profile currentProfile) {
        Intent intent = new Intent("com.facebook.sdk.ACTION_CURRENT_PROFILE_CHANGED");
        intent.putExtra("com.facebook.sdk.EXTRA_OLD_PROFILE", oldProfile);
        intent.putExtra("com.facebook.sdk.EXTRA_NEW_PROFILE", currentProfile);
        this.f1437b.m788a(intent);
    }
}
