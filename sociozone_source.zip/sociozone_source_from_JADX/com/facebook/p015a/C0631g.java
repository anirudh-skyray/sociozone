package com.facebook.p015a;

import android.os.Bundle;
import com.facebook.C0757o;
import com.facebook.p014b.C0680l;
import java.io.Serializable;
import java.util.Locale;

/* compiled from: FacebookTimeSpentData */
class C0631g implements Serializable {
    private static final String f1087a = C0631g.class.getCanonicalName();
    private static final long[] f1088b = new long[]{300000, 900000, 1800000, 3600000, 21600000, 43200000, 86400000, 172800000, 259200000, 604800000, 1209600000, 1814400000, 2419200000L, 5184000000L, 7776000000L, 10368000000L, 12960000000L, 15552000000L, 31536000000L};
    private boolean f1089c;
    private boolean f1090d;
    private long f1091e;
    private long f1092f;
    private long f1093g;
    private long f1094h;
    private int f1095i;
    private String f1096j;

    /* compiled from: FacebookTimeSpentData */
    private static class C0630a implements Serializable {
        private final long f1082a;
        private final long f1083b;
        private final long f1084c;
        private final int f1085d;
        private final String f1086e;

        C0630a(long lastResumeTime, long lastSuspendTime, long millisecondsSpentInSession, int interruptionCount, String firstOpenSourceApplication) {
            this.f1082a = lastResumeTime;
            this.f1083b = lastSuspendTime;
            this.f1084c = millisecondsSpentInSession;
            this.f1085d = interruptionCount;
            this.f1086e = firstOpenSourceApplication;
        }

        private Object readResolve() {
            return new C0631g(this.f1082a, this.f1083b, this.f1084c, this.f1085d, this.f1086e);
        }
    }

    C0631g() {
        m2597a();
    }

    private C0631g(long lastResumeTime, long lastSuspendTime, long millisecondsSpentInSession, int interruptionCount, String firstOpenSourceApplication) {
        m2597a();
        this.f1092f = lastResumeTime;
        this.f1093g = lastSuspendTime;
        this.f1094h = millisecondsSpentInSession;
        this.f1095i = interruptionCount;
        this.f1096j = firstOpenSourceApplication;
    }

    private Object writeReplace() {
        return new C0630a(this.f1092f, this.f1093g, this.f1094h, this.f1095i, this.f1096j);
    }

    void m2601a(C0628f logger, long eventTime) {
        if (this.f1090d) {
            long now = eventTime;
            long delta = now - this.f1092f;
            if (delta < 0) {
                C0680l.m2695a(C0757o.APP_EVENTS, f1087a, "Clock skew detected");
                delta = 0;
            }
            this.f1094h += delta;
            this.f1093g = now;
            this.f1090d = false;
            return;
        }
        C0680l.m2695a(C0757o.APP_EVENTS, f1087a, "Suspend for inactive app");
    }

    void m2602a(C0628f logger, long eventTime, String sourceApplicationInfo) {
        long now = eventTime;
        if (m2600c() || now - this.f1091e > 300000) {
            Bundle eventParams = new Bundle();
            eventParams.putString("fb_mobile_launch_source", sourceApplicationInfo);
            logger.m2593a("fb_mobile_activate_app", eventParams);
            this.f1091e = now;
        }
        if (this.f1090d) {
            C0680l.m2695a(C0757o.APP_EVENTS, f1087a, "Resume for active app");
            return;
        }
        long interruptionDurationMillis = m2599b() ? now - this.f1093g : 0;
        if (interruptionDurationMillis < 0) {
            C0680l.m2695a(C0757o.APP_EVENTS, f1087a, "Clock skew detected");
            interruptionDurationMillis = 0;
        }
        if (interruptionDurationMillis > 60000) {
            m2598b(logger, interruptionDurationMillis);
        } else if (interruptionDurationMillis > 1000) {
            this.f1095i++;
        }
        if (this.f1095i == 0) {
            this.f1096j = sourceApplicationInfo;
        }
        this.f1092f = now;
        this.f1090d = true;
    }

    private void m2598b(C0628f logger, long interruptionDurationMillis) {
        Bundle eventParams = new Bundle();
        eventParams.putInt("fb_mobile_app_interruptions", this.f1095i);
        eventParams.putString("fb_mobile_time_between_sessions", String.format(Locale.ROOT, "session_quanta_%d", new Object[]{Integer.valueOf(C0631g.m2596a(interruptionDurationMillis))}));
        eventParams.putString("fb_mobile_launch_source", this.f1096j);
        logger.m2592a("fb_mobile_deactivate_app", (double) (this.f1094h / 1000), eventParams);
        m2597a();
    }

    private static int m2596a(long timeBetweenSessions) {
        int quantaIndex = 0;
        while (quantaIndex < f1088b.length && f1088b[quantaIndex] < timeBetweenSessions) {
            quantaIndex++;
        }
        return quantaIndex;
    }

    private void m2597a() {
        this.f1090d = false;
        this.f1092f = -1;
        this.f1093g = -1;
        this.f1095i = 0;
        this.f1094h = 0;
    }

    private boolean m2599b() {
        return this.f1093g != -1;
    }

    private boolean m2600c() {
        boolean result = !this.f1089c;
        this.f1089c = true;
        return result;
    }
}
