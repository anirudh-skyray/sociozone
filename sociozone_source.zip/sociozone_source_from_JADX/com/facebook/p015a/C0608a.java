package com.facebook.p015a;

import com.facebook.AccessToken;
import com.facebook.C0717g;
import com.facebook.p014b.C0699q;
import java.io.Serializable;

/* compiled from: AccessTokenAppIdPair */
class C0608a implements Serializable {
    private final String f1030a;
    private final String f1031b;

    /* compiled from: AccessTokenAppIdPair */
    static class C0604a implements Serializable {
        private final String f1022a;
        private final String f1023b;

        private C0604a(String accessTokenString, String appId) {
            this.f1022a = accessTokenString;
            this.f1023b = appId;
        }

        private Object readResolve() {
            return new C0608a(this.f1022a, this.f1023b);
        }
    }

    public C0608a(AccessToken accessToken) {
        this(accessToken.m2410b(), C0717g.m2883i());
    }

    public C0608a(String accessTokenString, String applicationId) {
        if (C0699q.m2807a(accessTokenString)) {
            accessTokenString = null;
        }
        this.f1030a = accessTokenString;
        this.f1031b = applicationId;
    }

    public String m2530a() {
        return this.f1030a;
    }

    public String m2531b() {
        return this.f1031b;
    }

    public int hashCode() {
        int i = 0;
        int hashCode = this.f1030a == null ? 0 : this.f1030a.hashCode();
        if (this.f1031b != null) {
            i = this.f1031b.hashCode();
        }
        return hashCode ^ i;
    }

    public boolean equals(Object o) {
        if (!(o instanceof C0608a)) {
            return false;
        }
        C0608a p = (C0608a) o;
        if (C0699q.m2806a(p.f1030a, this.f1030a) && C0699q.m2806a(p.f1031b, this.f1031b)) {
            return true;
        }
        return false;
    }

    private Object writeReplace() {
        return new C0604a(this.f1030a, this.f1031b);
    }
}
