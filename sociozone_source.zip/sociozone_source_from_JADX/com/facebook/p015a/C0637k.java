package com.facebook.p015a;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

/* compiled from: PersistedEvents */
class C0637k implements Serializable {
    private HashMap<C0608a, List<C0612b>> f1112a = new HashMap();

    /* compiled from: PersistedEvents */
    static class C0636a implements Serializable {
        private final HashMap<C0608a, List<C0612b>> f1111a;

        private C0636a(HashMap<C0608a, List<C0612b>> events) {
            this.f1111a = events;
        }

        private Object readResolve() {
            return new C0637k(this.f1111a);
        }
    }

    public C0637k(HashMap<C0608a, List<C0612b>> appEventMap) {
        this.f1112a.putAll(appEventMap);
    }

    public Set<C0608a> m2604a() {
        return this.f1112a.keySet();
    }

    public List<C0612b> m2603a(C0608a accessTokenAppIdPair) {
        return (List) this.f1112a.get(accessTokenAppIdPair);
    }

    public boolean m2606b(C0608a accessTokenAppIdPair) {
        return this.f1112a.containsKey(accessTokenAppIdPair);
    }

    public void m2605a(C0608a accessTokenAppIdPair, List<C0612b> appEvents) {
        if (this.f1112a.containsKey(accessTokenAppIdPair)) {
            ((List) this.f1112a.get(accessTokenAppIdPair)).addAll(appEvents);
        } else {
            this.f1112a.put(accessTokenAppIdPair, appEvents);
        }
    }

    private Object writeReplace() {
        return new C0636a(this.f1112a);
    }
}
