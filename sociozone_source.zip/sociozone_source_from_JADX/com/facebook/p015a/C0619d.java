package com.facebook.p015a;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.C0214h;
import android.util.Log;
import com.facebook.C0717g;
import com.facebook.C0723l;
import com.facebook.C0757o;
import com.facebook.FacebookRequestError;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0588b;
import com.facebook.p014b.C0680l;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0699q.C0697b;
import com.facebook.p015a.C0628f.C0625a;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import org.json.JSONArray;
import org.json.JSONException;

/* compiled from: AppEventQueue */
class C0619d {
    private static final String f1052a = C0619d.class.getName();
    private static volatile C0613c f1053b = new C0613c();
    private static final ScheduledExecutorService f1054c = Executors.newSingleThreadScheduledExecutor();
    private static ScheduledFuture f1055d;
    private static final Runnable f1056e = new C06141();

    /* compiled from: AppEventQueue */
    static class C06141 implements Runnable {
        C06141() {
        }

        public void run() {
            C0619d.f1055d = null;
            if (C0628f.m2571a() != C0625a.EXPLICIT_ONLY) {
                C0619d.m2557b(C0632h.TIMER);
            }
        }
    }

    C0619d() {
    }

    public static void m2554a(final C0632h reason) {
        f1054c.execute(new Runnable() {
            public void run() {
                C0619d.m2557b(reason);
            }
        });
    }

    public static void m2553a(final C0608a accessTokenAppId, final C0612b appEvent) {
        f1054c.execute(new Runnable() {
            public void run() {
                C0619d.f1053b.m2544a(accessTokenAppId, appEvent);
                if (C0628f.m2571a() != C0625a.EXPLICIT_ONLY && C0619d.f1053b.m2546b() > 100) {
                    C0619d.m2557b(C0632h.EVENT_THRESHOLD);
                } else if (C0619d.f1055d == null) {
                    C0619d.f1055d = C0619d.f1054c.schedule(C0619d.f1056e, 15, TimeUnit.SECONDS);
                }
            }
        });
    }

    public static Set<C0608a> m2550a() {
        return f1053b.m2543a();
    }

    static void m2557b(C0632h reason) {
        f1053b.m2545a(C0621e.m2561a());
        try {
            C0634j flushResults = C0619d.m2549a(reason, f1053b);
            if (flushResults != null) {
                Intent intent = new Intent("com.facebook.sdk.APP_EVENTS_FLUSHED");
                intent.putExtra("com.facebook.sdk.APP_EVENTS_NUM_EVENTS_FLUSHED", flushResults.f1109a);
                intent.putExtra("com.facebook.sdk.APP_EVENTS_FLUSH_RESULT", flushResults.f1110b);
                C0214h.m783a(C0717g.m2880f()).m788a(intent);
            }
        } catch (Exception e) {
            Log.w(f1052a, "Caught unexpected exception while flushing app events: ", e);
        }
    }

    private static C0634j m2549a(C0632h reason, C0613c appEventCollection) {
        C0634j flushResults = new C0634j();
        boolean limitEventUsage = C0717g.m2875b(C0717g.m2880f());
        List<GraphRequest> requestsToExecute = new ArrayList();
        for (C0608a accessTokenAppId : appEventCollection.m2543a()) {
            GraphRequest request = C0619d.m2548a(accessTokenAppId, appEventCollection.m2542a(accessTokenAppId), limitEventUsage, flushResults);
            if (request != null) {
                requestsToExecute.add(request);
            }
        }
        if (requestsToExecute.size() <= 0) {
            return null;
        }
        C0680l.m2696a(C0757o.APP_EVENTS, f1052a, "Flushing %d events due to %s.", Integer.valueOf(flushResults.f1109a), reason.toString());
        for (GraphRequest request2 : requestsToExecute) {
            request2.m2511i();
        }
        return flushResults;
    }

    private static GraphRequest m2548a(final C0608a accessTokenAppId, final C0638l appEvents, boolean limitEventUsage, final C0634j flushState) {
        C0697b fetchedAppSettings = C0699q.m2776a(accessTokenAppId.m2531b(), false);
        final GraphRequest postRequest = GraphRequest.m2460a(null, String.format("%s/activities", new Object[]{applicationId}), null, null);
        Bundle requestParameters = postRequest.m2507e();
        if (requestParameters == null) {
            requestParameters = new Bundle();
        }
        requestParameters.putString("access_token", accessTokenAppId.m2530a());
        String pushNotificationsRegistrationId = C0628f.m2585c();
        if (pushNotificationsRegistrationId != null) {
            requestParameters.putString("device_token", pushNotificationsRegistrationId);
        }
        postRequest.m2498a(requestParameters);
        if (fetchedAppSettings == null) {
            return null;
        }
        int numEvents = appEvents.m2610a(postRequest, C0717g.m2880f(), fetchedAppSettings.m2766a(), limitEventUsage);
        if (numEvents == 0) {
            return null;
        }
        flushState.f1109a += numEvents;
        postRequest.m2499a(new C0588b() {
            public void mo855a(C0723l response) {
                C0619d.m2556b(accessTokenAppId, postRequest, response, appEvents, flushState);
            }
        });
        return postRequest;
    }

    private static void m2556b(final C0608a accessTokenAppId, GraphRequest request, C0723l response, C0638l appEvents, C0634j flushState) {
        FacebookRequestError error = response.m2915a();
        String resultDescription = "Success";
        C0633i flushResult = C0633i.SUCCESS;
        if (error != null) {
            if (error.m2429b() == -1) {
                resultDescription = "Failed: No Connectivity";
                flushResult = C0633i.NO_CONNECTIVITY;
            } else {
                resultDescription = String.format("Failed:\n  Response: %s\n  Error %s", new Object[]{response.toString(), error.toString()});
                flushResult = C0633i.SERVER_ERROR;
            }
        }
        if (C0717g.m2872a(C0757o.APP_EVENTS)) {
            String prettyPrintedEvents;
            try {
                prettyPrintedEvents = new JSONArray((String) request.m2510h()).toString(2);
            } catch (JSONException e) {
                prettyPrintedEvents = "<Can't encode events for debug logging>";
            }
            C0680l.m2696a(C0757o.APP_EVENTS, f1052a, "Flush completed\nParams: %s\n  Result: %s\n  Events JSON: %s", request.m2497a().toString(), resultDescription, prettyPrintedEvents);
        }
        appEvents.m2612a(error != null);
        if (flushResult == C0633i.NO_CONNECTIVITY) {
            final C0638l c0638l = appEvents;
            C0717g.m2878d().execute(new Runnable() {
                public void run() {
                    C0621e.m2562a(accessTokenAppId, c0638l);
                }
            });
        }
        if (flushResult != C0633i.SUCCESS && flushState.f1110b != C0633i.NO_CONNECTIVITY) {
            flushState.f1110b = flushResult;
        }
    }
}
