package com.facebook.p015a;

import android.os.Bundle;
import com.facebook.C0709e;
import com.facebook.C0757o;
import com.facebook.p014b.C0680l;
import com.facebook.p014b.C0699q;
import java.io.Serializable;
import java.security.MessageDigest;
import java.util.HashSet;
import java.util.Locale;
import java.util.UUID;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: AppEvent */
class C0612b implements Serializable {
    private static final HashSet<String> f1037a = new HashSet();
    private final JSONObject f1038b;
    private final boolean f1039c;
    private final String f1040d;
    private final String f1041e;

    /* compiled from: AppEvent */
    static class C0610a implements Serializable {
        private final String f1032a;
        private final boolean f1033b;

        private Object readResolve() throws JSONException {
            return new C0612b(this.f1032a, this.f1033b, null);
        }
    }

    /* compiled from: AppEvent */
    static class C0611b implements Serializable {
        private final String f1034a;
        private final boolean f1035b;
        private final String f1036c;

        private C0611b(String jsonString, boolean isImplicit, String checksum) {
            this.f1034a = jsonString;
            this.f1035b = isImplicit;
            this.f1036c = checksum;
        }

        private Object readResolve() throws JSONException {
            return new C0612b(this.f1034a, this.f1035b, this.f1036c);
        }
    }

    public C0612b(String contextName, String eventName, Double valueToSum, Bundle parameters, boolean isImplicitlyLogged, UUID currentSessionId) throws JSONException, C0709e {
        this.f1038b = C0612b.m2533a(contextName, eventName, valueToSum, parameters, isImplicitlyLogged, currentSessionId);
        this.f1039c = isImplicitlyLogged;
        this.f1040d = eventName;
        this.f1041e = m2536e();
    }

    public String m2537a() {
        return this.f1040d;
    }

    private C0612b(String jsonString, boolean isImplicit, String checksum) throws JSONException {
        this.f1038b = new JSONObject(jsonString);
        this.f1039c = isImplicit;
        this.f1040d = this.f1038b.optString("_eventName");
        this.f1041e = checksum;
    }

    public boolean m2538b() {
        return this.f1039c;
    }

    public JSONObject m2539c() {
        return this.f1038b;
    }

    public boolean m2540d() {
        if (this.f1041e == null) {
            return true;
        }
        return m2536e().equals(this.f1041e);
    }

    private static void m2534a(String identifier) throws C0709e {
        String regex = "^[0-9a-zA-Z_]+[0-9a-zA-Z _-]*$";
        if (identifier == null || identifier.length() == 0 || identifier.length() > 40) {
            if (identifier == null) {
                identifier = "<None Provided>";
            }
            throw new C0709e(String.format(Locale.ROOT, "Identifier '%s' must be less than %d characters", new Object[]{identifier, Integer.valueOf(40)}));
        }
        synchronized (f1037a) {
            boolean alreadyValidated = f1037a.contains(identifier);
        }
        if (!alreadyValidated) {
            if (identifier.matches("^[0-9a-zA-Z_]+[0-9a-zA-Z _-]*$")) {
                synchronized (f1037a) {
                    f1037a.add(identifier);
                }
                return;
            }
            throw new C0709e(String.format("Skipping event named '%s' due to illegal name - must be under 40 chars and alphanumeric, _, - or space, and not start with a space or hyphen.", new Object[]{identifier}));
        }
    }

    private static JSONObject m2533a(String contextName, String eventName, Double valueToSum, Bundle parameters, boolean isImplicitlyLogged, UUID currentSessionId) throws C0709e, JSONException {
        C0612b.m2534a(eventName);
        JSONObject eventObject = new JSONObject();
        eventObject.put("_eventName", eventName);
        eventObject.put("_logTime", System.currentTimeMillis() / 1000);
        eventObject.put("_ui", contextName);
        if (currentSessionId != null) {
            eventObject.put("_session_id", currentSessionId);
        }
        if (valueToSum != null) {
            eventObject.put("_valueToSum", valueToSum.doubleValue());
        }
        if (isImplicitlyLogged) {
            eventObject.put("_implicitlyLogged", "1");
        }
        if (parameters != null) {
            for (String key : parameters.keySet()) {
                C0612b.m2534a(key);
                Object value = parameters.get(key);
                if ((value instanceof String) || (value instanceof Number)) {
                    eventObject.put(key, value.toString());
                } else {
                    throw new C0709e(String.format("Parameter value '%s' for key '%s' should be a string or a numeric type.", new Object[]{value, key}));
                }
            }
        }
        if (!isImplicitlyLogged) {
            C0680l.m2696a(C0757o.APP_EVENTS, "AppEvents", "Created app event '%s'", eventObject.toString());
        }
        return eventObject;
    }

    private Object writeReplace() {
        return new C0611b(this.f1038b.toString(), this.f1039c, this.f1041e);
    }

    public String toString() {
        return String.format("\"%s\", implicit: %b, json: %s", new Object[]{this.f1038b.optString("_eventName"), Boolean.valueOf(this.f1039c), this.f1038b.toString()});
    }

    private String m2536e() {
        return C0612b.m2535b(this.f1038b.toString());
    }

    private static String m2535b(String toHash) {
        try {
            MessageDigest digest = MessageDigest.getInstance("MD5");
            byte[] bytes = toHash.getBytes("UTF-8");
            digest.update(bytes, 0, bytes.length);
            return C0612b.m2532a(digest.digest());
        } catch (Exception e) {
            C0699q.m2799a("Failed to generate checksum: ", e);
            return "0";
        } catch (Exception e2) {
            C0699q.m2799a("Failed to generate checksum: ", e2);
            return "1";
        }
    }

    private static String m2532a(byte[] bytes) {
        StringBuffer sb = new StringBuffer();
        int length = bytes.length;
        for (int i = 0; i < length; i++) {
            sb.append(String.format("%02x", new Object[]{Byte.valueOf(bytes[i])}));
        }
        return sb.toString();
    }
}
