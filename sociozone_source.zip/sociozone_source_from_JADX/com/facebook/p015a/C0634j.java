package com.facebook.p015a;

/* compiled from: FlushStatistics */
class C0634j {
    public int f1109a = 0;
    public C0633i f1110b = C0633i.SUCCESS;

    C0634j() {
    }
}
