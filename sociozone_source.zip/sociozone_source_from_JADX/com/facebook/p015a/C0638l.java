package com.facebook.p015a;

import android.content.Context;
import android.os.Bundle;
import com.facebook.GraphRequest;
import com.facebook.p014b.C0648a;
import com.facebook.p014b.C0648a.C0647a;
import com.facebook.p014b.C0652b;
import com.facebook.p014b.C0699q;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: SessionEventsState */
class C0638l {
    private List<C0612b> f1113a = new ArrayList();
    private List<C0612b> f1114b = new ArrayList();
    private int f1115c;
    private C0652b f1116d;
    private String f1117e;
    private final int f1118f = 1000;

    public C0638l(C0652b identifiers, String anonymousGUID) {
        this.f1116d = identifiers;
        this.f1117e = anonymousGUID;
    }

    public synchronized void m2611a(C0612b event) {
        if (this.f1113a.size() + this.f1114b.size() >= 1000) {
            this.f1115c++;
        } else {
            this.f1113a.add(event);
        }
    }

    public synchronized int m2609a() {
        return this.f1113a.size();
    }

    public synchronized void m2612a(boolean moveToAccumulated) {
        if (moveToAccumulated) {
            this.f1113a.addAll(this.f1114b);
        }
        this.f1114b.clear();
        this.f1115c = 0;
    }

    public int m2610a(GraphRequest request, Context applicationContext, boolean includeImplicitEvents, boolean limitEventUsage) {
        synchronized (this) {
            int numSkipped = this.f1115c;
            this.f1114b.addAll(this.f1113a);
            this.f1113a.clear();
            JSONArray jsonArray = new JSONArray();
            for (C0612b event : this.f1114b) {
                if (!event.m2540d()) {
                    C0699q.m2800a("Event with invalid checksum: %s", event.toString());
                } else if (includeImplicitEvents || !event.m2538b()) {
                    jsonArray.put(event.m2539c());
                }
            }
            if (jsonArray.length() == 0) {
                return 0;
            }
            m2607a(request, applicationContext, numSkipped, jsonArray, limitEventUsage);
            return jsonArray.length();
        }
    }

    public synchronized List<C0612b> m2613b() {
        List<C0612b> result;
        result = this.f1113a;
        this.f1113a = new ArrayList();
        return result;
    }

    private void m2607a(GraphRequest request, Context applicationContext, int numSkipped, JSONArray events, boolean limitEventUsage) {
        JSONObject publishParams;
        try {
            publishParams = C0648a.m2626a(C0647a.CUSTOM_APP_EVENTS, this.f1116d, this.f1117e, limitEventUsage, applicationContext);
            if (this.f1115c > 0) {
                publishParams.put("num_skipped_events", numSkipped);
            }
        } catch (JSONException e) {
            publishParams = new JSONObject();
        }
        request.m2502a(publishParams);
        Bundle requestParameters = request.m2507e();
        if (requestParameters == null) {
            requestParameters = new Bundle();
        }
        Object jsonString = events.toString();
        if (jsonString != null) {
            requestParameters.putByteArray("custom_events_file", m2608a((String) jsonString));
            request.m2501a(jsonString);
        }
        request.m2498a(requestParameters);
    }

    private byte[] m2608a(String jsonString) {
        byte[] jsonUtf8 = null;
        try {
            jsonUtf8 = jsonString.getBytes("UTF-8");
        } catch (Exception e) {
            C0699q.m2799a("Encoding exception: ", e);
        }
        return jsonUtf8;
    }
}
