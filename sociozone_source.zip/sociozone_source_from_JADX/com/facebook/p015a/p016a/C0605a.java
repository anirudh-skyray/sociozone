package com.facebook.p015a.p016a;

import java.util.UUID;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: ActivityLifecycleTracker */
public class C0605a {
    private static final String f1024a = C0605a.class.getCanonicalName();
    private static final ScheduledExecutorService f1025b = Executors.newSingleThreadScheduledExecutor();
    private static AtomicInteger f1026c = new AtomicInteger(0);
    private static volatile C0607c f1027d;
    private static AtomicBoolean f1028e = new AtomicBoolean(false);

    public static boolean m2526a() {
        return f1028e.get();
    }

    public static UUID m2527b() {
        return f1027d != null ? f1027d.m2529a() : null;
    }
}
