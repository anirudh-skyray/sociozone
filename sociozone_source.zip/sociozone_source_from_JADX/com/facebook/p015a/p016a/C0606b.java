package com.facebook.p015a.p016a;

/* compiled from: Constants */
public class C0606b {
    public static int m2528a() {
        return 60;
    }
}
