package com.facebook.p015a.p016a;

import java.util.UUID;

/* compiled from: SessionInfo */
class C0607c {
    private UUID f1029a;

    public UUID m2529a() {
        return this.f1029a;
    }
}
