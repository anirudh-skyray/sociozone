package com.facebook.p015a;

/* compiled from: FlushResult */
public enum C0633i {
    SUCCESS,
    SERVER_ERROR,
    NO_CONNECTIVITY,
    UNKNOWN_ERROR
}
