package com.facebook.p015a;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import com.facebook.AccessToken;
import com.facebook.C0709e;
import com.facebook.C0717g;
import com.facebook.C0757o;
import com.facebook.p014b.C0680l;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0700r;
import com.facebook.p015a.p016a.C0605a;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.FileNotFoundException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.json.JSONException;
import p000a.C0000a;

/* compiled from: AppEventsLogger */
public class C0628f {
    private static final String f1071a = C0628f.class.getCanonicalName();
    private static ScheduledThreadPoolExecutor f1072d;
    private static C0625a f1073e = C0625a.AUTO;
    private static Object f1074f = new Object();
    private static String f1075g;
    private static String f1076h;
    private static boolean f1077i;
    private static boolean f1078j;
    private static String f1079k;
    private final String f1080b;
    private final C0608a f1081c;

    /* compiled from: AppEventsLogger */
    static class C06243 implements Runnable {
        C06243() {
        }

        public void run() {
            Set<String> applicationIds = new HashSet();
            for (C0608a accessTokenAppId : C0619d.m2550a()) {
                applicationIds.add(accessTokenAppId.m2531b());
            }
            for (String applicationId : applicationIds) {
                C0699q.m2776a(applicationId, true);
            }
        }
    }

    /* compiled from: AppEventsLogger */
    public enum C0625a {
        AUTO,
        EXPLICIT_ONLY
    }

    /* compiled from: AppEventsLogger */
    static class C0627b {
        private static final Object f1066a = new Object();
        private static boolean f1067b = false;
        private static boolean f1068c = false;
        private static Map<C0608a, C0631g> f1069d;
        private static final Runnable f1070e = new C06261();

        /* compiled from: AppEventsLogger */
        static class C06261 implements Runnable {
            C06261() {
            }

            public void run() {
                C0627b.m2567a(C0717g.m2880f());
            }
        }

        private static void m2570b(Context context) {
            Throwable th;
            Exception e;
            Closeable ois = null;
            synchronized (f1066a) {
                if (!f1068c) {
                    try {
                        Closeable ois2 = new ObjectInputStream(context.openFileInput("AppEventsLogger.persistedsessioninfo"));
                        try {
                            f1069d = (HashMap) ois2.readObject();
                            C0680l.m2695a(C0757o.APP_EVENTS, "AppEvents", "App session info loaded");
                            try {
                                C0699q.m2797a(ois2);
                                context.deleteFile("AppEventsLogger.persistedsessioninfo");
                                if (f1069d == null) {
                                    f1069d = new HashMap();
                                }
                                f1068c = true;
                                f1067b = false;
                                ois = ois2;
                            } catch (Throwable th2) {
                                th = th2;
                                ois = ois2;
                                throw th;
                            }
                        } catch (FileNotFoundException e2) {
                            ois = ois2;
                            C0699q.m2797a(ois);
                            context.deleteFile("AppEventsLogger.persistedsessioninfo");
                            if (f1069d == null) {
                                f1069d = new HashMap();
                            }
                            f1068c = true;
                            f1067b = false;
                        } catch (Exception e3) {
                            e = e3;
                            ois = ois2;
                            try {
                                Log.w(C0628f.f1071a, "Got unexpected exception restoring app session info: " + e.toString());
                                C0699q.m2797a(ois);
                                context.deleteFile("AppEventsLogger.persistedsessioninfo");
                                if (f1069d == null) {
                                    f1069d = new HashMap();
                                }
                                f1068c = true;
                                f1067b = false;
                            } catch (Throwable th3) {
                                th = th3;
                                C0699q.m2797a(ois);
                                context.deleteFile("AppEventsLogger.persistedsessioninfo");
                                if (f1069d == null) {
                                    f1069d = new HashMap();
                                }
                                f1068c = true;
                                f1067b = false;
                                throw th;
                            }
                        } catch (Throwable th4) {
                            th = th4;
                            ois = ois2;
                            C0699q.m2797a(ois);
                            context.deleteFile("AppEventsLogger.persistedsessioninfo");
                            if (f1069d == null) {
                                f1069d = new HashMap();
                            }
                            f1068c = true;
                            f1067b = false;
                            throw th;
                        }
                    } catch (FileNotFoundException e4) {
                        C0699q.m2797a(ois);
                        context.deleteFile("AppEventsLogger.persistedsessioninfo");
                        if (f1069d == null) {
                            f1069d = new HashMap();
                        }
                        f1068c = true;
                        f1067b = false;
                    } catch (Exception e5) {
                        e = e5;
                        Log.w(C0628f.f1071a, "Got unexpected exception restoring app session info: " + e.toString());
                        C0699q.m2797a(ois);
                        context.deleteFile("AppEventsLogger.persistedsessioninfo");
                        if (f1069d == null) {
                            f1069d = new HashMap();
                        }
                        f1068c = true;
                        f1067b = false;
                    } catch (Throwable th5) {
                        th = th5;
                        throw th;
                    }
                }
            }
        }

        static void m2567a(Context context) {
            Throwable th;
            Exception e;
            Closeable oos = null;
            synchronized (f1066a) {
                try {
                    if (f1067b) {
                        try {
                            Closeable oos2 = new ObjectOutputStream(new BufferedOutputStream(context.openFileOutput("AppEventsLogger.persistedsessioninfo", 0)));
                            try {
                                oos2.writeObject(f1069d);
                                f1067b = false;
                                C0680l.m2695a(C0757o.APP_EVENTS, "AppEvents", "App session info saved");
                                try {
                                    C0699q.m2797a(oos2);
                                    oos = oos2;
                                } catch (Throwable th2) {
                                    th = th2;
                                    oos = oos2;
                                    throw th;
                                }
                            } catch (Exception e2) {
                                e = e2;
                                oos = oos2;
                                try {
                                    Log.w(C0628f.f1071a, "Got unexpected exception while writing app session info: " + e.toString());
                                    C0699q.m2797a(oos);
                                } catch (Throwable th3) {
                                    th = th3;
                                    C0699q.m2797a(oos);
                                    throw th;
                                }
                            } catch (Throwable th4) {
                                th = th4;
                                oos = oos2;
                                C0699q.m2797a(oos);
                                throw th;
                            }
                        } catch (Exception e3) {
                            e = e3;
                            Log.w(C0628f.f1071a, "Got unexpected exception while writing app session info: " + e.toString());
                            C0699q.m2797a(oos);
                        }
                    }
                } catch (Throwable th5) {
                    th = th5;
                    throw th;
                }
            }
        }

        static void m2569a(Context context, C0608a accessTokenAppId, C0628f logger, long eventTime, String sourceApplicationInfo) {
            synchronized (f1066a) {
                C0627b.m2565a(context, accessTokenAppId).m2602a(logger, eventTime, sourceApplicationInfo);
                C0627b.m2566a();
            }
        }

        static void m2568a(Context context, C0608a accessTokenAppId, C0628f logger, long eventTime) {
            synchronized (f1066a) {
                C0627b.m2565a(context, accessTokenAppId).m2601a(logger, eventTime);
                C0627b.m2566a();
            }
        }

        private static C0631g m2565a(Context context, C0608a accessTokenAppId) {
            C0627b.m2570b(context);
            C0631g result = (C0631g) f1069d.get(accessTokenAppId);
            if (result != null) {
                return result;
            }
            result = new C0631g();
            f1069d.put(accessTokenAppId, result);
            return result;
        }

        private static void m2566a() {
            if (!f1067b) {
                f1067b = true;
                C0628f.f1072d.schedule(f1070e, 30, TimeUnit.SECONDS);
            }
        }
    }

    @Deprecated
    public static void m2575a(Context context) {
        if (C0605a.m2526a()) {
            Log.w(f1071a, "activateApp events are being logged automatically. There's no need to call activateApp explicitly, this is safe to remove.");
            return;
        }
        C0717g.m2868a(context);
        C0628f.m2577a(context, C0699q.m2781a(context));
    }

    @Deprecated
    public static void m2577a(Context context, String applicationId) {
        if (C0605a.m2526a()) {
            Log.w(f1071a, "activateApp events are being logged automatically. There's no need to call activateApp explicitly, this is safe to remove.");
        } else if (context == null || applicationId == null) {
            throw new IllegalArgumentException("Both context and applicationId must be non-null");
        } else {
            if (context instanceof Activity) {
                C0628f.m2574a((Activity) context);
            } else {
                C0628f.m2588e();
                Log.d(C0628f.class.getName(), "To set source application the context of activateApp must be an instance of Activity");
            }
            C0717g.m2870a(context, applicationId);
            final C0628f logger = new C0628f(context, applicationId, null);
            final long eventTime = System.currentTimeMillis();
            final String sourceApplicationInfo = C0628f.m2586d();
            f1072d.execute(new Runnable() {
                public void run() {
                    logger.m2573a(eventTime, sourceApplicationInfo);
                }
            });
        }
    }

    @Deprecated
    public static void m2581b(Context context) {
        if (C0605a.m2526a()) {
            Log.w(f1071a, "deactivateApp events are being logged automatically. There's no need to call deactivateApp, this is safe to remove.");
        } else {
            C0628f.m2582b(context, C0699q.m2781a(context));
        }
    }

    @Deprecated
    public static void m2582b(Context context, String applicationId) {
        if (C0605a.m2526a()) {
            Log.w(f1071a, "deactivateApp events are being logged automatically. There's no need to call deactivateApp, this is safe to remove.");
        } else if (context == null || applicationId == null) {
            throw new IllegalArgumentException("Both context and applicationId must be non-null");
        } else {
            C0628f.m2588e();
            final C0628f logger = new C0628f(context, applicationId, null);
            final long eventTime = System.currentTimeMillis();
            f1072d.execute(new Runnable() {
                public void run() {
                    logger.m2572a(eventTime);
                }
            });
        }
    }

    private void m2573a(long eventTime, String sourceApplicationInfo) {
        C0627b.m2569a(C0717g.m2880f(), this.f1081c, this, eventTime, sourceApplicationInfo);
    }

    private void m2572a(long eventTime) {
        C0627b.m2568a(C0717g.m2880f(), this.f1081c, this, eventTime);
    }

    public static C0628f m2583c(Context context) {
        return new C0628f(context, null, null);
    }

    public static C0628f m2584c(Context context, String applicationId) {
        return new C0628f(context, applicationId, null);
    }

    public static C0625a m2571a() {
        C0625a c0625a;
        synchronized (f1074f) {
            c0625a = f1073e;
        }
        return c0625a;
    }

    public void m2593a(String eventName, Bundle parameters) {
        m2580a(eventName, null, parameters, false, C0605a.m2527b());
    }

    public void m2592a(String eventName, double valueToSum, Bundle parameters) {
        m2580a(eventName, Double.valueOf(valueToSum), parameters, false, C0605a.m2527b());
    }

    public void m2595b() {
        C0619d.m2554a(C0632h.EXPLICIT);
    }

    static String m2585c() {
        String str;
        synchronized (f1074f) {
            str = f1079k;
        }
        return str;
    }

    public void m2594a(String eventName, Double valueToSum, Bundle parameters) {
        m2580a(eventName, valueToSum, parameters, true, C0605a.m2527b());
    }

    private C0628f(Context context, String applicationId, AccessToken accessToken) {
        this(C0699q.m2817c(context), applicationId, accessToken);
    }

    protected C0628f(String activityName, String applicationId, AccessToken accessToken) {
        C0700r.m2828a();
        this.f1080b = activityName;
        if (accessToken == null) {
            accessToken = AccessToken.m2403a();
        }
        if (accessToken == null || !(applicationId == null || applicationId.equals(accessToken.m2416h()))) {
            if (applicationId == null) {
                applicationId = C0699q.m2781a(C0717g.m2880f());
            }
            this.f1081c = new C0608a(null, applicationId);
        } else {
            this.f1081c = new C0608a(accessToken);
        }
        C0628f.m2591h();
    }

    private static void m2591h() {
        synchronized (f1074f) {
            if (f1072d != null) {
                return;
            }
            f1072d = new ScheduledThreadPoolExecutor(1);
            f1072d.scheduleAtFixedRate(new C06243(), 0, 86400, TimeUnit.SECONDS);
        }
    }

    private void m2580a(String eventName, Double valueToSum, Bundle parameters, boolean isImplicitlyLogged, UUID currentSessionId) {
        try {
            C0628f.m2576a(C0717g.m2880f(), new C0612b(this.f1080b, eventName, valueToSum, parameters, isImplicitlyLogged, currentSessionId), this.f1081c);
        } catch (JSONException jsonException) {
            C0680l.m2696a(C0757o.APP_EVENTS, "AppEvents", "JSON encoding for app event failed: '%s'", jsonException.toString());
        } catch (C0709e e) {
            C0680l.m2696a(C0757o.APP_EVENTS, "AppEvents", "Invalid app event: %s", e.toString());
        }
    }

    private static void m2576a(Context context, C0612b event, C0608a accessTokenAppId) {
        C0619d.m2553a(accessTokenAppId, event);
        if (!event.m2538b() && !f1078j) {
            if (event.m2537a() == "fb_mobile_activate_app") {
                f1078j = true;
            } else {
                C0680l.m2695a(C0757o.APP_EVENTS, "AppEvents", "Warning: Please call AppEventsLogger.activateApp(...)from the long-lived activity's onResume() methodbefore logging other app events.");
            }
        }
    }

    private static void m2574a(Activity activity) {
        ComponentName callingApplication = activity.getCallingActivity();
        if (callingApplication != null) {
            String callingApplicationPackage = callingApplication.getPackageName();
            if (callingApplicationPackage.equals(activity.getPackageName())) {
                C0628f.m2588e();
                return;
            }
            f1076h = callingApplicationPackage;
        }
        Intent openIntent = activity.getIntent();
        if (openIntent == null || openIntent.getBooleanExtra("_fbSourceApplicationHasBeenSet", false)) {
            C0628f.m2588e();
            return;
        }
        Bundle applinkData = C0000a.m0a(openIntent);
        if (applinkData == null) {
            C0628f.m2588e();
            return;
        }
        f1077i = true;
        Bundle applinkReferrerData = applinkData.getBundle("referer_app_link");
        if (applinkReferrerData == null) {
            f1076h = null;
            return;
        }
        f1076h = applinkReferrerData.getString("package");
        openIntent.putExtra("_fbSourceApplicationHasBeenSet", true);
    }

    static String m2586d() {
        String openType = "Unclassified";
        if (f1077i) {
            openType = "Applink";
        }
        if (f1076h != null) {
            return openType + "(" + f1076h + ")";
        }
        return openType;
    }

    static void m2588e() {
        f1076h = null;
        f1077i = false;
    }

    public static String m2587d(Context context) {
        if (f1075g == null) {
            synchronized (f1074f) {
                if (f1075g == null) {
                    f1075g = context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).getString("anonymousAppDeviceGUID", null);
                    if (f1075g == null) {
                        f1075g = "XZ" + UUID.randomUUID().toString();
                        context.getSharedPreferences("com.facebook.sdk.appEventPreferences", 0).edit().putString("anonymousAppDeviceGUID", f1075g).apply();
                    }
                }
            }
        }
        return f1075g;
    }
}
