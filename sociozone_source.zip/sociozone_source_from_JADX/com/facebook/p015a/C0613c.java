package com.facebook.p015a;

import android.content.Context;
import com.facebook.C0717g;
import com.facebook.p014b.C0652b;
import java.util.HashMap;
import java.util.Set;

/* compiled from: AppEventCollection */
class C0613c {
    private final HashMap<C0608a, C0638l> f1042a = new HashMap();

    public synchronized void m2545a(C0637k persistedEvents) {
        if (persistedEvents != null) {
            for (C0608a accessTokenAppIdPair : persistedEvents.m2604a()) {
                C0638l sessionEventsState = m2541b(accessTokenAppIdPair);
                for (C0612b appEvent : persistedEvents.m2603a(accessTokenAppIdPair)) {
                    sessionEventsState.m2611a(appEvent);
                }
            }
        }
    }

    public synchronized void m2544a(C0608a accessTokenAppIdPair, C0612b appEvent) {
        m2541b(accessTokenAppIdPair).m2611a(appEvent);
    }

    public synchronized Set<C0608a> m2543a() {
        return this.f1042a.keySet();
    }

    public synchronized C0638l m2542a(C0608a accessTokenAppIdPair) {
        return (C0638l) this.f1042a.get(accessTokenAppIdPair);
    }

    public synchronized int m2546b() {
        int count;
        count = 0;
        for (C0638l sessionEventsState : this.f1042a.values()) {
            count += sessionEventsState.m2609a();
        }
        return count;
    }

    private synchronized C0638l m2541b(C0608a accessTokenAppId) {
        C0638l eventsState;
        eventsState = (C0638l) this.f1042a.get(accessTokenAppId);
        if (eventsState == null) {
            Context context = C0717g.m2880f();
            eventsState = new C0638l(C0652b.m2630a(context), C0628f.m2587d(context));
        }
        this.f1042a.put(accessTokenAppId, eventsState);
        return eventsState;
    }
}
