package com.facebook;

/* compiled from: FacebookServiceException */
public class C0719i extends C0709e {
    private final FacebookRequestError f1307a;

    public C0719i(FacebookRequestError error, String errorMessage) {
        super(errorMessage);
        this.f1307a = error;
    }

    public final FacebookRequestError m2888a() {
        return this.f1307a;
    }

    public final String toString() {
        return "{FacebookServiceException: " + "httpResponseCode: " + this.f1307a.m2428a() + ", facebookErrorCode: " + this.f1307a.m2429b() + ", facebookErrorType: " + this.f1307a.m2431d() + ", message: " + this.f1307a.m2432e() + "}";
    }
}
