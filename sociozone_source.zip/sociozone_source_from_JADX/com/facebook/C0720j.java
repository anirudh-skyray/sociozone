package com.facebook;

import android.os.AsyncTask;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import java.net.HttpURLConnection;
import java.util.List;

/* compiled from: GraphRequestAsyncTask */
public class C0720j extends AsyncTask<Void, Void, List<C0723l>> {
    private static final String f1308a = C0720j.class.getCanonicalName();
    private final HttpURLConnection f1309b;
    private final C0722k f1310c;
    private Exception f1311d;

    protected /* synthetic */ Object doInBackground(Object[] objArr) {
        return m2889a((Void[]) objArr);
    }

    protected /* synthetic */ void onPostExecute(Object obj) {
        m2890a((List) obj);
    }

    public C0720j(C0722k requests) {
        this(null, requests);
    }

    public C0720j(HttpURLConnection connection, C0722k requests) {
        this.f1310c = requests;
        this.f1309b = connection;
    }

    public String toString() {
        return "{RequestAsyncTask: " + " connection: " + this.f1309b + ", requests: " + this.f1310c + "}";
    }

    protected void onPreExecute() {
        super.onPreExecute();
        if (C0717g.m2874b()) {
            Log.d(f1308a, String.format("execute async task: %s", new Object[]{this}));
        }
        if (this.f1310c.m2901c() == null) {
            Handler handler;
            if (Thread.currentThread() instanceof HandlerThread) {
                handler = new Handler();
            } else {
                handler = new Handler(Looper.getMainLooper());
            }
            this.f1310c.m2895a(handler);
        }
    }

    protected void m2890a(List<C0723l> result) {
        super.onPostExecute(result);
        if (this.f1311d != null) {
            Log.d(f1308a, String.format("onPostExecute: exception encountered during request: %s", new Object[]{this.f1311d.getMessage()}));
        }
    }

    protected List<C0723l> m2889a(Void... params) {
        try {
            if (this.f1309b == null) {
                return this.f1310c.m2905g();
            }
            return GraphRequest.m2465a(this.f1309b, this.f1310c);
        } catch (Exception e) {
            this.f1311d = e;
            return null;
        }
    }
}
