package com.facebook;

/* compiled from: FacebookSdkNotInitializedException */
public class C0718h extends C0709e {
    public C0718h(String message) {
        super(message);
    }
}
