package com.facebook;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.C0214h;
import com.facebook.p014b.C0665f;

public class CustomTabMainActivity extends Activity {
    public static final String f953a = (CustomTabMainActivity.class.getSimpleName() + ".extra_params");
    public static final String f954b = (CustomTabMainActivity.class.getSimpleName() + ".extra_chromePackage");
    public static final String f955c = (CustomTabMainActivity.class.getSimpleName() + ".extra_url");
    public static final String f956d = (CustomTabMainActivity.class.getSimpleName() + ".action_refresh");
    private boolean f957e = true;
    private BroadcastReceiver f958f;

    class C05841 extends BroadcastReceiver {
        final /* synthetic */ CustomTabMainActivity f952a;

        C05841(CustomTabMainActivity this$0) {
            this.f952a = this$0;
        }

        public void onReceive(Context context, Intent intent) {
            Intent newIntent = new Intent(this.f952a, CustomTabMainActivity.class);
            newIntent.setAction(CustomTabMainActivity.f956d);
            newIntent.putExtra(CustomTabMainActivity.f955c, intent.getStringExtra(CustomTabMainActivity.f955c));
            newIntent.addFlags(603979776);
            this.f952a.startActivity(newIntent);
        }
    }

    public static final String m2419a() {
        return "fb" + C0717g.m2883i() + "://authorize";
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (CustomTabActivity.f949a.equals(getIntent().getAction())) {
            setResult(0);
            finish();
        } else if (savedInstanceState == null) {
            Bundle parameters = getIntent().getBundleExtra(f953a);
            new C0665f("oauth", parameters).m2653a(this, getIntent().getStringExtra(f954b));
            this.f957e = false;
            this.f958f = new C05841(this);
            C0214h.m783a((Context) this).m787a(this.f958f, new IntentFilter(CustomTabActivity.f949a));
        }
    }

    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (f956d.equals(intent.getAction())) {
            C0214h.m783a((Context) this).m788a(new Intent(CustomTabActivity.f950b));
            m2420a(-1, intent);
        } else if (CustomTabActivity.f949a.equals(intent.getAction())) {
            m2420a(-1, intent);
        }
    }

    protected void onResume() {
        super.onResume();
        if (this.f957e) {
            m2420a(0, null);
        }
        this.f957e = true;
    }

    private void m2420a(int resultCode, Intent resultIntent) {
        C0214h.m783a((Context) this).m786a(this.f958f);
        if (resultIntent != null) {
            setResult(resultCode, resultIntent);
        } else {
            setResult(resultCode);
        }
        finish();
    }
}
