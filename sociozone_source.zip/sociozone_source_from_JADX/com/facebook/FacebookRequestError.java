package com.facebook;

import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import com.facebook.p014b.C0673h;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0699q.C0697b;
import java.net.HttpURLConnection;
import org.json.JSONException;
import org.json.JSONObject;

public final class FacebookRequestError implements Parcelable {
    public static final Creator<FacebookRequestError> CREATOR = new C05851();
    static final C0587b f969a = new C0587b(200, 299);
    private final C0586a f970b;
    private final int f971c;
    private final int f972d;
    private final int f973e;
    private final String f974f;
    private final String f975g;
    private final String f976h;
    private final String f977i;
    private final String f978j;
    private final JSONObject f979k;
    private final JSONObject f980l;
    private final Object f981m;
    private final HttpURLConnection f982n;
    private final C0709e f983o;

    static class C05851 implements Creator<FacebookRequestError> {
        C05851() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2423a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2424a(i);
        }

        public FacebookRequestError m2423a(Parcel in) {
            return new FacebookRequestError(in);
        }

        public FacebookRequestError[] m2424a(int size) {
            return new FacebookRequestError[size];
        }
    }

    public enum C0586a {
        LOGIN_RECOVERABLE,
        OTHER,
        TRANSIENT
    }

    private static class C0587b {
        private final int f967a;
        private final int f968b;

        private C0587b(int start, int end) {
            this.f967a = start;
            this.f968b = end;
        }

        boolean m2425a(int value) {
            return this.f967a <= value && value <= this.f968b;
        }
    }

    private FacebookRequestError(int requestStatusCode, int errorCode, int subErrorCode, String errorType, String errorMessage, String errorUserTitle, String errorUserMessage, boolean errorIsTransient, JSONObject requestResultBody, JSONObject requestResult, Object batchRequestResult, HttpURLConnection connection, C0709e exception) {
        C0586a c0586a;
        this.f971c = requestStatusCode;
        this.f972d = errorCode;
        this.f973e = subErrorCode;
        this.f974f = errorType;
        this.f975g = errorMessage;
        this.f980l = requestResultBody;
        this.f979k = requestResult;
        this.f981m = batchRequestResult;
        this.f982n = connection;
        this.f976h = errorUserTitle;
        this.f977i = errorUserMessage;
        boolean isLocalException = false;
        if (exception != null) {
            this.f983o = exception;
            isLocalException = true;
        } else {
            this.f983o = new C0719i(this, errorMessage);
        }
        C0673h errorClassification = m2427g();
        if (isLocalException) {
            c0586a = C0586a.OTHER;
        } else {
            c0586a = errorClassification.m2666a(errorCode, subErrorCode, errorIsTransient);
        }
        this.f970b = c0586a;
        this.f978j = errorClassification.m2667a(this.f970b);
    }

    FacebookRequestError(HttpURLConnection connection, Exception exception) {
        this(-1, -1, -1, null, null, null, null, false, null, null, null, connection, exception instanceof C0709e ? (C0709e) exception : new C0709e((Throwable) exception));
    }

    public FacebookRequestError(int errorCode, String errorType, String errorMessage) {
        this(-1, errorCode, -1, errorType, errorMessage, null, null, false, null, null, null, null, null);
    }

    public int m2428a() {
        return this.f971c;
    }

    public int m2429b() {
        return this.f972d;
    }

    public int m2430c() {
        return this.f973e;
    }

    public String m2431d() {
        return this.f974f;
    }

    public String m2432e() {
        if (this.f975g != null) {
            return this.f975g;
        }
        return this.f983o.getLocalizedMessage();
    }

    public C0709e m2433f() {
        return this.f983o;
    }

    public String toString() {
        return "{HttpStatus: " + this.f971c + ", errorCode: " + this.f972d + ", errorType: " + this.f974f + ", errorMessage: " + m2432e() + "}";
    }

    static FacebookRequestError m2426a(JSONObject singleResult, Object batchResult, HttpURLConnection connection) {
        try {
            if (singleResult.has("code")) {
                int responseCode = singleResult.getInt("code");
                Object body = C0699q.m2779a(singleResult, "body", "FACEBOOK_NON_JSON_RESULT");
                if (body != null && (body instanceof JSONObject)) {
                    JSONObject jsonBody = (JSONObject) body;
                    String errorType = null;
                    String errorMessage = null;
                    String errorUserMessage = null;
                    String errorUserTitle = null;
                    boolean errorIsTransient = false;
                    int errorCode = -1;
                    int errorSubCode = -1;
                    boolean hasError = false;
                    if (jsonBody.has("error")) {
                        JSONObject error = (JSONObject) C0699q.m2779a(jsonBody, "error", null);
                        errorType = error.optString("type", null);
                        errorMessage = error.optString("message", null);
                        errorCode = error.optInt("code", -1);
                        errorSubCode = error.optInt("error_subcode", -1);
                        errorUserMessage = error.optString("error_user_msg", null);
                        errorUserTitle = error.optString("error_user_title", null);
                        errorIsTransient = error.optBoolean("is_transient", false);
                        hasError = true;
                    } else if (jsonBody.has("error_code") || jsonBody.has("error_msg") || jsonBody.has("error_reason")) {
                        errorType = jsonBody.optString("error_reason", null);
                        errorMessage = jsonBody.optString("error_msg", null);
                        errorCode = jsonBody.optInt("error_code", -1);
                        errorSubCode = jsonBody.optInt("error_subcode", -1);
                        hasError = true;
                    }
                    if (hasError) {
                        return new FacebookRequestError(responseCode, errorCode, errorSubCode, errorType, errorMessage, errorUserTitle, errorUserMessage, errorIsTransient, jsonBody, singleResult, batchResult, connection, null);
                    }
                }
                if (!f969a.m2425a(responseCode)) {
                    JSONObject jSONObject;
                    if (singleResult.has("body")) {
                        jSONObject = (JSONObject) C0699q.m2779a(singleResult, "body", "FACEBOOK_NON_JSON_RESULT");
                    } else {
                        jSONObject = null;
                    }
                    return new FacebookRequestError(responseCode, -1, -1, null, null, null, null, false, jSONObject, singleResult, batchResult, connection, null);
                }
            }
        } catch (JSONException e) {
        }
        return null;
    }

    static synchronized C0673h m2427g() {
        C0673h a;
        synchronized (FacebookRequestError.class) {
            C0697b appSettings = C0699q.m2816c(C0717g.m2883i());
            if (appSettings == null) {
                a = C0673h.m2662a();
            } else {
                a = appSettings.m2768c();
            }
        }
        return a;
    }

    public void writeToParcel(Parcel out, int flags) {
        out.writeInt(this.f971c);
        out.writeInt(this.f972d);
        out.writeInt(this.f973e);
        out.writeString(this.f974f);
        out.writeString(this.f975g);
        out.writeString(this.f976h);
        out.writeString(this.f977i);
    }

    private FacebookRequestError(Parcel in) {
        this(in.readInt(), in.readInt(), in.readInt(), in.readString(), in.readString(), in.readString(), in.readString(), false, null, null, null, null, null);
    }

    public int describeContents() {
        return 0;
    }
}
