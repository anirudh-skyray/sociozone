package com.facebook;

import android.content.SharedPreferences;
import android.os.Bundle;
import com.facebook.p014b.C0700r;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: AccessTokenCache */
class C0639a {
    private final SharedPreferences f1119a;
    private final C0602a f1120b;
    private C0756n f1121c;

    /* compiled from: AccessTokenCache */
    static class C0602a {
        C0602a() {
        }

        public C0756n m2525a() {
            return new C0756n(C0717g.m2880f());
        }
    }

    C0639a(SharedPreferences sharedPreferences, C0602a tokenCachingStrategyFactory) {
        this.f1119a = sharedPreferences;
        this.f1120b = tokenCachingStrategyFactory;
    }

    public C0639a() {
        this(C0717g.m2880f().getSharedPreferences("com.facebook.AccessTokenManager.SharedPreferences", 0), new C0602a());
    }

    public AccessToken m2619a() {
        if (m2614c()) {
            return m2615d();
        }
        if (!m2616e()) {
            return null;
        }
        AccessToken accessToken = m2617f();
        if (accessToken == null) {
            return accessToken;
        }
        m2620a(accessToken);
        m2618g().m3107b();
        return accessToken;
    }

    public void m2620a(AccessToken accessToken) {
        C0700r.m2830a((Object) accessToken, "accessToken");
        try {
            this.f1119a.edit().putString("com.facebook.AccessTokenManager.CachedAccessToken", accessToken.m2418j().toString()).apply();
        } catch (JSONException e) {
        }
    }

    public void m2621b() {
        this.f1119a.edit().remove("com.facebook.AccessTokenManager.CachedAccessToken").apply();
        if (m2616e()) {
            m2618g().m3107b();
        }
    }

    private boolean m2614c() {
        return this.f1119a.contains("com.facebook.AccessTokenManager.CachedAccessToken");
    }

    private AccessToken m2615d() {
        AccessToken accessToken = null;
        String jsonString = this.f1119a.getString("com.facebook.AccessTokenManager.CachedAccessToken", accessToken);
        if (jsonString != null) {
            try {
                accessToken = AccessToken.m2405a(new JSONObject(jsonString));
            } catch (JSONException e) {
            }
        }
        return accessToken;
    }

    private boolean m2616e() {
        return C0717g.m2877c();
    }

    private AccessToken m2617f() {
        Bundle bundle = m2618g().m3106a();
        if (bundle == null || !C0756n.m3102a(bundle)) {
            return null;
        }
        return AccessToken.m2404a(bundle);
    }

    private C0756n m2618g() {
        if (this.f1121c == null) {
            synchronized (this) {
                if (this.f1121c == null) {
                    this.f1121c = this.f1120b.m2525a();
                }
            }
        }
        return this.f1121c;
    }
}
