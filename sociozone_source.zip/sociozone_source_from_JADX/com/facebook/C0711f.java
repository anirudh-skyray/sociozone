package com.facebook;

/* compiled from: FacebookOperationCanceledException */
public class C0711f extends C0709e {
    public C0711f(String message) {
        super(message);
    }
}
