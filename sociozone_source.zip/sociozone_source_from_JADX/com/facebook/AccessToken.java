package com.facebook;

import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0700r;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class AccessToken implements Parcelable {
    public static final Creator<AccessToken> CREATOR = new C05811();
    private static final Date f936a = new Date(Long.MAX_VALUE);
    private static final Date f937b = f936a;
    private static final Date f938c = new Date();
    private static final C0708c f939d = C0708c.FACEBOOK_APPLICATION_WEB;
    private final Date f940e;
    private final Set<String> f941f;
    private final Set<String> f942g;
    private final String f943h;
    private final C0708c f944i;
    private final Date f945j;
    private final String f946k;
    private final String f947l;

    static class C05811 implements Creator {
        C05811() {
        }

        public /* synthetic */ Object createFromParcel(Parcel parcel) {
            return m2399a(parcel);
        }

        public /* synthetic */ Object[] newArray(int i) {
            return m2400a(i);
        }

        public AccessToken m2399a(Parcel source) {
            return new AccessToken(source);
        }

        public AccessToken[] m2400a(int size) {
            return new AccessToken[size];
        }
    }

    public interface C0582a {
        void m2401a(AccessToken accessToken);

        void m2402a(C0709e c0709e);
    }

    public AccessToken(String accessToken, String applicationId, String userId, Collection<String> permissions, Collection<String> declinedPermissions, C0708c accessTokenSource, Date expirationTime, Date lastRefreshTime) {
        C0700r.m2831a(accessToken, "accessToken");
        C0700r.m2831a(applicationId, "applicationId");
        C0700r.m2831a(userId, "userId");
        if (expirationTime == null) {
            expirationTime = f937b;
        }
        this.f940e = expirationTime;
        this.f941f = Collections.unmodifiableSet(permissions != null ? new HashSet(permissions) : new HashSet());
        this.f942g = Collections.unmodifiableSet(declinedPermissions != null ? new HashSet(declinedPermissions) : new HashSet());
        this.f943h = accessToken;
        if (accessTokenSource == null) {
            accessTokenSource = f939d;
        }
        this.f944i = accessTokenSource;
        if (lastRefreshTime == null) {
            lastRefreshTime = f938c;
        }
        this.f945j = lastRefreshTime;
        this.f946k = applicationId;
        this.f947l = userId;
    }

    public static AccessToken m2403a() {
        return C0707b.m2848a().m2858b();
    }

    public static void m2407a(AccessToken accessToken) {
        C0707b.m2848a().m2857a(accessToken);
    }

    public String m2410b() {
        return this.f943h;
    }

    public Date m2411c() {
        return this.f940e;
    }

    public Set<String> m2412d() {
        return this.f941f;
    }

    public Set<String> m2413e() {
        return this.f942g;
    }

    public C0708c m2414f() {
        return this.f944i;
    }

    public Date m2415g() {
        return this.f945j;
    }

    public String m2416h() {
        return this.f946k;
    }

    public String m2417i() {
        return this.f947l;
    }

    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("{AccessToken");
        builder.append(" token:").append(m2409k());
        m2408a(builder);
        builder.append("}");
        return builder.toString();
    }

    /* JADX WARNING: inconsistent code. */
    /* Code decompiled incorrectly, please refer to instructions dump. */
    public boolean equals(java.lang.Object r6) {
        /*
        r5 = this;
        r1 = 1;
        r2 = 0;
        if (r5 != r6) goto L_0x0005;
    L_0x0004:
        return r1;
    L_0x0005:
        r3 = r6 instanceof com.facebook.AccessToken;
        if (r3 != 0) goto L_0x000b;
    L_0x0009:
        r1 = r2;
        goto L_0x0004;
    L_0x000b:
        r0 = r6;
        r0 = (com.facebook.AccessToken) r0;
        r3 = r5.f940e;
        r4 = r0.f940e;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0018:
        r3 = r5.f941f;
        r4 = r0.f941f;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0022:
        r3 = r5.f942g;
        r4 = r0.f942g;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x002c:
        r3 = r5.f943h;
        r4 = r0.f943h;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0036:
        r3 = r5.f944i;
        r4 = r0.f944i;
        if (r3 != r4) goto L_0x0058;
    L_0x003c:
        r3 = r5.f945j;
        r4 = r0.f945j;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0046:
        r3 = r5.f946k;
        if (r3 != 0) goto L_0x005a;
    L_0x004a:
        r3 = r0.f946k;
        if (r3 != 0) goto L_0x0058;
    L_0x004e:
        r3 = r5.f947l;
        r4 = r0.f947l;
        r3 = r3.equals(r4);
        if (r3 != 0) goto L_0x0004;
    L_0x0058:
        r1 = r2;
        goto L_0x0004;
    L_0x005a:
        r3 = r5.f946k;
        r4 = r0.f946k;
        r3 = r3.equals(r4);
        if (r3 == 0) goto L_0x0058;
    L_0x0064:
        goto L_0x004e;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.AccessToken.equals(java.lang.Object):boolean");
    }

    public int hashCode() {
        return ((((((((((((((this.f940e.hashCode() + 527) * 31) + this.f941f.hashCode()) * 31) + this.f942g.hashCode()) * 31) + this.f943h.hashCode()) * 31) + this.f944i.hashCode()) * 31) + this.f945j.hashCode()) * 31) + (this.f946k == null ? 0 : this.f946k.hashCode())) * 31) + this.f947l.hashCode();
    }

    static AccessToken m2404a(Bundle bundle) {
        List<String> permissions = m2406a(bundle, "com.facebook.TokenCachingStrategy.Permissions");
        List<String> declinedPermissions = m2406a(bundle, "com.facebook.TokenCachingStrategy.DeclinedPermissions");
        String applicationId = C0756n.m3105d(bundle);
        if (C0699q.m2807a(applicationId)) {
            applicationId = C0717g.m2883i();
        }
        String tokenString = C0756n.m3103b(bundle);
        try {
            return new AccessToken(tokenString, applicationId, C0699q.m2819d(tokenString).getString("id"), permissions, declinedPermissions, C0756n.m3104c(bundle), C0756n.m3100a(bundle, "com.facebook.TokenCachingStrategy.ExpirationDate"), C0756n.m3100a(bundle, "com.facebook.TokenCachingStrategy.LastRefreshDate"));
        } catch (JSONException e) {
            return null;
        }
    }

    static List<String> m2406a(Bundle bundle, String key) {
        List<String> originalPermissions = bundle.getStringArrayList(key);
        if (originalPermissions == null) {
            return Collections.emptyList();
        }
        return Collections.unmodifiableList(new ArrayList(originalPermissions));
    }

    JSONObject m2418j() throws JSONException {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("version", 1);
        jsonObject.put("token", this.f943h);
        jsonObject.put("expires_at", this.f940e.getTime());
        jsonObject.put("permissions", new JSONArray(this.f941f));
        jsonObject.put("declined_permissions", new JSONArray(this.f942g));
        jsonObject.put("last_refresh", this.f945j.getTime());
        jsonObject.put("source", this.f944i.name());
        jsonObject.put("application_id", this.f946k);
        jsonObject.put("user_id", this.f947l);
        return jsonObject;
    }

    static AccessToken m2405a(JSONObject jsonObject) throws JSONException {
        if (jsonObject.getInt("version") > 1) {
            throw new C0709e("Unknown AccessToken serialization format.");
        }
        String token = jsonObject.getString("token");
        Date expiresAt = new Date(jsonObject.getLong("expires_at"));
        JSONArray permissionsArray = jsonObject.getJSONArray("permissions");
        JSONArray declinedPermissionsArray = jsonObject.getJSONArray("declined_permissions");
        Date lastRefresh = new Date(jsonObject.getLong("last_refresh"));
        return new AccessToken(token, jsonObject.getString("application_id"), jsonObject.getString("user_id"), C0699q.m2790a(permissionsArray), C0699q.m2790a(declinedPermissionsArray), C0708c.valueOf(jsonObject.getString("source")), expiresAt, lastRefresh);
    }

    private String m2409k() {
        if (this.f943h == null) {
            return "null";
        }
        if (C0717g.m2872a(C0757o.INCLUDE_ACCESS_TOKENS)) {
            return this.f943h;
        }
        return "ACCESS_TOKEN_REMOVED";
    }

    private void m2408a(StringBuilder builder) {
        builder.append(" permissions:");
        if (this.f941f == null) {
            builder.append("null");
            return;
        }
        builder.append("[");
        builder.append(TextUtils.join(", ", this.f941f));
        builder.append("]");
    }

    AccessToken(Parcel parcel) {
        this.f940e = new Date(parcel.readLong());
        ArrayList<String> permissionsList = new ArrayList();
        parcel.readStringList(permissionsList);
        this.f941f = Collections.unmodifiableSet(new HashSet(permissionsList));
        permissionsList.clear();
        parcel.readStringList(permissionsList);
        this.f942g = Collections.unmodifiableSet(new HashSet(permissionsList));
        this.f943h = parcel.readString();
        this.f944i = C0708c.valueOf(parcel.readString());
        this.f945j = new Date(parcel.readLong());
        this.f946k = parcel.readString();
        this.f947l = parcel.readString();
    }

    public int describeContents() {
        return 0;
    }

    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(this.f940e.getTime());
        dest.writeStringList(new ArrayList(this.f941f));
        dest.writeStringList(new ArrayList(this.f942g));
        dest.writeString(this.f943h);
        dest.writeString(this.f944i.name());
        dest.writeLong(this.f945j.getTime());
        dest.writeString(this.f946k);
        dest.writeString(this.f947l);
    }
}
