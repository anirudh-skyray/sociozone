package com.facebook;

/* compiled from: AccessTokenSource */
public enum C0708c {
    NONE(false),
    FACEBOOK_APPLICATION_WEB(true),
    FACEBOOK_APPLICATION_NATIVE(true),
    FACEBOOK_APPLICATION_SERVICE(true),
    WEB_VIEW(true),
    CHROME_CUSTOM_TAB(true),
    TEST_USER(true),
    CLIENT_TOKEN(true),
    DEVICE_AUTH(true);
    
    private final boolean f1281j;

    private C0708c(boolean canExtendToken) {
        this.f1281j = canExtendToken;
    }

    boolean m2861a() {
        return this.f1281j;
    }
}
