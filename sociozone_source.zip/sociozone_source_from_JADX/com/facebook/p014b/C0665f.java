package com.facebook.p014b;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.support.p001a.C0008c;
import android.support.p001a.C0008c.C0007a;

/* compiled from: CustomTab */
public class C0665f {
    private Uri f1168a;

    public C0665f(String action, Bundle parameters) {
        if (parameters == null) {
            parameters = new Bundle();
        }
        this.f1168a = C0699q.m2774a(C0692p.m2756a(), C0692p.m2759d() + "/" + "dialog/" + action, parameters);
    }

    public void m2653a(Activity activity, String packageName) {
        C0008c customTabsIntent = new C0007a().m11a();
        customTabsIntent.f8a.setPackage(packageName);
        customTabsIntent.f8a.addFlags(1073741824);
        customTabsIntent.m12a(activity, this.f1168a);
    }
}
