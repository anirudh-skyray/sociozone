package com.facebook.p014b;

import android.content.Context;
import android.support.v4.app.ag;
import com.facebook.C0757o;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: AppEventsLoggerUtility */
public class C0648a {
    private static final Map<C0647a, String> f1142a = new C06461();

    /* compiled from: AppEventsLoggerUtility */
    static class C06461 extends HashMap<C0647a, String> {
        C06461() {
            put(C0647a.MOBILE_INSTALL_EVENT, "MOBILE_APP_INSTALL");
            put(C0647a.CUSTOM_APP_EVENTS, "CUSTOM_APP_EVENTS");
        }
    }

    /* compiled from: AppEventsLoggerUtility */
    public enum C0647a {
        MOBILE_INSTALL_EVENT,
        CUSTOM_APP_EVENTS
    }

    public static JSONObject m2626a(C0647a activityType, C0652b attributionIdentifiers, String anonymousAppDeviceGUID, boolean limitEventUsage, Context context) throws JSONException {
        JSONObject publishParams = new JSONObject();
        publishParams.put(ag.CATEGORY_EVENT, f1142a.get(activityType));
        C0699q.m2804a(publishParams, attributionIdentifiers, anonymousAppDeviceGUID, limitEventUsage);
        try {
            C0699q.m2803a(publishParams, context);
        } catch (Exception e) {
            C0680l.m2696a(C0757o.APP_EVENTS, "AppEvents", "Fetching extended device info parameters failed: '%s'", e.toString());
        }
        publishParams.put("application_package_name", context.getPackageName());
        return publishParams;
    }
}
