package com.facebook.p014b;

import com.facebook.FacebookRequestError.C0586a;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.json.JSONArray;
import org.json.JSONObject;

/* compiled from: FacebookRequestErrorClassification */
public final class C0673h {
    private static C0673h f1173g;
    private final Map<Integer, Set<Integer>> f1174a;
    private final Map<Integer, Set<Integer>> f1175b;
    private final Map<Integer, Set<Integer>> f1176c;
    private final String f1177d;
    private final String f1178e;
    private final String f1179f;

    /* compiled from: FacebookRequestErrorClassification */
    static class C06701 extends HashMap<Integer, Set<Integer>> {
        C06701() {
            put(Integer.valueOf(2), null);
            put(Integer.valueOf(4), null);
            put(Integer.valueOf(9), null);
            put(Integer.valueOf(17), null);
            put(Integer.valueOf(341), null);
        }
    }

    /* compiled from: FacebookRequestErrorClassification */
    static class C06712 extends HashMap<Integer, Set<Integer>> {
        C06712() {
            put(Integer.valueOf(102), null);
            put(Integer.valueOf(190), null);
        }
    }

    C0673h(Map<Integer, Set<Integer>> otherErrors, Map<Integer, Set<Integer>> transientErrors, Map<Integer, Set<Integer>> loginRecoverableErrors, String otherRecoveryMessage, String transientRecoveryMessage, String loginRecoverableRecoveryMessage) {
        this.f1174a = otherErrors;
        this.f1175b = transientErrors;
        this.f1176c = loginRecoverableErrors;
        this.f1177d = otherRecoveryMessage;
        this.f1178e = transientRecoveryMessage;
        this.f1179f = loginRecoverableRecoveryMessage;
    }

    public String m2667a(C0586a category) {
        switch (category) {
            case OTHER:
                return this.f1177d;
            case LOGIN_RECOVERABLE:
                return this.f1179f;
            case TRANSIENT:
                return this.f1178e;
            default:
                return null;
        }
    }

    public C0586a m2666a(int errorCode, int errorSubCode, boolean isTransient) {
        if (isTransient) {
            return C0586a.TRANSIENT;
        }
        Set<Integer> subCodes;
        if (this.f1174a != null && this.f1174a.containsKey(Integer.valueOf(errorCode))) {
            subCodes = (Set) this.f1174a.get(Integer.valueOf(errorCode));
            if (subCodes == null || subCodes.contains(Integer.valueOf(errorSubCode))) {
                return C0586a.OTHER;
            }
        }
        if (this.f1176c != null && this.f1176c.containsKey(Integer.valueOf(errorCode))) {
            subCodes = (Set) this.f1176c.get(Integer.valueOf(errorCode));
            if (subCodes == null || subCodes.contains(Integer.valueOf(errorSubCode))) {
                return C0586a.LOGIN_RECOVERABLE;
            }
        }
        if (this.f1175b != null && this.f1175b.containsKey(Integer.valueOf(errorCode))) {
            subCodes = (Set) this.f1175b.get(Integer.valueOf(errorCode));
            if (subCodes == null || subCodes.contains(Integer.valueOf(errorSubCode))) {
                return C0586a.TRANSIENT;
            }
        }
        return C0586a.OTHER;
    }

    public static synchronized C0673h m2662a() {
        C0673h c0673h;
        synchronized (C0673h.class) {
            if (f1173g == null) {
                f1173g = C0673h.m2665b();
            }
            c0673h = f1173g;
        }
        return c0673h;
    }

    private static C0673h m2665b() {
        return new C0673h(null, new C06701(), new C06712(), null, null, null);
    }

    private static Map<Integer, Set<Integer>> m2664a(JSONObject definition) {
        JSONArray itemsArray = definition.optJSONArray("items");
        if (itemsArray.length() == 0) {
            return null;
        }
        Map<Integer, Set<Integer>> items = new HashMap();
        for (int i = 0; i < itemsArray.length(); i++) {
            JSONObject item = itemsArray.optJSONObject(i);
            if (item != null) {
                int code = item.optInt("code");
                if (code != 0) {
                    Set<Integer> subcodes = null;
                    JSONArray subcodesArray = item.optJSONArray("subcodes");
                    if (subcodesArray != null && subcodesArray.length() > 0) {
                        subcodes = new HashSet();
                        for (int j = 0; j < subcodesArray.length(); j++) {
                            int subCode = subcodesArray.optInt(j);
                            if (subCode != 0) {
                                subcodes.add(Integer.valueOf(subCode));
                            }
                        }
                    }
                    items.put(Integer.valueOf(code), subcodes);
                }
            }
        }
        return items;
    }

    public static C0673h m2663a(JSONArray jsonArray) {
        if (jsonArray == null) {
            return null;
        }
        Map<Integer, Set<Integer>> otherErrors = null;
        Map<Integer, Set<Integer>> transientErrors = null;
        Map<Integer, Set<Integer>> loginRecoverableErrors = null;
        String otherRecoveryMessage = null;
        String transientRecoveryMessage = null;
        String loginRecoverableRecoveryMessage = null;
        for (int i = 0; i < jsonArray.length(); i++) {
            JSONObject definition = jsonArray.optJSONObject(i);
            if (definition != null) {
                String name = definition.optString("name");
                if (name != null) {
                    if (name.equalsIgnoreCase("other")) {
                        otherRecoveryMessage = definition.optString("recovery_message", null);
                        otherErrors = C0673h.m2664a(definition);
                    } else if (name.equalsIgnoreCase("transient")) {
                        transientRecoveryMessage = definition.optString("recovery_message", null);
                        transientErrors = C0673h.m2664a(definition);
                    } else if (name.equalsIgnoreCase("login_recoverable")) {
                        loginRecoverableRecoveryMessage = definition.optString("recovery_message", null);
                        loginRecoverableErrors = C0673h.m2664a(definition);
                    }
                }
            }
        }
        return new C0673h(otherErrors, transientErrors, loginRecoverableErrors, otherRecoveryMessage, transientRecoveryMessage, loginRecoverableRecoveryMessage);
    }
}
