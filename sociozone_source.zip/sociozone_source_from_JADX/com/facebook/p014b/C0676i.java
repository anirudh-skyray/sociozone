package com.facebook.p014b;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.webkit.WebView;
import org.json.JSONObject;

/* compiled from: FacebookWebFallbackDialog */
public class C0676i extends C0675s {
    private static final String f1191a = C0676i.class.getName();
    private boolean f1192b;

    /* compiled from: FacebookWebFallbackDialog */
    class C06741 implements Runnable {
        final /* synthetic */ C0676i f1180a;

        C06741(C0676i this$0) {
            this.f1180a = this$0;
        }

        public void run() {
            super.cancel();
        }
    }

    public C0676i(Context context, String url, String expectedRedirectUrl) {
        super(context, url);
        m2683b(expectedRedirectUrl);
    }

    protected Bundle mo864a(String url) {
        Bundle queryParams = C0699q.m2810b(Uri.parse(url).getQuery());
        String bridgeArgsJSONString = queryParams.getString("bridge_args");
        queryParams.remove("bridge_args");
        if (!C0699q.m2807a(bridgeArgsJSONString)) {
            try {
                queryParams.putBundle("com.facebook.platform.protocol.BRIDGE_ARGS", C0662d.m2651a(new JSONObject(bridgeArgsJSONString)));
            } catch (Throwable je) {
                C0699q.m2801a(f1191a, "Unable to parse bridge_args JSON", je);
            }
        }
        String methodResultsJSONString = queryParams.getString("method_results");
        queryParams.remove("method_results");
        if (!C0699q.m2807a(methodResultsJSONString)) {
            if (C0699q.m2807a(methodResultsJSONString)) {
                methodResultsJSONString = "{}";
            }
            try {
                queryParams.putBundle("com.facebook.platform.protocol.RESULT_ARGS", C0662d.m2651a(new JSONObject(methodResultsJSONString)));
            } catch (Throwable je2) {
                C0699q.m2801a(f1191a, "Unable to parse bridge_args JSON", je2);
            }
        }
        queryParams.remove("version");
        queryParams.putInt("com.facebook.platform.protocol.PROTOCOL_VERSION", C0687m.m2721a());
        return queryParams;
    }

    public void cancel() {
        WebView webView = m2685c();
        if (!m2684b() || m2682a() || webView == null || !webView.isShown()) {
            super.cancel();
        } else if (!this.f1192b) {
            this.f1192b = true;
            webView.loadUrl("javascript:" + "(function() {  var event = document.createEvent('Event');  event.initEvent('fbPlatformDialogMustClose',true,true);  document.dispatchEvent(event);})();");
            new Handler(Looper.getMainLooper()).postDelayed(new C06741(this), 1500);
        }
    }
}
