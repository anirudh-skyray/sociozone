package com.facebook.p014b;

import com.facebook.C0717g;
import java.util.Collection;

/* compiled from: ServerProtocol */
public final class C0692p {
    public static final Collection<String> f1221a = C0699q.m2788a("service_disabled", "AndroidAuthKillSwitchException");
    public static final Collection<String> f1222b = C0699q.m2788a("access_denied", "OAuthAccessDeniedException");
    private static final String f1223c = C0692p.class.getName();

    public static final String m2756a() {
        return String.format("m.%s", new Object[]{C0717g.m2879e()});
    }

    public static final String m2757b() {
        return String.format("https://graph.%s", new Object[]{C0717g.m2879e()});
    }

    public static final String m2758c() {
        return String.format("https://graph-video.%s", new Object[]{C0717g.m2879e()});
    }

    public static final String m2759d() {
        return "v2.7";
    }
}
