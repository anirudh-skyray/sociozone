package com.facebook.p014b;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.v4.content.C0214h;
import com.facebook.p015a.C0628f;

/* compiled from: BoltsMeasurementEventListener */
public class C0653c extends BroadcastReceiver {
    private static C0653c f1153a;
    private Context f1154b;

    private C0653c(Context context) {
        this.f1154b = context.getApplicationContext();
    }

    private void m2641a() {
        C0214h.m783a(this.f1154b).m787a(this, new IntentFilter("com.parse.bolts.measurement_event"));
    }

    private void m2642b() {
        C0214h.m783a(this.f1154b).m786a((BroadcastReceiver) this);
    }

    public static C0653c m2640a(Context context) {
        if (f1153a != null) {
            return f1153a;
        }
        f1153a = new C0653c(context);
        f1153a.m2641a();
        return f1153a;
    }

    protected void finalize() throws Throwable {
        try {
            m2642b();
        } finally {
            super.finalize();
        }
    }

    public void onReceive(Context context, Intent intent) {
        C0628f appEventsLogger = C0628f.m2583c(context);
        String eventName = "bf_" + intent.getStringExtra("event_name");
        Bundle eventArgs = intent.getBundleExtra("event_args");
        Bundle logData = new Bundle();
        for (String key : eventArgs.keySet()) {
            logData.putString(key.replaceAll("[^0-9a-zA-Z _-]", "-").replaceAll("^[ -]*", "").replaceAll("[ -]*$", ""), (String) eventArgs.get(key));
        }
        appEventsLogger.m2593a(eventName, logData);
    }
}
