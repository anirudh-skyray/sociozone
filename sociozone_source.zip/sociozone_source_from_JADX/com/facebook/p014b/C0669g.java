package com.facebook.p014b;

import android.app.Dialog;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v4.app.C0159p;
import android.support.v4.app.C0164q;
import com.facebook.C0709e;
import com.facebook.C0717g;
import com.facebook.p014b.C0675s.C0666c;
import com.facebook.p014b.C0675s.C0705a;

/* compiled from: FacebookDialogFragment */
public class C0669g extends C0159p {
    private Dialog f1171a;

    /* compiled from: FacebookDialogFragment */
    class C06671 implements C0666c {
        final /* synthetic */ C0669g f1169a;

        C06671(C0669g this$0) {
            this.f1169a = this$0;
        }

        public void mo861a(Bundle values, C0709e error) {
            this.f1169a.m2658a(values, error);
        }
    }

    /* compiled from: FacebookDialogFragment */
    class C06682 implements C0666c {
        final /* synthetic */ C0669g f1170a;

        C06682(C0669g this$0) {
            this.f1170a = this$0;
        }

        public void mo861a(Bundle values, C0709e error) {
            this.f1170a.m2657a(values);
        }
    }

    public void m2661a(Dialog dialog) {
        this.f1171a = dialog;
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (this.f1171a == null) {
            C0675s webDialog;
            C0164q activity = getActivity();
            Bundle params = C0687m.m2741c(activity.getIntent());
            if (params.getBoolean("is_fallback", false)) {
                String url = params.getString("url");
                if (C0699q.m2807a(url)) {
                    C0699q.m2800a("FacebookDialogFragment", "Cannot start a fallback WebDialog with an empty/missing 'url'");
                    activity.finish();
                    return;
                }
                webDialog = new C0676i(activity, url, String.format("fb%s://bridge/", new Object[]{C0717g.m2883i()}));
                webDialog.m2680a(new C06682(this));
            } else {
                String actionName = params.getString("action");
                Bundle webParams = params.getBundle("params");
                if (C0699q.m2807a(actionName)) {
                    C0699q.m2800a("FacebookDialogFragment", "Cannot start a WebDialog with an empty/missing 'actionName'");
                    activity.finish();
                    return;
                }
                webDialog = new C0705a(activity, actionName, webParams).m2840a(new C06671(this)).mo881a();
            }
            this.f1171a = webDialog;
        }
    }

    public Dialog onCreateDialog(Bundle savedInstanceState) {
        if (this.f1171a == null) {
            m2658a(null, null);
            setShowsDialog(false);
        }
        return this.f1171a;
    }

    public void onResume() {
        super.onResume();
        if (this.f1171a instanceof C0675s) {
            ((C0675s) this.f1171a).m2686d();
        }
    }

    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if ((this.f1171a instanceof C0675s) && isResumed()) {
            ((C0675s) this.f1171a).m2686d();
        }
    }

    public void onDestroyView() {
        if (getDialog() != null && getRetainInstance()) {
            getDialog().setDismissMessage(null);
        }
        super.onDestroyView();
    }

    private void m2658a(Bundle values, C0709e error) {
        C0164q fragmentActivity = getActivity();
        fragmentActivity.setResult(error == null ? -1 : 0, C0687m.m2728a(fragmentActivity.getIntent(), values, error));
        fragmentActivity.finish();
    }

    private void m2657a(Bundle values) {
        C0164q fragmentActivity = getActivity();
        Intent resultIntent = new Intent();
        if (values == null) {
            values = new Bundle();
        }
        resultIntent.putExtras(values);
        fragmentActivity.setResult(-1, resultIntent);
        fragmentActivity.finish();
    }
}
