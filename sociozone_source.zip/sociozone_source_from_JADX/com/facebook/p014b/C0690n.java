package com.facebook.p014b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.RemoteException;

/* compiled from: PlatformServiceClient */
public abstract class C0690n implements ServiceConnection {
    private final Context f1211a;
    private final Handler f1212b;
    private C0689a f1213c;
    private boolean f1214d;
    private Messenger f1215e;
    private int f1216f;
    private int f1217g;
    private final String f1218h;
    private final int f1219i;

    /* compiled from: PlatformServiceClient */
    class C06881 extends Handler {
        final /* synthetic */ C0690n f1210a;

        C06881(C0690n this$0) {
            this.f1210a = this$0;
        }

        public void handleMessage(Message message) {
            this.f1210a.m2750a(message);
        }
    }

    /* compiled from: PlatformServiceClient */
    public interface C0689a {
        void mo879a(Bundle bundle);
    }

    protected abstract void mo883a(Bundle bundle);

    public C0690n(Context context, int requestMessage, int replyMessage, int protocolVersion, String applicationId) {
        Context applicationContext = context.getApplicationContext();
        if (applicationContext == null) {
            applicationContext = context;
        }
        this.f1211a = applicationContext;
        this.f1216f = requestMessage;
        this.f1217g = replyMessage;
        this.f1218h = applicationId;
        this.f1219i = protocolVersion;
        this.f1212b = new C06881(this);
    }

    public void m2751a(C0689a listener) {
        this.f1213c = listener;
    }

    public boolean m2752a() {
        if (this.f1214d || C0687m.m2734b(this.f1219i) == -1) {
            return false;
        }
        Intent intent = C0687m.m2725a(this.f1211a);
        if (intent == null) {
            return false;
        }
        this.f1214d = true;
        this.f1211a.bindService(intent, this, 1);
        return true;
    }

    public void m2753b() {
        this.f1214d = false;
    }

    public void onServiceConnected(ComponentName name, IBinder service) {
        this.f1215e = new Messenger(service);
        m2748c();
    }

    public void onServiceDisconnected(ComponentName name) {
        this.f1215e = null;
        try {
            this.f1211a.unbindService(this);
        } catch (IllegalArgumentException e) {
        }
        m2747b(null);
    }

    private void m2748c() {
        Bundle data = new Bundle();
        data.putString("com.facebook.platform.extra.APPLICATION_ID", this.f1218h);
        mo883a(data);
        Message request = Message.obtain(null, this.f1216f);
        request.arg1 = this.f1219i;
        request.setData(data);
        request.replyTo = new Messenger(this.f1212b);
        try {
            this.f1215e.send(request);
        } catch (RemoteException e) {
            m2747b(null);
        }
    }

    protected void m2750a(Message message) {
        if (message.what == this.f1217g) {
            Bundle extras = message.getData();
            if (extras.getString("com.facebook.platform.status.ERROR_TYPE") != null) {
                m2747b(null);
            } else {
                m2747b(extras);
            }
            try {
                this.f1211a.unbindService(this);
            } catch (IllegalArgumentException e) {
            }
        }
    }

    private void m2747b(Bundle result) {
        if (this.f1214d) {
            this.f1214d = false;
            C0689a callback = this.f1213c;
            if (callback != null) {
                callback.mo879a(result);
            }
        }
    }
}
