package com.facebook.p014b;

import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import com.facebook.C0709e;
import com.facebook.C0711f;
import com.facebook.C0717g;
import com.facebook.login.C0746a;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: NativeProtocol */
public final class C0687m {
    private static final String f1205a = C0687m.class.getName();
    private static List<C0682d> f1206b = C0687m.m2744e();
    private static Map<String, List<C0682d>> f1207c = C0687m.m2745f();
    private static AtomicBoolean f1208d = new AtomicBoolean(false);
    private static final List<Integer> f1209e = Arrays.asList(new Integer[]{Integer.valueOf(20160327), Integer.valueOf(20141218), Integer.valueOf(20141107), Integer.valueOf(20141028), Integer.valueOf(20141001), Integer.valueOf(20140701), Integer.valueOf(20140324), Integer.valueOf(20140204), Integer.valueOf(20131107), Integer.valueOf(20130618), Integer.valueOf(20130502), Integer.valueOf(20121101)});

    /* compiled from: NativeProtocol */
    static class C06811 implements Runnable {
        C06811() {
        }

        public void run() {
            try {
                for (C0682d appInfo : C0687m.f1206b) {
                    appInfo.m2707a(true);
                }
            } finally {
                C0687m.f1208d.set(false);
            }
        }
    }

    /* compiled from: NativeProtocol */
    private static abstract class C0682d {
        private static final HashSet<String> f1203a = C0682d.m2708d();
        private TreeSet<Integer> f1204b;

        protected abstract String mo866a();

        protected abstract String mo867b();

        private C0682d() {
        }

        private static HashSet<String> m2708d() {
            HashSet<String> set = new HashSet();
            set.add("8a3c4b262d721acd49a4bf97d5213199c86fa2b9");
            set.add("a4b7452e2ed8f5f191058ca7bbfd26b0d3214bfc");
            set.add("5e8f16062ea3cd2c4a0d547876baa6f38cabf625");
            return set;
        }

        public boolean m2710a(Context context, String packageName) {
            String brand = Build.BRAND;
            int applicationFlags = context.getApplicationInfo().flags;
            if (brand.startsWith("generic") && (applicationFlags & 2) != 0) {
                return true;
            }
            try {
                PackageInfo packageInfo = context.getPackageManager().getPackageInfo(packageName, 64);
                if (packageInfo.signatures == null || packageInfo.signatures.length <= 0) {
                    return false;
                }
                for (Signature signature : packageInfo.signatures) {
                    if (!f1203a.contains(C0699q.m2785a(signature.toByteArray()))) {
                        return false;
                    }
                }
                return true;
            } catch (NameNotFoundException e) {
                return false;
            }
        }

        public TreeSet<Integer> m2712c() {
            if (this.f1204b == null) {
                m2707a(false);
            }
            return this.f1204b;
        }

        /* JADX WARNING: inconsistent code. */
        /* Code decompiled incorrectly, please refer to instructions dump. */
        private synchronized void m2707a(boolean r2) {
            /*
            r1 = this;
            monitor-enter(r1);
            if (r2 != 0) goto L_0x0007;
        L_0x0003:
            r0 = r1.f1204b;	 Catch:{ all -> 0x000f }
            if (r0 != 0) goto L_0x000d;
        L_0x0007:
            r0 = com.facebook.p014b.C0687m.m2737b(r1);	 Catch:{ all -> 0x000f }
            r1.f1204b = r0;	 Catch:{ all -> 0x000f }
        L_0x000d:
            monitor-exit(r1);
            return;
        L_0x000f:
            r0 = move-exception;
            monitor-exit(r1);
            throw r0;
            */
            throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.m.d.a(boolean):void");
        }
    }

    /* compiled from: NativeProtocol */
    private static class C0683a extends C0682d {
        private C0683a() {
            super();
        }

        protected String mo866a() {
            return "com.facebook.lite";
        }

        protected String mo867b() {
            return "com.facebook.lite.platform.LoginGDPDialogActivity";
        }
    }

    /* compiled from: NativeProtocol */
    private static class C0684b extends C0682d {
        private C0684b() {
            super();
        }

        protected String mo866a() {
            return "com.facebook.katana";
        }

        protected String mo867b() {
            return "com.facebook.katana.ProxyAuth";
        }
    }

    /* compiled from: NativeProtocol */
    private static class C0685c extends C0682d {
        private C0685c() {
            super();
        }

        protected String mo866a() {
            return "com.facebook.orca";
        }

        protected String mo867b() {
            return null;
        }
    }

    /* compiled from: NativeProtocol */
    private static class C0686e extends C0682d {
        private C0686e() {
            super();
        }

        protected String mo866a() {
            return "com.facebook.wakizashi";
        }

        protected String mo867b() {
            return "com.facebook.katana.ProxyAuth";
        }
    }

    private static List<C0682d> m2744e() {
        List<C0682d> list = new ArrayList();
        list.add(new C0684b());
        list.add(new C0686e());
        return list;
    }

    private static Map<String, List<C0682d>> m2745f() {
        Map<String, List<C0682d>> map = new HashMap();
        ArrayList<C0682d> messengerAppInfoList = new ArrayList();
        messengerAppInfoList.add(new C0685c());
        map.put("com.facebook.platform.action.request.OGACTIONPUBLISH_DIALOG", f1206b);
        map.put("com.facebook.platform.action.request.FEED_DIALOG", f1206b);
        map.put("com.facebook.platform.action.request.LIKE_DIALOG", f1206b);
        map.put("com.facebook.platform.action.request.APPINVITES_DIALOG", f1206b);
        map.put("com.facebook.platform.action.request.MESSAGE_DIALOG", messengerAppInfoList);
        map.put("com.facebook.platform.action.request.OGMESSAGEPUBLISH_DIALOG", messengerAppInfoList);
        return map;
    }

    static Intent m2726a(Context context, Intent intent, C0682d appInfo) {
        if (intent == null) {
            return null;
        }
        ResolveInfo resolveInfo = context.getPackageManager().resolveActivity(intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        if (appInfo.m2710a(context, resolveInfo.activityInfo.packageName)) {
            return intent;
        }
        return null;
    }

    static Intent m2735b(Context context, Intent intent, C0682d appInfo) {
        if (intent == null) {
            return null;
        }
        ResolveInfo resolveInfo = context.getPackageManager().resolveService(intent, 0);
        if (resolveInfo == null) {
            return null;
        }
        if (appInfo.m2710a(context, resolveInfo.serviceInfo.packageName)) {
            return intent;
        }
        return null;
    }

    public static Intent m2727a(Context context, String applicationId, Collection<String> permissions, String e2e, boolean isRerequest, boolean isForPublish, C0746a defaultAudience, String clientState) {
        C0682d appInfo = new C0683a();
        return C0687m.m2726a(context, C0687m.m2729a(appInfo, applicationId, (Collection) permissions, e2e, isRerequest, isForPublish, defaultAudience, clientState), appInfo);
    }

    private static Intent m2729a(C0682d appInfo, String applicationId, Collection<String> permissions, String e2e, boolean isRerequest, boolean isForPublish, C0746a defaultAudience, String clientState) {
        String activityName = appInfo.mo867b();
        if (activityName == null) {
            return null;
        }
        Intent intent = new Intent().setClassName(appInfo.mo866a(), activityName).putExtra("client_id", applicationId);
        if (!C0699q.m2808a((Collection) permissions)) {
            intent.putExtra("scope", TextUtils.join(",", permissions));
        }
        if (!C0699q.m2807a(e2e)) {
            intent.putExtra("e2e", e2e);
        }
        intent.putExtra("state", clientState);
        intent.putExtra("response_type", "token,signed_request");
        intent.putExtra("return_scopes", "true");
        if (isForPublish) {
            intent.putExtra("default_audience", defaultAudience.m3077a());
        }
        intent.putExtra("legacy_override", "v2.7");
        intent.putExtra("auth_type", "rerequest");
        return intent;
    }

    public static Intent m2736b(Context context, String applicationId, Collection<String> permissions, String e2e, boolean isRerequest, boolean isForPublish, C0746a defaultAudience, String clientState) {
        for (C0682d appInfo : f1206b) {
            Intent intent = C0687m.m2726a(context, C0687m.m2729a(appInfo, applicationId, (Collection) permissions, e2e, isRerequest, isForPublish, defaultAudience, clientState), appInfo);
            if (intent != null) {
                return intent;
            }
        }
        return null;
    }

    public static final int m2721a() {
        return ((Integer) f1209e.get(0)).intValue();
    }

    public static boolean m2733a(int version) {
        return f1209e.contains(Integer.valueOf(version)) && version >= 20140701;
    }

    public static Intent m2728a(Intent requestIntent, Bundle results, C0709e error) {
        UUID callId = C0687m.m2738b(requestIntent);
        if (callId == null) {
            return null;
        }
        Intent resultIntent = new Intent();
        resultIntent.putExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", C0687m.m2722a(requestIntent));
        Bundle bridgeArguments = new Bundle();
        bridgeArguments.putString("action_id", callId.toString());
        if (error != null) {
            bridgeArguments.putBundle("error", C0687m.m2730a(error));
        }
        resultIntent.putExtra("com.facebook.platform.protocol.BRIDGE_ARGS", bridgeArguments);
        if (results == null) {
            return resultIntent;
        }
        resultIntent.putExtra("com.facebook.platform.protocol.RESULT_ARGS", results);
        return resultIntent;
    }

    public static Intent m2725a(Context context) {
        for (C0682d appInfo : f1206b) {
            Intent intent = C0687m.m2735b(context, new Intent("com.facebook.platform.PLATFORM_SERVICE").setPackage(appInfo.mo866a()).addCategory("android.intent.category.DEFAULT"), appInfo);
            if (intent != null) {
                return intent;
            }
        }
        return null;
    }

    public static int m2722a(Intent intent) {
        return intent.getIntExtra("com.facebook.platform.protocol.PROTOCOL_VERSION", 0);
    }

    public static UUID m2738b(Intent intent) {
        if (intent == null) {
            return null;
        }
        String callIdString = null;
        if (C0687m.m2733a(C0687m.m2722a(intent))) {
            Bundle bridgeArgs = intent.getBundleExtra("com.facebook.platform.protocol.BRIDGE_ARGS");
            if (bridgeArgs != null) {
                callIdString = bridgeArgs.getString("action_id");
            }
        } else {
            callIdString = intent.getStringExtra("com.facebook.platform.protocol.CALL_ID");
        }
        UUID callId = null;
        if (callIdString == null) {
            return callId;
        }
        try {
            return UUID.fromString(callIdString);
        } catch (IllegalArgumentException e) {
            return callId;
        }
    }

    public static Bundle m2741c(Intent intent) {
        if (C0687m.m2733a(C0687m.m2722a(intent))) {
            return intent.getBundleExtra("com.facebook.platform.protocol.METHOD_ARGS");
        }
        return intent.getExtras();
    }

    public static C0709e m2731a(Bundle errorData) {
        if (errorData == null) {
            return null;
        }
        String type = errorData.getString("error_type");
        if (type == null) {
            type = errorData.getString("com.facebook.platform.status.ERROR_TYPE");
        }
        String description = errorData.getString("error_description");
        if (description == null) {
            description = errorData.getString("com.facebook.platform.status.ERROR_DESCRIPTION");
        }
        if (type == null || !type.equalsIgnoreCase("UserCanceled")) {
            return new C0709e(description);
        }
        return new C0711f(description);
    }

    public static Bundle m2730a(C0709e e) {
        if (e == null) {
            return null;
        }
        Bundle errorBundle = new Bundle();
        errorBundle.putString("error_description", e.toString());
        if (!(e instanceof C0711f)) {
            return errorBundle;
        }
        errorBundle.putString("error_type", "UserCanceled");
        return errorBundle;
    }

    public static int m2734b(int minimumVersion) {
        return C0687m.m2723a(f1206b, new int[]{minimumVersion});
    }

    private static int m2723a(List<C0682d> appInfoList, int[] versionSpec) {
        C0687m.m2739b();
        if (appInfoList == null) {
            return -1;
        }
        for (C0682d appInfo : appInfoList) {
            int protocolVersion = C0687m.m2724a(appInfo.m2712c(), C0687m.m2721a(), versionSpec);
            if (protocolVersion != -1) {
                return protocolVersion;
            }
        }
        return -1;
    }

    public static void m2739b() {
        if (f1208d.compareAndSet(false, true)) {
            C0717g.m2878d().execute(new C06811());
        }
    }

    private static TreeSet<Integer> m2737b(C0682d appInfo) {
        TreeSet<Integer> allAvailableVersions = new TreeSet();
        ContentResolver contentResolver = C0717g.m2880f().getContentResolver();
        String[] projection = new String[]{"version"};
        Uri uri = C0687m.m2740c(appInfo);
        Cursor c = null;
        if (C0717g.m2880f().getPackageManager().resolveContentProvider(appInfo.mo866a() + ".provider.PlatformProvider", 0) != null) {
            try {
                c = contentResolver.query(uri, projection, null, null, null);
            } catch (NullPointerException e) {
                try {
                    Log.e(f1205a, "Failed to query content resolver.");
                    c = null;
                    if (c != null) {
                        while (c.moveToNext()) {
                            allAvailableVersions.add(Integer.valueOf(c.getInt(c.getColumnIndex("version"))));
                        }
                    }
                    if (c != null) {
                        c.close();
                    }
                    return allAvailableVersions;
                } catch (Throwable th) {
                    if (c != null) {
                        c.close();
                    }
                }
            } catch (SecurityException e2) {
                Log.e(f1205a, "Failed to query content resolver.");
                c = null;
                if (c != null) {
                    while (c.moveToNext()) {
                        allAvailableVersions.add(Integer.valueOf(c.getInt(c.getColumnIndex("version"))));
                    }
                }
                if (c != null) {
                    c.close();
                }
                return allAvailableVersions;
            }
            if (c != null) {
                while (c.moveToNext()) {
                    allAvailableVersions.add(Integer.valueOf(c.getInt(c.getColumnIndex("version"))));
                }
            }
        }
        if (c != null) {
            c.close();
        }
        return allAvailableVersions;
    }

    public static int m2724a(TreeSet<Integer> allAvailableFacebookAppVersions, int latestSdkVersion, int[] versionSpec) {
        int versionSpecIndex = versionSpec.length - 1;
        Iterator<Integer> fbAppVersionsIterator = allAvailableFacebookAppVersions.descendingIterator();
        int latestFacebookAppVersion = -1;
        while (fbAppVersionsIterator.hasNext()) {
            int fbAppVersion = ((Integer) fbAppVersionsIterator.next()).intValue();
            latestFacebookAppVersion = Math.max(latestFacebookAppVersion, fbAppVersion);
            while (versionSpecIndex >= 0 && versionSpec[versionSpecIndex] > fbAppVersion) {
                versionSpecIndex--;
            }
            if (versionSpecIndex < 0) {
                return -1;
            }
            if (versionSpec[versionSpecIndex] == fbAppVersion) {
                return versionSpecIndex % 2 == 0 ? Math.min(latestFacebookAppVersion, latestSdkVersion) : -1;
            }
        }
        return -1;
    }

    private static Uri m2740c(C0682d appInfo) {
        return Uri.parse("content://" + appInfo.mo866a() + ".provider.PlatformProvider/versions");
    }
}
