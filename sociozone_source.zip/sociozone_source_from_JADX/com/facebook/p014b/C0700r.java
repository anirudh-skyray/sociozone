package com.facebook.p014b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.util.Log;
import com.facebook.C0717g;
import com.facebook.C0718h;
import com.facebook.CustomTabActivity;
import com.facebook.FacebookActivity;
import java.util.Collection;
import java.util.List;

/* compiled from: Validate */
public final class C0700r {
    private static final String f1252a = C0700r.class.getName();

    public static void m2830a(Object arg, String name) {
        if (arg == null) {
            throw new NullPointerException("Argument '" + name + "' cannot be null");
        }
    }

    public static <T> void m2832a(Collection<T> container, String name) {
        if (container.isEmpty()) {
            throw new IllegalArgumentException("Container '" + name + "' cannot be empty");
        }
    }

    public static <T> void m2836b(Collection<T> container, String name) {
        C0700r.m2830a((Object) container, name);
        for (T item : container) {
            if (item == null) {
                throw new NullPointerException("Container '" + name + "' cannot contain null values");
            }
        }
    }

    public static <T> void m2838c(Collection<T> container, String name) {
        C0700r.m2836b((Collection) container, name);
        C0700r.m2832a((Collection) container, name);
    }

    public static void m2831a(String arg, String name) {
        if (C0699q.m2807a(arg)) {
            throw new IllegalArgumentException("Argument '" + name + "' cannot be null or empty");
        }
    }

    public static void m2828a() {
        if (!C0717g.m2871a()) {
            throw new C0718h("The SDK has not been initialized, make sure to call FacebookSdk.sdkInitialize() first.");
        }
    }

    public static String m2834b() {
        String id = C0717g.m2883i();
        if (id != null) {
            return id;
        }
        throw new IllegalStateException("No App ID found, please set the App ID.");
    }

    public static String m2837c() {
        String token = C0717g.m2884j();
        if (token != null) {
            return token;
        }
        throw new IllegalStateException("No Client Token found, please set the Client Token.");
    }

    public static void m2829a(Context context, boolean shouldThrow) {
        C0700r.m2830a((Object) context, "context");
        if (context.checkCallingOrSelfPermission("android.permission.INTERNET") != -1) {
            return;
        }
        if (shouldThrow) {
            throw new IllegalStateException("No internet permissions granted for the app, please add <uses-permission android:name=\"android.permission.INTERNET\" /> to your AndroidManifest.xml.");
        }
        Log.w(f1252a, "No internet permissions granted for the app, please add <uses-permission android:name=\"android.permission.INTERNET\" /> to your AndroidManifest.xml.");
    }

    public static void m2835b(Context context, boolean shouldThrow) {
        C0700r.m2830a((Object) context, "context");
        PackageManager pm = context.getPackageManager();
        ActivityInfo activityInfo = null;
        if (pm != null) {
            try {
                activityInfo = pm.getActivityInfo(new ComponentName(context, FacebookActivity.class), 1);
            } catch (NameNotFoundException e) {
            }
        }
        if (activityInfo != null) {
            return;
        }
        if (shouldThrow) {
            throw new IllegalStateException("FacebookActivity is not declared in the AndroidManifest.xml, please add com.facebook.FacebookActivity to your AndroidManifest.xml file. See https://developers.facebook.com/docs/android/getting-started for more info.");
        }
        Log.w(f1252a, "FacebookActivity is not declared in the AndroidManifest.xml, please add com.facebook.FacebookActivity to your AndroidManifest.xml file. See https://developers.facebook.com/docs/android/getting-started for more info.");
    }

    public static boolean m2833a(Context context) {
        C0700r.m2830a((Object) context, "context");
        PackageManager pm = context.getPackageManager();
        List<ResolveInfo> infos = null;
        if (pm != null) {
            Intent intent = new Intent();
            intent.setAction("android.intent.action.VIEW");
            intent.addCategory("android.intent.category.DEFAULT");
            intent.addCategory("android.intent.category.BROWSABLE");
            intent.setData(Uri.parse("fb" + C0717g.m2883i() + "://authorize"));
            infos = pm.queryIntentActivities(intent, 64);
        }
        boolean hasActivity = false;
        if (infos != null) {
            for (ResolveInfo info : infos) {
                if (!info.activityInfo.name.equals(CustomTabActivity.class.getName())) {
                    return false;
                }
                hasActivity = true;
            }
        }
        return hasActivity;
    }
}
