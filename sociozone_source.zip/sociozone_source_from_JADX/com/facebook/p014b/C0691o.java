package com.facebook.p014b;

import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONObject;

/* compiled from: ProfileInformationCache */
class C0691o {
    private static final ConcurrentHashMap<String, JSONObject> f1220a = new ConcurrentHashMap();

    public static JSONObject m2754a(String accessToken) {
        return (JSONObject) f1220a.get(accessToken);
    }

    public static void m2755a(String key, JSONObject value) {
        f1220a.put(key, value);
    }
}
