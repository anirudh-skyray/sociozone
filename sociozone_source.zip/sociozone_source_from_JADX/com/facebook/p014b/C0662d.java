package com.facebook.p014b;

import android.os.Bundle;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

/* compiled from: BundleJSONConverter */
public class C0662d {
    private static final Map<Class<?>, C0654a> f1155a = new HashMap();

    /* compiled from: BundleJSONConverter */
    public interface C0654a {
        void mo860a(Bundle bundle, String str, Object obj) throws JSONException;
    }

    /* compiled from: BundleJSONConverter */
    static class C06551 implements C0654a {
        C06551() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putBoolean(key, ((Boolean) value).booleanValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    static class C06562 implements C0654a {
        C06562() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putInt(key, ((Integer) value).intValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    static class C06573 implements C0654a {
        C06573() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putLong(key, ((Long) value).longValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    static class C06584 implements C0654a {
        C06584() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putDouble(key, ((Double) value).doubleValue());
        }
    }

    /* compiled from: BundleJSONConverter */
    static class C06595 implements C0654a {
        C06595() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            bundle.putString(key, (String) value);
        }
    }

    /* compiled from: BundleJSONConverter */
    static class C06606 implements C0654a {
        C06606() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            throw new IllegalArgumentException("Unexpected type from JSON");
        }
    }

    /* compiled from: BundleJSONConverter */
    static class C06617 implements C0654a {
        C06617() {
        }

        public void mo860a(Bundle bundle, String key, Object value) throws JSONException {
            JSONArray jsonArray = (JSONArray) value;
            ArrayList<String> stringArrayList = new ArrayList();
            if (jsonArray.length() == 0) {
                bundle.putStringArrayList(key, stringArrayList);
                return;
            }
            int i = 0;
            while (i < jsonArray.length()) {
                Object current = jsonArray.get(i);
                if (current instanceof String) {
                    stringArrayList.add((String) current);
                    i++;
                } else {
                    throw new IllegalArgumentException("Unexpected type in an array: " + current.getClass());
                }
            }
            bundle.putStringArrayList(key, stringArrayList);
        }
    }

    static {
        f1155a.put(Boolean.class, new C06551());
        f1155a.put(Integer.class, new C06562());
        f1155a.put(Long.class, new C06573());
        f1155a.put(Double.class, new C06584());
        f1155a.put(String.class, new C06595());
        f1155a.put(String[].class, new C06606());
        f1155a.put(JSONArray.class, new C06617());
    }

    public static Bundle m2651a(JSONObject jsonObject) throws JSONException {
        Bundle bundle = new Bundle();
        Iterator<String> jsonIterator = jsonObject.keys();
        while (jsonIterator.hasNext()) {
            String key = (String) jsonIterator.next();
            Object value = jsonObject.get(key);
            if (!(value == null || value == JSONObject.NULL)) {
                if (value instanceof JSONObject) {
                    bundle.putBundle(key, C0662d.m2651a((JSONObject) value));
                } else {
                    C0654a setter = (C0654a) f1155a.get(value.getClass());
                    if (setter == null) {
                        throw new IllegalArgumentException("Unsupported type: " + value.getClass());
                    }
                    setter.mo860a(bundle, key, value);
                }
            }
        }
        return bundle;
    }
}
