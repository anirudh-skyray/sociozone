package com.facebook.p014b;

import com.facebook.C0717g;
import java.util.HashMap;
import java.util.Map;

/* compiled from: CallbackManagerImpl */
public final class C0664e {
    private static Map<Integer, Object> f1167a = new HashMap();

    /* compiled from: CallbackManagerImpl */
    public enum C0663a {
        Login(0),
        Share(1),
        Message(2),
        Like(3),
        GameRequest(4),
        AppGroupCreate(5),
        AppGroupJoin(6),
        AppInvite(7),
        DeviceShare(8);
        
        private final int f1166j;

        private C0663a(int offset) {
            this.f1166j = offset;
        }

        public int m2652a() {
            return C0717g.m2886l() + this.f1166j;
        }
    }
}
