package com.facebook.p014b;

import com.facebook.C0717g;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.FutureTask;

/* compiled from: LockOnGetVariable */
public class C0679k<T> {
    private T f1196a;
    private CountDownLatch f1197b = new CountDownLatch(1);

    public C0679k(final Callable<T> callable) {
        C0717g.m2878d().execute(new FutureTask(new Callable<Void>(this) {
            final /* synthetic */ C0679k f1195b;

            public /* synthetic */ Object call() throws Exception {
                return m2690a();
            }

            public Void m2690a() throws Exception {
                try {
                    this.f1195b.f1196a = callable.call();
                    return null;
                } finally {
                    this.f1195b.f1197b.countDown();
                }
            }
        }));
    }
}
