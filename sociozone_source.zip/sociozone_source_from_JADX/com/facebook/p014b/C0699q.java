package com.facebook.p014b;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.Parcel;
import android.os.StatFs;
import android.support.v4.app.ag;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Display;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.CookieSyncManager;
import com.facebook.AccessToken;
import com.facebook.C0709e;
import com.facebook.C0717g;
import com.facebook.C0723l;
import com.facebook.C0755m;
import com.facebook.GraphRequest;
import com.facebook.GraphRequest.C0588b;
import com.facebook.p015a.p016a.C0606b;
import java.io.BufferedInputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Random;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Pattern;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/* compiled from: Utility */
public final class C0699q {
    private static final String[] f1242a = new String[]{"supports_implicit_sdk_logging", "gdpv4_nux_content", "gdpv4_nux_enabled", "gdpv4_chrome_custom_tabs_enabled", "android_dialog_configs", "android_sdk_error_categories", "app_events_session_timeout"};
    private static Map<String, C0697b> f1243b = new ConcurrentHashMap();
    private static AtomicBoolean f1244c = new AtomicBoolean(false);
    private static int f1245d = 0;
    private static long f1246e = -1;
    private static long f1247f = -1;
    private static long f1248g = -1;
    private static String f1249h = "";
    private static String f1250i = "";
    private static String f1251j = "NoCarrier";

    /* compiled from: Utility */
    public interface C0599c {
        void mo857a(C0709e c0709e);

        void mo858a(JSONObject jSONObject);
    }

    /* compiled from: Utility */
    static class C06953 implements FilenameFilter {
        C06953() {
        }

        public boolean accept(File dir, String fileName) {
            return Pattern.matches("cpu[0-9]+", fileName);
        }
    }

    /* compiled from: Utility */
    public static class C0696a {
        private String f1229a;
        private String f1230b;
        private Uri f1231c;
        private int[] f1232d;

        private static C0696a m2763b(JSONObject dialogConfigJSON) {
            String dialogNameWithFeature = dialogConfigJSON.optString("name");
            if (C0699q.m2807a(dialogNameWithFeature)) {
                return null;
            }
            String[] components = dialogNameWithFeature.split("\\|");
            if (components.length != 2) {
                return null;
            }
            String dialogName = components[0];
            String featureName = components[1];
            if (C0699q.m2807a(dialogName) || C0699q.m2807a(featureName)) {
                return null;
            }
            String urlString = dialogConfigJSON.optString("url");
            Uri fallbackUri = null;
            if (!C0699q.m2807a(urlString)) {
                fallbackUri = Uri.parse(urlString);
            }
            return new C0696a(dialogName, featureName, fallbackUri, C0696a.m2762a(dialogConfigJSON.optJSONArray("versions")));
        }

        private static int[] m2762a(JSONArray versionsJSON) {
            int[] versionSpec = null;
            if (versionsJSON != null) {
                int numVersions = versionsJSON.length();
                versionSpec = new int[numVersions];
                for (int i = 0; i < numVersions; i++) {
                    int version = versionsJSON.optInt(i, -1);
                    if (version == -1) {
                        String versionString = versionsJSON.optString(i);
                        if (!C0699q.m2807a(versionString)) {
                            try {
                                version = Integer.parseInt(versionString);
                            } catch (Exception nfe) {
                                C0699q.m2799a("FacebookSDK", nfe);
                                version = -1;
                            }
                        }
                    }
                    versionSpec[i] = version;
                }
            }
            return versionSpec;
        }

        private C0696a(String dialogName, String featureName, Uri fallbackUrl, int[] featureVersionSpec) {
            this.f1229a = dialogName;
            this.f1230b = featureName;
            this.f1231c = fallbackUrl;
            this.f1232d = featureVersionSpec;
        }

        public String m2764a() {
            return this.f1229a;
        }

        public String m2765b() {
            return this.f1230b;
        }
    }

    /* compiled from: Utility */
    public static class C0697b {
        private boolean f1233a;
        private String f1234b;
        private boolean f1235c;
        private boolean f1236d;
        private int f1237e;
        private Map<String, Map<String, C0696a>> f1238f;
        private C0673h f1239g;

        private C0697b(boolean supportsImplicitLogging, String nuxContent, boolean nuxEnabled, boolean customTabsEnabled, int sessionTimeoutInSeconds, Map<String, Map<String, C0696a>> dialogConfigMap, C0673h errorClassification) {
            this.f1233a = supportsImplicitLogging;
            this.f1234b = nuxContent;
            this.f1235c = nuxEnabled;
            this.f1236d = customTabsEnabled;
            this.f1238f = dialogConfigMap;
            this.f1239g = errorClassification;
            this.f1237e = sessionTimeoutInSeconds;
        }

        public boolean m2766a() {
            return this.f1233a;
        }

        public boolean m2767b() {
            return this.f1236d;
        }

        public C0673h m2768c() {
            return this.f1239g;
        }
    }

    /* compiled from: Utility */
    public static class C0698d {
        List<String> f1240a;
        List<String> f1241b;

        public C0698d(List<String> grantedPermissions, List<String> declinedPermissions) {
            this.f1240a = grantedPermissions;
            this.f1241b = declinedPermissions;
        }

        public List<String> m2769a() {
            return this.f1240a;
        }

        public List<String> m2770b() {
            return this.f1241b;
        }
    }

    public static <T> boolean m2808a(Collection<T> c) {
        return c == null || c.size() == 0;
    }

    public static boolean m2807a(String s) {
        return s == null || s.length() == 0;
    }

    public static <T> Collection<T> m2788a(T... ts) {
        return Collections.unmodifiableCollection(Arrays.asList(ts));
    }

    public static String m2785a(byte[] bytes) {
        return C0699q.m2783a("SHA-1", bytes);
    }

    private static String m2783a(String algorithm, byte[] bytes) {
        try {
            return C0699q.m2784a(MessageDigest.getInstance(algorithm), bytes);
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    private static String m2784a(MessageDigest hash, byte[] bytes) {
        hash.update(bytes);
        byte[] digest = hash.digest();
        StringBuilder builder = new StringBuilder();
        for (int b : digest) {
            builder.append(Integer.toHexString((b >> 4) & 15));
            builder.append(Integer.toHexString((b >> 0) & 15));
        }
        return builder.toString();
    }

    public static Uri m2774a(String authority, String path, Bundle parameters) {
        Builder builder = new Builder();
        builder.scheme("https");
        builder.authority(authority);
        builder.path(path);
        if (parameters != null) {
            for (String key : parameters.keySet()) {
                Object parameter = parameters.get(key);
                if (parameter instanceof String) {
                    builder.appendQueryParameter(key, (String) parameter);
                }
            }
        }
        return builder.build();
    }

    public static Bundle m2810b(String queryString) {
        Bundle params = new Bundle();
        if (!C0699q.m2807a(queryString)) {
            for (String parameter : queryString.split("&")) {
                String[] keyValuePair = parameter.split("=");
                try {
                    if (keyValuePair.length == 2) {
                        params.putString(URLDecoder.decode(keyValuePair[0], "UTF-8"), URLDecoder.decode(keyValuePair[1], "UTF-8"));
                    } else if (keyValuePair.length == 1) {
                        params.putString(URLDecoder.decode(keyValuePair[0], "UTF-8"), "");
                    }
                } catch (Exception e) {
                    C0699q.m2799a("FacebookSDK", e);
                }
            }
        }
        return params;
    }

    public static void m2795a(Bundle b, String key, String value) {
        if (!C0699q.m2807a(value)) {
            b.putString(key, value);
        }
    }

    public static void m2794a(Bundle b, String key, Uri uri) {
        if (uri != null) {
            C0699q.m2795a(b, key, uri.toString());
        }
    }

    public static void m2797a(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
            }
        }
    }

    public static void m2802a(URLConnection connection) {
        if (connection != null && (connection instanceof HttpURLConnection)) {
            ((HttpURLConnection) connection).disconnect();
        }
    }

    public static String m2781a(Context context) {
        C0700r.m2830a((Object) context, "context");
        C0717g.m2868a(context);
        return C0717g.m2883i();
    }

    public static Object m2779a(JSONObject jsonObject, String key, String nonJSONPropertyKey) throws JSONException {
        JSONObject value = jsonObject.opt(key);
        if (value != null && (value instanceof String)) {
            value = new JSONTokener((String) value).nextValue();
        }
        if (value == null || (value instanceof JSONObject) || (value instanceof JSONArray)) {
            return value;
        }
        if (nonJSONPropertyKey != null) {
            jsonObject = new JSONObject();
            jsonObject.putOpt(nonJSONPropertyKey, value);
            return jsonObject;
        }
        throw new C0709e("Got an unexpected non-JSON object.");
    }

    public static String m2782a(InputStream inputStream) throws IOException {
        Throwable th;
        Closeable bufferedInputStream = null;
        Closeable reader = null;
        try {
            Closeable reader2;
            Closeable bufferedInputStream2 = new BufferedInputStream(inputStream);
            try {
                reader2 = new InputStreamReader(bufferedInputStream2);
            } catch (Throwable th2) {
                th = th2;
                bufferedInputStream = bufferedInputStream2;
                C0699q.m2797a(bufferedInputStream);
                C0699q.m2797a(reader);
                throw th;
            }
            try {
                StringBuilder stringBuilder = new StringBuilder();
                char[] buffer = new char[2048];
                while (true) {
                    int n = reader2.read(buffer);
                    if (n != -1) {
                        stringBuilder.append(buffer, 0, n);
                    } else {
                        String stringBuilder2 = stringBuilder.toString();
                        C0699q.m2797a(bufferedInputStream2);
                        C0699q.m2797a(reader2);
                        return stringBuilder2;
                    }
                }
            } catch (Throwable th3) {
                th = th3;
                reader = reader2;
                bufferedInputStream = bufferedInputStream2;
                C0699q.m2797a(bufferedInputStream);
                C0699q.m2797a(reader);
                throw th;
            }
        } catch (Throwable th4) {
            th = th4;
            C0699q.m2797a(bufferedInputStream);
            C0699q.m2797a(reader);
            throw th;
        }
    }

    public static int m2771a(InputStream inputStream, OutputStream outputStream) throws IOException {
        Throwable th;
        BufferedInputStream bufferedInputStream = null;
        int totalBytes = 0;
        try {
            BufferedInputStream bufferedInputStream2 = new BufferedInputStream(inputStream);
            try {
                byte[] buffer = new byte[8192];
                while (true) {
                    int bytesRead = bufferedInputStream2.read(buffer);
                    if (bytesRead == -1) {
                        break;
                    }
                    outputStream.write(buffer, 0, bytesRead);
                    totalBytes += bytesRead;
                }
                if (bufferedInputStream2 != null) {
                    bufferedInputStream2.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                return totalBytes;
            } catch (Throwable th2) {
                th = th2;
                bufferedInputStream = bufferedInputStream2;
                if (bufferedInputStream != null) {
                    bufferedInputStream.close();
                }
                if (inputStream != null) {
                    inputStream.close();
                }
                throw th;
            }
        } catch (Throwable th3) {
            th = th3;
            if (bufferedInputStream != null) {
                bufferedInputStream.close();
            }
            if (inputStream != null) {
                inputStream.close();
            }
            throw th;
        }
    }

    private static void m2815b(Context context, String domain) {
        CookieSyncManager.createInstance(context).sync();
        CookieManager cookieManager = CookieManager.getInstance();
        String cookies = cookieManager.getCookie(domain);
        if (cookies != null) {
            for (String cookie : cookies.split(";")) {
                String[] cookieParts = cookie.split("=");
                if (cookieParts.length > 0) {
                    cookieManager.setCookie(domain, cookieParts[0].trim() + "=;expires=Sat, 1 Jan 2000 00:00:01 UTC;");
                }
            }
            cookieManager.removeExpiredCookie();
        }
    }

    public static void m2814b(Context context) {
        C0699q.m2815b(context, "facebook.com");
        C0699q.m2815b(context, ".facebook.com");
        C0699q.m2815b(context, "https://facebook.com");
        C0699q.m2815b(context, "https://.facebook.com");
    }

    public static void m2799a(String tag, Exception e) {
        if (C0717g.m2874b() && tag != null && e != null) {
            Log.d(tag, e.getClass().getSimpleName() + ": " + e.getMessage());
        }
    }

    public static void m2800a(String tag, String msg) {
        if (C0717g.m2874b() && tag != null && msg != null) {
            Log.d(tag, msg);
        }
    }

    public static void m2801a(String tag, String msg, Throwable t) {
        if (C0717g.m2874b() && !C0699q.m2807a(tag)) {
            Log.d(tag, msg, t);
        }
    }

    public static <T> boolean m2806a(T a, T b) {
        if (a == null) {
            return b == null;
        } else {
            return a.equals(b);
        }
    }

    public static void m2793a(final Context context, final String applicationId) {
        boolean canStartLoading = f1244c.compareAndSet(false, true);
        if (!C0699q.m2807a(applicationId) && !f1243b.containsKey(applicationId) && canStartLoading) {
            final String settingsKey = String.format("com.facebook.internal.APP_SETTINGS.%s", new Object[]{applicationId});
            C0717g.m2878d().execute(new Runnable() {
                public void run() {
                    SharedPreferences sharedPrefs = context.getSharedPreferences("com.facebook.internal.preferences.APP_SETTINGS", 0);
                    String settingsJSONString = sharedPrefs.getString(settingsKey, null);
                    if (!C0699q.m2807a(settingsJSONString)) {
                        JSONObject settingsJSON = null;
                        try {
                            settingsJSON = new JSONObject(settingsJSONString);
                        } catch (Exception je) {
                            C0699q.m2799a("FacebookSDK", je);
                        }
                        if (settingsJSON != null) {
                            C0699q.m2811b(applicationId, settingsJSON);
                        }
                    }
                    JSONObject resultJSON = C0699q.m2825f(applicationId);
                    if (resultJSON != null) {
                        C0699q.m2811b(applicationId, resultJSON);
                        sharedPrefs.edit().putString(settingsKey, resultJSON.toString()).apply();
                    }
                    C0699q.f1244c.set(false);
                }
            });
        }
    }

    public static C0697b m2816c(String applicationId) {
        return applicationId != null ? (C0697b) f1243b.get(applicationId) : null;
    }

    public static C0697b m2776a(String applicationId, boolean forceRequery) {
        if (!forceRequery && f1243b.containsKey(applicationId)) {
            return (C0697b) f1243b.get(applicationId);
        }
        JSONObject response = C0699q.m2825f(applicationId);
        if (response == null) {
            return null;
        }
        return C0699q.m2811b(applicationId, response);
    }

    private static C0697b m2811b(String applicationId, JSONObject settingsJSON) {
        C0673h errorClassification;
        JSONArray errorClassificationJSON = settingsJSON.optJSONArray("android_sdk_error_categories");
        if (errorClassificationJSON == null) {
            errorClassification = C0673h.m2662a();
        } else {
            errorClassification = C0673h.m2663a(errorClassificationJSON);
        }
        C0697b result = new C0697b(settingsJSON.optBoolean("supports_implicit_sdk_logging", false), settingsJSON.optString("gdpv4_nux_content", ""), settingsJSON.optBoolean("gdpv4_nux_enabled", false), settingsJSON.optBoolean("gdpv4_chrome_custom_tabs_enabled", false), settingsJSON.optInt("app_events_session_timeout", C0606b.m2528a()), C0699q.m2813b(settingsJSON.optJSONObject("android_dialog_configs")), errorClassification);
        f1243b.put(applicationId, result);
        return result;
    }

    private static JSONObject m2825f(String applicationId) {
        Bundle appSettingsParams = new Bundle();
        appSettingsParams.putString("fields", TextUtils.join(",", f1242a));
        GraphRequest request = GraphRequest.m2459a(null, applicationId, null);
        request.m2503a(true);
        request.m2498a(appSettingsParams);
        return request.m2511i().m2916b();
    }

    private static Map<String, Map<String, C0696a>> m2813b(JSONObject dialogConfigResponse) {
        HashMap<String, Map<String, C0696a>> dialogConfigMap = new HashMap();
        if (dialogConfigResponse != null) {
            JSONArray dialogConfigData = dialogConfigResponse.optJSONArray("data");
            if (dialogConfigData != null) {
                for (int i = 0; i < dialogConfigData.length(); i++) {
                    C0696a dialogConfig = C0696a.m2763b(dialogConfigData.optJSONObject(i));
                    if (dialogConfig != null) {
                        String dialogName = dialogConfig.m2764a();
                        Map<String, C0696a> featureMap = (Map) dialogConfigMap.get(dialogName);
                        if (featureMap == null) {
                            featureMap = new HashMap();
                            dialogConfigMap.put(dialogName, featureMap);
                        }
                        featureMap.put(dialogConfig.m2765b(), dialogConfig);
                    }
                }
            }
        }
        return dialogConfigMap;
    }

    public static <T> List<T> m2812b(T... array) {
        ArrayList<T> result = new ArrayList();
        for (T t : array) {
            if (t != null) {
                result.add(t);
            }
        }
        return result;
    }

    public static List<String> m2790a(JSONArray jsonArray) throws JSONException {
        ArrayList<String> result = new ArrayList();
        for (int i = 0; i < jsonArray.length(); i++) {
            result.add(jsonArray.getString(i));
        }
        return result;
    }

    public static void m2804a(JSONObject params, C0652b attributionIdentifiers, String anonymousAppDeviceGUID, boolean limitEventUsage) throws JSONException {
        boolean z = true;
        if (!(attributionIdentifiers == null || attributionIdentifiers.m2636a() == null)) {
            params.put("attribution", attributionIdentifiers.m2636a());
        }
        if (!(attributionIdentifiers == null || attributionIdentifiers.m2637b() == null)) {
            params.put("advertiser_id", attributionIdentifiers.m2637b());
            params.put("advertiser_tracking_enabled", !attributionIdentifiers.m2639d());
        }
        if (!(attributionIdentifiers == null || attributionIdentifiers.m2638c() == null)) {
            params.put("installer_package", attributionIdentifiers.m2638c());
        }
        params.put("anon_id", anonymousAppDeviceGUID);
        String str = "application_tracking_enabled";
        if (limitEventUsage) {
            z = false;
        }
        params.put(str, z);
    }

    public static void m2803a(JSONObject params, Context appContext) throws JSONException {
        Locale locale;
        JSONArray extraInfoArray = new JSONArray();
        extraInfoArray.put("a2");
        C0699q.m2820d(appContext);
        String pkgName = appContext.getPackageName();
        int versionCode = -1;
        String versionName = "";
        try {
            PackageInfo pi = appContext.getPackageManager().getPackageInfo(pkgName, 0);
            versionCode = pi.versionCode;
            versionName = pi.versionName;
        } catch (NameNotFoundException e) {
        }
        extraInfoArray.put(pkgName);
        extraInfoArray.put(versionCode);
        extraInfoArray.put(versionName);
        extraInfoArray.put(VERSION.RELEASE);
        extraInfoArray.put(Build.MODEL);
        try {
            locale = appContext.getResources().getConfiguration().locale;
        } catch (Exception e2) {
            locale = Locale.getDefault();
        }
        extraInfoArray.put(locale.getLanguage() + "_" + locale.getCountry());
        extraInfoArray.put(f1249h);
        extraInfoArray.put(f1251j);
        int width = 0;
        int height = 0;
        double density = 0.0d;
        try {
            WindowManager wm = (WindowManager) appContext.getSystemService("window");
            if (wm != null) {
                Display display = wm.getDefaultDisplay();
                DisplayMetrics displayMetrics = new DisplayMetrics();
                display.getMetrics(displayMetrics);
                width = displayMetrics.widthPixels;
                height = displayMetrics.heightPixels;
                density = (double) displayMetrics.density;
            }
        } catch (Exception e3) {
        }
        extraInfoArray.put(width);
        extraInfoArray.put(height);
        extraInfoArray.put(String.format("%.2f", new Object[]{Double.valueOf(density)}));
        extraInfoArray.put(C0699q.m2809b());
        extraInfoArray.put(f1247f);
        extraInfoArray.put(f1248g);
        extraInfoArray.put(f1250i);
        params.put("extinfo", extraInfoArray.toString());
    }

    public static Method m2786a(Class<?> clazz, String methodName, Class<?>... parameterTypes) {
        try {
            return clazz.getMethod(methodName, parameterTypes);
        } catch (NoSuchMethodException e) {
            return null;
        }
    }

    public static Method m2787a(String className, String methodName, Class<?>... parameterTypes) {
        try {
            return C0699q.m2786a(Class.forName(className), methodName, (Class[]) parameterTypes);
        } catch (ClassNotFoundException e) {
            return null;
        }
    }

    public static Object m2778a(Object receiver, Method method, Object... args) {
        Object obj = null;
        try {
            obj = method.invoke(receiver, args);
        } catch (IllegalAccessException e) {
        } catch (InvocationTargetException e2) {
        }
        return obj;
    }

    public static String m2817c(Context context) {
        if (context == null) {
            return "null";
        }
        if (context == context.getApplicationContext()) {
            return "unknown";
        }
        return context.getClass().getSimpleName();
    }

    public static long m2773a(Uri contentUri) {
        Cursor cursor = null;
        try {
            cursor = C0717g.m2880f().getContentResolver().query(contentUri, null, null, null, null);
            int sizeIndex = cursor.getColumnIndex("_size");
            cursor.moveToFirst();
            long j = cursor.getLong(sizeIndex);
            return j;
        } finally {
            if (cursor != null) {
                cursor.close();
            }
        }
    }

    public static Date m2789a(Bundle bundle, String key, Date dateBase) {
        if (bundle == null) {
            return null;
        }
        long secondsFromBase;
        Object secondsObject = bundle.get(key);
        if (secondsObject instanceof Long) {
            secondsFromBase = ((Long) secondsObject).longValue();
        } else if (!(secondsObject instanceof String)) {
            return null;
        } else {
            try {
                secondsFromBase = Long.parseLong((String) secondsObject);
            } catch (NumberFormatException e) {
                return null;
            }
        }
        if (secondsFromBase == 0) {
            return new Date(Long.MAX_VALUE);
        }
        return new Date(dateBase.getTime() + (1000 * secondsFromBase));
    }

    public static void m2796a(Parcel parcel, Map<String, String> map) {
        if (map == null) {
            parcel.writeInt(-1);
            return;
        }
        parcel.writeInt(map.size());
        for (Entry<String, String> entry : map.entrySet()) {
            parcel.writeString((String) entry.getKey());
            parcel.writeString((String) entry.getValue());
        }
    }

    public static Map<String, String> m2791a(Parcel parcel) {
        int size = parcel.readInt();
        if (size < 0) {
            return null;
        }
        Map<String, String> map = new HashMap();
        for (int i = 0; i < size; i++) {
            map.put(parcel.readString(), parcel.readString());
        }
        return map;
    }

    public static boolean m2805a(AccessToken token) {
        return token != null ? token.equals(AccessToken.m2403a()) : false;
    }

    public static void m2798a(final String accessToken, final C0599c callback) {
        JSONObject cachedValue = C0691o.m2754a(accessToken);
        if (cachedValue != null) {
            callback.mo858a(cachedValue);
            return;
        }
        C0588b graphCallback = new C0588b() {
            public void mo855a(C0723l response) {
                if (response.m2915a() != null) {
                    callback.mo857a(response.m2915a().m2433f());
                    return;
                }
                C0691o.m2755a(accessToken, response.m2916b());
                callback.mo858a(response.m2916b());
            }
        };
        GraphRequest graphRequest = C0699q.m2827g(accessToken);
        graphRequest.m2499a(graphCallback);
        graphRequest.m2512j();
    }

    public static JSONObject m2819d(String accessToken) {
        JSONObject cachedValue = C0691o.m2754a(accessToken);
        if (cachedValue != null) {
            return cachedValue;
        }
        C0723l response = C0699q.m2827g(accessToken).m2511i();
        if (response.m2915a() != null) {
            return null;
        }
        return response.m2916b();
    }

    private static GraphRequest m2827g(String accessToken) {
        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,first_name,middle_name,last_name,link");
        parameters.putString("access_token", accessToken);
        return new GraphRequest(null, "me", parameters, C0755m.GET, null);
    }

    private static int m2809b() {
        if (f1245d > 0) {
            return f1245d;
        }
        try {
            File[] cpuFiles = new File("/sys/devices/system/cpu/").listFiles(new C06953());
            if (cpuFiles != null) {
                f1245d = cpuFiles.length;
            }
        } catch (Exception e) {
        }
        if (f1245d <= 0) {
            f1245d = Math.max(Runtime.getRuntime().availableProcessors(), 1);
        }
        return f1245d;
    }

    private static void m2820d(Context appContext) {
        if (f1246e == -1 || System.currentTimeMillis() - f1246e >= 1800000) {
            f1246e = System.currentTimeMillis();
            C0699q.m2818c();
            C0699q.m2824e(appContext);
            C0699q.m2826f();
            C0699q.m2823e();
        }
    }

    private static void m2818c() {
        try {
            TimeZone tz = TimeZone.getDefault();
            f1249h = tz.getDisplayName(tz.inDaylightTime(new Date()), 0);
            f1250i = tz.getID();
        } catch (Exception e) {
        }
    }

    private static void m2824e(Context appContext) {
        if (f1251j.equals("NoCarrier")) {
            try {
                f1251j = ((TelephonyManager) appContext.getSystemService("phone")).getNetworkOperatorName();
            } catch (Exception e) {
            }
        }
    }

    private static boolean m2821d() {
        return "mounted".equals(Environment.getExternalStorageState());
    }

    private static void m2823e() {
        try {
            if (C0699q.m2821d()) {
                StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                f1248g = ((long) stat.getAvailableBlocks()) * ((long) stat.getBlockSize());
            }
            f1248g = C0699q.m2772a((double) f1248g);
        } catch (Exception e) {
        }
    }

    private static void m2826f() {
        try {
            if (C0699q.m2821d()) {
                StatFs stat = new StatFs(Environment.getExternalStorageDirectory().getPath());
                f1247f = ((long) stat.getBlockCount()) * ((long) stat.getBlockSize());
            }
            f1247f = C0699q.m2772a((double) f1247f);
        } catch (Exception e) {
        }
    }

    private static long m2772a(double bytes) {
        return Math.round(bytes / 1.073741824E9d);
    }

    public static C0698d m2777a(JSONObject result) throws JSONException {
        JSONArray data = result.getJSONObject("permissions").getJSONArray("data");
        List<String> grantedPermissions = new ArrayList(data.length());
        List<String> declinedPermissions = new ArrayList(data.length());
        for (int i = 0; i < data.length(); i++) {
            JSONObject object = data.optJSONObject(i);
            String permission = object.optString("permission");
            if (!(permission == null || permission.equals("installed"))) {
                String status = object.optString(ag.CATEGORY_STATUS);
                if (status != null) {
                    if (status.equals("granted")) {
                        grantedPermissions.add(permission);
                    } else if (status.equals("declined")) {
                        declinedPermissions.add(permission);
                    }
                }
            }
        }
        return new C0698d(grantedPermissions, declinedPermissions);
    }

    public static String m2780a(int length) {
        return new BigInteger(length * 5, new Random()).toString(32);
    }
}
