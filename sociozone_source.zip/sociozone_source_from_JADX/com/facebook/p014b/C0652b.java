package com.facebook.p014b;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.IBinder;
import android.os.IInterface;
import android.os.Looper;
import android.os.Parcel;
import android.os.RemoteException;
import com.facebook.C0709e;
import java.lang.reflect.Method;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.atomic.AtomicBoolean;

/* compiled from: AttributionIdentifiers */
public class C0652b {
    private static final String f1146a = C0652b.class.getCanonicalName();
    private static C0652b f1147g;
    private String f1148b;
    private String f1149c;
    private String f1150d;
    private boolean f1151e;
    private long f1152f;

    /* compiled from: AttributionIdentifiers */
    private static final class C0650a implements IInterface {
        private IBinder f1143a;

        C0650a(IBinder binder) {
            this.f1143a = binder;
        }

        public IBinder asBinder() {
            return this.f1143a;
        }

        public String m2627a() throws RemoteException {
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            try {
                data.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                this.f1143a.transact(1, data, reply, 0);
                reply.readException();
                String id = reply.readString();
                return id;
            } finally {
                reply.recycle();
                data.recycle();
            }
        }

        public boolean m2628b() throws RemoteException {
            boolean limitAdTracking = true;
            Parcel data = Parcel.obtain();
            Parcel reply = Parcel.obtain();
            try {
                data.writeInterfaceToken("com.google.android.gms.ads.identifier.internal.IAdvertisingIdService");
                data.writeInt(1);
                this.f1143a.transact(2, data, reply, 0);
                reply.readException();
                if (reply.readInt() == 0) {
                    limitAdTracking = false;
                }
                reply.recycle();
                data.recycle();
                return limitAdTracking;
            } catch (Throwable th) {
                reply.recycle();
                data.recycle();
            }
        }
    }

    /* compiled from: AttributionIdentifiers */
    private static final class C0651b implements ServiceConnection {
        private AtomicBoolean f1144a;
        private final BlockingQueue<IBinder> f1145b;

        private C0651b() {
            this.f1144a = new AtomicBoolean(false);
            this.f1145b = new LinkedBlockingDeque();
        }

        public void onServiceConnected(ComponentName name, IBinder service) {
            try {
                this.f1145b.put(service);
            } catch (InterruptedException e) {
            }
        }

        public void onServiceDisconnected(ComponentName name) {
        }

        public IBinder m2629a() throws InterruptedException {
            if (!this.f1144a.compareAndSet(true, true)) {
                return (IBinder) this.f1145b.take();
            }
            throw new IllegalStateException("Binder already consumed");
        }
    }

    public static com.facebook.p014b.C0652b m2630a(android.content.Context r16) {
        /* JADX: method processing error */
/*
Error: java.util.NoSuchElementException
	at java.util.HashMap$HashIterator.nextNode(HashMap.java:1431)
	at java.util.HashMap$KeyIterator.next(HashMap.java:1453)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.applyRemove(BlockFinallyExtract.java:535)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.extractFinally(BlockFinallyExtract.java:175)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.processExceptionHandler(BlockFinallyExtract.java:79)
	at jadx.core.dex.visitors.blocksmaker.BlockFinallyExtract.visit(BlockFinallyExtract.java:51)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:31)
	at jadx.core.dex.visitors.DepthTraversal.visit(DepthTraversal.java:17)
	at jadx.core.ProcessClass.process(ProcessClass.java:37)
	at jadx.core.ProcessClass.processDependencies(ProcessClass.java:59)
	at jadx.core.ProcessClass.process(ProcessClass.java:42)
	at jadx.api.JadxDecompiler.processClass(JadxDecompiler.java:306)
	at jadx.api.JavaClass.decompile(JavaClass.java:62)
	at jadx.api.JadxDecompiler$1.run(JadxDecompiler.java:199)
*/
        /*
        r0 = f1147g;
        if (r0 == 0) goto L_0x0017;
    L_0x0004:
        r4 = java.lang.System.currentTimeMillis();
        r0 = f1147g;
        r14 = r0.f1152f;
        r4 = r4 - r14;
        r14 = 3600000; // 0x36ee80 float:5.044674E-39 double:1.7786363E-317;
        r0 = (r4 > r14 ? 1 : (r4 == r14 ? 0 : -1));
        if (r0 >= 0) goto L_0x0017;
    L_0x0014:
        r0 = f1147g;
    L_0x0016:
        return r0;
    L_0x0017:
        r10 = com.facebook.p014b.C0652b.m2632b(r16);
        r8 = 0;
        r0 = 3;
        r2 = new java.lang.String[r0];	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "aid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r2[r0] = r3;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 1;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "androidid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r2[r0] = r3;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 2;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "limit_tracking";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r2[r0] = r3;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r1 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r16.getPackageManager();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "com.facebook.katana.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r0.resolveContentProvider(r3, r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 == 0) goto L_0x0056;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x003c:
        r0 = "content://com.facebook.katana.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r1 = android.net.Uri.parse(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0042:
        r11 = com.facebook.p014b.C0652b.m2635e(r16);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r11 == 0) goto L_0x004a;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0048:
        r10.f1150d = r11;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x004a:
        if (r1 != 0) goto L_0x006a;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x004c:
        r0 = com.facebook.p014b.C0652b.m2631a(r10);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r8 == 0) goto L_0x0016;
    L_0x0052:
        r8.close();
        goto L_0x0016;
    L_0x0056:
        r0 = r16.getPackageManager();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = "com.facebook.wakizashi.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r0.resolveContentProvider(r3, r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 == 0) goto L_0x0042;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0063:
        r0 = "content://com.facebook.wakizashi.provider.AttributionIdProvider";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r1 = android.net.Uri.parse(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        goto L_0x0042;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x006a:
        r0 = r16.getContentResolver();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r5 = 0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r8 = r0.query(r1, r2, r3, r4, r5);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r8 == 0) goto L_0x007d;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x0077:
        r0 = r8.moveToFirst();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 != 0) goto L_0x0087;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x007d:
        r0 = com.facebook.p014b.C0652b.m2631a(r10);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r8 == 0) goto L_0x0016;
    L_0x0083:
        r8.close();
        goto L_0x0016;
    L_0x0087:
        r0 = "aid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r7 = r8.getColumnIndex(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = "androidid";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r6 = r8.getColumnIndex(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = "limit_tracking";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r12 = r8.getColumnIndex(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r8.getString(r7);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r10.f1148b = r0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r6 <= 0) goto L_0x00b9;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00a1:
        if (r12 <= 0) goto L_0x00b9;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00a3:
        r0 = r10.m2637b();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        if (r0 != 0) goto L_0x00b9;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00a9:
        r0 = r8.getString(r6);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r10.f1149c = r0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = r8.getString(r12);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = java.lang.Boolean.parseBoolean(r0);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r10.f1151e = r0;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
    L_0x00b9:
        if (r8 == 0) goto L_0x00be;
    L_0x00bb:
        r8.close();
    L_0x00be:
        r0 = com.facebook.p014b.C0652b.m2631a(r10);
        goto L_0x0016;
    L_0x00c4:
        r9 = move-exception;
        r0 = f1146a;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = new java.lang.StringBuilder;	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3.<init>();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = "Caught unexpected exception in getAttributionId(): ";	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = r3.append(r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r4 = r9.toString();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = r3.append(r4);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r3 = r3.toString();	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        android.util.Log.d(r0, r3);	 Catch:{ Exception -> 0x00c4, all -> 0x00e9 }
        r0 = 0;
        if (r8 == 0) goto L_0x0016;
    L_0x00e4:
        r8.close();
        goto L_0x0016;
    L_0x00e9:
        r0 = move-exception;
        if (r8 == 0) goto L_0x00ef;
    L_0x00ec:
        r8.close();
    L_0x00ef:
        throw r0;
        */
        throw new UnsupportedOperationException("Method not decompiled: com.facebook.b.b.a(android.content.Context):com.facebook.b.b");
    }

    private static C0652b m2632b(Context context) {
        C0652b identifiers = C0652b.m2633c(context);
        if (identifiers != null) {
            return identifiers;
        }
        identifiers = C0652b.m2634d(context);
        if (identifiers == null) {
            return new C0652b();
        }
        return identifiers;
    }

    private static C0652b m2633c(Context context) {
        try {
            if (Looper.myLooper() == Looper.getMainLooper()) {
                throw new C0709e("getAndroidId cannot be called on the main thread.");
            }
            Method isGooglePlayServicesAvailable = C0699q.m2787a("com.google.android.gms.common.GooglePlayServicesUtil", "isGooglePlayServicesAvailable", Context.class);
            if (isGooglePlayServicesAvailable == null) {
                return null;
            }
            Object connectionResult = C0699q.m2778a(null, isGooglePlayServicesAvailable, context);
            if (!(connectionResult instanceof Integer) || ((Integer) connectionResult).intValue() != 0) {
                return null;
            }
            Method getAdvertisingIdInfo = C0699q.m2787a("com.google.android.gms.ads.identifier.AdvertisingIdClient", "getAdvertisingIdInfo", Context.class);
            if (getAdvertisingIdInfo == null) {
                return null;
            }
            Object advertisingInfo = C0699q.m2778a(null, getAdvertisingIdInfo, context);
            if (advertisingInfo == null) {
                return null;
            }
            Method getId = C0699q.m2786a(advertisingInfo.getClass(), "getId", new Class[0]);
            Method isLimitAdTrackingEnabled = C0699q.m2786a(advertisingInfo.getClass(), "isLimitAdTrackingEnabled", new Class[0]);
            if (getId == null || isLimitAdTrackingEnabled == null) {
                return null;
            }
            C0652b identifiers = new C0652b();
            identifiers.f1149c = (String) C0699q.m2778a(advertisingInfo, getId, new Object[0]);
            identifiers.f1151e = ((Boolean) C0699q.m2778a(advertisingInfo, isLimitAdTrackingEnabled, new Object[0])).booleanValue();
            return identifiers;
        } catch (Exception e) {
            C0699q.m2799a("android_id", e);
            return null;
        }
    }

    private static C0652b m2634d(Context context) {
        C0651b connection = new C0651b();
        Intent intent = new Intent("com.google.android.gms.ads.identifier.service.START");
        intent.setPackage("com.google.android.gms");
        if (context.bindService(intent, connection, 1)) {
            try {
                C0650a adInfo = new C0650a(connection.m2629a());
                C0652b identifiers = new C0652b();
                identifiers.f1149c = adInfo.m2627a();
                identifiers.f1151e = adInfo.m2628b();
                return identifiers;
            } catch (Exception exception) {
                C0699q.m2799a("android_id", exception);
            } finally {
                context.unbindService(connection);
            }
        }
        return null;
    }

    private static C0652b m2631a(C0652b identifiers) {
        identifiers.f1152f = System.currentTimeMillis();
        f1147g = identifiers;
        return identifiers;
    }

    public String m2636a() {
        return this.f1148b;
    }

    public String m2637b() {
        return this.f1149c;
    }

    public String m2638c() {
        return this.f1150d;
    }

    public boolean m2639d() {
        return this.f1151e;
    }

    private static String m2635e(Context context) {
        PackageManager packageManager = context.getPackageManager();
        if (packageManager != null) {
            return packageManager.getInstallerPackageName(context.getPackageName());
        }
        return null;
    }
}
