package com.facebook.p014b;

/* compiled from: InternalSettings */
public class C0677j {
    private static volatile String f1193a;

    public static String m2689a() {
        return f1193a;
    }
}
