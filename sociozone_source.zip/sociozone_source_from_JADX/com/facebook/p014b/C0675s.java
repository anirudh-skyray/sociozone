package com.facebook.p014b;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.WindowManager;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import com.facebook.AccessToken;
import com.facebook.C0709e;
import com.facebook.C0710d;
import com.facebook.C0711f;
import com.facebook.C0717g;
import com.facebook.C0719i;
import com.facebook.C0787t.C0782a;
import com.facebook.C0787t.C0785d;
import com.facebook.FacebookRequestError;
import java.util.Locale;

/* compiled from: WebDialog */
public class C0675s extends Dialog {
    private String f1181a;
    private String f1182b;
    private C0666c f1183c;
    private WebView f1184d;
    private ProgressDialog f1185e;
    private ImageView f1186f;
    private FrameLayout f1187g;
    private boolean f1188h;
    private boolean f1189i;
    private boolean f1190j;

    /* compiled from: WebDialog */
    public interface C0666c {
        void mo861a(Bundle bundle, C0709e c0709e);
    }

    /* compiled from: WebDialog */
    class C07011 implements OnCancelListener {
        final /* synthetic */ C0675s f1253a;

        C07011(C0675s this$0) {
            this.f1253a = this$0;
        }

        public void onCancel(DialogInterface dialogInterface) {
            this.f1253a.cancel();
        }
    }

    /* compiled from: WebDialog */
    class C07022 implements OnClickListener {
        final /* synthetic */ C0675s f1254a;

        C07022(C0675s this$0) {
            this.f1254a = this$0;
        }

        public void onClick(View v) {
            this.f1254a.cancel();
        }
    }

    /* compiled from: WebDialog */
    class C07044 implements OnTouchListener {
        final /* synthetic */ C0675s f1256a;

        C07044(C0675s this$0) {
            this.f1256a = this$0;
        }

        public boolean onTouch(View v, MotionEvent event) {
            if (!v.hasFocus()) {
                v.requestFocus();
            }
            return false;
        }
    }

    /* compiled from: WebDialog */
    public static class C0705a {
        private Context f1257a;
        private String f1258b;
        private String f1259c;
        private int f1260d;
        private C0666c f1261e;
        private Bundle f1262f;
        private AccessToken f1263g;

        public C0705a(Context context, String action, Bundle parameters) {
            this.f1263g = AccessToken.m2403a();
            if (this.f1263g == null) {
                String applicationId = C0699q.m2781a(context);
                if (applicationId != null) {
                    this.f1258b = applicationId;
                } else {
                    throw new C0709e("Attempted to create a builder without a valid access token or a valid default Application ID.");
                }
            }
            m2839a(context, action, parameters);
        }

        public C0705a(Context context, String applicationId, String action, Bundle parameters) {
            if (applicationId == null) {
                applicationId = C0699q.m2781a(context);
            }
            C0700r.m2831a(applicationId, "applicationId");
            this.f1258b = applicationId;
            m2839a(context, action, parameters);
        }

        public C0705a m2840a(C0666c listener) {
            this.f1261e = listener;
            return this;
        }

        public C0675s mo881a() {
            if (this.f1263g != null) {
                this.f1262f.putString("app_id", this.f1263g.m2416h());
                this.f1262f.putString("access_token", this.f1263g.m2410b());
            } else {
                this.f1262f.putString("app_id", this.f1258b);
            }
            return new C0675s(this.f1257a, this.f1259c, this.f1262f, this.f1260d, this.f1261e);
        }

        public String m2842b() {
            return this.f1258b;
        }

        public Context m2843c() {
            return this.f1257a;
        }

        public int m2844d() {
            return this.f1260d;
        }

        public Bundle m2845e() {
            return this.f1262f;
        }

        public C0666c m2846f() {
            return this.f1261e;
        }

        private void m2839a(Context context, String action, Bundle parameters) {
            this.f1257a = context;
            this.f1259c = action;
            if (parameters != null) {
                this.f1262f = parameters;
            } else {
                this.f1262f = new Bundle();
            }
        }
    }

    /* compiled from: WebDialog */
    private class C0706b extends WebViewClient {
        final /* synthetic */ C0675s f1264a;

        private C0706b(C0675s c0675s) {
            this.f1264a = c0675s;
        }

        public boolean shouldOverrideUrlLoading(WebView view, String url) {
            C0699q.m2800a("FacebookSDK.WebDialog", "Redirect URL: " + url);
            if (url.startsWith(this.f1264a.f1182b)) {
                Bundle values = this.f1264a.mo864a(url);
                String error = values.getString("error");
                if (error == null) {
                    error = values.getString("error_type");
                }
                String errorMessage = values.getString("error_msg");
                if (errorMessage == null) {
                    errorMessage = values.getString("error_message");
                }
                if (errorMessage == null) {
                    errorMessage = values.getString("error_description");
                }
                String errorCodeString = values.getString("error_code");
                int errorCode = -1;
                if (!C0699q.m2807a(errorCodeString)) {
                    try {
                        errorCode = Integer.parseInt(errorCodeString);
                    } catch (NumberFormatException e) {
                        errorCode = -1;
                    }
                }
                if (C0699q.m2807a(error) && C0699q.m2807a(errorMessage) && errorCode == -1) {
                    this.f1264a.m2679a(values);
                } else if (error != null && (error.equals("access_denied") || error.equals("OAuthAccessDeniedException"))) {
                    this.f1264a.cancel();
                } else if (errorCode == 4201) {
                    this.f1264a.cancel();
                } else {
                    this.f1264a.m2681a(new C0719i(new FacebookRequestError(errorCode, error, errorMessage), errorMessage));
                }
                return true;
            } else if (url.startsWith("fbconnect://cancel")) {
                this.f1264a.cancel();
                return true;
            } else if (url.contains("touch")) {
                return false;
            } else {
                try {
                    this.f1264a.getContext().startActivity(new Intent("android.intent.action.VIEW", Uri.parse(url)));
                    return true;
                } catch (ActivityNotFoundException e2) {
                    return false;
                }
            }
        }

        public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
            super.onReceivedError(view, errorCode, description, failingUrl);
            this.f1264a.m2681a(new C0710d(description, errorCode, failingUrl));
        }

        public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
            super.onReceivedSslError(view, handler, error);
            handler.cancel();
            this.f1264a.m2681a(new C0710d(null, -11, null));
        }

        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            C0699q.m2800a("FacebookSDK.WebDialog", "Webview loading URL: " + url);
            super.onPageStarted(view, url, favicon);
            if (!this.f1264a.f1189i) {
                this.f1264a.f1185e.show();
            }
        }

        public void onPageFinished(WebView view, String url) {
            super.onPageFinished(view, url);
            if (!this.f1264a.f1189i) {
                this.f1264a.f1185e.dismiss();
            }
            this.f1264a.f1187g.setBackgroundColor(0);
            this.f1264a.f1184d.setVisibility(0);
            this.f1264a.f1186f.setVisibility(0);
            this.f1264a.f1190j = true;
        }
    }

    public C0675s(Context context, String url) {
        this(context, url, C0717g.m2885k());
    }

    public C0675s(Context context, String url, int theme) {
        if (theme == 0) {
            theme = C0717g.m2885k();
        }
        super(context, theme);
        this.f1182b = "fbconnect://success";
        this.f1188h = false;
        this.f1189i = false;
        this.f1190j = false;
        this.f1181a = url;
    }

    public C0675s(Context context, String action, Bundle parameters, int theme, C0666c listener) {
        if (theme == 0) {
            theme = C0717g.m2885k();
        }
        super(context, theme);
        this.f1182b = "fbconnect://success";
        this.f1188h = false;
        this.f1189i = false;
        this.f1190j = false;
        if (parameters == null) {
            parameters = new Bundle();
        }
        parameters.putString("redirect_uri", "fbconnect://success");
        parameters.putString("display", "touch");
        parameters.putString("sdk", String.format(Locale.ROOT, "android-%s", new Object[]{C0717g.m2881g()}));
        this.f1181a = C0699q.m2774a(C0692p.m2756a(), C0692p.m2759d() + "/" + "dialog/" + action, parameters).toString();
        this.f1183c = listener;
    }

    public void m2680a(C0666c listener) {
        this.f1183c = listener;
    }

    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == 4) {
            cancel();
        }
        return super.onKeyDown(keyCode, event);
    }

    public void dismiss() {
        if (this.f1184d != null) {
            this.f1184d.stopLoading();
        }
        if (!(this.f1189i || this.f1185e == null || !this.f1185e.isShowing())) {
            this.f1185e.dismiss();
        }
        super.dismiss();
    }

    protected void onStart() {
        super.onStart();
        m2686d();
    }

    public void onDetachedFromWindow() {
        this.f1189i = true;
        super.onDetachedFromWindow();
    }

    public void onAttachedToWindow() {
        this.f1189i = false;
        super.onAttachedToWindow();
    }

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.f1185e = new ProgressDialog(getContext());
        this.f1185e.requestWindowFeature(1);
        this.f1185e.setMessage(getContext().getString(C0785d.com_facebook_loading));
        this.f1185e.setCanceledOnTouchOutside(false);
        this.f1185e.setOnCancelListener(new C07011(this));
        requestWindowFeature(1);
        this.f1187g = new FrameLayout(getContext());
        m2686d();
        getWindow().setGravity(17);
        getWindow().setSoftInputMode(16);
        m2676e();
        m2670a((this.f1186f.getDrawable().getIntrinsicWidth() / 2) + 1);
        this.f1187g.addView(this.f1186f, new LayoutParams(-2, -2));
        setContentView(this.f1187g);
    }

    protected void m2683b(String expectedRedirectUrl) {
        this.f1182b = expectedRedirectUrl;
    }

    protected Bundle mo864a(String urlString) {
        Uri u = Uri.parse(urlString);
        Bundle b = C0699q.m2810b(u.getQuery());
        b.putAll(C0699q.m2810b(u.getFragment()));
        return b;
    }

    protected boolean m2682a() {
        return this.f1188h;
    }

    protected boolean m2684b() {
        return this.f1190j;
    }

    protected WebView m2685c() {
        return this.f1184d;
    }

    public void m2686d() {
        Display display = ((WindowManager) getContext().getSystemService("window")).getDefaultDisplay();
        DisplayMetrics metrics = new DisplayMetrics();
        display.getMetrics(metrics);
        getWindow().setLayout(Math.min(m2668a(metrics.widthPixels < metrics.heightPixels ? metrics.widthPixels : metrics.heightPixels, metrics.density, 480, 800), metrics.widthPixels), Math.min(m2668a(metrics.widthPixels < metrics.heightPixels ? metrics.heightPixels : metrics.widthPixels, metrics.density, 800, 1280), metrics.heightPixels));
    }

    private int m2668a(int screenSize, float density, int noPaddingSize, int maxPaddingSize) {
        double scaleFactor;
        int scaledSize = (int) (((float) screenSize) / density);
        if (scaledSize <= noPaddingSize) {
            scaleFactor = 1.0d;
        } else if (scaledSize >= maxPaddingSize) {
            scaleFactor = 0.5d;
        } else {
            scaleFactor = 0.5d + ((((double) (maxPaddingSize - scaledSize)) / ((double) (maxPaddingSize - noPaddingSize))) * 0.5d);
        }
        return (int) (((double) screenSize) * scaleFactor);
    }

    protected void m2679a(Bundle values) {
        if (this.f1183c != null && !this.f1188h) {
            this.f1188h = true;
            this.f1183c.mo861a(values, null);
            dismiss();
        }
    }

    protected void m2681a(Throwable error) {
        if (this.f1183c != null && !this.f1188h) {
            C0709e facebookException;
            this.f1188h = true;
            if (error instanceof C0709e) {
                facebookException = (C0709e) error;
            } else {
                facebookException = new C0709e(error);
            }
            this.f1183c.mo861a(null, facebookException);
            dismiss();
        }
    }

    public void cancel() {
        if (this.f1183c != null && !this.f1188h) {
            m2681a(new C0711f());
        }
    }

    private void m2676e() {
        this.f1186f = new ImageView(getContext());
        this.f1186f.setOnClickListener(new C07022(this));
        this.f1186f.setImageDrawable(getContext().getResources().getDrawable(C0782a.com_facebook_close));
        this.f1186f.setVisibility(4);
    }

    @SuppressLint({"SetJavaScriptEnabled"})
    private void m2670a(int margin) {
        LinearLayout webViewContainer = new LinearLayout(getContext());
        this.f1184d = new WebView(this, getContext().getApplicationContext()) {
            final /* synthetic */ C0675s f1255a;

            public void onWindowFocusChanged(boolean hasWindowFocus) {
                try {
                    super.onWindowFocusChanged(hasWindowFocus);
                } catch (NullPointerException e) {
                }
            }
        };
        this.f1184d.setVerticalScrollBarEnabled(false);
        this.f1184d.setHorizontalScrollBarEnabled(false);
        this.f1184d.setWebViewClient(new C0706b());
        this.f1184d.getSettings().setJavaScriptEnabled(true);
        this.f1184d.loadUrl(this.f1181a);
        this.f1184d.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        this.f1184d.setVisibility(4);
        this.f1184d.getSettings().setSavePassword(false);
        this.f1184d.getSettings().setSaveFormData(false);
        this.f1184d.setFocusable(true);
        this.f1184d.setFocusableInTouchMode(true);
        this.f1184d.setOnTouchListener(new C07044(this));
        webViewContainer.setPadding(margin, margin, margin, margin);
        webViewContainer.addView(this.f1184d);
        webViewContainer.setBackgroundColor(-872415232);
        this.f1187g.addView(webViewContainer);
    }
}
