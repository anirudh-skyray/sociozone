package com.facebook.p014b;

import android.util.Log;
import com.facebook.C0717g;
import com.facebook.C0757o;
import java.util.HashMap;
import java.util.Map.Entry;

/* compiled from: Logger */
public class C0680l {
    private static final HashMap<String, String> f1198a = new HashMap();
    private final C0757o f1199b;
    private final String f1200c;
    private StringBuilder f1201d;
    private int f1202e = 3;

    public static synchronized void m2698a(String original, String replace) {
        synchronized (C0680l.class) {
            f1198a.put(original, replace);
        }
    }

    public static synchronized void m2697a(String accessToken) {
        synchronized (C0680l.class) {
            if (!C0717g.m2872a(C0757o.INCLUDE_ACCESS_TOKENS)) {
                C0680l.m2698a(accessToken, "ACCESS_TOKEN_REMOVED");
            }
        }
    }

    public static void m2695a(C0757o behavior, String tag, String string) {
        C0680l.m2693a(behavior, 3, tag, string);
    }

    public static void m2696a(C0757o behavior, String tag, String format, Object... args) {
        if (C0717g.m2872a(behavior)) {
            C0680l.m2693a(behavior, 3, tag, String.format(format, args));
        }
    }

    public static void m2694a(C0757o behavior, int priority, String tag, String format, Object... args) {
        if (C0717g.m2872a(behavior)) {
            C0680l.m2693a(behavior, priority, tag, String.format(format, args));
        }
    }

    public static void m2693a(C0757o behavior, int priority, String tag, String string) {
        if (C0717g.m2872a(behavior)) {
            string = C0680l.m2700d(string);
            if (!tag.startsWith("FacebookSDK.")) {
                tag = "FacebookSDK." + tag;
            }
            Log.println(priority, tag, string);
            if (behavior == C0757o.DEVELOPER_ERRORS) {
                new Exception().printStackTrace();
            }
        }
    }

    private static synchronized String m2700d(String string) {
        synchronized (C0680l.class) {
            for (Entry<String, String> entry : f1198a.entrySet()) {
                string = string.replace((CharSequence) entry.getKey(), (CharSequence) entry.getValue());
            }
        }
        return string;
    }

    public C0680l(C0757o behavior, String tag) {
        C0700r.m2831a(tag, "tag");
        this.f1199b = behavior;
        this.f1200c = "FacebookSDK." + tag;
        this.f1201d = new StringBuilder();
    }

    public void m2701a() {
        m2704b(this.f1201d.toString());
        this.f1201d = new StringBuilder();
    }

    public void m2704b(String string) {
        C0680l.m2693a(this.f1199b, this.f1202e, this.f1200c, string);
    }

    public void m2705c(String string) {
        if (m2699b()) {
            this.f1201d.append(string);
        }
    }

    public void m2703a(String format, Object... args) {
        if (m2699b()) {
            this.f1201d.append(String.format(format, args));
        }
    }

    public void m2702a(String key, Object value) {
        m2703a("  %s:\t%s\n", key, value);
    }

    private boolean m2699b() {
        return C0717g.m2872a(this.f1199b);
    }
}
