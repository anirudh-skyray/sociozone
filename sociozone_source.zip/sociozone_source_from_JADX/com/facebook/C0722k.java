package com.facebook;

import android.os.Handler;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

/* compiled from: GraphRequestBatch */
public class C0722k extends AbstractList<GraphRequest> {
    private static AtomicInteger f1312a = new AtomicInteger();
    private Handler f1313b;
    private List<GraphRequest> f1314c;
    private int f1315d;
    private final String f1316e;
    private List<C0643a> f1317f;
    private String f1318g;

    /* compiled from: GraphRequestBatch */
    public interface C0643a {
        void mo859a(C0722k c0722k);
    }

    /* compiled from: GraphRequestBatch */
    public interface C0721b extends C0643a {
        void m2891a(C0722k c0722k, long j, long j2);
    }

    public /* synthetic */ void add(int i, Object obj) {
        m2894a(i, (GraphRequest) obj);
    }

    public /* synthetic */ boolean add(Object obj) {
        return m2897a((GraphRequest) obj);
    }

    public /* synthetic */ Object get(int i) {
        return m2893a(i);
    }

    public /* synthetic */ Object remove(int i) {
        return m2898b(i);
    }

    public /* synthetic */ Object set(int i, Object obj) {
        return m2899b(i, (GraphRequest) obj);
    }

    public C0722k() {
        this.f1314c = new ArrayList();
        this.f1315d = 0;
        this.f1316e = Integer.valueOf(f1312a.incrementAndGet()).toString();
        this.f1317f = new ArrayList();
        this.f1314c = new ArrayList();
    }

    public C0722k(Collection<GraphRequest> requests) {
        this.f1314c = new ArrayList();
        this.f1315d = 0;
        this.f1316e = Integer.valueOf(f1312a.incrementAndGet()).toString();
        this.f1317f = new ArrayList();
        this.f1314c = new ArrayList(requests);
    }

    public C0722k(GraphRequest... requests) {
        this.f1314c = new ArrayList();
        this.f1315d = 0;
        this.f1316e = Integer.valueOf(f1312a.incrementAndGet()).toString();
        this.f1317f = new ArrayList();
        this.f1314c = Arrays.asList(requests);
    }

    public int m2892a() {
        return this.f1315d;
    }

    public void m2896a(C0643a callback) {
        if (!this.f1317f.contains(callback)) {
            this.f1317f.add(callback);
        }
    }

    public final boolean m2897a(GraphRequest request) {
        return this.f1314c.add(request);
    }

    public final void m2894a(int location, GraphRequest request) {
        this.f1314c.add(location, request);
    }

    public final void clear() {
        this.f1314c.clear();
    }

    public final GraphRequest m2893a(int i) {
        return (GraphRequest) this.f1314c.get(i);
    }

    public final GraphRequest m2898b(int location) {
        return (GraphRequest) this.f1314c.remove(location);
    }

    public final GraphRequest m2899b(int location, GraphRequest request) {
        return (GraphRequest) this.f1314c.set(location, request);
    }

    public final int size() {
        return this.f1314c.size();
    }

    final String m2900b() {
        return this.f1316e;
    }

    final Handler m2901c() {
        return this.f1313b;
    }

    final void m2895a(Handler callbackHandler) {
        this.f1313b = callbackHandler;
    }

    final List<GraphRequest> m2902d() {
        return this.f1314c;
    }

    final List<C0643a> m2903e() {
        return this.f1317f;
    }

    public final String m2904f() {
        return this.f1318g;
    }

    public final List<C0723l> m2905g() {
        return m2907i();
    }

    public final C0720j m2906h() {
        return m2908j();
    }

    List<C0723l> m2907i() {
        return GraphRequest.m2480b(this);
    }

    C0720j m2908j() {
        return GraphRequest.m2484c(this);
    }
}
