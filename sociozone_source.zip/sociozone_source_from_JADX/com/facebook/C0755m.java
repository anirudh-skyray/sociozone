package com.facebook;

/* compiled from: HttpMethod */
public enum C0755m {
    GET,
    POST,
    DELETE
}
