package com.facebook;

import android.os.Handler;
import com.facebook.C0722k.C0643a;
import com.facebook.C0722k.C0721b;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Map;

/* compiled from: ProgressOutputStream */
class C0763s extends FilterOutputStream implements C0760u {
    private final Map<GraphRequest, C0789v> f1447a;
    private final C0722k f1448b;
    private final long f1449c = C0717g.m2882h();
    private long f1450d;
    private long f1451e;
    private long f1452f;
    private C0789v f1453g;

    C0763s(OutputStream out, C0722k requests, Map<GraphRequest, C0789v> progressMap, long maxProgress) {
        super(out);
        this.f1448b = requests;
        this.f1447a = progressMap;
        this.f1452f = maxProgress;
    }

    private void m3124a(long size) {
        if (this.f1453g != null) {
            this.f1453g.m3197a(size);
        }
        this.f1450d += size;
        if (this.f1450d >= this.f1451e + this.f1449c || this.f1450d >= this.f1452f) {
            m3123a();
        }
    }

    private void m3123a() {
        if (this.f1450d > this.f1451e) {
            for (C0643a callback : this.f1448b.m2903e()) {
                if (callback instanceof C0721b) {
                    Handler callbackHandler = this.f1448b.m2901c();
                    final C0721b progressCallback = (C0721b) callback;
                    if (callbackHandler == null) {
                        progressCallback.m2891a(this.f1448b, this.f1450d, this.f1452f);
                    } else {
                        callbackHandler.post(new Runnable(this) {
                            final /* synthetic */ C0763s f1446b;

                            public void run() {
                                progressCallback.m2891a(this.f1446b.f1448b, this.f1446b.f1450d, this.f1446b.f1452f);
                            }
                        });
                    }
                }
            }
            this.f1451e = this.f1450d;
        }
    }

    public void mo889a(GraphRequest request) {
        this.f1453g = request != null ? (C0789v) this.f1447a.get(request) : null;
    }

    public void write(byte[] buffer) throws IOException {
        this.out.write(buffer);
        m3124a((long) buffer.length);
    }

    public void write(byte[] buffer, int offset, int length) throws IOException {
        this.out.write(buffer, offset, length);
        m3124a((long) length);
    }

    public void write(int oneByte) throws IOException {
        this.out.write(oneByte);
        m3124a(1);
    }

    public void close() throws IOException {
        super.close();
        for (C0789v p : this.f1447a.values()) {
            p.m3196a();
        }
        m3123a();
    }
}
