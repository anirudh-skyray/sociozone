package com.facebook;

import android.graphics.Bitmap;
import android.graphics.Bitmap.CompressFormat;
import android.net.Uri;
import android.net.Uri.Builder;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.ParcelFileDescriptor;
import android.os.ParcelFileDescriptor.AutoCloseInputStream;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.text.TextUtils;
import android.util.Log;
import android.util.Pair;
import com.facebook.C0722k.C0643a;
import com.facebook.C0722k.C0721b;
import com.facebook.p014b.C0677j;
import com.facebook.p014b.C0680l;
import com.facebook.p014b.C0692p;
import com.facebook.p014b.C0699q;
import com.facebook.p014b.C0700r;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPOutputStream;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class GraphRequest {
    public static final String f999a = GraphRequest.class.getSimpleName();
    private static String f1000b;
    private static Pattern f1001c = Pattern.compile("^/?v\\d+\\.\\d+/(.*)");
    private static volatile String f1002q;
    private AccessToken f1003d;
    private C0755m f1004e;
    private String f1005f;
    private JSONObject f1006g;
    private String f1007h;
    private String f1008i;
    private boolean f1009j;
    private Bundle f1010k;
    private C0588b f1011l;
    private String f1012m;
    private Object f1013n;
    private String f1014o;
    private boolean f1015p;

    public interface C0588b {
        void mo855a(C0723l c0723l);
    }

    static class C05891 implements C0588b {
        final /* synthetic */ C0596c f984a;

        public void mo855a(C0723l response) {
            if (this.f984a != null) {
                this.f984a.m2445a(response.m2916b(), response);
            }
        }
    }

    private interface C0592d {
        void mo856a(String str, String str2) throws IOException;
    }

    public static class ParcelableResourceWithMimeType<RESOURCE extends Parcelable> implements Parcelable {
        public static final Creator<ParcelableResourceWithMimeType> CREATOR = new C05941();
        private final String f991a;
        private final RESOURCE f992b;

        static class C05941 implements Creator<ParcelableResourceWithMimeType> {
            C05941() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2439a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2440a(i);
            }

            public ParcelableResourceWithMimeType m2439a(Parcel in) {
                return new ParcelableResourceWithMimeType(in);
            }

            public ParcelableResourceWithMimeType[] m2440a(int size) {
                return new ParcelableResourceWithMimeType[size];
            }
        }

        public String m2441a() {
            return this.f991a;
        }

        public RESOURCE m2442b() {
            return this.f992b;
        }

        public int describeContents() {
            return 1;
        }

        public void writeToParcel(Parcel out, int flags) {
            out.writeString(this.f991a);
            out.writeParcelable(this.f992b, flags);
        }

        private ParcelableResourceWithMimeType(Parcel in) {
            this.f991a = in.readString();
            this.f992b = in.readParcelable(C0717g.m2880f().getClassLoader());
        }
    }

    private static class C0595a {
        private final GraphRequest f993a;
        private final Object f994b;

        public C0595a(GraphRequest request, Object value) {
            this.f993a = request;
            this.f994b = value;
        }

        public GraphRequest m2443a() {
            return this.f993a;
        }

        public Object m2444b() {
            return this.f994b;
        }
    }

    public interface C0596c {
        void m2445a(JSONObject jSONObject, C0723l c0723l);
    }

    public interface C0597e extends C0588b {
        void m2446a(long j, long j2);
    }

    private static class C0598f implements C0592d {
        private final OutputStream f995a;
        private final C0680l f996b;
        private boolean f997c = true;
        private boolean f998d = false;

        public C0598f(OutputStream outputStream, C0680l logger, boolean useUrlEncode) {
            this.f995a = outputStream;
            this.f996b = logger;
            this.f998d = useUrlEncode;
        }

        public void m2452a(String key, Object value, GraphRequest request) throws IOException {
            if (this.f995a instanceof C0760u) {
                ((C0760u) this.f995a).mo889a(request);
            }
            if (GraphRequest.m2489e(value)) {
                mo856a(key, GraphRequest.m2490f(value));
            } else if (value instanceof Bitmap) {
                m2449a(key, (Bitmap) value);
            } else if (value instanceof byte[]) {
                m2456a(key, (byte[]) value);
            } else if (value instanceof Uri) {
                m2450a(key, (Uri) value, null);
            } else if (value instanceof ParcelFileDescriptor) {
                m2451a(key, (ParcelFileDescriptor) value, null);
            } else if (value instanceof ParcelableResourceWithMimeType) {
                ParcelableResourceWithMimeType resourceWithMimeType = (ParcelableResourceWithMimeType) value;
                Parcelable resource = resourceWithMimeType.m2442b();
                String mimeType = resourceWithMimeType.m2441a();
                if (resource instanceof ParcelFileDescriptor) {
                    m2451a(key, (ParcelFileDescriptor) resource, mimeType);
                } else if (resource instanceof Uri) {
                    m2450a(key, (Uri) resource, mimeType);
                } else {
                    throw m2447b();
                }
            } else {
                throw m2447b();
            }
        }

        private RuntimeException m2447b() {
            return new IllegalArgumentException("value is not a supported type.");
        }

        public void m2455a(String key, JSONArray requestJsonArray, Collection<GraphRequest> requests) throws IOException, JSONException {
            if (this.f995a instanceof C0760u) {
                C0760u requestOutputStream = this.f995a;
                m2454a(key, null, null);
                m2457a("[", new Object[0]);
                int i = 0;
                for (GraphRequest request : requests) {
                    JSONObject requestJson = requestJsonArray.getJSONObject(i);
                    requestOutputStream.mo889a(request);
                    if (i > 0) {
                        m2457a(",%s", requestJson.toString());
                    } else {
                        m2457a("%s", requestJson.toString());
                    }
                    i++;
                }
                m2457a("]", new Object[0]);
                if (this.f996b != null) {
                    this.f996b.m2702a("    " + key, requestJsonArray.toString());
                    return;
                }
                return;
            }
            mo856a(key, requestJsonArray.toString());
        }

        public void mo856a(String key, String value) throws IOException {
            m2454a(key, null, null);
            m2458b("%s", value);
            m2448a();
            if (this.f996b != null) {
                this.f996b.m2702a("    " + key, (Object) value);
            }
        }

        public void m2449a(String key, Bitmap bitmap) throws IOException {
            m2454a(key, key, "image/png");
            bitmap.compress(CompressFormat.PNG, 100, this.f995a);
            m2458b("", new Object[0]);
            m2448a();
            if (this.f996b != null) {
                this.f996b.m2702a("    " + key, (Object) "<Image>");
            }
        }

        public void m2456a(String key, byte[] bytes) throws IOException {
            m2454a(key, key, "content/unknown");
            this.f995a.write(bytes);
            m2458b("", new Object[0]);
            m2448a();
            if (this.f996b != null) {
                this.f996b.m2702a("    " + key, String.format(Locale.ROOT, "<Data: %d>", new Object[]{Integer.valueOf(bytes.length)}));
            }
        }

        public void m2450a(String key, Uri contentUri, String mimeType) throws IOException {
            if (mimeType == null) {
                mimeType = "content/unknown";
            }
            m2454a(key, key, mimeType);
            int totalBytes = 0;
            if (this.f995a instanceof C0761r) {
                ((C0761r) this.f995a).m3119a(C0699q.m2773a(contentUri));
            } else {
                totalBytes = 0 + C0699q.m2771a(C0717g.m2880f().getContentResolver().openInputStream(contentUri), this.f995a);
            }
            m2458b("", new Object[0]);
            m2448a();
            if (this.f996b != null) {
                this.f996b.m2702a("    " + key, String.format(Locale.ROOT, "<Data: %d>", new Object[]{Integer.valueOf(totalBytes)}));
            }
        }

        public void m2451a(String key, ParcelFileDescriptor descriptor, String mimeType) throws IOException {
            if (mimeType == null) {
                mimeType = "content/unknown";
            }
            m2454a(key, key, mimeType);
            int totalBytes = 0;
            if (this.f995a instanceof C0761r) {
                ((C0761r) this.f995a).m3119a(descriptor.getStatSize());
            } else {
                totalBytes = 0 + C0699q.m2771a(new AutoCloseInputStream(descriptor), this.f995a);
            }
            m2458b("", new Object[0]);
            m2448a();
            if (this.f996b != null) {
                this.f996b.m2702a("    " + key, String.format(Locale.ROOT, "<Data: %d>", new Object[]{Integer.valueOf(totalBytes)}));
            }
        }

        public void m2448a() throws IOException {
            if (this.f998d) {
                this.f995a.write("&".getBytes());
                return;
            }
            m2458b("--%s", "3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f");
        }

        public void m2454a(String name, String filename, String contentType) throws IOException {
            if (this.f998d) {
                this.f995a.write(String.format("%s=", new Object[]{name}).getBytes());
                return;
            }
            m2457a("Content-Disposition: form-data; name=\"%s\"", name);
            if (filename != null) {
                m2457a("; filename=\"%s\"", filename);
            }
            m2458b("", new Object[0]);
            if (contentType != null) {
                m2458b("%s: %s", "Content-Type", contentType);
            }
            m2458b("", new Object[0]);
        }

        public void m2457a(String format, Object... args) throws IOException {
            if (this.f998d) {
                this.f995a.write(URLEncoder.encode(String.format(Locale.US, format, args), "UTF-8").getBytes());
                return;
            }
            if (this.f997c) {
                this.f995a.write("--".getBytes());
                this.f995a.write("3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f".getBytes());
                this.f995a.write("\r\n".getBytes());
                this.f997c = false;
            }
            this.f995a.write(String.format(format, args).getBytes());
        }

        public void m2458b(String format, Object... args) throws IOException {
            m2457a(format, args);
            if (!this.f998d) {
                m2457a("\r\n", new Object[0]);
            }
        }
    }

    public GraphRequest() {
        this(null, null, null, null, null);
    }

    public GraphRequest(AccessToken accessToken, String graphPath, Bundle parameters, C0755m httpMethod, C0588b callback) {
        this(accessToken, graphPath, parameters, httpMethod, callback, null);
    }

    public GraphRequest(AccessToken accessToken, String graphPath, Bundle parameters, C0755m httpMethod, C0588b callback, String version) {
        this.f1009j = true;
        this.f1015p = false;
        this.f1003d = accessToken;
        this.f1005f = graphPath;
        this.f1014o = version;
        m2499a(callback);
        m2500a(httpMethod);
        if (parameters != null) {
            this.f1010k = new Bundle(parameters);
        } else {
            this.f1010k = new Bundle();
        }
        if (this.f1014o == null) {
            this.f1014o = C0692p.m2759d();
        }
    }

    public static GraphRequest m2460a(AccessToken accessToken, String graphPath, JSONObject graphObject, C0588b callback) {
        GraphRequest request = new GraphRequest(accessToken, graphPath, null, C0755m.POST, callback);
        request.m2502a(graphObject);
        return request;
    }

    public static GraphRequest m2459a(AccessToken accessToken, String graphPath, C0588b callback) {
        return new GraphRequest(accessToken, graphPath, null, null, callback);
    }

    public final JSONObject m2497a() {
        return this.f1006g;
    }

    public final void m2502a(JSONObject graphObject) {
        this.f1006g = graphObject;
    }

    public final String m2504b() {
        return this.f1005f;
    }

    public final C0755m m2505c() {
        return this.f1004e;
    }

    public final void m2500a(C0755m httpMethod) {
        if (this.f1012m == null || httpMethod == C0755m.GET) {
            if (httpMethod == null) {
                httpMethod = C0755m.GET;
            }
            this.f1004e = httpMethod;
            return;
        }
        throw new C0709e("Can't change HTTP method on request with overridden URL.");
    }

    public final String m2506d() {
        return this.f1014o;
    }

    public final void m2503a(boolean skipClientToken) {
        this.f1015p = skipClientToken;
    }

    public final Bundle m2507e() {
        return this.f1010k;
    }

    public final void m2498a(Bundle parameters) {
        this.f1010k = parameters;
    }

    public final AccessToken m2508f() {
        return this.f1003d;
    }

    public final C0588b m2509g() {
        return this.f1011l;
    }

    public final void m2499a(final C0588b callback) {
        if (C0717g.m2872a(C0757o.GRAPH_API_DEBUG_INFO) || C0717g.m2872a(C0757o.GRAPH_API_DEBUG_WARNING)) {
            this.f1011l = new C0588b(this) {
                final /* synthetic */ GraphRequest f986b;

                public void mo855a(C0723l response) {
                    JSONObject debug;
                    JSONArray debugMessages;
                    JSONObject responseObject = response.m2916b();
                    if (responseObject != null) {
                        debug = responseObject.optJSONObject("__debug__");
                    } else {
                        debug = null;
                    }
                    if (debug != null) {
                        debugMessages = debug.optJSONArray("messages");
                    } else {
                        debugMessages = null;
                    }
                    if (debugMessages != null) {
                        for (int i = 0; i < debugMessages.length(); i++) {
                            String debugMessage;
                            String debugMessageType;
                            String debugMessageLink;
                            JSONObject debugMessageObject = debugMessages.optJSONObject(i);
                            if (debugMessageObject != null) {
                                debugMessage = debugMessageObject.optString("message");
                            } else {
                                debugMessage = null;
                            }
                            if (debugMessageObject != null) {
                                debugMessageType = debugMessageObject.optString("type");
                            } else {
                                debugMessageType = null;
                            }
                            if (debugMessageObject != null) {
                                debugMessageLink = debugMessageObject.optString("link");
                            } else {
                                debugMessageLink = null;
                            }
                            if (!(debugMessage == null || debugMessageType == null)) {
                                C0757o behavior = C0757o.GRAPH_API_DEBUG_INFO;
                                if (debugMessageType.equals("warning")) {
                                    behavior = C0757o.GRAPH_API_DEBUG_WARNING;
                                }
                                if (!C0699q.m2807a(debugMessageLink)) {
                                    debugMessage = debugMessage + " Link: " + debugMessageLink;
                                }
                                C0680l.m2695a(behavior, GraphRequest.f999a, debugMessage);
                            }
                        }
                    }
                    if (callback != null) {
                        callback.mo855a(response);
                    }
                }
            };
        } else {
            this.f1011l = callback;
        }
    }

    public final void m2501a(Object tag) {
        this.f1013n = tag;
    }

    public final Object m2510h() {
        return this.f1013n;
    }

    public final C0723l m2511i() {
        return m2461a(this);
    }

    public final C0720j m2512j() {
        return m2479b(this);
    }

    public static HttpURLConnection m2463a(C0722k requests) {
        Exception e;
        m2486d(requests);
        try {
            URL url;
            if (requests.size() == 1) {
                url = new URL(requests.m2893a(0).m2514l());
            } else {
                url = new URL(C0692p.m2757b());
            }
            URLConnection uRLConnection = null;
            try {
                uRLConnection = m2464a(url);
                m2471a(requests, (HttpURLConnection) uRLConnection);
                return uRLConnection;
            } catch (IOException e2) {
                e = e2;
                C0699q.m2802a(uRLConnection);
                throw new C0709e("could not construct request body", e);
            } catch (JSONException e3) {
                e = e3;
                C0699q.m2802a(uRLConnection);
                throw new C0709e("could not construct request body", e);
            }
        } catch (MalformedURLException e4) {
            throw new C0709e("could not construct URL for request", e4);
        }
    }

    public static C0723l m2461a(GraphRequest request) {
        List<C0723l> responses = m2467a(request);
        if (responses != null && responses.size() == 1) {
            return (C0723l) responses.get(0);
        }
        throw new C0709e("invalid state: expected a single response");
    }

    public static List<C0723l> m2467a(GraphRequest... requests) {
        C0700r.m2830a((Object) requests, "requests");
        return m2466a(Arrays.asList(requests));
    }

    public static List<C0723l> m2466a(Collection<GraphRequest> requests) {
        return m2480b(new C0722k((Collection) requests));
    }

    public static List<C0723l> m2480b(C0722k requests) {
        List<C0723l> responses;
        C0700r.m2838c(requests, "requests");
        URLConnection connection = null;
        try {
            connection = m2463a(requests);
            responses = m2465a((HttpURLConnection) connection, requests);
        } catch (Throwable ex) {
            responses = C0723l.m2914a(requests.m2902d(), null, new C0709e(ex));
            m2472a(requests, (List) responses);
        } finally {
            C0699q.m2802a(connection);
        }
        return responses;
    }

    public static C0720j m2479b(GraphRequest... requests) {
        C0700r.m2830a((Object) requests, "requests");
        return m2478b(Arrays.asList(requests));
    }

    public static C0720j m2478b(Collection<GraphRequest> requests) {
        return m2484c(new C0722k((Collection) requests));
    }

    public static C0720j m2484c(C0722k requests) {
        C0700r.m2838c(requests, "requests");
        C0720j asyncTask = new C0720j(requests);
        asyncTask.executeOnExecutor(C0717g.m2878d(), new Void[0]);
        return asyncTask;
    }

    public static List<C0723l> m2465a(HttpURLConnection connection, C0722k requests) {
        List responses = C0723l.m2912a(connection, requests);
        C0699q.m2802a((URLConnection) connection);
        if (requests.size() != responses.size()) {
            throw new C0709e(String.format(Locale.US, "Received %d responses while expecting %d", new Object[]{Integer.valueOf(responses.size()), Integer.valueOf(requests.size())}));
        }
        m2472a(requests, responses);
        C0707b.m2848a().m2860d();
        return responses;
    }

    public String toString() {
        return "{Request: " + " accessToken: " + (this.f1003d == null ? "null" : this.f1003d) + ", graphPath: " + this.f1005f + ", graphObject: " + this.f1006g + ", httpMethod: " + this.f1004e + ", parameters: " + this.f1010k + "}";
    }

    static void m2472a(final C0722k requests, List<C0723l> responses) {
        int numRequests = requests.size();
        final ArrayList<Pair<C0588b, C0723l>> callbacks = new ArrayList();
        for (int i = 0; i < numRequests; i++) {
            GraphRequest request = requests.m2893a(i);
            if (request.f1011l != null) {
                callbacks.add(new Pair(request.f1011l, responses.get(i)));
            }
        }
        if (callbacks.size() > 0) {
            Runnable runnable = new Runnable() {
                public void run() {
                    Iterator it = callbacks.iterator();
                    while (it.hasNext()) {
                        Pair<C0588b, C0723l> pair = (Pair) it.next();
                        ((C0588b) pair.first).mo855a((C0723l) pair.second);
                    }
                    for (C0643a batchCallback : requests.m2903e()) {
                        batchCallback.mo859a(requests);
                    }
                }
            };
            Handler callbackHandler = requests.m2901c();
            if (callbackHandler == null) {
                runnable.run();
            } else {
                callbackHandler.post(runnable);
            }
        }
    }

    private static HttpURLConnection m2464a(URL url) throws IOException {
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestProperty("User-Agent", m2496p());
        connection.setRequestProperty("Accept-Language", Locale.getDefault().toString());
        connection.setChunkedStreamingMode(0);
        return connection;
    }

    private void m2493m() {
        if (this.f1003d != null) {
            if (!this.f1010k.containsKey("access_token")) {
                String token = this.f1003d.m2410b();
                C0680l.m2697a(token);
                this.f1010k.putString("access_token", token);
            }
        } else if (!(this.f1015p || this.f1010k.containsKey("access_token"))) {
            String appID = C0717g.m2883i();
            String clientToken = C0717g.m2884j();
            if (C0699q.m2807a(appID) || C0699q.m2807a(clientToken)) {
                Log.d(f999a, "Warning: Request without access token missing application ID or client token.");
            } else {
                this.f1010k.putString("access_token", appID + "|" + clientToken);
            }
        }
        this.f1010k.putString("sdk", "android");
        this.f1010k.putString("format", "json");
        if (C0717g.m2872a(C0757o.GRAPH_API_DEBUG_INFO)) {
            this.f1010k.putString("debug", "info");
        } else if (C0717g.m2872a(C0757o.GRAPH_API_DEBUG_WARNING)) {
            this.f1010k.putString("debug", "warning");
        }
    }

    private String m2462a(String baseUrl) {
        Builder uriBuilder = Uri.parse(baseUrl).buildUpon();
        for (String key : this.f1010k.keySet()) {
            Object value = this.f1010k.get(key);
            if (value == null) {
                value = "";
            }
            if (m2489e(value)) {
                uriBuilder.appendQueryParameter(key, m2490f(value).toString());
            } else if (this.f1004e == C0755m.GET) {
                throw new IllegalArgumentException(String.format(Locale.US, "Unsupported parameter type for GET request: %s", new Object[]{value.getClass().getSimpleName()}));
            }
        }
        return uriBuilder.toString();
    }

    final String m2513k() {
        if (this.f1012m != null) {
            throw new C0709e("Can't override URL for a batch request");
        }
        String baseUrl = String.format("%s/%s", new Object[]{C0692p.m2757b(), m2494n()});
        m2493m();
        Uri uri = Uri.parse(m2462a(baseUrl));
        return String.format("%s?%s", new Object[]{uri.getPath(), uri.getQuery()});
    }

    final String m2514l() {
        if (this.f1012m != null) {
            return this.f1012m.toString();
        }
        String graphBaseUrlBase;
        if (m2505c() == C0755m.POST && this.f1005f != null && this.f1005f.endsWith("/videos")) {
            graphBaseUrlBase = C0692p.m2758c();
        } else {
            graphBaseUrlBase = C0692p.m2757b();
        }
        String baseUrl = String.format("%s/%s", new Object[]{graphBaseUrlBase, m2494n()});
        m2493m();
        return m2462a(baseUrl);
    }

    private String m2494n() {
        if (f1001c.matcher(this.f1005f).matches()) {
            return this.f1005f;
        }
        return String.format("%s/%s", new Object[]{this.f1014o, this.f1005f});
    }

    private void m2476a(JSONArray batch, Map<String, C0595a> attachments) throws JSONException, IOException {
        JSONObject batchEntry = new JSONObject();
        if (this.f1007h != null) {
            batchEntry.put("name", this.f1007h);
            batchEntry.put("omit_response_on_success", this.f1009j);
        }
        if (this.f1008i != null) {
            batchEntry.put("depends_on", this.f1008i);
        }
        String relativeURL = m2513k();
        batchEntry.put("relative_url", relativeURL);
        batchEntry.put("method", this.f1004e);
        if (this.f1003d != null) {
            C0680l.m2697a(this.f1003d.m2410b());
        }
        ArrayList<String> attachmentNames = new ArrayList();
        for (String key : this.f1010k.keySet()) {
            Object value = this.f1010k.get(key);
            if (m2487d(value)) {
                String name = String.format(Locale.ROOT, "%s%d", new Object[]{"file", Integer.valueOf(attachments.size())});
                attachmentNames.add(name);
                attachments.put(name, new C0595a(this, value));
            }
        }
        if (!attachmentNames.isEmpty()) {
            batchEntry.put("attached_files", TextUtils.join(",", attachmentNames));
        }
        if (this.f1006g != null) {
            final ArrayList<String> keysAndValues = new ArrayList();
            m2477a(this.f1006g, relativeURL, new C0592d(this) {
                final /* synthetic */ GraphRequest f990b;

                public void mo856a(String key, String value) throws IOException {
                    keysAndValues.add(String.format(Locale.US, "%s=%s", new Object[]{key, URLEncoder.encode(value, "UTF-8")}));
                }
            });
            batchEntry.put("body", TextUtils.join("&", keysAndValues));
        }
        batch.put(batchEntry);
    }

    private static boolean m2488e(C0722k requests) {
        for (C0643a callback : requests.m2903e()) {
            if (callback instanceof C0721b) {
                return true;
            }
        }
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            if (((GraphRequest) it.next()).m2509g() instanceof C0597e) {
                return true;
            }
        }
        return false;
    }

    private static void m2474a(HttpURLConnection connection, boolean shouldUseGzip) {
        if (shouldUseGzip) {
            connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            connection.setRequestProperty("Content-Encoding", "gzip");
            return;
        }
        connection.setRequestProperty("Content-Type", m2495o());
    }

    private static boolean m2491f(C0722k requests) {
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            GraphRequest request = (GraphRequest) it.next();
            for (String key : request.f1010k.keySet()) {
                if (m2487d(request.f1010k.get(key))) {
                    return false;
                }
            }
        }
        return true;
    }

    static final boolean m2481b(GraphRequest request) {
        boolean z = false;
        String version = request.m2506d();
        if (C0699q.m2807a(version)) {
            return true;
        }
        if (version.startsWith("v")) {
            version = version.substring(1);
        }
        String[] versionParts = version.split("\\.");
        if ((versionParts.length >= 2 && Integer.parseInt(versionParts[0]) > 2) || (Integer.parseInt(versionParts[0]) >= 2 && Integer.parseInt(versionParts[1]) >= 4)) {
            z = true;
        }
        return z;
    }

    static final void m2486d(C0722k requests) {
        Iterator it = requests.iterator();
        while (it.hasNext()) {
            GraphRequest request = (GraphRequest) it.next();
            if (C0755m.GET.equals(request.m2505c()) && m2481b(request)) {
                Bundle params = request.m2507e();
                if (!params.containsKey("fields") || C0699q.m2807a(params.getString("fields"))) {
                    C0680l.m2694a(C0757o.DEVELOPER_ERRORS, 5, "Request", "starting with Graph API v2.4, GET requests for /%s should contain an explicit \"fields\" parameter.", request.m2504b());
                }
            }
        }
    }

    static final void m2471a(C0722k requests, HttpURLConnection connection) throws IOException, JSONException {
        Throwable th;
        C0680l c0680l = new C0680l(C0757o.REQUESTS, "Request");
        int numRequests = requests.size();
        boolean shouldUseGzip = m2491f(requests);
        C0755m connectionHttpMethod = numRequests == 1 ? requests.m2893a(0).f1004e : C0755m.POST;
        connection.setRequestMethod(connectionHttpMethod.name());
        m2474a(connection, shouldUseGzip);
        URL url = connection.getURL();
        c0680l.m2705c("Request:\n");
        c0680l.m2702a("Id", requests.m2900b());
        c0680l.m2702a("URL", (Object) url);
        c0680l.m2702a("Method", connection.getRequestMethod());
        c0680l.m2702a("User-Agent", connection.getRequestProperty("User-Agent"));
        c0680l.m2702a("Content-Type", connection.getRequestProperty("Content-Type"));
        connection.setConnectTimeout(requests.m2892a());
        connection.setReadTimeout(requests.m2892a());
        if (connectionHttpMethod == C0755m.POST) {
            connection.setDoOutput(true);
            OutputStream outputStream = null;
            try {
                OutputStream outputStream2 = new BufferedOutputStream(connection.getOutputStream());
                if (shouldUseGzip) {
                    try {
                        outputStream2 = new GZIPOutputStream(outputStream2);
                    } catch (Throwable th2) {
                        th = th2;
                        outputStream = outputStream2;
                        if (outputStream != null) {
                            outputStream.close();
                        }
                        throw th;
                    }
                }
                if (m2488e(requests)) {
                    C0761r countingStream = new C0761r(requests.m2901c());
                    m2470a(requests, null, numRequests, url, countingStream, shouldUseGzip);
                    outputStream = new C0763s(outputStream2, requests, countingStream.m3121b(), (long) countingStream.m3118a());
                } else {
                    outputStream = outputStream2;
                }
                m2470a(requests, c0680l, numRequests, url, outputStream, shouldUseGzip);
                if (outputStream != null) {
                    outputStream.close();
                }
                c0680l.m2701a();
                return;
            } catch (Throwable th3) {
                th = th3;
                if (outputStream != null) {
                    outputStream.close();
                }
                throw th;
            }
        }
        c0680l.m2701a();
    }

    private static void m2470a(C0722k requests, C0680l logger, int numRequests, URL url, OutputStream outputStream, boolean shouldUseGzip) throws IOException, JSONException {
        C0598f serializer = new C0598f(outputStream, logger, shouldUseGzip);
        Map attachments;
        if (numRequests == 1) {
            GraphRequest request = requests.m2893a(0);
            attachments = new HashMap();
            for (String key : request.f1010k.keySet()) {
                Object value = request.f1010k.get(key);
                if (m2487d(value)) {
                    attachments.put(key, new C0595a(request, value));
                }
            }
            if (logger != null) {
                logger.m2705c("  Parameters:\n");
            }
            m2468a(request.f1010k, serializer, request);
            if (logger != null) {
                logger.m2705c("  Attachments:\n");
            }
            m2475a(attachments, serializer);
            if (request.f1006g != null) {
                m2477a(request.f1006g, url.getPath(), (C0592d) serializer);
                return;
            }
            return;
        }
        String batchAppID = m2492g(requests);
        if (C0699q.m2807a(batchAppID)) {
            throw new C0709e("App ID was not specified at the request or Settings.");
        }
        serializer.mo856a("batch_app_id", batchAppID);
        attachments = new HashMap();
        m2469a(serializer, (Collection) requests, attachments);
        if (logger != null) {
            logger.m2705c("  Attachments:\n");
        }
        m2475a(attachments, serializer);
    }

    private static boolean m2483b(String path) {
        Matcher matcher = f1001c.matcher(path);
        if (matcher.matches()) {
            path = matcher.group(1);
        }
        if (path.startsWith("me/") || path.startsWith("/me/")) {
            return true;
        }
        return false;
    }

    private static void m2477a(JSONObject graphObject, String path, C0592d serializer) throws IOException {
        boolean isOGAction = false;
        if (m2483b(path)) {
            int colonLocation = path.indexOf(":");
            int questionMarkLocation = path.indexOf("?");
            if (colonLocation <= 3 || (questionMarkLocation != -1 && colonLocation >= questionMarkLocation)) {
                isOGAction = false;
            } else {
                isOGAction = true;
            }
        }
        Iterator<String> keyIterator = graphObject.keys();
        while (keyIterator.hasNext()) {
            boolean passByValue;
            String key = (String) keyIterator.next();
            Object value = graphObject.opt(key);
            if (isOGAction && key.equalsIgnoreCase("image")) {
                passByValue = true;
            } else {
                passByValue = false;
            }
            m2473a(key, value, serializer, passByValue);
        }
    }

    private static void m2473a(String key, Object value, C0592d serializer, boolean passByValue) throws IOException {
        Class<?> valueClass = value.getClass();
        if (JSONObject.class.isAssignableFrom(valueClass)) {
            JSONObject jsonObject = (JSONObject) value;
            if (passByValue) {
                Iterator<String> keys = jsonObject.keys();
                while (keys.hasNext()) {
                    Object[] objArr = new Object[]{key, (String) keys.next()};
                    m2473a(String.format("%s[%s]", objArr), jsonObject.opt((String) keys.next()), serializer, passByValue);
                }
            } else if (jsonObject.has("id")) {
                m2473a(key, jsonObject.optString("id"), serializer, passByValue);
            } else if (jsonObject.has("url")) {
                m2473a(key, jsonObject.optString("url"), serializer, passByValue);
            } else if (jsonObject.has("fbsdk:create_object")) {
                m2473a(key, jsonObject.toString(), serializer, passByValue);
            }
        } else if (JSONArray.class.isAssignableFrom(valueClass)) {
            JSONArray jsonArray = (JSONArray) value;
            int length = jsonArray.length();
            for (int i = 0; i < length; i++) {
                m2473a(String.format(Locale.ROOT, "%s[%d]", new Object[]{key, Integer.valueOf(i)}), jsonArray.opt(i), serializer, passByValue);
            }
        } else if (String.class.isAssignableFrom(valueClass) || Number.class.isAssignableFrom(valueClass) || Boolean.class.isAssignableFrom(valueClass)) {
            serializer.mo856a(key, value.toString());
        } else if (Date.class.isAssignableFrom(valueClass)) {
            C0592d c0592d = serializer;
            String str = key;
            c0592d.mo856a(str, new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format((Date) value));
        }
    }

    private static void m2468a(Bundle bundle, C0598f serializer, GraphRequest request) throws IOException {
        for (String key : bundle.keySet()) {
            Object value = bundle.get(key);
            if (m2489e(value)) {
                serializer.m2452a(key, value, request);
            }
        }
    }

    private static void m2475a(Map<String, C0595a> attachments, C0598f serializer) throws IOException {
        for (String key : attachments.keySet()) {
            C0595a attachment = (C0595a) attachments.get(key);
            if (m2487d(attachment.m2444b())) {
                serializer.m2452a(key, attachment.m2444b(), attachment.m2443a());
            }
        }
    }

    private static void m2469a(C0598f serializer, Collection<GraphRequest> requests, Map<String, C0595a> attachments) throws JSONException, IOException {
        JSONArray batch = new JSONArray();
        for (GraphRequest request : requests) {
            request.m2476a(batch, (Map) attachments);
        }
        serializer.m2455a("batch", batch, (Collection) requests);
    }

    private static String m2495o() {
        return String.format("multipart/form-data; boundary=%s", new Object[]{"3i2ndDfv2rTHiSisAbouNdArYfORhtTPEefj3q2f"});
    }

    private static String m2496p() {
        if (f1002q == null) {
            f1002q = String.format("%s.%s", new Object[]{"FBAndroidSDK", "4.15.0"});
            if (!C0699q.m2807a(C0677j.m2689a())) {
                f1002q = String.format(Locale.ROOT, "%s/%s", new Object[]{f1002q, C0677j.m2689a()});
            }
        }
        return f1002q;
    }

    private static String m2492g(C0722k batch) {
        if (!C0699q.m2807a(batch.m2904f())) {
            return batch.m2904f();
        }
        Iterator it = batch.iterator();
        while (it.hasNext()) {
            AccessToken accessToken = ((GraphRequest) it.next()).f1003d;
            if (accessToken != null) {
                String applicationId = accessToken.m2416h();
                if (applicationId != null) {
                    return applicationId;
                }
            }
        }
        if (C0699q.m2807a(f1000b)) {
            return C0717g.m2883i();
        }
        return f1000b;
    }

    private static boolean m2487d(Object value) {
        return (value instanceof Bitmap) || (value instanceof byte[]) || (value instanceof Uri) || (value instanceof ParcelFileDescriptor) || (value instanceof ParcelableResourceWithMimeType);
    }

    private static boolean m2489e(Object value) {
        return (value instanceof String) || (value instanceof Boolean) || (value instanceof Number) || (value instanceof Date);
    }

    private static String m2490f(Object value) {
        if (value instanceof String) {
            return (String) value;
        }
        if ((value instanceof Boolean) || (value instanceof Number)) {
            return value.toString();
        }
        if (value instanceof Date) {
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", Locale.US).format(value);
        }
        throw new IllegalArgumentException("Unsupported parameter type.");
    }
}
