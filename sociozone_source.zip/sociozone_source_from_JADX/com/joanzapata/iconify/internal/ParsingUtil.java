package com.joanzapata.iconify.internal;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.support.v4.view.ai;
import android.text.SpannableStringBuilder;
import android.util.TypedValue;
import android.widget.TextView;
import com.joanzapata.iconify.Icon;
import com.joanzapata.iconify.internal.HasOnViewAttachListener.OnViewAttachListener;
import java.util.List;

public final class ParsingUtil {
    private static final String ANDROID_PACKAGE_NAME = "android";

    private ParsingUtil() {
    }

    public static CharSequence parse(Context context, List<IconFontDescriptorWrapper> iconFontDescriptors, CharSequence text, final TextView target) {
        context = context.getApplicationContext();
        if (text == null) {
            return text;
        }
        SpannableStringBuilder spannableBuilder = new SpannableStringBuilder(text);
        recursivePrepareSpannableIndexes(context, text.toString(), spannableBuilder, iconFontDescriptors, 0);
        if (hasAnimatedSpans(spannableBuilder)) {
            if (target == null) {
                throw new IllegalArgumentException("You can't use \"spin\" without providing the target TextView.");
            } else if (target instanceof HasOnViewAttachListener) {
                ((HasOnViewAttachListener) target).setOnViewAttachListener(new OnViewAttachListener() {
                    boolean isAttached = false;

                    class C11091 implements Runnable {
                        C11091() {
                        }

                        public void run() {
                            if (C11101.this.isAttached) {
                                target.invalidate();
                                ai.m1500a(target, (Runnable) this);
                            }
                        }
                    }

                    public void onAttach() {
                        this.isAttached = true;
                        ai.m1500a(target, new C11091());
                    }

                    public void onDetach() {
                        this.isAttached = false;
                    }
                });
            } else {
                throw new IllegalArgumentException(target.getClass().getSimpleName() + " does not implement " + "HasOnViewAttachListener. Please use IconTextView, IconButton or IconToggleButton.");
            }
        } else if (target instanceof HasOnViewAttachListener) {
            ((HasOnViewAttachListener) target).setOnViewAttachListener(null);
        }
        return spannableBuilder;
    }

    private static boolean hasAnimatedSpans(SpannableStringBuilder spannableBuilder) {
        for (CustomTypefaceSpan span : (CustomTypefaceSpan[]) spannableBuilder.getSpans(0, spannableBuilder.length(), CustomTypefaceSpan.class)) {
            if (span.isAnimated()) {
                return true;
            }
        }
        return false;
    }

    private static void recursivePrepareSpannableIndexes(Context context, String fullText, SpannableStringBuilder text, List<IconFontDescriptorWrapper> iconFontDescriptors, int start) {
        String stringText = text.toString();
        int startIndex = stringText.indexOf("{", start);
        if (startIndex != -1) {
            int endIndex = stringText.indexOf("}", startIndex) + 1;
            if (endIndex != -1) {
                int i;
                String[] strokes = stringText.substring(startIndex + 1, endIndex - 1).split(" ");
                String key = strokes[0];
                IconFontDescriptorWrapper iconFontDescriptor = null;
                Icon icon = null;
                for (i = 0; i < iconFontDescriptors.size(); i++) {
                    iconFontDescriptor = (IconFontDescriptorWrapper) iconFontDescriptors.get(i);
                    icon = iconFontDescriptor.getIcon(key);
                    if (icon != null) {
                        break;
                    }
                }
                if (icon == null) {
                    recursivePrepareSpannableIndexes(context, fullText, text, iconFontDescriptors, endIndex);
                    return;
                }
                float iconSizePx = -1.0f;
                int iconColor = ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
                float iconSizeRatio = -1.0f;
                boolean spin = false;
                boolean baselineAligned = false;
                for (i = 1; i < strokes.length; i++) {
                    String stroke = strokes[i];
                    if (stroke.equalsIgnoreCase("spin")) {
                        spin = true;
                    } else {
                        if (stroke.equalsIgnoreCase("baseline")) {
                            baselineAligned = true;
                        } else {
                            Context context2;
                            if (stroke.matches("([0-9]*(\\.[0-9]*)?)dp")) {
                                context2 = context;
                                iconSizePx = dpToPx(context2, Float.valueOf(stroke.substring(0, stroke.length() - 2)).floatValue());
                            } else {
                                if (stroke.matches("([0-9]*(\\.[0-9]*)?)sp")) {
                                    context2 = context;
                                    iconSizePx = spToPx(context2, Float.valueOf(stroke.substring(0, stroke.length() - 2)).floatValue());
                                } else {
                                    if (stroke.matches("([0-9]*)px")) {
                                        iconSizePx = (float) Integer.valueOf(stroke.substring(0, stroke.length() - 2)).intValue();
                                    } else {
                                        if (stroke.matches("@dimen/(.*)")) {
                                            iconSizePx = getPxFromDimen(context, context.getPackageName(), stroke.substring(7));
                                            if (iconSizePx < 0.0f) {
                                                throw new IllegalArgumentException("Unknown resource " + stroke + " in \"" + fullText + "\"");
                                            }
                                        } else {
                                            if (stroke.matches("@android:dimen/(.*)")) {
                                                iconSizePx = getPxFromDimen(context, ANDROID_PACKAGE_NAME, stroke.substring(15));
                                                if (iconSizePx < 0.0f) {
                                                    throw new IllegalArgumentException("Unknown resource " + stroke + " in \"" + fullText + "\"");
                                                }
                                            } else {
                                                if (stroke.matches("([0-9]*(\\.[0-9]*)?)%")) {
                                                    iconSizeRatio = Float.valueOf(stroke.substring(0, stroke.length() - 1)).floatValue() / 100.0f;
                                                } else {
                                                    if (stroke.matches("#([0-9A-Fa-f]{6}|[0-9A-Fa-f]{8})")) {
                                                        iconColor = Color.parseColor(stroke);
                                                    } else {
                                                        if (stroke.matches("@color/(.*)")) {
                                                            iconColor = getColorFromResource(context, context.getPackageName(), stroke.substring(7));
                                                            if (iconColor == ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED) {
                                                                throw new IllegalArgumentException("Unknown resource " + stroke + " in \"" + fullText + "\"");
                                                            }
                                                        } else {
                                                            if (stroke.matches("@android:color/(.*)")) {
                                                                iconColor = getColorFromResource(context, ANDROID_PACKAGE_NAME, stroke.substring(15));
                                                                if (iconColor == ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED) {
                                                                    throw new IllegalArgumentException("Unknown resource " + stroke + " in \"" + fullText + "\"");
                                                                }
                                                            } else {
                                                                throw new IllegalArgumentException("Unknown expression " + stroke + " in \"" + fullText + "\"");
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                text = text.replace(startIndex, endIndex, "" + icon.character());
                text.setSpan(new CustomTypefaceSpan(icon, iconFontDescriptor.getTypeface(context), iconSizePx, iconSizeRatio, iconColor, spin, baselineAligned), startIndex, startIndex + 1, 17);
                recursivePrepareSpannableIndexes(context, fullText, text, iconFontDescriptors, startIndex);
            }
        }
    }

    public static float getPxFromDimen(Context context, String packageName, String resName) {
        Resources resources = context.getResources();
        int resId = resources.getIdentifier(resName, "dimen", packageName);
        if (resId <= 0) {
            return -1.0f;
        }
        return resources.getDimension(resId);
    }

    public static int getColorFromResource(Context context, String packageName, String resName) {
        Resources resources = context.getResources();
        int resId = resources.getIdentifier(resName, "color", packageName);
        if (resId <= 0) {
            return ActivityChooserViewAdapter.MAX_ACTIVITY_COUNT_UNLIMITED;
        }
        return resources.getColor(resId);
    }

    public static float dpToPx(Context context, float dp) {
        return TypedValue.applyDimension(1, dp, context.getResources().getDisplayMetrics());
    }

    public static float spToPx(Context context, float sp) {
        return TypedValue.applyDimension(2, sp, context.getResources().getDisplayMetrics());
    }
}
