package com.joanzapata.iconify;

public interface IconFontDescriptor {
    Icon[] characters();

    String ttfFileName();
}
