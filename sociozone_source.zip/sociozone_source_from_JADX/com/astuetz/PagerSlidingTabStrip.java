package com.astuetz;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Paint.Style;
import android.graphics.Typeface;
import android.os.Build.VERSION;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.Parcelable.Creator;
import android.support.v4.p011e.C0243h;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.C0259f;
import android.support.v4.view.ai;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.BaseSavedState;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver.OnGlobalLayoutListener;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.LinearLayout.LayoutParams;
import android.widget.TextView;
import io.gonative.android.C1296q.C1295a;
import java.util.Locale;
import socio.zone.fairchildrepublic.R;

public class PagerSlidingTabStrip extends HorizontalScrollView {
    private static final int[] f897c = new int[]{16842901, 16842904, 16842966, 16842968, 16842806};
    private int f898A;
    private int f899B;
    private boolean f900C;
    private boolean f901D;
    private boolean f902E;
    private Typeface f903F;
    private int f904G;
    private int f905H;
    private int f906I;
    private int f907J;
    private int f908K;
    private Locale f909L;
    private OnGlobalLayoutListener f910M;
    public C0259f f911a;
    private C0578b f912b;
    private final C0580d f913d;
    private LayoutParams f914e;
    private LayoutParams f915f;
    private final C0579c f916g;
    private LinearLayout f917h;
    private ViewPager f918i;
    private int f919j;
    private int f920k;
    private float f921l;
    private Paint f922m;
    private Paint f923n;
    private int f924o;
    private int f925p;
    private int f926q;
    private int f927r;
    private int f928s;
    private int f929t;
    private int f930u;
    private int f931v;
    private int f932w;
    private ColorStateList f933x;
    private float f934y;
    private float f935z;

    class C05731 implements OnGlobalLayoutListener {
        final /* synthetic */ PagerSlidingTabStrip f889a;

        C05731(PagerSlidingTabStrip this$0) {
            this.f889a = this$0;
        }

        @SuppressLint({"NewApi"})
        public void onGlobalLayout() {
            if (VERSION.SDK_INT < 16) {
                this.f889a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            } else {
                this.f889a.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
            this.f889a.f920k = this.f889a.f918i.getCurrentItem();
            this.f889a.f921l = 0.0f;
            this.f889a.m2377a(this.f889a.f920k, 0);
            this.f889a.m2376a(this.f889a.f920k);
        }
    }

    class C05753 implements OnGlobalLayoutListener {
        final /* synthetic */ PagerSlidingTabStrip f892a;

        C05753(PagerSlidingTabStrip this$0) {
            this.f892a = this$0;
        }

        public void onGlobalLayout() {
            View view = this.f892a.f917h.getChildAt(0);
            if (VERSION.SDK_INT < 16) {
                this.f892a.getViewTreeObserver().removeGlobalOnLayoutListener(this);
            } else {
                this.f892a.getViewTreeObserver().removeOnGlobalLayoutListener(this);
            }
            if (this.f892a.f902E) {
                this.f892a.f898A = this.f892a.f899B = (this.f892a.getWidth() / 2) - (view.getWidth() / 2);
            }
            this.f892a.setPadding(this.f892a.f898A, this.f892a.getPaddingTop(), this.f892a.f899B, this.f892a.getPaddingBottom());
            if (this.f892a.f906I == 0) {
                this.f892a.f906I = (this.f892a.getWidth() / 2) - this.f892a.f898A;
            }
        }
    }

    static class SavedState extends BaseSavedState {
        public static final Creator<SavedState> CREATOR = new C05761();
        int f893a;

        static class C05761 implements Creator<SavedState> {
            C05761() {
            }

            public /* synthetic */ Object createFromParcel(Parcel parcel) {
                return m2365a(parcel);
            }

            public /* synthetic */ Object[] newArray(int i) {
                return m2366a(i);
            }

            public SavedState m2365a(Parcel in) {
                return new SavedState(in);
            }

            public SavedState[] m2366a(int size) {
                return new SavedState[size];
            }
        }

        public SavedState(Parcelable superState) {
            super(superState);
        }

        private SavedState(Parcel in) {
            super(in);
            this.f893a = in.readInt();
        }

        public void writeToParcel(Parcel dest, int flags) {
            super.writeToParcel(dest, flags);
            dest.writeInt(this.f893a);
        }
    }

    public interface C0577a {
        View m2367a(ViewGroup viewGroup, int i);
    }

    public interface C0578b {
        void a_(int i);
    }

    private class C0579c implements C0259f {
        final /* synthetic */ PagerSlidingTabStrip f894a;

        private C0579c(PagerSlidingTabStrip pagerSlidingTabStrip) {
            this.f894a = pagerSlidingTabStrip;
        }

        public void mo853a(int position, float positionOffset, int positionOffsetPixels) {
            this.f894a.f920k = position;
            this.f894a.f921l = positionOffset;
            this.f894a.m2377a(position, this.f894a.f919j > 0 ? (int) (((float) this.f894a.f917h.getChildAt(position).getWidth()) * positionOffset) : 0);
            this.f894a.invalidate();
            if (this.f894a.f911a != null) {
                this.f894a.f911a.mo853a(position, positionOffset, positionOffsetPixels);
            }
        }

        public void mo854b(int state) {
            if (state == 0) {
                this.f894a.m2377a(this.f894a.f918i.getCurrentItem(), 0);
            }
            this.f894a.m2385b(this.f894a.f917h.getChildAt(this.f894a.f918i.getCurrentItem()));
            if (this.f894a.f918i.getCurrentItem() - 1 >= 0) {
                this.f894a.m2379a(this.f894a.f917h.getChildAt(this.f894a.f918i.getCurrentItem() - 1));
            }
            if (this.f894a.f918i.getCurrentItem() + 1 <= this.f894a.f918i.getAdapter().mo1163a() - 1) {
                this.f894a.m2379a(this.f894a.f917h.getChildAt(this.f894a.f918i.getCurrentItem() + 1));
            }
            if (this.f894a.f911a != null) {
                this.f894a.f911a.mo854b(state);
            }
        }

        public void mo852a(int position) {
            this.f894a.m2376a(position);
            if (this.f894a.f911a != null) {
                this.f894a.f911a.mo852a(position);
            }
        }
    }

    private class C0580d extends DataSetObserver {
        final /* synthetic */ PagerSlidingTabStrip f895a;
        private boolean f896b;

        private C0580d(PagerSlidingTabStrip pagerSlidingTabStrip) {
            this.f895a = pagerSlidingTabStrip;
            this.f896b = false;
        }

        public void onChanged() {
            this.f895a.m2398a();
        }

        public void m2371a(boolean attached) {
            this.f896b = attached;
        }

        public boolean m2372a() {
            return this.f896b;
        }
    }

    public PagerSlidingTabStrip(Context context) {
        this(context, null);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public PagerSlidingTabStrip(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
        this.f913d = new C0580d();
        this.f916g = new C0579c();
        this.f920k = 0;
        this.f921l = 0.0f;
        this.f925p = 2;
        this.f926q = 0;
        this.f928s = 0;
        this.f929t = 0;
        this.f931v = 12;
        this.f932w = 14;
        this.f933x = null;
        this.f934y = 0.5f;
        this.f935z = 1.0f;
        this.f898A = 0;
        this.f899B = 0;
        this.f900C = false;
        this.f901D = true;
        this.f902E = false;
        this.f903F = null;
        this.f904G = 1;
        this.f905H = 1;
        this.f907J = 0;
        this.f908K = R.drawable.background_tab;
        this.f910M = new C05753(this);
        setFillViewport(true);
        setWillNotDraw(false);
        this.f917h = new LinearLayout(context);
        this.f917h.setOrientation(0);
        this.f917h.setLayoutParams(new FrameLayout.LayoutParams(-1, -1));
        addView(this.f917h);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        this.f906I = (int) TypedValue.applyDimension(1, (float) this.f906I, dm);
        this.f925p = (int) TypedValue.applyDimension(1, (float) this.f925p, dm);
        this.f926q = (int) TypedValue.applyDimension(1, (float) this.f926q, dm);
        this.f929t = (int) TypedValue.applyDimension(1, (float) this.f929t, dm);
        this.f931v = (int) TypedValue.applyDimension(1, (float) this.f931v, dm);
        this.f928s = (int) TypedValue.applyDimension(1, (float) this.f928s, dm);
        this.f932w = (int) TypedValue.applyDimension(2, (float) this.f932w, dm);
        TypedArray a = context.obtainStyledAttributes(attrs, f897c);
        this.f932w = a.getDimensionPixelSize(0, this.f932w);
        ColorStateList colorStateList = a.getColorStateList(1);
        int textPrimaryColor = a.getColor(4, 17170443);
        TypedArray ta = context.obtainStyledAttributes(attrs, C1295a.PagerSlidingTabStrip);
        textPrimaryColor = ta.getColor(0, textPrimaryColor);
        ta.recycle();
        if (colorStateList != null) {
            this.f933x = colorStateList;
        } else {
            this.f933x = m2383b(textPrimaryColor);
        }
        this.f927r = textPrimaryColor;
        this.f930u = textPrimaryColor;
        this.f924o = textPrimaryColor;
        this.f898A = a.getDimensionPixelSize(2, this.f898A);
        this.f899B = a.getDimensionPixelSize(3, this.f899B);
        a.recycle();
        if (this.f899B < this.f898A) {
            this.f899B = this.f898A;
        }
        if (this.f898A < this.f899B) {
            this.f898A = this.f899B;
        }
        a = context.obtainStyledAttributes(attrs, C1295a.PagerSlidingTabStrip);
        this.f924o = a.getColor(1, this.f924o);
        this.f927r = a.getColor(2, this.f927r);
        this.f930u = a.getColor(3, this.f930u);
        this.f928s = a.getDimensionPixelSize(4, this.f928s);
        this.f925p = a.getDimensionPixelSize(5, this.f925p);
        this.f926q = a.getDimensionPixelSize(6, this.f926q);
        this.f929t = a.getDimensionPixelSize(7, this.f929t);
        this.f931v = a.getDimensionPixelSize(8, this.f931v);
        this.f908K = a.getResourceId(10, this.f908K);
        this.f900C = a.getBoolean(11, this.f900C);
        this.f906I = a.getDimensionPixelSize(9, this.f906I);
        this.f901D = a.getBoolean(12, this.f901D);
        this.f902E = a.getBoolean(13, this.f902E);
        this.f904G = a.getInt(14, 1);
        this.f905H = a.getInt(15, 1);
        this.f934y = a.getFloat(16, 0.5f);
        this.f935z = a.getFloat(17, 1.0f);
        a.recycle();
        this.f922m = new Paint();
        this.f922m.setAntiAlias(true);
        this.f922m.setStyle(Style.FILL);
        this.f923n = new Paint();
        this.f923n.setAntiAlias(true);
        this.f923n.setStrokeWidth((float) this.f928s);
        this.f914e = new LayoutParams(-2, -1);
        this.f915f = new LayoutParams(0, -1, 1.0f);
        if (this.f909L == null) {
            this.f909L = getResources().getConfiguration().locale;
        }
    }

    public void setViewPager(ViewPager pager) {
        this.f918i = pager;
        if (pager.getAdapter() == null) {
            throw new IllegalStateException("ViewPager does not have adapter instance.");
        }
        pager.setOnPageChangeListener(this.f916g);
        pager.getAdapter().m1307a(this.f913d);
        this.f913d.m2371a(true);
        m2398a();
    }

    public void m2398a() {
        this.f917h.removeAllViews();
        this.f919j = this.f918i.getAdapter().mo1163a();
        for (int i = 0; i < this.f919j; i++) {
            View tabView;
            if (this.f918i.getAdapter() instanceof C0577a) {
                tabView = ((C0577a) this.f918i.getAdapter()).m2367a(this, i);
            } else {
                tabView = LayoutInflater.from(getContext()).inflate(R.layout.tab, this, false);
            }
            m2378a(i, this.f918i.getAdapter().mo1164a(i), tabView);
        }
        m2384b();
        getViewTreeObserver().addOnGlobalLayoutListener(new C05731(this));
    }

    private void m2378a(final int position, CharSequence title, View tabView) {
        View textView = (TextView) tabView.findViewById(R.id.tab_title);
        if (textView != null) {
            if (title != null) {
                textView.setText(title);
            }
            ai.m1507b(textView, this.f918i.getCurrentItem() == position ? this.f935z : this.f934y);
        }
        tabView.setFocusable(true);
        tabView.setOnClickListener(new OnClickListener(this) {
            final /* synthetic */ PagerSlidingTabStrip f891b;

            public void onClick(View v) {
                if (this.f891b.f912b != null) {
                    this.f891b.f912b.a_(position);
                }
                if (this.f891b.f918i.getCurrentItem() != position) {
                    this.f891b.m2379a(this.f891b.f917h.getChildAt(this.f891b.f918i.getCurrentItem()));
                    this.f891b.f918i.setCurrentItem(position);
                }
            }
        });
        tabView.setPadding(this.f931v, tabView.getPaddingTop(), this.f931v, tabView.getPaddingBottom());
        this.f917h.addView(tabView, position, this.f900C ? this.f915f : this.f914e);
    }

    private void m2384b() {
        int i = 0;
        while (i < this.f919j) {
            View v = this.f917h.getChildAt(i);
            v.setBackgroundResource(this.f908K);
            TextView tab_title = (TextView) v.findViewById(R.id.tab_title);
            if (tab_title != null) {
                tab_title.setTextSize(0, (float) this.f932w);
                tab_title.setTypeface(this.f903F, this.f918i.getCurrentItem() == i ? this.f905H : this.f904G);
                if (this.f933x != null) {
                    tab_title.setTextColor(this.f933x);
                }
                if (this.f901D) {
                    if (VERSION.SDK_INT >= 14) {
                        tab_title.setAllCaps(true);
                    } else {
                        tab_title.setText(tab_title.getText().toString().toUpperCase(this.f909L));
                    }
                }
            }
            i++;
        }
    }

    private void m2377a(int position, int offset) {
        if (this.f919j != 0) {
            int newScrollX = this.f917h.getChildAt(position).getLeft() + offset;
            if (position > 0 || offset > 0) {
                newScrollX -= this.f906I;
                C0243h<Float, Float> lines = getIndicatorCoordinates();
                newScrollX = (int) (((((Float) lines.f459b).floatValue() - ((Float) lines.f458a).floatValue()) / 2.0f) + ((float) newScrollX));
            }
            if (newScrollX != this.f907J) {
                this.f907J = newScrollX;
                scrollTo(newScrollX, 0);
            }
        }
    }

    private C0243h<Float, Float> getIndicatorCoordinates() {
        View currentTab = this.f917h.getChildAt(this.f920k);
        float lineLeft = (float) currentTab.getLeft();
        float lineRight = (float) currentTab.getRight();
        if (this.f921l > 0.0f && this.f920k < this.f919j - 1) {
            View nextTab = this.f917h.getChildAt(this.f920k + 1);
            lineLeft = (this.f921l * ((float) nextTab.getLeft())) + ((1.0f - this.f921l) * lineLeft);
            lineRight = (this.f921l * ((float) nextTab.getRight())) + ((1.0f - this.f921l) * lineRight);
        }
        return new C0243h(Float.valueOf(lineLeft), Float.valueOf(lineRight));
    }

    protected void onLayout(boolean changed, int l, int t, int r, int b) {
        this.f917h.setMinimumWidth(getWidth());
        setClipToPadding(false);
        if (this.f917h.getChildCount() > 0) {
            this.f917h.getChildAt(0).getViewTreeObserver().addOnGlobalLayoutListener(this.f910M);
        }
        super.onLayout(changed, l, t, r, b);
    }

    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!isInEditMode() && this.f919j != 0) {
            int height = getHeight();
            this.f922m.setColor(this.f924o);
            C0243h<Float, Float> lines = getIndicatorCoordinates();
            Canvas canvas2 = canvas;
            canvas2.drawRect(((float) this.f898A) + ((Float) lines.f458a).floatValue(), (float) (height - this.f925p), ((float) this.f899B) + ((Float) lines.f459b).floatValue(), (float) height, this.f922m);
            this.f922m.setColor(this.f927r);
            canvas.drawRect((float) this.f898A, (float) (height - this.f926q), (float) (this.f917h.getWidth() + this.f899B), (float) height, this.f922m);
            if (this.f928s != 0) {
                this.f923n.setStrokeWidth((float) this.f928s);
                this.f923n.setColor(this.f930u);
                for (int i = 0; i < this.f919j - 1; i++) {
                    View tab = this.f917h.getChildAt(i);
                    canvas.drawLine((float) tab.getRight(), (float) this.f929t, (float) tab.getRight(), (float) (height - this.f929t), this.f923n);
                }
            }
        }
    }

    public void setOnPageChangeListener(C0259f listener) {
        this.f911a = listener;
    }

    private void m2376a(int position) {
        int i = 0;
        while (i < this.f919j) {
            View tv = this.f917h.getChildAt(i);
            tv.setSelected(i == position);
            if (i == position) {
                m2385b(tv);
            } else {
                m2379a(tv);
            }
            i++;
        }
    }

    private void m2379a(View tab) {
        View title = (TextView) tab.findViewById(R.id.tab_title);
        if (title != null) {
            title.setTypeface(this.f903F, this.f904G);
            ai.m1507b(title, this.f934y);
        }
    }

    private void m2385b(View tab) {
        View title = (TextView) tab.findViewById(R.id.tab_title);
        if (title != null) {
            title.setTypeface(this.f903F, this.f905H);
            ai.m1507b(title, this.f935z);
        }
    }

    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (this.f918i != null && !this.f913d.m2372a()) {
            this.f918i.getAdapter().m1307a(this.f913d);
            this.f913d.m2371a(true);
        }
    }

    protected void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        if (this.f918i != null && this.f913d.m2372a()) {
            this.f918i.getAdapter().m1316b(this.f913d);
            this.f913d.m2371a(false);
        }
    }

    public void onRestoreInstanceState(Parcelable state) {
        SavedState savedState = (SavedState) state;
        super.onRestoreInstanceState(savedState.getSuperState());
        this.f920k = savedState.f893a;
        if (this.f920k != 0 && this.f917h.getChildCount() > 0) {
            m2379a(this.f917h.getChildAt(0));
            m2385b(this.f917h.getChildAt(this.f920k));
        }
        requestLayout();
    }

    public Parcelable onSaveInstanceState() {
        SavedState savedState = new SavedState(super.onSaveInstanceState());
        savedState.f893a = this.f920k;
        return savedState;
    }

    public int getIndicatorColor() {
        return this.f924o;
    }

    public int getIndicatorHeight() {
        return this.f925p;
    }

    public int getUnderlineColor() {
        return this.f927r;
    }

    public int getDividerColor() {
        return this.f930u;
    }

    public int getDividerWidth() {
        return this.f928s;
    }

    public int getUnderlineHeight() {
        return this.f926q;
    }

    public int getDividerPadding() {
        return this.f929t;
    }

    public int getScrollOffset() {
        return this.f906I;
    }

    public boolean getShouldExpand() {
        return this.f900C;
    }

    public int getTextSize() {
        return this.f932w;
    }

    public ColorStateList getTextColor() {
        return this.f933x;
    }

    public int getTabBackground() {
        return this.f908K;
    }

    public int getTabPaddingLeftRight() {
        return this.f931v;
    }

    public void setIndicatorColor(int indicatorColor) {
        this.f924o = indicatorColor;
        invalidate();
    }

    public void setIndicatorColorResource(int resId) {
        this.f924o = getResources().getColor(resId);
        invalidate();
    }

    public void setIndicatorHeight(int indicatorLineHeightPx) {
        this.f925p = indicatorLineHeightPx;
        invalidate();
    }

    public void setUnderlineColor(int underlineColor) {
        this.f927r = underlineColor;
        invalidate();
    }

    public void setUnderlineColorResource(int resId) {
        this.f927r = getResources().getColor(resId);
        invalidate();
    }

    public void setDividerColor(int dividerColor) {
        this.f930u = dividerColor;
        invalidate();
    }

    public void setDividerColorResource(int resId) {
        this.f930u = getResources().getColor(resId);
        invalidate();
    }

    public void setDividerWidth(int dividerWidthPx) {
        this.f928s = dividerWidthPx;
        invalidate();
    }

    public void setUnderlineHeight(int underlineHeightPx) {
        this.f926q = underlineHeightPx;
        invalidate();
    }

    public void setDividerPadding(int dividerPaddingPx) {
        this.f929t = dividerPaddingPx;
        invalidate();
    }

    public void setScrollOffset(int scrollOffsetPx) {
        this.f906I = scrollOffsetPx;
        invalidate();
    }

    public void setShouldExpand(boolean shouldExpand) {
        this.f900C = shouldExpand;
        if (this.f918i != null) {
            requestLayout();
        }
    }

    public void setAllCaps(boolean textAllCaps) {
        this.f901D = textAllCaps;
    }

    public void setTextSize(int textSizePx) {
        this.f932w = textSizePx;
        m2384b();
    }

    public void setTextColor(int textColor) {
        setTextColor(m2383b(textColor));
    }

    private ColorStateList m2383b(int textColor) {
        return new ColorStateList(new int[][]{new int[0]}, new int[]{textColor});
    }

    public void setTextColor(ColorStateList colorStateList) {
        this.f933x = colorStateList;
        m2384b();
    }

    public void setTextColorResource(int resId) {
        setTextColor(getResources().getColor(resId));
    }

    public void setTextColorStateListResource(int resId) {
        setTextColor(getResources().getColorStateList(resId));
    }

    public void setTabBackground(int resId) {
        this.f908K = resId;
    }

    public void setTabPaddingLeftRight(int paddingPx) {
        this.f931v = paddingPx;
        m2384b();
    }

    public void setTabClickListener(C0578b tabClickListener) {
        this.f912b = tabClickListener;
    }

    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        this.f917h.measure(widthMeasureSpec, heightMeasureSpec);
    }
}
